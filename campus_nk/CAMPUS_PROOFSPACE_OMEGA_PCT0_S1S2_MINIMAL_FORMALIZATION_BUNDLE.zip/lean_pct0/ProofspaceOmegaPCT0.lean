/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Root Module: ProofspaceOmegaPCT0
-/

import ProofspaceOmegaPCT0.GenG
import ProofspaceOmegaPCT0.GenH
import ProofspaceOmegaPCT0.TransportCore
import ProofspaceOmegaPCT0.AuthorityAndAdmission
import ProofspaceOmegaPCT0.ControlsAndCounterexamples
import ProofspaceOmegaPCT0.PCT0AxiomAudit

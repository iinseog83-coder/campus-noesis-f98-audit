/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Module: ProofspaceOmegaPCT0.GenH

  Independent Generation-h 3-Compartment Conservation-Dissipation Semantics.
  Architectural Invariant (PCT0-Q1 / F-PCT0-11):
    - ZERO imports from GenG, TransportCore, AuthorityAndAdmission, or any shared user base.
    - Depends exclusively on Lean core prelude types (`Int`, `Prop`).
-/

namespace ProofspaceOmegaPCT0.GenH

/-- Generation-h 3-compartment model parameters `(alphaH, betaH, delta2a, delta2b, xiExt, capH) ∈ ℤ⁶`.
    Here `betaH` is the internal transfer flux `2a → 2b` inside the split compartment `{2a, 2b}`. -/
structure ModelH where
  alphaH  : Int
  betaH   : Int
  delta2a : Int
  delta2b : Int
  xiExt   : Int
  capH    : Int
  deriving DecidableEq, Repr

/-- Generation-h 3-compartment state/context `(v1, v2a, v2b) ∈ ℤ³`. -/
structure CtxH where
  v1  : Int
  v2a : Int
  v2b : Int
  deriving DecidableEq, Repr

/-- Non-negative 3-compartment state `v1 ≥ 0 ∧ v2a ≥ 0 ∧ v2b ≥ 0`. -/
def NonnegCtxH (x : CtxH) : Prop :=
  0 ≤ x.v1 ∧ 0 ≤ x.v2a ∧ 0 ≤ x.v2b

/-- Total Generation-h quantity `S_h(v1, v2a, v2b) = v1 + v2a + v2b`. -/
def massH (x : CtxH) : Int :=
  x.v1 + x.v2a + x.v2b

/-- Single-step 3-compartment update `F_{M_h}(v1, v2a, v2b)`. -/
def stepH (M : ModelH) (x : CtxH) : CtxH :=
  { v1  := x.v1 - M.alphaH
  , v2a := x.v2a + M.alphaH - M.betaH - M.delta2a
  , v2b := x.v2b + M.betaH - M.delta2b + M.xiExt }

/-- Generation-h admissible theory `Σ_h`: non-negative fluxes/dissipations, `xiExt ≤ 0`, `capH ≥ 12`. -/
def AdmissibleH (M : ModelH) : Prop :=
  0 ≤ M.alphaH ∧
  0 ≤ M.betaH ∧
  0 ≤ M.delta2a ∧
  0 ≤ M.delta2b ∧
  M.xiExt ≤ 0 ∧
  12 ≤ M.capH

/-- Dynamical comparison model space `M_h^{comp}` (`04B-1`): permits bounded external inflow `xiExt ≤ 2`. -/
def CompBoundedInflowModelH (M : ModelH) : Prop :=
  0 ≤ M.alphaH ∧
  0 ≤ M.betaH ∧
  0 ≤ M.delta2a ∧
  0 ≤ M.delta2b ∧
  M.xiExt ≤ 2 ∧
  12 ≤ M.capH

/-- Step feasibility (one-step non-negativity of all 3 compartments and capacity bound). -/
def StepFeasibleH (M : ModelH) (x : CtxH) : Prop :=
  NonnegCtxH x ∧
  M.alphaH ≤ x.v1 ∧
  M.betaH + M.delta2a ≤ x.v2a + M.alphaH ∧
  M.delta2b ≤ x.v2b + M.betaH + M.xiExt ∧
  massH x ≤ M.capH

/-- Generation-h realizable model-context incidence relation `E_h`. -/
def RealizableH (M : ModelH) (x : CtxH) : Prop :=
  AdmissibleH M ∧ StepFeasibleH M x

/-- Non-equivalence comparison context domain `B_h^{comp} = B_h^{≤12}` (`F-PCT0-12`, `04B-2`). -/
def BhCompLe12 (x : CtxH) : Prop :=
  NonnegCtxH x ∧ massH x ≤ 12

/-- `F-PCT0-16` Case A (Model Inconsistency): imposing `capH = 8` on `AdmissibleH` (`12 ≤ capH`) makes the model set itself empty. -/
def ContradictorySpecH (M : ModelH) : Prop :=
  AdmissibleH M ∧ M.capH = 8

/-- `F-PCT0-16` Case B (Consistent Low-Capacity Model Spec): allows `capH = 8` consistently (`M_low ≠ ∅`),
    used to isolate pure joint-incidence emptiness from model inconsistency. -/
def LowCapConsistentSpecH (M : ModelH) : Prop :=
  0 ≤ M.alphaH ∧
  0 ≤ M.betaH ∧
  0 ≤ M.delta2a ∧
  0 ≤ M.delta2b ∧
  M.xiExt ≤ 0 ∧
  M.capH = 8

/-- Generation-h proposition syntax. -/
inductive ClaimH where
  | dissipStepSlack      : Int → ClaimH
  | massAtMost           : Int → ClaimH
  | sub2bStepNonIncrease : ClaimH
  deriving DecidableEq, Repr

/-- Independent Generation-h satisfaction relation `M, x ⊨_h d`. -/
def SatisfiesH (M : ModelH) (x : CtxH) : ClaimH → Prop
  | .dissipStepSlack s    => massH (stepH M x) ≤ massH x + s
  | .massAtMost b         => massH x ≤ b
  | .sub2bStepNonIncrease => (stepH M x).v2b ≤ x.v2b

/-- Realizable scoped target validity `Σ_h ⊨^{real}_{B_h} d`. -/
def ValidOnH (Bh : CtxH → Prop) (d : ClaimH) : Prop :=
  ∀ M x, RealizableH M x → Bh x → SatisfiesH M x d

theorem stepH_mass_identity (M : ModelH) (x : CtxH) :
    massH (stepH M x) = massH x - M.delta2a - M.delta2b + M.xiExt := by
  dsimp [massH, stepH]
  omega

theorem stepH_preserves_nonneg {M : ModelH} {x : CtxH} (hFeas : StepFeasibleH M x) :
    NonnegCtxH (stepH M x) := by
  rcases hFeas with ⟨⟨hv1, hv2a, hv2b⟩, h1, h2, h3, _⟩
  dsimp [NonnegCtxH, stepH]
  omega

theorem f16_model_inconsistency_empty (M : ModelH) :
    ¬ ContradictorySpecH M := by
  intro hC
  rcases hC with ⟨⟨_, _, _, _, _, hCap12⟩, hCap8⟩
  omega

end ProofspaceOmegaPCT0.GenH

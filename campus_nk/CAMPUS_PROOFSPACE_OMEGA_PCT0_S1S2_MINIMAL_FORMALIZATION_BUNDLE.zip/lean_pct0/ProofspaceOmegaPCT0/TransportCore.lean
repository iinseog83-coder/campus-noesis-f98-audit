/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Module: ProofspaceOmegaPCT0.TransportCore

  Contravariant Model/Context Reduction, Unidirectional Satisfaction Pullback (`T3_⇐`),
  Epistemic Status Orthogonalization (`F-PCT0-10`, `F-PCT0-16`), and Master Theorem `PCT-THM-S1S2`.
-/

import ProofspaceOmegaPCT0.GenG
import ProofspaceOmegaPCT0.GenH

namespace ProofspaceOmegaPCT0

open ProofspaceOmegaPCT0.GenG
open ProofspaceOmegaPCT0.GenH

/-- Contravariant model reduction `R : M_h → M_g` (`F-PCT0-13` exact formula):
    `R(alphaH, betaH, delta2a, delta2b, xiExt, capH) = (alphaH, delta2a + delta2b - xiExt, capH)`. -/
def reduceModel (M : ModelH) : ModelG :=
  { alphaG := M.alphaH
  , deltaG := M.delta2a + M.delta2b - M.xiExt
  , capG   := M.capH }

/-- Contravariant context projection `f : X_h → X_g`: merges `{2a, 2b}` into compartment `2`. -/
def reduceCtx (x : CtxH) : CtxG :=
  { u1 := x.v1
  , u2 := x.v2a + x.v2b }

/-- Geometric inverse-image context region `f⁻¹(B_g^{src})`. -/
def pullbackRegion (BgSrc : CtxG → Prop) (x : CtxH) : Prop :=
  BgSrc (reduceCtx x)

/-- Exact mass conservation across context projection `S_g(f(x_h)) = S_h(x_h)`. -/
theorem mass_commutes (x : CtxH) :
    massG (reduceCtx x) = massH x := by
  dsimp [massG, reduceCtx, massH]
  omega

/-- Exact dynamical commutation `f(F_{M_h}(x_h)) = F_{R(M_h)}(f(x_h))` (internal `betaH` cancels). -/
theorem step_commutes (M : ModelH) (x : CtxH) :
    reduceCtx (stepH M x) = stepG (reduceModel M) (reduceCtx x) := by
  dsimp [reduceCtx, stepH, stepG, reduceModel]
  congr 1 <;> omega

/-- Exact one-step mass-change equality across `R` and `f` for ALL unconstrained `(M, x)`. -/
theorem step_mass_commutes (M : ModelH) (x : CtxH) :
    massG (stepG (reduceModel M) (reduceCtx x)) = massH (stepH M x) := by
  rw [← step_commutes, mass_commutes]

/-- `F-PCT0-10`: 3-valued empirical status strictly separated from formal realizability (`UNKNOWN ≠ FALSE`). -/
inductive EmpiricalStatus where
  | SUPPORTED  : EmpiricalStatus
  | REFUTED    : EmpiricalStatus
  | UNASSESSED : EmpiricalStatus
  deriving DecidableEq, Repr

/-- `F-PCT0-16` & Caution 2: 3-valued formal realizability separating verified witness, proven emptiness, and unproved status. -/
inductive FormalRealizability where
  | FORMAL_WITNESS_VERIFIED : FormalRealizability
  | PROVEN_EMPTY            : FormalRealizability
  | UNPROVED                : FormalRealizability
  deriving DecidableEq, Repr

/-- `F-PCT0-04`: Geometric boundary eligibility (never equivalent to canonical admission on its own). -/
inductive BoundaryEligibility where
  | ELIGIBLE_CANDIDATE       : BoundaryEligibility
  | INELIGIBLE_OUT_OF_BOUNDS : BoundaryEligibility
  deriving DecidableEq, Repr

/-- `T0_joint`: Constructive joint realizability witness on `E_h|_{B_h}` and reduced `E_g|_{B_g^{src}}`. -/
structure JointWitness (BgSrc : CtxG → Prop) (Bh : CtxH → Prop) where
  mh     : ModelH
  xh     : CtxH
  hRealH : RealizableH mh xh
  hBh    : Bh xh
  hRealG : RealizableG (reduceModel mh) (reduceCtx xh)
  hBgSrc : BgSrc (reduceCtx xh)

/-- `T1_real`: Realizability preservation under contravariant reduction `(R, f)`. -/
def T1RealObligation (Bh : CtxH → Prop) : Prop :=
  ∀ M x, RealizableH M x → Bh x → RealizableG (reduceModel M) (reduceCtx x)

/-- `T2_ctx`: Geometric context pullback inclusion `f(B_h) ⊆ B_g^{src}`. -/
def T2CtxObligation (BgSrc : CtxG → Prop) (Bh : CtxH → Prop) : Prop :=
  ∀ x, Bh x → BgSrc (reduceCtx x)

/-- `T3_⇐` (`F-PCT0-09` `P-PCT0-04A`): Strictly UNIDIRECTIONAL satisfaction preservation (`→`, never `↔`). -/
def T3PullbackObligation (Bh : CtxH → Prop) (c : ClaimG) (tau : ClaimG → ClaimH) : Prop :=
  ∀ M x, RealizableH M x → Bh x →
    SatisfiesG (reduceModel M) (reduceCtx x) c →
    SatisfiesH M x (tau c)

/-- Geometric pullback automatically satisfies `T2_ctx`. -/
theorem pullback_satisfies_t2_ctx (BgSrc : CtxG → Prop) :
    T2CtxObligation BgSrc (pullbackRegion BgSrc) := by
  intro x hx
  exact hx

/-- **Master Theorem `PCT-THM-S1S2` (`pct_thm_s1s2`):**
    Given source validity `ValidOnG BgSrc c`, constructive joint inhabitance `T0_joint`,
    realizability reduction `T1_real`, context inclusion `T2_ctx`, and unidirectional `T3_⇐`,
    the translated proposition `tau c` is both universally valid and non-vacuously inhabited on `E_h|_{B_h}`. -/
theorem pct_thm_s1s2
    {BgSrc : CtxG → Prop}
    {Bh : CtxH → Prop}
    {c : ClaimG}
    {tau : ClaimG → ClaimH}
    (hSrcValid : ValidOnG BgSrc c)
    (hT0 : Nonempty (JointWitness BgSrc Bh))
    (hT1 : T1RealObligation Bh)
    (hT2 : T2CtxObligation BgSrc Bh)
    (hT3 : T3PullbackObligation Bh c tau) :
    ValidOnH Bh (tau c) ∧ (∃ M x, RealizableH M x ∧ Bh x ∧ SatisfiesH M x (tau c)) := by
  have hValidH : ValidOnH Bh (tau c) := by
    intro M x hRealH hBh
    have hRealG : RealizableG (reduceModel M) (reduceCtx x) := hT1 M x hRealH hBh
    have hBg : BgSrc (reduceCtx x) := hT2 x hBh
    have hSatG : SatisfiesG (reduceModel M) (reduceCtx x) c := hSrcValid (reduceModel M) (reduceCtx x) hRealG hBg
    exact hT3 M x hRealH hBh hSatG
  rcases hT0 with ⟨w⟩
  refine ⟨hValidH, ⟨w.mh, w.xh, w.hRealH, w.hBh, ?_⟩⟩
  exact hValidH w.mh w.xh w.hRealH w.hBh

end ProofspaceOmegaPCT0

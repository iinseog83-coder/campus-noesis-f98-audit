/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Module: ProofspaceOmegaPCT0.ControlsAndCounterexamples

  Complete Positive Controls (`P-PCT0-01`..`05`), Negative Controls (`M-PCT0-01`..`10`),
  `F-PCT0-12`..`16` Separation Proofs, and Target Theorems for Semantic Mutations (`M-PCT0-LEAN-01`..`05`).
-/

import ProofspaceOmegaPCT0.AuthorityAndAdmission

namespace ProofspaceOmegaPCT0.Controls

open ProofspaceOmegaPCT0
open ProofspaceOmegaPCT0.GenG
open ProofspaceOmegaPCT0.GenH

/-- Canonical Generation-h witness model `M_h^⋆ = (1, 1, 1, 1, 0, 15)`. -/
def MhStar : ModelH :=
  { alphaH := 1, betaH := 1, delta2a := 1, delta2b := 1, xiExt := 0, capH := 15 }

/-- Canonical Generation-h joint witness state `x_h^⋆ = (4, 2, 2)`. -/
def xhStar : CtxH :=
  { v1 := 4, v2a := 2, v2b := 2 }

/-- Exact dissipative proposition translator `τ_c^{exact}`. -/
def tauExact : ClaimG → ClaimH
  | .dissipStep   => .dissipStepSlack 0
  | .massAtMost b => .massAtMost b

/-- Slack dissipative/band proposition translator `τ_c^{slack}` (`P-PCT0-04A/B`). -/
def tauSlack2 : ClaimG → ClaimH
  | .dissipStep   => .dissipStepSlack 2
  | .massAtMost b => .massAtMost (b + 2)

/-- Defective sub-compartment translator `τ_c^{bad}` (`M-PCT0-04`). -/
def tauBadSub2b : ClaimG → ClaimH
  | .dissipStep   => .sub2bStepNonIncrease
  | .massAtMost b => .massAtMost b

/-- `F-PCT0-13` exact model reduction verification: `R(1, 1, 1, 1, 0, 15) = (1, 2, 15)`. -/
theorem f13_reduceModel_MhStar_exact :
    reduceModel MhStar = { alphaG := 1, deltaG := 2, capG := 15 } := rfl

/-- `P-PCT0-02`: Joint realizability witness `(MhStar, xhStar)` on both `f⁻¹(B_g^{≤10})` and `f⁻¹(B_g)`. -/
def jointWitnessBgLe10 : JointWitness BgLe10 (pullbackRegion BgLe10) :=
  { mh := MhStar
  , xh := xhStar
  , hRealH := by
      dsimp [RealizableH, AdmissibleH, StepFeasibleH, NonnegCtxH, massH, MhStar, xhStar]
      decide
  , hBh := by
      dsimp [pullbackRegion, BgLe10, Bg, NonnegCtxG, massG, reduceCtx, xhStar]
      decide
  , hRealG := by
      dsimp [RealizableG, AdmissibleG, StepFeasibleG, NonnegCtxG, massG, reduceModel, reduceCtx, MhStar, xhStar]
      decide
  , hBgSrc := by
      dsimp [BgLe10, Bg, NonnegCtxG, massG, reduceCtx, xhStar]
      decide }

def jointWitnessBg : JointWitness Bg (pullbackRegion Bg) :=
  { mh := MhStar
  , xh := xhStar
  , hRealH := jointWitnessBgLe10.hRealH
  , hBh := jointWitnessBgLe10.hBh.1
  , hRealG := jointWitnessBgLe10.hRealG
  , hBgSrc := jointWitnessBgLe10.hBgSrc.1 }

theorem p_pct0_02_joint_realizable_witness :
    RealizableH MhStar xhStar ∧
    reduceModel MhStar = ⟨1, 2, 15⟩ ∧
    RealizableG (reduceModel MhStar) (reduceCtx xhStar) ∧
    pullbackRegion BgLe10 xhStar ∧
    pullbackRegion Bg xhStar :=
  ⟨jointWitnessBgLe10.hRealH, rfl, jointWitnessBgLe10.hRealG, jointWitnessBgLe10.hBh, jointWitnessBg.hBh⟩

/-- **Target Theorem 1 (`P-PCT0-01`, mutation target of `M-PCT0-LEAN-01` and `M-PCT0-LEAN-02`):**
    Exact conservation-dissipation law transports from `B_g` to `f⁻¹(B_g)` via `pct_thm_s1s2`. -/
theorem pct0_s1s2_dissip_transport :
    ValidOnH (pullbackRegion Bg) (tauExact .dissipStep) ∧
    (∃ M x, RealizableH M x ∧ pullbackRegion Bg x ∧ SatisfiesH M x (tauExact .dissipStep)) := by
  have hT1 : T1RealObligation (pullbackRegion Bg) := by
    intro M x hRealH _
    rcases hRealH with ⟨⟨ha, hb, hd2a, hd2b, hxi, hcap⟩, ⟨⟨hv1, hv2a, hv2b⟩, hs1, hs2, hs3, hsm⟩⟩
    dsimp [RealizableG, AdmissibleG, StepFeasibleG, NonnegCtxG, massG, reduceModel, reduceCtx]
    dsimp [massH] at hsm
    refine ⟨⟨ha, ?_, hcap⟩, ⟨⟨hv1, ?_⟩, hs1, ?_, ?_⟩⟩ <;> omega
  have hT2 : T2CtxObligation Bg (pullbackRegion Bg) :=
    pullback_satisfies_t2_ctx Bg
  have hT3 : T3PullbackObligation (pullbackRegion Bg) .dissipStep tauExact := by
    intro M x _ _ hSatG
    dsimp [SatisfiesG] at hSatG
    rw [step_mass_commutes, mass_commutes] at hSatG
    dsimp [tauExact, SatisfiesH]
    omega
  exact pct_thm_s1s2 g_dissip_valid_on_Bg ⟨jointWitnessBg⟩ hT1 hT2 hT3

/-- General `T1_real` lemma for any target region `Bh` under canonical `Σ_h`. -/
theorem canonical_t1_real (Bh : CtxH → Prop) : T1RealObligation Bh := by
  intro M x hRealH _
  rcases hRealH with ⟨⟨ha, hb, hd2a, hd2b, hxi, hcap⟩, ⟨⟨hv1, hv2a, hv2b⟩, hs1, hs2, hs3, hsm⟩⟩
  dsimp [RealizableG, AdmissibleG, StepFeasibleG, NonnegCtxG, massG, reduceModel, reduceCtx]
  dsimp [massH] at hsm
  refine ⟨⟨ha, ?_, hcap⟩, ⟨⟨hv1, ?_⟩, hs1, ?_, ?_⟩⟩ <;> omega

/-- `P-PCT0-03`: Boundary pullback eligibility (`ELIGIBLE_CANDIDATE`) holds on `f⁻¹(B_g)`,
    yet cannot produce `CanonicalAdmissible = true` without proof and commit authorization. -/
theorem p_pct0_03_boundary_eligibility_not_admission
    (Ph : LedgerStateH)
    (K' : TransportCandidateK) :
    T2CtxObligation Bg (pullbackRegion Bg) ∧
    CanonicalAdmissible Ph none none K' = false :=
  ⟨pullback_satisfies_t2_ctx Bg, rfl⟩

/-- `P-PCT0-04A`: Unidirectional slack transport (`→`, never assuming `↔`) for BOTH:
    (i) `c_dissip` on `B_g` ↦ `dissipStepSlack 2` on `f⁻¹(B_g)`, and
    (ii) `c_{≤10}` on restricted `B_g^{≤10}` ↦ `massAtMost 12` on `f⁻¹(B_g^{≤10})`. -/
theorem p_pct0_04a_unidirectional_slack_and_band_transport :
    ValidOnH (pullbackRegion Bg) (tauSlack2 .dissipStep) ∧
    ValidOnH (pullbackRegion BgLe10) (tauSlack2 (.massAtMost 10)) := by
  have hDissip : ValidOnH (pullbackRegion Bg) (tauSlack2 .dissipStep) := by
    have hT3D : T3PullbackObligation (pullbackRegion Bg) .dissipStep tauSlack2 := by
      intro M x _ _ hSatG
      dsimp [SatisfiesG] at hSatG
      rw [step_mass_commutes, mass_commutes] at hSatG
      dsimp [tauSlack2, SatisfiesH]
      omega
    exact (pct_thm_s1s2 g_dissip_valid_on_Bg ⟨jointWitnessBg⟩
      (canonical_t1_real (pullbackRegion Bg))
      (pullback_satisfies_t2_ctx Bg) hT3D).1
  have hBand : ValidOnH (pullbackRegion BgLe10) (tauSlack2 (.massAtMost 10)) := by
    have hT3B : T3PullbackObligation (pullbackRegion BgLe10) (.massAtMost 10) tauSlack2 := by
      intro M x _ _ hSatG
      dsimp [SatisfiesG] at hSatG
      rw [mass_commutes] at hSatG
      dsimp [tauSlack2, SatisfiesH]
      omega
    exact (pct_thm_s1s2 g_le10_valid_on_BgLe10 ⟨jointWitnessBgLe10⟩
      (canonical_t1_real (pullbackRegion BgLe10))
      (pullback_satisfies_t2_ctx BgLe10) hT3B).1
  exact ⟨hDissip, hBand⟩

/-- `P-PCT0-04B-1`: Explicit dynamical comparison-space non-equivalence counterexample (`MhAmb = (0,0,0,0,+1,15)`, `xh = (2,2,2)`). -/
theorem p_pct0_04b_1_dynamical_comparison_non_equiv :
    let MhAmb : ModelH := ⟨0, 0, 0, 0, 1, 15⟩
    let xh : CtxH := ⟨2, 2, 2⟩
    CompBoundedInflowModelH MhAmb ∧
    StepFeasibleH MhAmb xh ∧
    pullbackRegion Bg xh ∧
    reduceModel MhAmb = ⟨0, -1, 15⟩ ∧
    (∀ M x, CompBoundedInflowModelH M →
      SatisfiesG (reduceModel M) (reduceCtx x) .dissipStep →
      SatisfiesH M x (tauSlack2 .dissipStep)) ∧
    SatisfiesH MhAmb xh (tauSlack2 .dissipStep) ∧
    ¬ SatisfiesG (reduceModel MhAmb) (reduceCtx xh) .dissipStep := by
  dsimp
  refine ⟨?_, ?_, ?_, rfl, ?_, ?_, ?_⟩
  · dsimp [CompBoundedInflowModelH]; decide
  · dsimp [StepFeasibleH, NonnegCtxH, massH]; decide
  · dsimp [pullbackRegion, Bg, NonnegCtxG, massG, reduceCtx]; decide
  · intro M x _ hSatG
    dsimp [SatisfiesG] at hSatG
    rw [step_mass_commutes, mass_commutes] at hSatG
    dsimp [tauSlack2, SatisfiesH]
    omega
  · dsimp [tauSlack2, SatisfiesH, stepH, massH]; decide
  · dsimp [SatisfiesG, stepG, massG, reduceModel, reduceCtx]; decide

/-- `P-PCT0-04B-2` (`F-PCT0-12` & `F-PCT0-13` 4-part independent check):
    Strictly inside `Σ_h`-admissible models (`MhStar = (1,1,1,1,0,15)`, `R(MhStar) = (1,2,15)`),
    separates restricted source domain `BgLe10`, authorized transport domain `f⁻¹(BgLe10)`,
    and comparison-only domain `BhCompLe12` at witness `xhSharp = (4, 4, 3)`. -/
theorem p_pct0_04b_2_admissible_band_comparison_non_equiv :
    let xhSharp : CtxH := ⟨4, 4, 3⟩
    (ValidOnG BgLe10 (.massAtMost 10) ∧ ¬ ValidOnG Bg (.massAtMost 10)) ∧
    (RealizableH MhStar xhSharp ∧ reduceModel MhStar = ⟨1, 2, 15⟩ ∧ RealizableG (reduceModel MhStar) (reduceCtx xhSharp)) ∧
    (BhCompLe12 xhSharp ∧ ¬ pullbackRegion BgLe10 xhSharp) ∧
    (SatisfiesH MhStar xhSharp (tauSlack2 (.massAtMost 10)) ∧ ¬ SatisfiesG (reduceModel MhStar) (reduceCtx xhSharp) (.massAtMost 10)) := by
  dsimp
  refine ⟨⟨g_le10_valid_on_BgLe10, g_le10_not_valid_on_Bg.2⟩, ?_, ?_, ?_⟩
  · refine ⟨?_, rfl, ?_⟩
    · dsimp [RealizableH, AdmissibleH, StepFeasibleH, NonnegCtxH, massH, MhStar]; decide
    · dsimp [RealizableG, AdmissibleG, StepFeasibleG, NonnegCtxG, massG, reduceModel, reduceCtx, MhStar]; decide
  · refine ⟨?_, ?_⟩
    · dsimp [BhCompLe12, NonnegCtxH, massH]; decide
    · dsimp [pullbackRegion, BgLe10, Bg, NonnegCtxG, massG, reduceCtx]; decide
  · refine ⟨?_, ?_⟩
    · dsimp [tauSlack2, SatisfiesH, massH]; decide
    · dsimp [SatisfiesG, massG, reduceCtx]; decide

/-- Target region alias for `certDissipExact` (mutated in `M-PCT0-LEAN-03`). -/
def canonicalTargetRegion : CtxH → Prop :=
  pullbackRegion Bg

/-- Canonical candidate `K'` for `P-PCT0-05` (`empiricalStatus = .UNASSESSED`). -/
def candDissipExact : TransportCandidateK :=
  { candidateId := 101
  , sourceGenId := 1
  , targetGenId := 2
  , targetSpecHash := 20261119
  , sourceClaim := .dissipStep
  , translatedClaim := tauExact .dissipStep
  , eligibility := .ELIGIBLE_CANDIDATE
  , formalRealizability := .FORMAL_WITNESS_VERIFIED
  , empiricalStatus := .UNASSESSED
  , untrustedClaimedAdmissible := false }

def PhInit : LedgerStateH :=
  { activeGenId := 2
  , activeSpecHash := 20261119
  , ledgerEpoch := 7
  , trustedAuthorityId := 900
  , expectedAuthoritySeal := 778899
  , hasExternalEmpiricalLedger := false
  , consumedGrantIds := []
  , committedCandidateIds := [] }

def grantValidInit : CommitAuthGrant :=
  { grantId := 5001
  , issuerAuthorityId := 900
  , authoritySeal := 778899
  , authorizedCandidateId := 101
  , authorizedTargetGenId := 2
  , authorizedSpecHash := 20261119
  , issuedAtEpoch := 7 }

/-- **Target Theorem 2 (`P-PCT0-05`, mutation target of `M-PCT0-LEAN-03`, `04`, `05`):**
    Valid transport certificate + PCIC policy + external state-bound `CommitAuthGrant` achieves
    `CanonicalAdmissible = true` while maintaining `W_theorem = 0` (`F-PCT0-14` & `F-PCT0-15`). -/
theorem pct0_s1s2_canonical_admissible :
    ∃ cert : VerifiedTransportCertificate,
      cert.cand = candDissipExact ∧
      CanonicalAdmissible PhInit (some cert) (some grantValidInit) candDissipExact = true ∧
      computeTransportNoveltyReward false 0 = { credit := 0 } := by
  let w0 : JointWitness Bg canonicalTargetRegion :=
    { mh := MhStar
    , xh := xhStar
    , hRealH := jointWitnessBg.hRealH
    , hBh := by
        dsimp [canonicalTargetRegion, pullbackRegion, Bg, NonnegCtxG, massG, reduceCtx, xhStar]
        decide
    , hRealG := jointWitnessBg.hRealG
    , hBgSrc := jointWitnessBg.hBgSrc }
  let cert : VerifiedTransportCertificate :=
    { cand := candDissipExact
    , BgSrc := Bg
    , Bh := canonicalTargetRegion
    , tau := tauExact
    , hTranslatedEq := rfl
    , hEligibility := rfl
    , hFormalVerified := rfl
    , hSrcValid := g_dissip_valid_on_Bg
    , hT0 := ⟨w0⟩
    , hT1 := canonical_t1_real canonicalTargetRegion
    , hT2 := by
        intro x hx
        exact hx
    , hT3 := by
        intro M x _ _ hSatG
        dsimp [candDissipExact, SatisfiesG] at hSatG
        rw [step_mass_commutes, mass_commutes] at hSatG
        dsimp [candDissipExact, tauExact, SatisfiesH]
        omega }
  refine ⟨cert, rfl, ?_, rfl⟩
  decide

/-- **Negative Control `M-PCT0-01`:** Leaky external inflow `xiExt = +5` violates `T1_real` (`deltaG = -3 < 0`). -/
theorem m_pct0_01_leaky_inflow_violates_T1_real :
    let MhLeaky : ModelH := ⟨1, 1, 1, 1, 5, 15⟩
    reduceModel MhLeaky = ⟨1, -3, 15⟩ ∧
    ¬ AdmissibleG (reduceModel MhLeaky) ∧
    ¬ SatisfiesH MhLeaky ⟨2, 2, 2⟩ (tauExact .dissipStep) := by
  refine ⟨rfl, ?_, ?_⟩
  · dsimp [reduceModel, AdmissibleG]; decide
  · dsimp [tauExact, SatisfiesH, stepH, massH]; decide

/-- **Negative Control `M-PCT0-02`:** Wide context `BhCompLe12` violates `T2_ctx` relative to `BgLe10`. -/
theorem m_pct0_02_wide_context_violates_T2_ctx :
    (BhCompLe12 ⟨4, 4, 3⟩ ∧ ¬ BgLe10 (reduceCtx ⟨4, 4, 3⟩)) ∧
    ¬ T2CtxObligation BgLe10 BhCompLe12 := by
  have hIn : BhCompLe12 ⟨4, 4, 3⟩ := by
    dsimp [BhCompLe12, NonnegCtxH, massH]; decide
  have hOut : ¬ BgLe10 (reduceCtx ⟨4, 4, 3⟩) := by
    dsimp [BgLe10, Bg, NonnegCtxG, massG, reduceCtx]; decide
  refine ⟨⟨hIn, hOut⟩, ?_⟩
  intro hT2
  exact hOut (hT2 ⟨4, 4, 3⟩ hIn)

/-- **Negative Control `M-PCT0-03A` & `M-PCT0-03B` (`F-PCT0-16` Mandatory Separation):**
    Separates (A) contradictory model specification (`capH = 8 ∧ capH ≥ 12`, empty model set) from
    (B) consistent low-capacity model specification (`LowCapConsistentSpecH`, non-empty model marginal AND
        non-empty context marginal `f⁻¹(BgGe10)`, yet PROVEN EMPTY joint incidence fiber). -/
theorem m_pct0_03_f16_empty_model_vs_empty_incidence_separated :
    (∀ M, ¬ ContradictorySpecH M) ∧
    (∃ M x, LowCapConsistentSpecH M ∧ StepFeasibleH M x) ∧
    (∃ x, pullbackRegion BgGe10 x) ∧
    (∀ M x, ¬ (LowCapConsistentSpecH M ∧ StepFeasibleH M x ∧ pullbackRegion BgGe10 x)) := by
  refine ⟨f16_model_inconsistency_empty, ?_, ?_, ?_⟩
  · refine ⟨⟨1, 1, 1, 1, 0, 8⟩, ⟨2, 2, 2⟩, ?_, ?_⟩
    · dsimp [LowCapConsistentSpecH]; decide
    · dsimp [StepFeasibleH, NonnegCtxH, massH]; decide
  · refine ⟨⟨4, 3, 3⟩, ?_⟩
    dsimp [pullbackRegion, BgGe10, Bg, NonnegCtxG, massG, reduceCtx]; decide
  · intro M x ⟨hSpec, hFeas, hCtx⟩
    rcases hSpec with ⟨_, _, _, _, _, hCap8⟩
    rcases hFeas with ⟨_, _, _, _, hMassCap⟩
    rcases hCtx with ⟨_, hGe10⟩
    rw [mass_commutes] at hGe10
    omega

/-- **Negative Control `M-PCT0-04`:** Defective sub-compartment translator `tauBadSub2b` fails `T3_⇐`
    at `Σ_h`-admissible `MhBad = (1, 3, 1, 1, 0, 15)` (`R(MhBad) = (1, 2, 15)`) and `xh = (2, 4, 1) ∈ f⁻¹(Bg)`. -/
theorem m_pct0_04_bad_translator_violates_T3 :
    let MhBad : ModelH := ⟨1, 3, 1, 1, 0, 15⟩
    let xh : CtxH := ⟨2, 4, 1⟩
    (RealizableH MhBad xh ∧
     reduceModel MhBad = ⟨1, 2, 15⟩ ∧
     pullbackRegion Bg xh ∧
     SatisfiesG (reduceModel MhBad) (reduceCtx xh) .dissipStep ∧
     ¬ SatisfiesH MhBad xh (tauBadSub2b .dissipStep)) ∧
    ¬ T3PullbackObligation (pullbackRegion Bg) .dissipStep tauBadSub2b := by
  dsimp
  have hRealH : RealizableH ⟨1, 3, 1, 1, 0, 15⟩ ⟨2, 4, 1⟩ := by
    dsimp [RealizableH, AdmissibleH, StepFeasibleH, NonnegCtxH, massH]; decide
  have hPb : pullbackRegion Bg ⟨2, 4, 1⟩ := by
    dsimp [pullbackRegion, Bg, NonnegCtxG, massG, reduceCtx]; decide
  have hSatG : SatisfiesG (reduceModel ⟨1, 3, 1, 1, 0, 15⟩) (reduceCtx ⟨2, 4, 1⟩) .dissipStep := by
    dsimp [SatisfiesG, stepG, massG, reduceModel, reduceCtx]; decide
  have hNotH : ¬ SatisfiesH ⟨1, 3, 1, 1, 0, 15⟩ ⟨2, 4, 1⟩ (tauBadSub2b .dissipStep) := by
    dsimp [tauBadSub2b, SatisfiesH, stepH]; decide
  refine ⟨⟨hRealH, rfl, hPb, hSatG, hNotH⟩, ?_⟩
  intro hT3
  exact hNotH (hT3 ⟨1, 3, 1, 1, 0, 15⟩ ⟨2, 4, 1⟩ hRealH hPb hSatG)

/-- **Negative Control `M-PCT0-08` (`F-PCT0-10`):** Promoting `UNASSESSED` to `SUPPORTED` without external empirical ledger is rejected. -/
theorem m_pct0_08_empirical_conflation_rejected (certOpt : Option VerifiedTransportCertificate) :
    let candInflated := { candDissipExact with empiricalStatus := .SUPPORTED }
    PCICPolicySatisfied PhInit candInflated = false ∧
    CanonicalAdmissible PhInit certOpt (some grantValidInit) candInflated = false := by
  have hPol : PCICPolicySatisfied PhInit { candDissipExact with empiricalStatus := .SUPPORTED } = false := by
    decide
  refine ⟨hPol, ?_⟩
  dsimp [CanonicalAdmissible]
  rw [hPol]
  simp

/-- **Negative Control `M-PCT0-09A` & `M-PCT0-09B` (`F-PCT0-14`):**
    (A) Spoofed `untrustedClaimedAdmissible = true`, `ELIGIBLE_CANDIDATE`, valid `CommitAuthGrant`, and `claimedNovelty = 1`
        still fail admission when `certOpt = none`.
    (B) Pure heritage transport claiming `untrustedClaimedNovelty = 1` is clamped to `W_theorem = 0`. -/
theorem m_pct0_09_authority_and_reward_separation :
    let candSpoof := { candDissipExact with untrustedClaimedAdmissible := true }
    CanonicalAdmissible PhInit none (some grantValidInit) candSpoof = false ∧
    computeTransportNoveltyReward false 1 = { credit := 0 } := by
  exact ⟨rfl, rfl⟩

/-- **Negative Control `M-PCT0-10` (`F-PCT0-15` Mandatory Commit-Authority Separation):**
    Even when semantic truth holds, `VerifiedProof` holds, and `PCICPolicySatisfied` holds,
    missing, forged, wrong-candidate, stale-epoch, or replayed `CommitAuthGrant` is ALWAYS rejected. -/
theorem m_pct0_10_f15_commit_authority_guards :
    ∀ cert : VerifiedTransportCertificate,
      cert.cand = candDissipExact →
      let gForgedSeal := { grantValidInit with authoritySeal := 0 }
      let gWrongCand  := { grantValidInit with authorizedCandidateId := 999 }
      let gStaleEpoch := { grantValidInit with issuedAtEpoch := 6 }
      let PhConsumed  := { PhInit with consumedGrantIds := [5001] }
      CanonicalAdmissible PhInit (some cert) none candDissipExact = false ∧
      CanonicalAdmissible PhInit (some cert) (some gForgedSeal) candDissipExact = false ∧
      CanonicalAdmissible PhInit (some cert) (some gWrongCand) candDissipExact = false ∧
      CanonicalAdmissible PhInit (some cert) (some gStaleEpoch) candDissipExact = false ∧
      CanonicalAdmissible PhConsumed (some cert) (some grantValidInit) candDissipExact = false := by
  intro cert _
  have hAuth0 : CommitAuthorized PhInit none candDissipExact = false := rfl
  have hAuth1 : CommitAuthorized PhInit (some { grantValidInit with authoritySeal := 0 }) candDissipExact = false := by decide
  have hAuth2 : CommitAuthorized PhInit (some { grantValidInit with authorizedCandidateId := 999 }) candDissipExact = false := by decide
  have hAuth3 : CommitAuthorized PhInit (some { grantValidInit with issuedAtEpoch := 6 }) candDissipExact = false := by decide
  have hAuth4 : CommitAuthorized { PhInit with consumedGrantIds := [5001] } (some grantValidInit) candDissipExact = false := by decide
  dsimp [CanonicalAdmissible]
  rw [hAuth0, hAuth1, hAuth2, hAuth3, hAuth4]
  simp

/-- **Three-Layer Evidence Separation Master Theorem (Tribunal Core Mandate):**
    Constructively exhibits three distinct configurations proving that:
      (1) Semantic Truth (`ValidOnH`) can hold while `VerifiedProof = false` and `CanonicalAdmissible = false`,
      (2) Semantic Truth + `VerifiedProof = true` + `PCICPolicySatisfied = true` can hold while `CommitAuthorized = false` and `CanonicalAdmissible = false`,
      (3) All three distinct evidences together achieve `CanonicalAdmissible = true` with `W_theorem = 0`. -/
theorem pct0_three_distinct_evidences_separation :
    ∃ cert : VerifiedTransportCertificate,
      ValidOnH (pullbackRegion Bg) candDissipExact.translatedClaim ∧
      (VerifiedProof none candDissipExact = false ∧
       CanonicalAdmissible PhInit none (some grantValidInit) candDissipExact = false) ∧
      (VerifiedProof (some cert) candDissipExact = true ∧
       PCICPolicySatisfied PhInit candDissipExact = true ∧
       CommitAuthorized PhInit none candDissipExact = false ∧
       CanonicalAdmissible PhInit (some cert) none candDissipExact = false) ∧
      (CanonicalAdmissible PhInit (some cert) (some grantValidInit) candDissipExact = true ∧
       computeTransportNoveltyReward false 0 = { credit := 0 }) := by
  rcases pct0_s1s2_canonical_admissible with ⟨cert, hCandEq, hAdm, hRew⟩
  have hThree := (f15_canonical_admissible_iff_three_gates PhInit (some cert) (some grantValidInit) candDissipExact).mp hAdm
  refine ⟨cert, pct0_s1s2_dissip_transport.1, ⟨rfl, rfl⟩, ⟨hThree.1, hThree.2.1, rfl, ?_⟩, ⟨hAdm, hRew⟩⟩
  exact f15_checker_alone_without_commit_grant_rejected PhInit (some cert) candDissipExact

end ProofspaceOmegaPCT0.Controls

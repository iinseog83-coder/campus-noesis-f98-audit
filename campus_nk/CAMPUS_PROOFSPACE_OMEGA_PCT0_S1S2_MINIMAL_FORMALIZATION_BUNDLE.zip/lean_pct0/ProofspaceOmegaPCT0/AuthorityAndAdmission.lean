/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Module: ProofspaceOmegaPCT0.AuthorityAndAdmission

  Strict Separation of Four Orthogonal Channels (`F-PCT0-10`, `F-PCT0-14`, `F-PCT0-15`):
    1. Semantic Truth in GenH (`ValidOnH Bh d`)
    2. Checker-Verified Transport Proof Witness (`VerifiedProof certOpt K'`)
    3. Constitutional PCIC Policy Satisfaction (`PCICPolicySatisfied Ph K'`)
    4. State-Bound External Commit Authorization (`CommitAuthorized Ph grantOpt K'`)
    Plus Orthogonal Novelty Discovery Reward (`NoveltyReward`, `W_theorem = 0` for pure transport).
-/

import ProofspaceOmegaPCT0.TransportCore

namespace ProofspaceOmegaPCT0

open ProofspaceOmegaPCT0.GenG
open ProofspaceOmegaPCT0.GenH

/-- Candidate transported knowledge object `K'` proposed for Generation-h canonical ledger. -/
structure TransportCandidateK where
  candidateId                : Nat
  sourceGenId                : Nat
  targetGenId                : Nat
  targetSpecHash             : Nat
  sourceClaim                : ClaimG
  translatedClaim            : ClaimH
  eligibility                : BoundaryEligibility
  formalRealizability        : FormalRealizability
  empiricalStatus            : EmpiricalStatus
  untrustedClaimedAdmissible : Bool
  deriving DecidableEq, Repr

/-- Proof-carrying transport witness `w_h` verified by the Lean kernel checker. -/
structure VerifiedTransportCertificate where
  cand            : TransportCandidateK
  BgSrc           : CtxG → Prop
  Bh              : CtxH → Prop
  tau             : ClaimG → ClaimH
  hTranslatedEq   : cand.translatedClaim = tau cand.sourceClaim
  hEligibility    : cand.eligibility = .ELIGIBLE_CANDIDATE
  hFormalVerified : cand.formalRealizability = .FORMAL_WITNESS_VERIFIED
  hSrcValid       : ValidOnG BgSrc cand.sourceClaim
  hT0             : Nonempty (JointWitness BgSrc Bh)
  hT1             : T1RealObligation Bh
  hT2             : T2CtxObligation BgSrc Bh
  hT3             : T3PullbackObligation Bh cand.sourceClaim tau

/-- Every kernel-verified transport certificate entails non-vacuous semantic truth in `GenH`. -/
theorem verified_cert_entails_semantic_truth (cert : VerifiedTransportCertificate) :
    ValidOnH cert.Bh cert.cand.translatedClaim ∧
    (∃ M x, RealizableH M x ∧ cert.Bh x ∧ SatisfiesH M x cert.cand.translatedClaim) := by
  have hMain := pct_thm_s1s2 cert.hSrcValid cert.hT0 cert.hT1 cert.hT2 cert.hT3
  rw [cert.hTranslatedEq]
  exact hMain

/-- Generation-h constitutional ledger state `P_h`. -/
structure LedgerStateH where
  activeGenId                : Nat
  activeSpecHash             : Nat
  ledgerEpoch                : Nat
  trustedAuthorityId         : Nat
  expectedAuthoritySeal      : Nat
  hasExternalEmpiricalLedger : Bool
  consumedGrantIds           : List Nat
  committedCandidateIds      : List Nat
  deriving DecidableEq, Repr

/-- `F-PCT0-15`: Separate state-bound commit authorization grant (never produced by the proof checker). -/
structure CommitAuthGrant where
  grantId               : Nat
  issuerAuthorityId     : Nat
  authoritySeal         : Nat
  authorizedCandidateId : Nat
  authorizedTargetGenId : Nat
  authorizedSpecHash    : Nat
  issuedAtEpoch         : Nat
  deriving DecidableEq, Repr

/-- `F-PCT0-14`: Disjoint novelty discovery reward type (`W_theorem`), never accepted as an admission authority input. -/
structure NoveltyReward where
  credit : Nat
  deriving DecidableEq, Repr

/-- Gate 1 (`VerifiedProof(w_h)`): Checker confirms a proof-carrying certificate bound to `K'`. -/
def VerifiedProof (certOpt : Option VerifiedTransportCertificate) (K' : TransportCandidateK) : Bool :=
  match certOpt with
  | none      => false
  | some cert =>
      decide (cert.cand.candidateId = K'.candidateId) &&
      decide (cert.cand.sourceGenId = K'.sourceGenId) &&
      decide (cert.cand.targetGenId = K'.targetGenId) &&
      decide (cert.cand.targetSpecHash = K'.targetSpecHash) &&
      decide (cert.cand.sourceClaim = K'.sourceClaim) &&
      decide (cert.cand.translatedClaim = K'.translatedClaim) &&
      decide (cert.cand.eligibility = K'.eligibility) &&
      decide (cert.cand.formalRealizability = K'.formalRealizability) &&
      decide (cert.cand.empiricalStatus = K'.empiricalStatus)

/-- Gate 2 (`PCICPolicySatisfied(P_h, K')`): Constitutional policy, non-vacuity (`T0`), and empirical non-conflation (`F-PCT0-10`). -/
def PCICPolicySatisfied (Ph : LedgerStateH) (K' : TransportCandidateK) : Bool :=
  decide (K'.targetGenId = Ph.activeGenId) &&
  decide (K'.targetSpecHash = Ph.activeSpecHash) &&
  decide (K'.eligibility = .ELIGIBLE_CANDIDATE) &&
  decide (K'.formalRealizability = .FORMAL_WITNESS_VERIFIED) &&
  (Ph.hasExternalEmpiricalLedger || decide (K'.empiricalStatus = .UNASSESSED)) &&
  decide (K'.candidateId ∉ Ph.committedCandidateIds)

/-- Gate 3 (`CommitAuthorized(P_h, K')`, `F-PCT0-15`): State-bound, replay-protected external commit authorization. -/
def CommitAuthorized
    (Ph : LedgerStateH)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK) : Bool :=
  match grantOpt with
  | none   => false
  | some g =>
      decide (0 < g.grantId) &&
      decide (g.grantId ∉ Ph.consumedGrantIds) &&
      decide (g.issuerAuthorityId = Ph.trustedAuthorityId) &&
      decide (g.authoritySeal = Ph.expectedAuthoritySeal) &&
      decide (g.authorizedCandidateId = K'.candidateId) &&
      decide (g.authorizedTargetGenId = Ph.activeGenId) &&
      decide (g.authorizedSpecHash = Ph.activeSpecHash) &&
      decide (g.issuedAtEpoch = Ph.ledgerEpoch)

/-- `F-PCT0-15` Canonical Admission Predicate:
    `VerifiedProof(w_h) ∧ PCICPolicySatisfied(P_h, K') ∧ CommitAuthorized(P_h, K')`. -/
def CanonicalAdmissible
    (Ph : LedgerStateH)
    (certOpt : Option VerifiedTransportCertificate)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK) : Bool :=
  VerifiedProof certOpt K' &&
  PCICPolicySatisfied Ph K' &&
  CommitAuthorized Ph grantOpt K'

/-- State transition committing `K'` and consuming the one-shot authorization grant `g.grantId`. -/
def stepCanonicalCommit
    (Ph : LedgerStateH)
    (certOpt : Option VerifiedTransportCertificate)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK) : Bool × LedgerStateH :=
  if CanonicalAdmissible Ph certOpt grantOpt K' then
    match grantOpt with
    | none   => (false, Ph)
    | some g =>
        ( true
        , { Ph with
              consumedGrantIds := Ph.consumedGrantIds ++ [g.grantId]
              committedCandidateIds := Ph.committedCandidateIds ++ [K'.candidateId] } )
  else
    (false, Ph)

/-- `F-PCT0-14`: Pure heritage transport yields `W_theorem = 0` regardless of untrusted caller claims. -/
def computeTransportNoveltyReward
    (hasExclusiveGenHExtension : Bool)
    (_untrustedClaimedNovelty : Nat) : NoveltyReward :=
  if hasExclusiveGenHExtension then { credit := 1 } else { credit := 0 }

theorem f14_pure_transport_novelty_reward_zero (untrustedClaim : Nat) :
    computeTransportNoveltyReward false untrustedClaim = { credit := 0 } := rfl

theorem f14_admission_ignores_untrusted_admissible_flag
    (Ph : LedgerStateH)
    (certOpt : Option VerifiedTransportCertificate)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK)
    (b : Bool) :
    CanonicalAdmissible Ph certOpt grantOpt { K' with untrustedClaimedAdmissible := b } =
    CanonicalAdmissible Ph certOpt grantOpt K' := rfl

theorem f15_canonical_admissible_iff_three_gates
    (Ph : LedgerStateH)
    (certOpt : Option VerifiedTransportCertificate)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK) :
    CanonicalAdmissible Ph certOpt grantOpt K' = true ↔
      (VerifiedProof certOpt K' = true ∧
       PCICPolicySatisfied Ph K' = true ∧
       CommitAuthorized Ph grantOpt K' = true) := by
  dsimp [CanonicalAdmissible]
  cases VerifiedProof certOpt K' <;>
  cases PCICPolicySatisfied Ph K' <;>
  cases CommitAuthorized Ph grantOpt K' <;>
  decide

/-- `F-PCT0-15`: Checker acceptance + PCIC policy satisfaction ALONE cannot authorize canonical admission. -/
theorem f15_checker_alone_without_commit_grant_rejected
    (Ph : LedgerStateH)
    (certOpt : Option VerifiedTransportCertificate)
    (K' : TransportCandidateK) :
    CanonicalAdmissible Ph certOpt none K' = false := by
  dsimp [CanonicalAdmissible, CommitAuthorized]
  cases VerifiedProof certOpt K' <;> cases PCICPolicySatisfied Ph K' <;> rfl

/-- `F-PCT0-14 / M-PCT0-09A`: External commit grant + PCIC policy ALONE cannot bypass `VerifiedProof`. -/
theorem f15_commit_grant_without_verified_proof_rejected
    (Ph : LedgerStateH)
    (grantOpt : Option CommitAuthGrant)
    (K' : TransportCandidateK) :
    CanonicalAdmissible Ph none grantOpt K' = false := rfl

/-- `F-PCT0-15`: Any canonical admission entails kernel-verified semantic validity in `GenH`. -/
theorem f15_canonical_admissible_entails_semantic_truth
    {Ph : LedgerStateH}
    {cert : VerifiedTransportCertificate}
    {grantOpt : Option CommitAuthGrant}
    {K' : TransportCandidateK}
    (hAdm : CanonicalAdmissible Ph (some cert) grantOpt K' = true) :
    ValidOnH cert.Bh K'.translatedClaim := by
  have h3 := (f15_canonical_admissible_iff_three_gates Ph (some cert) grantOpt K').mp hAdm
  have hVP : VerifiedProof (some cert) K' = true := h3.1
  dsimp [VerifiedProof] at hVP
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hVP
  have hTrEq : cert.cand.translatedClaim = K'.translatedClaim := hVP.1.1.1.2
  rw [← hTrEq]
  exact (verified_cert_entails_semantic_truth cert).1

/-- `F-PCT0-15`: Once a commit grant is consumed by `stepCanonicalCommit`, replaying that grant is always rejected. -/
theorem f15_consumed_grant_replay_rejected
    {Ph Ph' : LedgerStateH}
    {certOpt certOpt2 : Option VerifiedTransportCertificate}
    {g : CommitAuthGrant}
    {K1 K2 : TransportCandidateK}
    (hStep : stepCanonicalCommit Ph certOpt (some g) K1 = (true, Ph')) :
    CommitAuthorized Ph' (some g) K2 = false ∧
    CanonicalAdmissible Ph' certOpt2 (some g) K2 = false := by
  dsimp [stepCanonicalCommit] at hStep
  split at hStep
  · injection hStep with _ hPh'
    rw [← hPh']
    have hMem : g.grantId ∈ Ph.consumedGrantIds ++ [g.grantId] := by
      simp
    have hNotAuth : CommitAuthorized
        { Ph with
            consumedGrantIds := Ph.consumedGrantIds ++ [g.grantId]
            committedCandidateIds := Ph.committedCandidateIds ++ [K1.candidateId] }
        (some g) K2 = false := by
      dsimp [CommitAuthorized]
      simp [hMem]
    refine ⟨hNotAuth, ?_⟩
    dsimp [CanonicalAdmissible]
    rw [hNotAuth]
    simp
  · injection hStep with hFalse _
    contradiction

end ProofspaceOmegaPCT0

/-
  CAMPUS-NATIVE PROOFSPACE Ω — PCT-0 (PCT-S1/S2 Minimal Formalization)
  Module: ProofspaceOmegaPCT0.GenG

  Independent Generation-g 2-Compartment Conservation-Dissipation Semantics.
  Architectural Invariant (PCT0-Q1 / F-PCT0-11):
    - ZERO imports from GenH, TransportCore, AuthorityAndAdmission, or any shared user base.
    - Depends exclusively on Lean core prelude types (`Int`, `Prop`).
-/

namespace ProofspaceOmegaPCT0.GenG

/-- Generation-g 2-compartment model parameters `(alphaG, deltaG, capG) ∈ ℤ³`. -/
structure ModelG where
  alphaG : Int
  deltaG : Int
  capG   : Int
  deriving DecidableEq, Repr

/-- Generation-g 2-compartment state/context `(u1, u2) ∈ ℤ²`. -/
structure CtxG where
  u1 : Int
  u2 : Int
  deriving DecidableEq, Repr

/-- Non-negative compartment populations `u1 ≥ 0 ∧ u2 ≥ 0`. -/
def NonnegCtxG (x : CtxG) : Prop :=
  0 ≤ x.u1 ∧ 0 ≤ x.u2

/-- Total conserved/dissipated quantity `S_g(u1, u2) = u1 + u2`. -/
def massG (x : CtxG) : Int :=
  x.u1 + x.u2

/-- Single-step 2-compartment update `F_{M_g}(u1, u2) = (u1 - alphaG, u2 + alphaG - deltaG)`. -/
def stepG (M : ModelG) (x : CtxG) : CtxG :=
  { u1 := x.u1 - M.alphaG
  , u2 := x.u2 + M.alphaG - M.deltaG }

/-- Generation-g admissible theory `Σ_g`: non-negative transfer, non-negative dissipation, capacity ≥ 12. -/
def AdmissibleG (M : ModelG) : Prop :=
  0 ≤ M.alphaG ∧ 0 ≤ M.deltaG ∧ 12 ≤ M.capG

/-- Generation-g step feasibility (one-step non-negativity and capacity bound). -/
def StepFeasibleG (M : ModelG) (x : CtxG) : Prop :=
  NonnegCtxG x ∧
  M.alphaG ≤ x.u1 ∧
  M.deltaG ≤ x.u2 + M.alphaG ∧
  massG x ≤ M.capG

/-- Generation-g realizable model-context incidence relation `E_g`. -/
def RealizableG (M : ModelG) (x : CtxG) : Prop :=
  AdmissibleG M ∧ StepFeasibleG M x

/-- Baseline source validity domain `B_g = {(u1, u2) ∈ ℤ²_{≥0} | u1 + u2 ≤ 12}`. -/
def Bg (x : CtxG) : Prop :=
  NonnegCtxG x ∧ massG x ≤ 12

/-- Restricted source validity sub-domain `B_g^{≤10} = B_g ∩ {S_g ≤ 10}` (`F-PCT0-12`). -/
def BgLe10 (x : CtxG) : Prop :=
  Bg x ∧ massG x ≤ 10

/-- Upper-tail source sub-domain `B_g^{≥10} = B_g ∩ {10 ≤ S_g}` (`F-PCT0-16`). -/
def BgGe10 (x : CtxG) : Prop :=
  Bg x ∧ 10 ≤ massG x

/-- Generation-g proposition syntax. -/
inductive ClaimG where
  | dissipStep : ClaimG
  | massAtMost : Int → ClaimG
  deriving DecidableEq, Repr

/-- Independent Generation-g satisfaction relation `M, x ⊨_g c`. -/
def SatisfiesG (M : ModelG) (x : CtxG) : ClaimG → Prop
  | .dissipStep   => massG (stepG M x) ≤ massG x
  | .massAtMost b => massG x ≤ b

/-- Realizable scoped source validity `Σ_g ⊨^{real}_B c`. -/
def ValidOnG (B : CtxG → Prop) (c : ClaimG) : Prop :=
  ∀ M x, RealizableG M x → B x → SatisfiesG M x c

theorem stepG_mass_identity (M : ModelG) (x : CtxG) :
    massG (stepG M x) = massG x - M.deltaG := by
  dsimp [massG, stepG]
  omega

theorem stepG_preserves_nonneg {M : ModelG} {x : CtxG} (hFeas : StepFeasibleG M x) :
    NonnegCtxG (stepG M x) := by
  rcases hFeas with ⟨⟨hu1, hu2⟩, h1, h2, _⟩
  dsimp [NonnegCtxG, stepG]
  omega

/-- Canonical source dissipation law holds across all of `B_g`. -/
theorem g_dissip_valid_on_Bg : ValidOnG Bg .dissipStep := by
  intro M x hReal _
  rcases hReal with ⟨⟨_, hDelta, _⟩, _⟩
  dsimp [SatisfiesG]
  have hId := stepG_mass_identity M x
  omega

/-- Restricted mass-band claim `S_g ≤ 10` holds across `B_g^{≤10}` (`F-PCT0-12`). -/
theorem g_le10_valid_on_BgLe10 : ValidOnG BgLe10 (.massAtMost 10) := by
  intro _ x _ hB
  exact hB.2

/-- `F-PCT0-12`: `S_g ≤ 10` is NOT valid across baseline `B_g` (concrete non-vacuous witness `(1,2,15)` at `(4,7)`). -/
theorem g_le10_not_valid_on_Bg :
    (RealizableG ⟨1, 2, 15⟩ ⟨4, 7⟩ ∧ Bg ⟨4, 7⟩ ∧ ¬ SatisfiesG ⟨1, 2, 15⟩ ⟨4, 7⟩ (.massAtMost 10)) ∧
    ¬ ValidOnG Bg (.massAtMost 10) := by
  have hReal : RealizableG ⟨1, 2, 15⟩ ⟨4, 7⟩ := by
    dsimp [RealizableG, AdmissibleG, StepFeasibleG, NonnegCtxG, massG]
    decide
  have hBg : Bg ⟨4, 7⟩ := by
    dsimp [Bg, NonnegCtxG, massG]
    decide
  have hNotSat : ¬ SatisfiesG ⟨1, 2, 15⟩ ⟨4, 7⟩ (.massAtMost 10) := by
    dsimp [SatisfiesG, massG]
    decide
  refine ⟨⟨hReal, hBg, hNotSat⟩, ?_⟩
  intro hValid
  exact hNotSat (hValid ⟨1, 2, 15⟩ ⟨4, 7⟩ hReal hBg)

end ProofspaceOmegaPCT0.GenG

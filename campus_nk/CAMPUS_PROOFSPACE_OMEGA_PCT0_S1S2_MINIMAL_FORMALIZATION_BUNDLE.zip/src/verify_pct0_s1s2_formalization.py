#!/usr/bin/env python3
"""Scoped Verifier, TransDeps Graph Auditor & Cleanroom Lean 4.33.1 Harness for `PCT-S1/S2`.

Implements all 6 items of the Independent Tribunal's Scoped Formalization Recommendation plus
mandatory guards `F-PCT0-15` (Commit Authority Separation) and `F-PCT0-16` (Model vs Incidence Emptiness),
and applies the `F-XH0-01` target-theorem semantic mutation verification discipline:
  1. `self_contained_offline_verdict`:
     - Byte-exact SHA-256 verification of embedded frozen `T105`, `P0-R2`, and `P0-XH0` receipts (`0 B` modified).
     - Static hygiene + zero-import audit on `GenG.lean` and `GenH.lean`.
     - Independent Python reference oracle verifying `P-PCT0-01..05` (`04A`, `04B-1`, `04B-2`) and
       `M-PCT0-01..10` (`F-PCT0-10`, `F-PCT0-12..16`).
  2. `lean_cleanroom_verdict`:
     - Cleanroom compilation of all 7 `ProofspaceOmegaPCT0` modules + Clean-Sheet Probe under
       pinned `Lean 4.33.1` (`commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6`).
     - Kernel `#print axioms` audit on 23 core theorems (`Classical.choice == 0`, `sorry == 0`).
     - Kernel `Lean.Environment` BFS `TransDeps` constant-dependency graph disjointness audit (`F-PCT0-11`).
     - 5 live semantic system-definition mutations (`M-PCT0-LEAN-01`..`05`) verified to parse cleanly
       (`0` syntax errors) and fail specifically inside their pre-registered target theorem line spans.
  3. `external_host_ancestors_verdict`:
     - Optional read-only check of host-mounted `#40`, `#46`, `E1_AUX`, `T104`, `T105`, and `P0 v1~XH0`
       archives (`9` artifacts, `0` modified bytes). Held as `EVIDENCE_UNAVAILABLE` when unmounted.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple
import zipfile

STAGE_ID = "CAMPUS_PROOFSPACE_OMEGA_PCT0_S1S2_MINIMAL_LEAN_FORMALIZATION"
GOVERNANCE_SCOPE_TOKEN = (
    "CAMPUS_PROOFSPACE_OMEGA_PCT0_S1S2_STATIC_CORRECTIONS_12_14_ACCEPTED__"
    "MINIMAL_LEAN_FORMALIZATION_SCOPED_EXECUTED__F_PCT0_15_16_MANDATORY_GUARDS_ENFORCED__"
    "PCT_S3_S4_HELD__T105_P0_XH0_FROZEN__P1_E1D_RELEASE47_NOT_AUTHORIZED"
)

PINNED_LEAN_VERSION = "4.33.1"
PINNED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"
ALLOWED_LEAN_AXIOMS = frozenset({"propext", "Quot.sound"})

STATUS_FAILED = "FAILED_INVALID"
STATUS_EVIDENCE_UNAVAILABLE = "EVIDENCE_UNAVAILABLE"
STATUS_SELF_CONTAINED_VERIFIED = "SELF_CONTAINED_OFFLINE_VERIFIED"
STATUS_LOCAL_CLEANROOM_VERIFIED = "LOCAL_CLEANROOM_VERIFIED"

POSET_RANK = {
    STATUS_FAILED: 0,
    STATUS_EVIDENCE_UNAVAILABLE: 1,
    STATUS_SELF_CONTAINED_VERIFIED: 2,
    STATUS_LOCAL_CLEANROOM_VERIFIED: 3,
}

EMBEDDED_FROZEN_RECEIPTS: Tuple[Tuple[str, str, str, int], ...] = (
    (
        "t105_closure_receipt_json",
        "T105_E1_CORE_CLOSURE_AND_FREEZE_RECEIPT.json",
        "cb03ec9ee02eb2fe666a918bd874fa0d1258191f5c3103e9ed29969129339dcb",
        6489,
    ),
    (
        "p0_r2_scoped_receipt_json",
        "P0_R2_SCOPED_REMEDIATION_RECEIPT.json",
        "a0e64bbd706cb7e0c917f2a69860368fab4b99164fa17edb0ddbece8d6bfb3eb",
        9062,
    ),
    (
        "p0_xh0_detached_receipt_json",
        "P0_XH0_DETACHED_QUALIFICATION_RECEIPT.json",
        "41d8eaa54305b69de88ce52d87ba8c2de06a6e8f2afe848255c0bd72bff6585c",
        2147,
    ),
)

EXTERNAL_HOST_ANCESTORS: Tuple[Tuple[str, str, str, int], ...] = (
    (
        "release_40_zip",
        "CAMPUS_NOESIS_OMEGA_KAPPA_STAGE1_0_PURE_TRUSTED_CHECKER_PACKAGE.zip",
        "93d9a02a84d6d91a36140de2c96cb362e26aa1b2c595ca3ac9562ddf8e3426bb",
        100029,
    ),
    (
        "release_46_zip",
        "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip",
        "4c42f12b605083d13228c02c84e12b4689cdf32be0f507041b6a36360eec4608",
        236214,
    ),
    (
        "e1_core_aux_zip",
        "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip",
        "38a055f39e259cac333b469bfb4602ed8b3859cb5f6bfa3e096a75be0200da39",
        190589,
    ),
    (
        "t104_qualification_pack_zip",
        "T104_INDEPENDENT_QUALIFICATION_EVIDENCE_PACK.zip",
        "71091172fbb4ba1ddccf05ea5694ed9df049057b5eeb8f7de97c199ce581f1b1",
        650086,
    ),
    (
        "t105_complete_bundle_zip",
        "T105_SUBMISSION_T104_AND_XH0_COMPLETE_EVIDENCE_BUNDLE.zip",
        "b78abf1c788b8d2c554f48562f218b81c48df8fee9e14175e9592f67d22f8aae",
        1359070,
    ),
    (
        "p0_v1_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_STATIC_FOUNDATION_BUNDLE.zip",
        "2d5076cd60f3e22b912d8e236880a472298336ebbde452486ca4556844e3da1f",
        55616,
    ),
    (
        "p0_t1_r1_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_T1_AND_R1_COMPLETE_BUNDLE.zip",
        "e17f719d761cd02d813fd778a723c5f934b837734c3c2cad1bfc13ca68c4a643",
        96081,
    ),
    (
        "p0_r2_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_R2_SCOPED_REMEDIATION_BUNDLE.zip",
        "f3a07777e9a067b0fa369fdddeacdca7df553c4a33ac4df8b387d02bd1f97a6b",
        183199,
    ),
    (
        "p0_xh0_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_XH0_COMPLETE_EVIDENCE_BUNDLE.zip",
        "e53c0b998ed7ad583f40ed467295399bcc9238f1f999c7a096a6eac247507174",
        239755,
    ),
)

ORDERED_PCT0_MODULES: Tuple[Tuple[str, str], ...] = (
    ("ProofspaceOmegaPCT0.GenG", "ProofspaceOmegaPCT0/GenG.lean"),
    ("ProofspaceOmegaPCT0.GenH", "ProofspaceOmegaPCT0/GenH.lean"),
    ("ProofspaceOmegaPCT0.TransportCore", "ProofspaceOmegaPCT0/TransportCore.lean"),
    ("ProofspaceOmegaPCT0.AuthorityAndAdmission", "ProofspaceOmegaPCT0/AuthorityAndAdmission.lean"),
    ("ProofspaceOmegaPCT0.ControlsAndCounterexamples", "ProofspaceOmegaPCT0/ControlsAndCounterexamples.lean"),
    ("ProofspaceOmegaPCT0.PCT0AxiomAudit", "ProofspaceOmegaPCT0/PCT0AxiomAudit.lean"),
    ("ProofspaceOmegaPCT0", "ProofspaceOmegaPCT0.lean"),
)

REQUIRED_23_PCT0_THEOREMS: Tuple[str, ...] = (
    "ProofspaceOmegaPCT0.GenG.g_dissip_valid_on_Bg",
    "ProofspaceOmegaPCT0.GenG.g_le10_valid_on_BgLe10",
    "ProofspaceOmegaPCT0.GenG.g_le10_not_valid_on_Bg",
    "ProofspaceOmegaPCT0.GenH.stepH_mass_identity",
    "ProofspaceOmegaPCT0.GenH.f16_model_inconsistency_empty",
    "ProofspaceOmegaPCT0.step_commutes",
    "ProofspaceOmegaPCT0.pct_thm_s1s2",
    "ProofspaceOmegaPCT0.f14_pure_transport_novelty_reward_zero",
    "ProofspaceOmegaPCT0.f15_canonical_admissible_iff_three_gates",
    "ProofspaceOmegaPCT0.f15_checker_alone_without_commit_grant_rejected",
    "ProofspaceOmegaPCT0.f15_canonical_admissible_entails_semantic_truth",
    "ProofspaceOmegaPCT0.f15_consumed_grant_replay_rejected",
    "ProofspaceOmegaPCT0.Controls.f13_reduceModel_MhStar_exact",
    "ProofspaceOmegaPCT0.Controls.p_pct0_02_joint_realizable_witness",
    "ProofspaceOmegaPCT0.Controls.pct0_s1s2_dissip_transport",
    "ProofspaceOmegaPCT0.Controls.p_pct0_04a_unidirectional_slack_and_band_transport",
    "ProofspaceOmegaPCT0.Controls.p_pct0_04b_1_dynamical_comparison_non_equiv",
    "ProofspaceOmegaPCT0.Controls.p_pct0_04b_2_admissible_band_comparison_non_equiv",
    "ProofspaceOmegaPCT0.Controls.pct0_s1s2_canonical_admissible",
    "ProofspaceOmegaPCT0.Controls.m_pct0_03_f16_empty_model_vs_empty_incidence_separated",
    "ProofspaceOmegaPCT0.Controls.m_pct0_04_bad_translator_violates_T3",
    "ProofspaceOmegaPCT0.Controls.m_pct0_10_f15_commit_authority_guards",
    "ProofspaceOmegaPCT0.Controls.pct0_three_distinct_evidences_separation",
)

FORBIDDEN_LEAN_PATTERNS = (
    re.compile(r"\bsorry\b"),
    re.compile(r"\badmit\b"),
    re.compile(r"(?m)^\s*axiom\s+"),
    re.compile(r"(?m)^\s*opaque\s+"),
    re.compile(r"\bnative_decide\b"),
    re.compile(r"\bofReduceBool\b"),
    re.compile(r"\btrustCompiler\b"),
    re.compile(r"\bimplemented_by\b"),
    re.compile(r"@\[[^\]]*\bextern\b"),
    re.compile(r"\bunsafe\b"),
    re.compile(r"(?m)^\s*partial\s+def\b"),
)

SYNTAX_ERROR_MARKERS = (
    "unexpected token",
    "expected token",
    "unknown identifier",
    "unterminated comment",
    "invalid syntax",
)

TRANSDEPS_AND_SMAP_INSPECTOR = r"""import ProofspaceOmegaPCT0
import pct0_independent_clean_sheet_probe
import Lean

open Lean

def isPCT0Target : Name → Bool
  | .anonymous => false
  | .str .anonymous s => s == "ProofspaceOmegaPCT0" || s == "PCT0IndependentCleanSheetProbe"
  | .str p _ => isPCT0Target p
  | .num p _ => isPCT0Target p

def isPurePCT0Namespace : Name → Bool
  | .anonymous => false
  | .str .anonymous s => s == "ProofspaceOmegaPCT0"
  | .str p _ => isPurePCT0Namespace p
  | .num p _ => isPurePCT0Namespace p

def hasPrefix2 (a b : String) : Name → Bool
  | .str (.str .anonymous s1) s2 => s1 == a && s2 == b
  | .str p _ => hasPrefix2 a b p
  | .num p _ => hasPrefix2 a b p
  | _ => false

def isGenGConst (nm : Name) : Bool := hasPrefix2 "ProofspaceOmegaPCT0" "GenG" nm
def isGenHConst (nm : Name) : Bool := hasPrefix2 "ProofspaceOmegaPCT0" "GenH" nm
def isTransportOrAdmissionConst (nm : Name) : Bool :=
  isPurePCT0Namespace nm && !(isGenGConst nm) && !(isGenHConst nm)

def computeTransDeps (env : Environment) (seeds : List Name) : List Name × NameSet × Bool := Id.run do
  let mut enqueued : NameSet := {}
  let mut queue : Array Name := #[]
  for s in seeds do
    if !enqueued.contains s then
      enqueued := enqueued.insert s
      queue := queue.push s
  let mut idx : Nat := 0
  for _ in [0 : 150000] do
    if h : idx < queue.size then
      let cur := queue[idx]
      idx := idx + 1
      if let some ci := env.find? cur then
        for dep in ci.getUsedConstantsAsSet.toList do
          if !enqueued.contains dep then
            enqueued := enqueued.insert dep
            queue := queue.push dep
    else
      break
  return (queue.toList, enqueued, decide (queue.size ≤ idx))

#eval show MetaM Unit from do
  let env ← getEnv
  let allEntries := env.constants.map₁.toList ++ env.constants.map₂.toList
  let mut consts : Nat := 0
  let mut thms : Nat := 0
  let mut sorryCnt : Nat := 0
  let mut userAxCnt : Nat := 0
  let mut opaqueCnt : Nat := 0
  let mut reduceBoolCnt : Nat := 0
  let mut choiceCnt : Nat := 0
  let mut seedsG : List Name := []
  let mut seedsH : List Name := []
  let mut transportCnt : Nat := 0

  for (nm, ci) in allEntries do
    if isGenGConst nm then seedsG := nm :: seedsG
    if isGenHConst nm then seedsH := nm :: seedsH
    if isTransportOrAdmissionConst nm then transportCnt := transportCnt + 1
    if isPCT0Target nm then
      consts := consts + 1
      match ci with
      | .thmInfo _ => thms := thms + 1
      | .axiomInfo _ => userAxCnt := userAxCnt + 1
      | .opaqueInfo _ => opaqueCnt := opaqueCnt + 1
      | _ => pure ()
      for u in ci.getUsedConstantsAsSet.toList do
        if u == ``sorryAx then sorryCnt := sorryCnt + 1
        if u == ``Classical.choice then choiceCnt := choiceCnt + 1
        if u == ``Lean.ofReduceBool || u == ``Lean.trustCompiler then
          reduceBoolCnt := reduceBoolCnt + 1

  let (listG, _setG, satG) := computeTransDeps env seedsG
  let (listH, setH, satH) := computeTransDeps env seedsH

  let gTransInter := (listG.filter isTransportOrAdmissionConst).length
  let gHInter := (listG.filter isGenHConst).length
  let hTransInter := (listH.filter isTransportOrAdmissionConst).length
  let hGInter := (listH.filter isGenGConst).length
  let sharedUserGH := (listG.filter (fun n => isPurePCT0Namespace n && setH.contains n)).length

  IO.println s!"PCT0_SMAP|constants={consts}|theorems={thms}|sorry={sorryCnt}|userAxioms={userAxCnt}|opaque={opaqueCnt}|reduceBool={reduceBoolCnt}|classicalChoice={choiceCnt}"
  IO.println s!"PCT0_TRANSDEPS|seedsG={seedsG.length}|seedsH={seedsH.length}|transportConsts={transportCnt}|closureG={listG.length}|closureH={listH.length}|satG={(if satG then 1 else 0)}|satH={(if satH then 1 else 0)}|interGTransport={gTransInter}|interGH={gHInter}|interHTransport={hTransInter}|interHG={hGInter}|sharedUserGH={sharedUserGH}"
"""


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def meet_poset(statuses: Iterable[str]) -> str:
    items = list(statuses)
    if not items:
        return STATUS_EVIDENCE_UNAVAILABLE
    for s in items:
        if s not in POSET_RANK:
            raise ValueError(f"Unknown status token: {s}")
    if STATUS_FAILED in items:
        return STATUS_FAILED
    if STATUS_EVIDENCE_UNAVAILABLE in items:
        return STATUS_EVIDENCE_UNAVAILABLE
    return min(items, key=lambda s: POSET_RANK[s])


def strip_lean_comments(src: str) -> str:
    out: List[str] = []
    i, n, depth, in_str = 0, len(src), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if src.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if src.startswith("--", i):
                while i < n and src[i] != "\n":
                    i += 1
                continue
            if src[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(src[i])
            i += 1
        elif in_str:
            if src[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if src[i] == '"':
                in_str = False
            i += 1
        else:
            if src.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if src.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if src[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def find_lean_exe() -> Optional[Path]:
    override = os.environ.get("PCT0_LEAN_BIN")
    if override is not None:
        if override == "":
            return None
        p = Path(override)
        return p if p.is_file() else None
    w = shutil.which("lean")
    if w:
        return Path(w)
    cand = Path.home() / ".elan" / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    return cand if cand.is_file() else None


def find_declaration_line_span(lean_src: str, decl_name: str) -> Tuple[int, int]:
    lines = lean_src.splitlines()
    start_ln = -1
    decl_re = re.compile(rf"^\s*(?:theorem|def)\s+{re.escape(decl_name)}\b")
    stop_re = re.compile(r"^\s*(?:theorem|def|structure|inductive|end)\s+")
    for idx, ln in enumerate(lines, start=1):
        if start_ln == -1:
            if decl_re.match(ln):
                start_ln = idx
        else:
            if stop_re.match(ln):
                return (start_ln, idx - 1)
    if start_ln == -1:
        raise ValueError(f"Declaration `{decl_name}` not found")
    return (start_ln, len(lines))


# =============================================================================
# Independent Python Reference Oracle for PCT-S1/S2 & F-PCT0-10..16
# =============================================================================

def reduce_model_py(mh: Tuple[int, int, int, int, int, int]) -> Tuple[int, int, int]:
    alpha_h, _beta_h, d2a, d2b, xi_ext, cap_h = mh
    return (alpha_h, d2a + d2b - xi_ext, cap_h)


def reduce_ctx_py(xh: Tuple[int, int, int]) -> Tuple[int, int]:
    v1, v2a, v2b = xh
    return (v1, v2a + v2b)


def step_g_py(mg: Tuple[int, int, int], xg: Tuple[int, int]) -> Tuple[int, int]:
    ag, dg, _cg = mg
    u1, u2 = xg
    return (u1 - ag, u2 + ag - dg)


def step_h_py(mh: Tuple[int, int, int, int, int, int], xh: Tuple[int, int, int]) -> Tuple[int, int, int]:
    ah, bh, d2a, d2b, xi, _ch = mh
    v1, v2a, v2b = xh
    return (v1 - ah, v2a + ah - bh - d2a, v2b + bh - d2b + xi)


def canonical_admissible_py(
    ledger: Mapping[str, Any],
    cert_verified_for_cand: bool,
    grant: Optional[Mapping[str, Any]],
    cand: Mapping[str, Any],
) -> bool:
    # Deliberately ignores cand.get("untrustedClaimedAdmissible") and any novelty reward!
    if not cert_verified_for_cand:
        return False
    policy_ok = (
        cand["targetGenId"] == ledger["activeGenId"]
        and cand["targetSpecHash"] == ledger["activeSpecHash"]
        and cand["eligibility"] == "ELIGIBLE_CANDIDATE"
        and cand["formalRealizability"] == "FORMAL_WITNESS_VERIFIED"
        and (ledger["hasExternalEmpiricalLedger"] or cand["empiricalStatus"] == "UNASSESSED")
        and (cand["candidateId"] not in ledger["committedCandidateIds"])
    )
    if not policy_ok or grant is None:
        return False
    commit_auth_ok = (
        grant["grantId"] > 0
        and (grant["grantId"] not in ledger["consumedGrantIds"])
        and grant["issuerAuthorityId"] == ledger["trustedAuthorityId"]
        and grant["authoritySeal"] == ledger["expectedAuthoritySeal"]
        and grant["authorizedCandidateId"] == cand["candidateId"]
        and grant["authorizedTargetGenId"] == ledger["activeGenId"]
        and grant["authorizedSpecHash"] == ledger["activeSpecHash"]
        and grant["issuedAtEpoch"] == ledger["ledgerEpoch"]
    )
    return commit_auth_ok


def compute_novelty_reward_py(has_exclusive_gen_h_extension: bool, untrusted_claim: int) -> int:
    _ = untrusted_claim
    return 1 if has_exclusive_gen_h_extension else 0


# =============================================================================
# Track 1: Self-Contained Offline Verification
# =============================================================================

def run_self_contained_offline_audit(pct0_root: Path) -> Dict[str, Any]:
    ro_dir = pct0_root / "readonly_frozen_receipts"
    frozen_records: Dict[str, Any] = {}
    for key, fname, exp_sha, exp_sz in EMBEDDED_FROZEN_RECEIPTS:
        fp = ro_dir / fname
        if not fp.is_file():
            return {"verdict": STATUS_FAILED, "error": f"Missing frozen receipt: {fname}"}
        raw = fp.read_bytes()
        act_sha = sha256_hex(raw)
        act_sz = len(raw)
        if act_sha != exp_sha or act_sz != exp_sz:
            return {"verdict": STATUS_FAILED, "error": f"Digest mismatch on {fname}"}
        frozen_records[key] = {
            "filename": fname,
            "sha256": act_sha,
            "size_bytes": act_sz,
            "modified_bytes": 0,
        }

    lean_digests: Dict[str, str] = {}
    zero_import_checked: Dict[str, bool] = {}
    for mod_name, rel in ORDERED_PCT0_MODULES:
        fp = pct0_root / "lean_pct0" / rel
        if not fp.is_file():
            return {"verdict": STATUS_FAILED, "error": f"Missing Lean file: {rel}"}
        stripped = strip_lean_comments(fp.read_text(encoding="utf-8"))
        for pat in FORBIDDEN_LEAN_PATTERNS:
            if pat.search(stripped):
                return {"verdict": STATUS_FAILED, "error": f"Forbidden token `{pat.pattern}` in {rel}"}
        if mod_name in ("ProofspaceOmegaPCT0.GenG", "ProofspaceOmegaPCT0.GenH"):
            has_import = bool(re.search(r"(?m)^\s*import\s+", stripped))
            if has_import:
                return {"verdict": STATUS_FAILED, "error": f"{mod_name} must have zero imports"}
            zero_import_checked[mod_name] = True
        lean_digests[mod_name] = sha256_hex(fp.read_bytes())

    probe_fp = pct0_root / "probes" / "pct0_independent_clean_sheet_probe.lean"
    if not probe_fp.is_file():
        return {"verdict": STATUS_FAILED, "error": "Missing clean-sheet probe"}
    probe_stripped = strip_lean_comments(probe_fp.read_text(encoding="utf-8"))
    for pat in FORBIDDEN_LEAN_PATTERNS:
        if pat.search(probe_stripped):
            return {"verdict": STATUS_FAILED, "error": f"Forbidden token `{pat.pattern}` in probe"}
    if re.search(r"(?m)^\s*import\s+", probe_stripped):
        return {"verdict": STATUS_FAILED, "error": "Clean-sheet probe must have zero imports"}
    lean_digests["PCT0IndependentCleanSheetProbe"] = sha256_hex(probe_fp.read_bytes())

    # Python Independent Reference Checks for F-PCT0-10..16 & Positive/Negative Controls
    mh_star = (1, 1, 1, 1, 0, 15)
    xh_star = (4, 2, 2)
    f13_exact = reduce_model_py(mh_star) == (1, 2, 15)
    comm_ok = reduce_ctx_py(step_h_py(mh_star, xh_star)) == step_g_py(reduce_model_py(mh_star), reduce_ctx_py(xh_star))

    # F-PCT0-12 & 04B-2 check at (4, 4, 3)
    xh_sharp = (4, 4, 3)
    xg_sharp = reduce_ctx_py(xh_sharp)  # (4, 7)
    f12_and_04b2_ok = (
        xg_sharp == (4, 7)
        and sum(xg_sharp) == 11
        and (sum(xg_sharp) <= 12)
        and not (sum(xg_sharp) <= 10)
        and (sum(xh_sharp) <= 12)
    )

    # 04B-1 dynamical comparison witness
    mh_amb = (0, 0, 0, 0, 1, 15)
    xh_amb = (2, 2, 2)
    p04b1_ok = (
        reduce_model_py(mh_amb) == (0, -1, 15)
        and sum(step_h_py(mh_amb, xh_amb)) <= sum(xh_amb) + 2
        and not (sum(step_g_py(reduce_model_py(mh_amb), reduce_ctx_py(xh_amb))) <= sum(reduce_ctx_py(xh_amb)))
    )

    # M-PCT0-04 bad translator witness
    mh_bad = (1, 3, 1, 1, 0, 15)
    xh_bad = (2, 4, 1)
    m04_ok = (
        reduce_model_py(mh_bad) == (1, 2, 15)
        and sum(step_g_py(reduce_model_py(mh_bad), reduce_ctx_py(xh_bad))) <= sum(reduce_ctx_py(xh_bad))
        and not (step_h_py(mh_bad, xh_bad)[2] <= xh_bad[2])
    )

    # F-PCT0-16 separation: empty model set vs non-empty marginals + empty joint incidence
    f16_model_empty = not any((cap == 8 and cap >= 12) for cap in (8, 12, 15))
    low_cap_marginal_ok = sum((2, 2, 2)) <= 8 and step_h_py((1, 1, 1, 1, 0, 8), (2, 2, 2)) == (1, 1, 2)
    ge10_marginal_ok = 10 <= sum((4, 3, 3)) <= 12
    f16_joint_empty = not any(
        (v1 + v2a + v2b <= 8 and v1 + v2a + v2b >= 10)
        for v1 in range(0, 9)
        for v2a in range(0, 9)
        for v2b in range(0, 9)
    )
    f16_ok = f16_model_empty and low_cap_marginal_ok and ge10_marginal_ok and f16_joint_empty

    # F-PCT0-10, F-PCT0-14, F-PCT0-15 gate & replay checks
    ledger0 = {
        "activeGenId": 2,
        "activeSpecHash": 20261119,
        "ledgerEpoch": 7,
        "trustedAuthorityId": 900,
        "expectedAuthoritySeal": 778899,
        "hasExternalEmpiricalLedger": False,
        "consumedGrantIds": [],
        "committedCandidateIds": [],
    }
    cand0 = {
        "candidateId": 101,
        "targetGenId": 2,
        "targetSpecHash": 20261119,
        "eligibility": "ELIGIBLE_CANDIDATE",
        "formalRealizability": "FORMAL_WITNESS_VERIFIED",
        "empiricalStatus": "UNASSESSED",
        "untrustedClaimedAdmissible": False,
    }
    grant0 = {
        "grantId": 5001,
        "issuerAuthorityId": 900,
        "authoritySeal": 778899,
        "authorizedCandidateId": 101,
        "authorizedTargetGenId": 2,
        "authorizedSpecHash": 20261119,
        "issuedAtEpoch": 7,
    }
    p05_ok = canonical_admissible_py(ledger0, True, grant0, cand0) and (compute_novelty_reward_py(False, 0) == 0)
    m08_ok = not canonical_admissible_py(ledger0, True, grant0, {**cand0, "empiricalStatus": "SUPPORTED"})
    m09_ok = (not canonical_admissible_py(ledger0, False, grant0, {**cand0, "untrustedClaimedAdmissible": True})) and (
        compute_novelty_reward_py(False, 1) == 0
    )
    m10_f15_ok = (
        not canonical_admissible_py(ledger0, True, None, cand0)
        and not canonical_admissible_py(ledger0, True, {**grant0, "authoritySeal": 0}, cand0)
        and not canonical_admissible_py(ledger0, True, {**grant0, "authorizedCandidateId": 999}, cand0)
        and not canonical_admissible_py(ledger0, True, {**grant0, "issuedAtEpoch": 6}, cand0)
        and not canonical_admissible_py({**ledger0, "consumedGrantIds": [5001]}, True, grant0, cand0)
    )

    all_oracle_ok = (
        f13_exact
        and comm_ok
        and f12_and_04b2_ok
        and p04b1_ok
        and m04_ok
        and f16_ok
        and p05_ok
        and m08_ok
        and m09_ok
        and m10_f15_ok
    )
    if not all_oracle_ok:
        return {"verdict": STATUS_FAILED, "error": "Python independent oracle check failed"}

    return {
        "verdict": STATUS_SELF_CONTAINED_VERIFIED,
        "embedded_frozen_receipts": frozen_records,
        "zero_import_semantics_verified": zero_import_checked,
        "pct0_source_sha256": lean_digests,
        "offline_oracle_controls": {
            "F_PCT0_13_exact_model_reduction_1_2_15": f13_exact and comm_ok,
            "F_PCT0_12_and_P04B2_domain_separation": f12_and_04b2_ok,
            "P_PCT0_04B1_dynamical_non_equiv": p04b1_ok,
            "M_PCT0_04_bad_subcompartment_translator_rejected": m04_ok,
            "F_PCT0_16_empty_model_vs_empty_incidence_separated": f16_ok,
            "P_PCT0_05_canonical_admissible_with_zero_novelty_reward": p05_ok,
            "M_PCT0_08_empirical_status_conflation_blocked": m08_ok,
            "M_PCT0_09_unverified_proof_and_novelty_inflation_blocked": m09_ok,
            "M_PCT0_10_F15_checker_vs_commit_authority_separated": m10_f15_ok,
        },
    }


# =============================================================================
# Track 2: Cleanroom Lean 4.33.1 Compilation, TransDeps, SMap & Semantic Mutations
# =============================================================================

def _run_lean_pct0_mutation(
    lean_bin: Path,
    lean_pct0_dir: Path,
    mut_id: str,
    rel_mut_file: str,
    old_str: str,
    new_str: str,
    expected_failing_module_idx: int,
    expected_target_theorem: str,
) -> Dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="pct0_mut_") as tmp:
        tp = Path(tmp)
        scp = tp / "lean_pct0"
        bld = tp / "bld"
        shutil.copytree(lean_pct0_dir, scp)
        (bld / "ProofspaceOmegaPCT0").mkdir(parents=True, exist_ok=True)

        tf = scp / rel_mut_file
        orig = tf.read_text(encoding="utf-8")
        mut = orig.replace(old_str, new_str, 1)
        assert mut != orig, f"[{mut_id}] mutation snippet not found in {rel_mut_file}"
        tf.write_text(mut, encoding="utf-8")

        _, fail_rel = ORDERED_PCT0_MODULES[expected_failing_module_idx]
        fail_src = (scp / fail_rel).read_text(encoding="utf-8")
        start_ln, end_ln = find_declaration_line_span(fail_src, expected_target_theorem)

        env = dict(os.environ)
        env["LEAN_PATH"] = str(bld)

        # Every prerequisite module strictly before `expected_failing_module_idx` MUST compile cleanly!
        for idx in range(expected_failing_module_idx):
            mod_nm, rel = ORDERED_PCT0_MODULES[idx]
            proc = subprocess.run(
                [str(lean_bin), "-o", str(bld / Path(rel).with_suffix(".olean")), rel],
                cwd=str(scp),
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            if proc.returncode != 0:
                return {
                    "id": mut_id,
                    "caught_semantically": False,
                    "reason": f"Prerequisite module {mod_nm} failed unexpectedly",
                    "output": (proc.stdout or "") + (proc.stderr or ""),
                }

        # Now compile the target module where the theorem must reject the mutated system definition
        fail_mod_nm, fail_mod_rel = ORDERED_PCT0_MODULES[expected_failing_module_idx]
        proc = subprocess.run(
            [str(lean_bin), "-o", str(bld / Path(fail_mod_rel).with_suffix(".olean")), fail_mod_rel],
            cwd=str(scp),
            capture_output=True,
            text=True,
            env=env,
            check=False,
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        low = out.lower()
        has_syntax_err = any(m in low for m in SYNTAX_ERROR_MARKERS)
        err_lines = [int(m.group(1)) for m in re.finditer(r":(\d+):\d+:\s*error:", out)]
        first_err_ln = err_lines[0] if err_lines else -1
        in_target_span = (start_ln <= first_err_ln <= end_ln)
        caught_semantically = (proc.returncode != 0) and (not has_syntax_err) and in_target_span

        return {
            "id": mut_id,
            "mutated_file": rel_mut_file,
            "failing_module": fail_mod_nm,
            "expected_target_theorem": expected_target_theorem,
            "target_theorem_line_span": [start_ln, end_ln],
            "first_error_line": first_err_ln,
            "parse_ok_zero_syntax_errors": not has_syntax_err,
            "failed_in_expected_target_theorem": in_target_span,
            "exit_code": proc.returncode,
            "caught_semantically": caught_semantically,
        }


def run_lean_cleanroom_and_mutations(pct0_root: Path) -> Dict[str, Any]:
    lean_bin = find_lean_exe()
    if lean_bin is None:
        return {
            "verdict": STATUS_EVIDENCE_UNAVAILABLE,
            "reason": "Lean 4.33.1 binary not installed in current environment; held per 104-F0 firewall.",
        }

    ver = subprocess.run([str(lean_bin), "--version"], capture_output=True, text=True, check=False)
    ver_out = (ver.stdout or "") + (ver.stderr or "")
    if PINNED_LEAN_VERSION not in ver_out or PINNED_LEAN_COMMIT not in ver_out:
        return {"verdict": STATUS_FAILED, "error": f"Toolchain mismatch: {ver_out.strip()}"}

    lean_pct0_dir = pct0_root / "lean_pct0"
    probe_file = pct0_root / "probes" / "pct0_independent_clean_sheet_probe.lean"

    with tempfile.TemporaryDirectory(prefix="pct0_cleanroom_") as tmp:
        tp = Path(tmp)
        scp = tp / "lean_pct0"
        bld = tp / "build"
        shutil.copytree(lean_pct0_dir, scp)
        shutil.copy2(probe_file, scp / "pct0_independent_clean_sheet_probe.lean")
        (bld / "ProofspaceOmegaPCT0").mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["LEAN_PATH"] = str(bld)

        axiom_raw = ""
        for mod_name, rel in ORDERED_PCT0_MODULES:
            proc = subprocess.run(
                [str(lean_bin), "-o", str(bld / Path(rel).with_suffix(".olean")), rel],
                cwd=str(scp),
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            if proc.returncode != 0:
                return {"verdict": STATUS_FAILED, "failed_module": mod_name, "stderr": proc.stdout + proc.stderr}
            if mod_name == "ProofspaceOmegaPCT0.PCT0AxiomAudit":
                axiom_raw = proc.stdout

        p_proc = subprocess.run(
            [
                str(lean_bin),
                "-o",
                str(bld / "pct0_independent_clean_sheet_probe.olean"),
                "pct0_independent_clean_sheet_probe.lean",
            ],
            cwd=str(scp),
            capture_output=True,
            text=True,
            env=env,
            check=False,
        )
        if p_proc.returncode != 0:
            return {
                "verdict": STATUS_FAILED,
                "failed_module": "pct0_independent_clean_sheet_probe",
                "stderr": p_proc.stdout + p_proc.stderr,
            }

        thm_axioms: Dict[str, List[str]] = {}
        for m in re.finditer(
            r"'([^']+)'\s+(?:(does not depend on any axioms)|depends on axioms:\s*\[([^\]]+)\])",
            axiom_raw,
            flags=re.DOTALL,
        ):
            tnm = m.group(1).strip()
            if m.group(2) is not None:
                thm_axioms[tnm] = []
            else:
                axs = [a.strip() for a in m.group(3).replace("\n", " ").split(",") if a.strip()]
                for ax in axs:
                    if ax not in ALLOWED_LEAN_AXIOMS:
                        return {"verdict": STATUS_FAILED, "error": f"Disallowed axiom `{ax}` on `{tnm}`"}
                thm_axioms[tnm] = axs

        missing = [t for t in REQUIRED_23_PCT0_THEOREMS if t not in thm_axioms]
        if missing:
            return {"verdict": STATUS_FAILED, "error": f"Missing audited PCT0 theorems: {missing}"}

        insp_path = scp / "PCT0TransDepsAndSMapInspector.lean"
        insp_path.write_text(TRANSDEPS_AND_SMAP_INSPECTOR, encoding="utf-8")
        insp = subprocess.run(
            [str(lean_bin), "PCT0TransDepsAndSMapInspector.lean"],
            cwd=str(scp),
            capture_output=True,
            text=True,
            env=env,
            check=False,
        )
        if insp.returncode != 0:
            return {"verdict": STATUS_FAILED, "error": f"Inspector failed: {insp.stdout} {insp.stderr}"}

        smap_ln = next((ln.strip() for ln in insp.stdout.splitlines() if ln.startswith("PCT0_SMAP|")), "")
        tdep_ln = next((ln.strip() for ln in insp.stdout.splitlines() if ln.startswith("PCT0_TRANSDEPS|")), "")
        if not smap_ln or not tdep_ln:
            return {"verdict": STATUS_FAILED, "error": f"Missing inspector output lines: {insp.stdout}"}

        smap = {k: int(v) for k, v in (seg.split("=", 1) for seg in smap_ln.split("|")[1:])}
        tdeps = {k: int(v) for k, v in (seg.split("=", 1) for seg in tdep_ln.split("|")[1:])}

        if (
            smap["sorry"] != 0
            or smap["userAxioms"] != 0
            or smap["opaque"] != 0
            or smap["reduceBool"] != 0
            or smap["classicalChoice"] != 0
        ):
            return {"verdict": STATUS_FAILED, "error": f"SMap soundness violation: {smap}"}

        if (
            tdeps["satG"] != 1
            or tdeps["satH"] != 1
            or tdeps["interGTransport"] != 0
            or tdeps["interGH"] != 0
            or tdeps["interHTransport"] != 0
            or tdeps["interHG"] != 0
            or tdeps["sharedUserGH"] != 0
        ):
            return {"verdict": STATUS_FAILED, "error": f"TransDeps disjointness violation: {tdeps}"}

    # 5 Live Semantic System-Definition Mutations (Zero theorem statements touched!)
    m1 = _run_lean_pct0_mutation(
        lean_bin,
        lean_pct0_dir,
        "M_PCT0_LEAN_01",
        "ProofspaceOmegaPCT0/GenH.lean",
        "M.xiExt ≤ 0 ∧",
        "M.xiExt ≤ 5 ∧",
        4,
        "pct0_s1s2_dissip_transport",
    )
    m2 = _run_lean_pct0_mutation(
        lean_bin,
        lean_pct0_dir,
        "M_PCT0_LEAN_02",
        "ProofspaceOmegaPCT0/ControlsAndCounterexamples.lean",
        "def tauExact : ClaimG → ClaimH\n  | .dissipStep   => .dissipStepSlack 0",
        "def tauExact : ClaimG → ClaimH\n  | .dissipStep   => .sub2bStepNonIncrease",
        4,
        "pct0_s1s2_dissip_transport",
    )
    m3 = _run_lean_pct0_mutation(
        lean_bin,
        lean_pct0_dir,
        "M_PCT0_LEAN_03",
        "ProofspaceOmegaPCT0/ControlsAndCounterexamples.lean",
        "def canonicalTargetRegion : CtxH → Prop :=\n  pullbackRegion Bg",
        "def canonicalTargetRegion : CtxH → Prop :=\n  fun x => pullbackRegion BgGe10 x ∧ massH x ≤ 8",
        4,
        "pct0_s1s2_canonical_admissible",
    )
    m4 = _run_lean_pct0_mutation(
        lean_bin,
        lean_pct0_dir,
        "M_PCT0_LEAN_04",
        "ProofspaceOmegaPCT0/AuthorityAndAdmission.lean",
        "  VerifiedProof certOpt K' &&\n  PCICPolicySatisfied Ph K' &&\n  CommitAuthorized Ph grantOpt K'",
        "  PCICPolicySatisfied Ph K' &&\n  CommitAuthorized Ph grantOpt K'",
        3,
        "f15_canonical_admissible_iff_three_gates",
    )
    m5 = _run_lean_pct0_mutation(
        lean_bin,
        lean_pct0_dir,
        "M_PCT0_LEAN_05",
        "ProofspaceOmegaPCT0/AuthorityAndAdmission.lean",
        "  VerifiedProof certOpt K' &&\n  PCICPolicySatisfied Ph K' &&\n  CommitAuthorized Ph grantOpt K'",
        "  VerifiedProof certOpt K' &&\n  PCICPolicySatisfied Ph K'",
        3,
        "f15_canonical_admissible_iff_three_gates",
    )

    lean_mutations = [m1, m2, m3, m4, m5]
    if not all(m["caught_semantically"] for m in lean_mutations):
        return {
            "verdict": STATUS_FAILED,
            "error": "One or more Lean semantic mutations were not caught in their target theorems",
            "lean_mutations": lean_mutations,
        }

    return {
        "verdict": STATUS_LOCAL_CLEANROOM_VERIFIED,
        "lean_toolchain": ver_out.strip(),
        "modules_plus_probe_compiled": len(ORDERED_PCT0_MODULES) + 1,
        "required_pct0_theorems_audited": len(REQUIRED_23_PCT0_THEOREMS),
        "zero_axiom_theorems_count": sum(1 for v in thm_axioms.values() if len(v) == 0),
        "classical_choice_theorems_count": sum(1 for v in thm_axioms.values() if "Classical.choice" in v),
        "standard_axioms_observed": sorted({ax for axs in thm_axioms.values() for ax in axs}),
        "smap_metrics": smap,
        "transdeps_audit": {
            "metrics": tdeps,
            "scope_boundary_note": (
                "Verifies kernel-level syntactic/definitional constant-closure disjointness "
                "(zero shared ProofspaceOmegaPCT0 constants between GenG and GenH, and zero transport "
                "dependencies in either semantics); does not claim cognitive/empirical independence "
                "against symmetric author modeling errors."
            ),
        },
        "theorem_axiom_footprints": thm_axioms,
        "live_lean_semantic_mutations": lean_mutations,
    }


# =============================================================================
# Track 3: Optional External Host Ancestor Mount Check (Read-Only, 0 B Modified)
# =============================================================================

def audit_external_host_ancestors(pct0_root: Path, allow_parent_search: bool = True) -> Dict[str, Any]:
    search_dirs: List[Path] = []
    if allow_parent_search:
        campus_nk = pct0_root.parent
        campus_root = campus_nk.parent
        search_dirs = [
            campus_root,
            campus_nk,
            campus_nk / "campus_proofspace_omega_p0_static_foundation",
            campus_nk / "campus_proofspace_omega_p0_t1_tribunal_and_r1_relock",
            campus_nk / "campus_proofspace_omega_p0_r2_scoped_remediation",
            campus_nk / "campus_proofspace_omega_p0_xh0_detached_qualification",
        ]
    records: Dict[str, Any] = {}
    statuses: List[str] = []
    for key, fname, exp_sha, exp_sz in EXTERNAL_HOST_ANCESTORS:
        found = next((d / fname for d in search_dirs if (d / fname).is_file()), None)
        if found is None:
            records[key] = {"filename": fname, "status": STATUS_EVIDENCE_UNAVAILABLE}
            statuses.append(STATUS_EVIDENCE_UNAVAILABLE)
            continue
        raw = found.read_bytes()
        ok = (sha256_hex(raw) == exp_sha) and (len(raw) == exp_sz)
        st = STATUS_LOCAL_CLEANROOM_VERIFIED if ok else STATUS_FAILED
        records[key] = {
            "filename": fname,
            "expected_sha256": exp_sha,
            "actual_sha256": sha256_hex(raw),
            "size_bytes": len(raw),
            "modified_bytes": 0 if ok else abs(len(raw) - exp_sz),
            "status": st,
        }
        statuses.append(st)
    return {
        "verdict": meet_poset(statuses),
        "records": records,
    }


def build_deterministic_bundle_zip(pct0_root: Path) -> Dict[str, Any]:
    zip_path = pct0_root / "CAMPUS_PROOFSPACE_OMEGA_PCT0_S1S2_MINIMAL_FORMALIZATION_BUNDLE.zip"
    include_rels: List[Path] = []
    for sub in ("lean_pct0", "probes", "readonly_frozen_receipts", "src", "tests", "ledger"):
        d = pct0_root / sub
        if d.is_dir():
            for p in sorted(d.rglob("*")):
                if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".pyc"):
                    include_rels.append(p.relative_to(pct0_root))
    readme = pct0_root / "README.md"
    if readme.is_file():
        include_rels.append(Path("README.md"))
    include_rels = sorted(include_rels, key=lambda p: p.as_posix())

    fixed_dt = (2026, 11, 19, 0, 0, 0)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in include_rels:
            zi = zipfile.ZipInfo(rel.as_posix(), date_time=fixed_dt)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, (pct0_root / rel).read_bytes())

    raw = zip_path.read_bytes()
    return {
        "bundle_path": str(zip_path),
        "size_bytes": len(raw),
        "sha256": sha256_hex(raw),
        "entry_count": len(include_rels),
    }


def execute_pct0_s1s2_audit(
    pct0_root: Path,
    write_ledger: bool = True,
    build_bundle: bool = False,
    allow_parent_search: bool = True,
) -> Dict[str, Any]:
    self_doc = run_self_contained_offline_audit(pct0_root)
    lean_doc = run_lean_cleanroom_and_mutations(pct0_root)
    ext_doc = audit_external_host_ancestors(pct0_root, allow_parent_search=allow_parent_search)

    def _norm(v: str) -> str:
        return STATUS_LOCAL_CLEANROOM_VERIFIED if v == STATUS_SELF_CONTAINED_VERIFIED else v

    pct0_core_verdict = meet_poset([_norm(self_doc["verdict"]), lean_doc["verdict"]])
    overall_poset_verdict = meet_poset([_norm(self_doc["verdict"]), lean_doc["verdict"], ext_doc["verdict"]])

    payload = {
        "schema": "CAMPUS_PROOFSPACE_OMEGA_PCT0_S1S2_MINIMAL_FORMALIZATION_RECEIPT_V1",
        "stage_id": STAGE_ID,
        "governance_scope_token": GOVERNANCE_SCOPE_TOKEN,
        "host_platform": f"{platform.system()}-{platform.release()}-{platform.machine()}",
        "verdicts": {
            "self_contained_offline_verdict": self_doc["verdict"],
            "lean_cleanroom_verdict": lean_doc["verdict"],
            "pct0_s1s2_core_verdict": pct0_core_verdict,
            "external_host_ancestors_verdict": ext_doc["verdict"],
            "overall_poset_verdict": overall_poset_verdict,
        },
        "explicit_holds_and_boundaries": {
            "empirical_instantiation_status": "UNASSESSED",
            "transdeps_independence_scope": "SYNTACTIC_AND_DEFINITIONAL_KERNEL_CONSTANT_CLOSURE_ONLY",
            "f_xh0_01_and_f_r2_01_03_lineage_holds": "PRESERVED_AS_HELD",
            "pct_s3_s4_holonomy_and_obstruction": "HELD",
            "p1_e1d_and_release_47": "NOT_AUTHORIZED",
            "t105_and_p0_ancestors": "IMMUTABLE_ZERO_MODIFIED_BYTES",
            "tribunal_final_acceptance_reserved": True,
        },
        "self_contained_offline_audit": self_doc,
        "lean_cleanroom_audit": lean_doc,
        "external_host_ancestors_audit": ext_doc,
    }
    payload_sha = sha256_hex(canonical_json(payload))
    receipt = {
        **payload,
        "seal": {
            "algorithm": "SHA-256",
            "canonicalization": "CAMPUS_CANONICAL_JSON_UTF8_SORTED_KEYS_V1",
            "payload_sha256": payload_sha,
        },
    }

    if write_ledger:
        ledger_dir = pct0_root / "ledger"
        ledger_dir.mkdir(parents=True, exist_ok=True)
        receipt_path = ledger_dir / "PCT0_S1S2_MINIMAL_FORMALIZATION_RECEIPT.json"
        receipt_bytes = json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n"
        receipt_path.write_bytes(receipt_bytes)

    if build_bundle:
        bundle_info = build_deterministic_bundle_zip(pct0_root)
        receipt["bundle_summary"] = bundle_info

    return receipt


def main() -> int:
    pct0_root = Path(__file__).resolve().parent.parent
    build_zip = "--build-bundle" in sys.argv
    no_write = "--no-write" in sys.argv
    res = execute_pct0_s1s2_audit(
        pct0_root,
        write_ledger=not no_write,
        build_bundle=build_zip,
        allow_parent_search=True,
    )
    print(
        json.dumps(
            {
                "verdicts": res["verdicts"],
                "payload_sha256": res["seal"]["payload_sha256"],
                "bundle_summary": res.get("bundle_summary"),
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0 if res["verdicts"]["pct0_s1s2_core_verdict"] == STATUS_LOCAL_CLEANROOM_VERIFIED else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Self-Contained Offline & Cleanroom Unit Tests for `PCT-S1/S2` Minimal Formalization.

Designed to succeed both:
  1. On a full Lean 4.33.1 cleanroom host (`4 PASS, 0 SKIP, 0 FAIL`), and
  2. Inside a completely isolated unzipped sandbox without Lean or external host archives
     (`3 PASS, 1 SKIP, 0 FAIL`), while strictly preserving `overall_poset_verdict == EVIDENCE_UNAVAILABLE`
     whenever Lean or external host mounts are absent (`104-F0` non-promotion firewall).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

PCT0_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PCT0_ROOT / "src"))

import verify_pct0_s1s2_formalization as vpct0  # noqa: E402


class TestPCT0S1S2MinimalFormalization(unittest.TestCase):
    def test_01_self_contained_offline_audit_and_controls(self) -> None:
        res = vpct0.run_self_contained_offline_audit(PCT0_ROOT)
        self.assertEqual(res["verdict"], vpct0.STATUS_SELF_CONTAINED_VERIFIED)
        self.assertTrue(res["zero_import_semantics_verified"]["ProofspaceOmegaPCT0.GenG"])
        self.assertTrue(res["zero_import_semantics_verified"]["ProofspaceOmegaPCT0.GenH"])
        for k, passed in res["offline_oracle_controls"].items():
            self.assertTrue(passed, f"Offline oracle control failed: {k}")

    def test_02_sealed_receipt_canonical_payload_integrity(self) -> None:
        receipt_fp = PCT0_ROOT / "ledger" / "PCT0_S1S2_MINIMAL_FORMALIZATION_RECEIPT.json"
        self.assertTrue(receipt_fp.is_file(), "Missing PCT0_S1S2_MINIMAL_FORMALIZATION_RECEIPT.json")
        doc = json.loads(receipt_fp.read_text(encoding="utf-8"))
        seal = doc["seal"]
        payload = {k: v for k, v in doc.items() if k not in ("seal", "bundle_summary")}
        recomputed = vpct0.sha256_hex(vpct0.canonical_json(payload))
        self.assertEqual(recomputed, seal["payload_sha256"])
        self.assertEqual(doc["explicit_holds_and_boundaries"]["empirical_instantiation_status"], "UNASSESSED")
        self.assertEqual(doc["explicit_holds_and_boundaries"]["pct_s3_s4_holonomy_and_obstruction"], "HELD")
        self.assertEqual(doc["explicit_holds_and_boundaries"]["p1_e1d_and_release_47"], "NOT_AUTHORIZED")

    def test_03_isolated_sandbox_simulation_never_promotes_missing_evidence(self) -> None:
        with tempfile.TemporaryDirectory(prefix="pct0_isolated_sbx_") as tmp:
            sbx = Path(tmp) / "isolated_pct0"
            shutil.copytree(
                PCT0_ROOT,
                sbx,
                ignore=shutil.ignore_patterns("*.zip", "__pycache__", "*.pyc"),
            )
            old_env = os.environ.get("PCT0_LEAN_BIN")
            os.environ["PCT0_LEAN_BIN"] = ""
            try:
                rep = vpct0.execute_pct0_s1s2_audit(
                    sbx,
                    write_ledger=False,
                    build_bundle=False,
                    allow_parent_search=False,
                )
            finally:
                if old_env is None:
                    os.environ.pop("PCT0_LEAN_BIN", None)
                else:
                    os.environ["PCT0_LEAN_BIN"] = old_env

            self.assertEqual(
                rep["verdicts"]["self_contained_offline_verdict"],
                vpct0.STATUS_SELF_CONTAINED_VERIFIED,
            )
            self.assertEqual(
                rep["verdicts"]["lean_cleanroom_verdict"],
                vpct0.STATUS_EVIDENCE_UNAVAILABLE,
            )
            self.assertEqual(
                rep["verdicts"]["external_host_ancestors_verdict"],
                vpct0.STATUS_EVIDENCE_UNAVAILABLE,
            )
            self.assertEqual(
                rep["verdicts"]["overall_poset_verdict"],
                vpct0.STATUS_EVIDENCE_UNAVAILABLE,
            )

    def test_04_lean_4331_cleanroom_transdeps_and_semantic_mutations(self) -> None:
        if vpct0.find_lean_exe() is None:
            self.skipTest("Lean 4.33.1 binary not installed in current sandbox; offline tracks verified.")
        lean_res = vpct0.run_lean_cleanroom_and_mutations(PCT0_ROOT)
        self.assertEqual(lean_res["verdict"], vpct0.STATUS_LOCAL_CLEANROOM_VERIFIED, msg=str(lean_res))
        self.assertEqual(lean_res["classical_choice_theorems_count"], 0)
        self.assertEqual(lean_res["smap_metrics"]["sorry"], 0)
        self.assertEqual(lean_res["smap_metrics"]["classicalChoice"], 0)
        td = lean_res["transdeps_audit"]["metrics"]
        self.assertEqual(td["interGTransport"], 0)
        self.assertEqual(td["interGH"], 0)
        self.assertEqual(td["interHTransport"], 0)
        self.assertEqual(td["interHG"], 0)
        self.assertEqual(td["sharedUserGH"], 0)
        self.assertEqual(len(lean_res["live_lean_semantic_mutations"]), 5)
        for m in lean_res["live_lean_semantic_mutations"]:
            self.assertTrue(m["caught_semantically"], msg=str(m))
            self.assertTrue(m["parse_ok_zero_syntax_errors"], msg=str(m))
            self.assertTrue(m["failed_in_expected_target_theorem"], msg=str(m))


if __name__ == "__main__":
    unittest.main(verbosity=2)

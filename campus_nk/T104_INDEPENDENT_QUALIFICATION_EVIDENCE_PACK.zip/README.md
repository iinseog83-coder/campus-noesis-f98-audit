# `CAMPUS-Ωλ-E1-T104-INDEPENDENT-QUALIFICATION`

Append-only, zero-shared-code qualification layer addressing the 104th Independent Tribunal findings (`F104-01`..`F104-05`) at their architectural root causes without modifying `OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip` or any frozen ancestor (`#1`–`#46`, `F99`, `F100`).

## Architectural Countermeasures
1. **`104-F0` Evidence-vs-Authority Poset (`src/t104_firewall_lattice.py`)**:
   - Eliminates untyped `"PASS"` promotion (`F104-01`): any missing/skipped gate yields `EVIDENCE_UNAVAILABLE`, forcing `QUALIFICATION_HELD`.
   - Enforces the `F104-04` naming firewall: `STATIC_PRESENT` gates cannot emit any key containing `"verified"`.
   - Enforces receipt re-derivation (`M104-10`) and live-input SHA-256 lifecycle binding (`M104-11`).
   - Hard-locks `E1-D` (`Packet0x03`) and `Release #47` at `NOT_AUTHORIZED`.
2. **`104-R0` Direct Raw-Byte Ancestor Relock (`ledger/T104_ANCESTOR_RELOCK.json`)**:
   - Compares all 24 precedent `.lean` files in `OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip` byte-for-byte against the physical Frozen `#46` ZIP and cross-checks `#40` `k3_case_a_evasion_exact_2` (`859 B`).
3. **`104-C0` Clean-Sheet Kernel Spec Probe (`src/t104_clean_sheet_spec_probe.lean`)**:
   - Forces Lean 4.33.1 (`-DwarningAsError=true`) to unify every `E1-A..C` and `F103-01` theorem against an independently authored specification (`M104-04`, `M104-05`).
4. **`104-M0` Pre-Locked 12-Vector Mutation Suite (`manifests/T104_MUTATION_MANIFEST.json`)**:
   - Executes `M104-01`..`M104-12` against real compiler, byte-parser, and receipt-tamper paths.

## Commands
```bash
python src/t104_independent_auditor.py
python -m unittest discover -s tests -v
```

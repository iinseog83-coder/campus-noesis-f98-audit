#!/usr/bin/env python3
"""Automated Unit Tests for `CAMPUS-Ωλ-E1-T104-INDEPENDENT-QUALIFICATION`."""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

T104_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = T104_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import t104_firewall_lattice as fw  # noqa: E402
import t104_independent_auditor as aud  # noqa: E402


class TestT104RootCauseQualification(unittest.TestCase):
    def test_01_f104_04_naming_firewall_blocks_verified_in_static_tier(self) -> None:
        with self.assertRaisesRegex(
            ValueError, "ERR_F104_04_STATIC_KEY_MISLABELED_AS_VERIFIED"
        ):
            fw.make_gate_record(
                "gate_104_static_syntax_scan",
                "STATIC_PRESENT",
                {"required_theorems_verified": 36},
            )

    def test_02_f104_01_missing_gate_blocks_scoped_acceptance(self) -> None:
        gates = {
            gid: fw.make_gate_record(gid, min_t, {})
            for gid, min_t in fw.REQUIRED_LOCAL_CLEANROOM_GATES.items()
        }
        gates["gate_104_c0_lean_kernel_28_and_clean_sheet_spec"] = fw.make_gate_record(
            "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "no lean"},
            error_code="EVIDENCE_UNAVAILABLE:lean",
        )
        verdict, reasons = fw.derive_tribunal_verdict(
            gates, fw.REQUIRED_LOCAL_CLEANROOM_GATES
        )
        self.assertEqual(verdict, "QUALIFICATION_HELD")
        self.assertNotIn(verdict, ("PASS", "SCOPED_ACCEPTED"))
        self.assertTrue(
            any("gate_104_c0_lean_kernel_28_and_clean_sheet_spec" in r for r in reasons)
        )

    def test_03_m104_10_forged_resealed_verdict_detected(self) -> None:
        gates = {
            gid: fw.make_gate_record(gid, min_t, {})
            for gid, min_t in fw.REQUIRED_LOCAL_CLEANROOM_GATES.items()
        }
        gates["gate_104_frozen40_wire_and_semantic_crosscheck"] = fw.make_gate_record(
            "gate_104_frozen40_wire_and_semantic_crosscheck",
            "EVIDENCE_UNAVAILABLE",
            {},
            error_code="EVIDENCE_UNAVAILABLE:frozen40",
        )
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "in.bin"
            p.write_bytes(b"abc")
            forged = fw.seal_json(
                {
                    "authority_boundaries": {
                        "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
                        "release_47_packaging": "NOT_AUTHORIZED",
                    },
                    "bound_input_digests": {
                        "in": {"sha256": aud.sha256_hex(b"abc"), "size_bytes": 3}
                    },
                    "gates": gates,
                    "verdicts": {
                        "local_cleanroom_e1_core_verdict": "SCOPED_ACCEPTED",
                        "multi_host_detached_e1_core_verdict": "QUALIFICATION_HELD",
                    },
                }
            )
            self.assertTrue(fw.verify_json_seal(forged))
            ok, err = fw.validate_receipt_consistency_and_live_state(forged, {"in": p})
            self.assertFalse(ok)
            self.assertIsNotNone(err)
            assert err is not None
            self.assertTrue(err.startswith("ERR_T104_VERDICT_EXCEEDS_EVIDENCE_LATTICE"))

    def test_04_m104_11_stale_input_invalidation_and_authority_firewall(self) -> None:
        gates = {
            gid: fw.make_gate_record(gid, min_t, {})
            for gid, min_t in fw.REQUIRED_LOCAL_CLEANROOM_GATES.items()
        }
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "in.bin"
            p.write_bytes(b"v1")
            rec = fw.seal_json(
                {
                    "authority_boundaries": {
                        "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
                        "release_47_packaging": "NOT_AUTHORIZED",
                    },
                    "bound_input_digests": {
                        "in": {"sha256": aud.sha256_hex(b"v1"), "size_bytes": 2}
                    },
                    "gates": gates,
                    "verdicts": {
                        "local_cleanroom_e1_core_verdict": "SCOPED_ACCEPTED",
                        "multi_host_detached_e1_core_verdict": "QUALIFICATION_HELD",
                    },
                }
            )
            ok1, _ = fw.validate_receipt_consistency_and_live_state(rec, {"in": p})
            self.assertTrue(ok1)
            p.write_bytes(b"v2")
            ok2, err2 = fw.validate_receipt_consistency_and_live_state(rec, {"in": p})
            self.assertFalse(ok2)
            self.assertEqual(err2, "ERR_T104_STALE_INPUT_STATE_INVALIDATED:mutated:in")

            # Also verify unauthorized E1-D promotion is rejected even with valid inputs
            p.write_bytes(b"v1")
            bad_auth = dict(rec)
            bad_auth["authority_boundaries"] = {
                "e1d_packet0x03_promotion": "AUTHORIZED",
                "release_47_packaging": "NOT_AUTHORIZED",
            }
            bad_auth = fw.seal_json(bad_auth)
            ok3, err3 = fw.validate_receipt_consistency_and_live_state(bad_auth, {"in": p})
            self.assertFalse(ok3)
            self.assertEqual(err3, "ERR_T104_UNAUTHORIZED_E1D_PROMOTION")

    def test_05_portable_no_lean_environment_yields_qualification_held_not_pass(self) -> None:
        paths = aud.resolve_artifact_paths(T104_ROOT)
        if paths["e1_aux_bundle_zip"] is None or paths["frozen40_zip"] is None or paths["frozen46_zip"] is None:
            self.skipTest("Core ancestor ZIPs not present")
        with tempfile.TemporaryDirectory() as td:
            iso = Path(td)
            for k in ("e1_aux_bundle_zip", "frozen40_zip", "frozen46_zip"):
                src_p = paths[k]
                assert src_p is not None
                shutil.copy2(src_p, iso / src_p.name)
            prev_lean = os.environ.get("LEAN_BIN")
            os.environ["LEAN_BIN"] = ""
            try:
                rec = aud.run_full_t104_qualification(
                    t104_root=T104_ROOT, override_dir=iso, write_ledger=False
                )
            finally:
                if prev_lean is None:
                    os.environ.pop("LEAN_BIN", None)
                else:
                    os.environ["LEAN_BIN"] = prev_lean
            # Even without Lean, #40 and #46 relock + cross-term lifecycle succeed!
            self.assertEqual(
                rec["gates"]["gate_104_r0_ancestor_relock_40_46"]["tier"],
                "SOURCE_BOUND",
            )
            self.assertEqual(
                rec["gates"]["gate_104_frozen40_wire_and_semantic_crosscheck"]["tier"],
                "SEMANTICALLY_VALIDATED",
            )
            # Unmounted historical #1..#39/#41..#45 are NOT falsely claimed!
            self.assertEqual(
                rec["gates"]["gate_104_r0_ancestor_relock_40_46"]["details"][
                    "unmounted_historical_archives_count"
                ],
                44,  # 45 total in #46 ledger minus #40 which IS mounted in iso!
            )
            # Missing Lean forces QUALIFICATION_HELD (never PASS / SCOPED_ACCEPTED)!
            self.assertEqual(
                rec["verdicts"]["local_cleanroom_e1_core_verdict"],
                "QUALIFICATION_HELD",
            )

    def test_06_ledger_7_deliverables_present_and_valid(self) -> None:
        ledger = T104_ROOT / "ledger"
        if not (ledger / "T104_VERIFICATION_RECEIPT.json").is_file():
            self.skipTest("Ledger not yet generated — run t104_independent_auditor.py first")
        required_files = (
            "T104_GATE_MANIFEST.json",
            "T104_ANCESTOR_RELOCK.json",
            "T104_LEAN_KERNEL_AUDIT.json",
            "T104_MUTATION_MANIFEST.json",
            "T104_DETACHED_REPLAY.json",
            "T104_TRIBUNAL_VERDICT.md",
            "T104_VERIFICATION_RECEIPT.json",
        )
        for rf in required_files:
            self.assertTrue((ledger / rf).is_file(), f"Missing {rf}")
            if rf.endswith(".json"):
                obj = json.loads((ledger / rf).read_text(encoding="utf-8"))
                self.assertTrue(fw.verify_json_seal(obj), f"Bad seal on {rf}")


if __name__ == "__main__":
    unittest.main()

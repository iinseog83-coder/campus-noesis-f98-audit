/-
  CAMPUS-Ωλ-E1-T104 Independent Clean-Sheet Specification Probe (`104-C0`)
  File: `t104_clean_sheet_spec_probe.lean`

  Root-Cause Purpose (`M104-04` & `M104-05`):
    A static regex or `#print axioms` check on theorem names alone can be fooled if a mutated
    module keeps the theorem name (`evasion0x01_source_exact_sound`) while weakening its
    conclusion (`: True := trivial`) or weakening `ExtractedLocalE1Evidence.sourceEvasionWitnesses`
    from 1-to-1 positional indexing `[r]?` to existential set membership `j ∈ ...`.
    Compiling this external clean-sheet probe forces the Lean 4.33.1 kernel to unify every
    critical `E1-A..C` & `F103-01` theorem against an independently written target type!
-/

import OmegaLambdaE1Core

namespace T104CleanSheetProbe

open OmegaLambda

-- 1. E1-A (`F102-01`): 70-byte header reuse & F91-03 bidirectional claim slice roundtrips
example :
    ∀ {bh : RawCarrierBindHeader},
      WF_RawBindHeader bh → (encodeBindHeaderList bh).length = 70 :=
  @OmegaLambda.e1_bind_header_length

example :
    ∀ {vTotal irTotal : Nat} {bh : RawCarrierBindHeader} {C : SourceCertTermE1},
      CanonicalClaimE1 vTotal irTotal bh C →
      ∃ B : ByteArray,
        encodeClaimSliceE1 vTotal irTotal bh C = some B ∧
        decodeClaimSliceE1 vTotal irTotal B = some (bh, C) :=
  @OmegaLambda.e1a_claim_slice_forward_roundtrip

example :
    ∀ {vTotal irTotal : Nat} {raw : ByteArray} {bh : RawCarrierBindHeader} {C : SourceCertTermE1},
      decodeClaimSliceE1 vTotal irTotal raw = some (bh, C) →
      CanonicalClaimE1 vTotal irTotal bh C ∧
      encodeClaimSliceE1 vTotal irTotal bh C = some raw :=
  @OmegaLambda.e1a_claim_slice_backward_roundtrip

example :
    ∀ (vTotal irTotal : Nat) (bh : RawCarrierBindHeader) (C : SourceCertTermE1),
      C.baseCert.evasionModeTag = 1 →
      C.baseCert.claimedL = C.baseCert.claimedU →
      checkCanonicalClaimPairE1Bool vTotal irTotal (bh, C) = false ∧
      encodeClaimSliceE1 vTotal irTotal bh C = none :=
  OmegaLambda.e1a_equal_bounds_evasion0x01_rejected

-- 2. E1-B (`F101-03`): Pascal-DP equivalence & Constructive Subset-Extension
example : ∀ (n k : Nat), binomDP n k = binomNat n k :=
  OmegaLambda.binomDP_eq_binomNat

example :
    ∀ {α : Type} [DecidableEq α] {xs D : List α} {k : Nat},
      NodupList xs →
      NodupList D →
      (∀ d ∈ D, d ∈ xs) →
      D.length ≤ k →
      k ≤ xs.length →
      ∃ S ∈ kSubsets k xs, ∀ d ∈ D, d ∈ S :=
  @OmegaLambda.exists_mem_kSubsets_superset

-- 3. F102-02 Legacy 0x00 Projection Soundness
example :
    ∀ (snap : SourceSnapshot) (ip : IssuerPartition) (b : BaseData)
      (s t : VertexId) (pkt : List (List VertexId)) (C : SourceCertTermE1),
      checkSourceLocalCert0x01 snap ip b s t pkt C = true →
      checkSourceCert0x00 ip b s t (.localPacket pkt) (projectE1ToLegacy0x00 C) = true :=
  OmegaLambda.e1_local_cert_legacy_projection_sound

-- 4. F103-01 Mandatory Positional Witness Binding (`[r]?` -> `[r]?` -> `[j]?`)
example
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (pkt : List (List VertexId)) (C : SourceCertTermE1)
    (ev : ExtractedLocalE1Evidence reg snap ent ip b s t pkt C)
    (r : Nat) (S : List IssuerId)
    (hr : (kSubsets (C.baseCert.claimedU - 1) ip.remIssuers)[r]? = some S) :
    ∃ (j : Nat) (γ : List VertexId),
      C.evasionPathIndices[r]? = some j ∧
      pkt[j]? = some γ ∧
      SourceWalkSurvivesIdx snap S γ :=
  ev.sourceEvasionWitnesses r S hr

-- 5. E1-C Layer 2 Master Exact Resilience Theorem (6-Argument SourceStringSemanticResilience)
example :
    ∀ (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
      (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
      (pkt : List (List VertexId)) (C : SourceCertTermE1),
      checkSourceAnchorAndSortLaw reg snap = true →
      lookupPinnedA1 snap.snapshotId reg = some ent →
      ip = projectIssuerPartition snap ent.pinnedConstIds →
      b.G = projectIRGraph snap →
      checkVerifiedBase ip b = true →
      checkSourceLocalCert0x01 snap ip b s t pkt C = true →
      C.baseCert.carrierTag = 1 ∧
      C.baseCert.modeTag = 2 ∧
      C.baseCert.evasionModeTag = 1 ∧
      1 ≤ C.baseCert.claimedL ∧
      C.baseCert.claimedL < C.baseCert.claimedU ∧
      ScopedSemanticResilience ip b s t (.localPacket pkt)
        (.finiteBounds C.baseCert.claimedL C.baseCert.claimedU) ∧
      ScopedSemanticResilience ip b s t (.localPacket pkt)
        (.finiteBounds C.baseCert.claimedU C.baseCert.claimedU) ∧
      SourceStringSemanticResilience reg snap b.kappa s t (.localPacket pkt)
        (.finiteBounds C.baseCert.claimedL C.baseCert.claimedU) ∧
      SourceStringSemanticResilience reg snap b.kappa s t (.localPacket pkt)
        (.finiteBounds C.baseCert.claimedU C.baseCert.claimedU) :=
  OmegaLambda.evasion0x01_source_exact_sound

-- 6. K3-Case A Exact [2, 2] Resilience & F103-01 Permutation Rejection
example :
    ScopedSemanticResilience E1Examples.ipK3 E1Examples.baseK3 0 4 (.localPacket E1Examples.pktK3) (.finiteBounds 1 2) ∧
    ScopedSemanticResilience E1Examples.ipK3 E1Examples.baseK3 0 4 (.localPacket E1Examples.pktK3) (.finiteBounds 2 2) ∧
    SourceStringSemanticResilience E1Examples.regK3 E1Examples.snapK3 .ePlus 0 4 (.localPacket E1Examples.pktK3) (.finiteBounds 1 2) ∧
    SourceStringSemanticResilience E1Examples.regK3 E1Examples.snapK3 .ePlus 0 4 (.localPacket E1Examples.pktK3) (.finiteBounds 2 2) :=
  OmegaLambda.E1Examples.e1_ex_k3_exact_resilience_2_proven

example :
    checkSourceWalkSurvivesIdxBool E1Examples.snapK3 [1] [0, 1, 2, 4] = false ∧
    checkSourceLocalCert0x01 E1Examples.snapK3 E1Examples.ipK3 E1Examples.baseK3 0 4
      E1Examples.pktK3 E1Examples.certK3Permuted012 = false :=
  OmegaLambda.E1Examples.adv_e1_f103_01_permuted_indices_rejected

end T104CleanSheetProbe

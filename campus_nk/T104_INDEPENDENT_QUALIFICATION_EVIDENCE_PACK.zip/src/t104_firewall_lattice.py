#!/usr/bin/env python3
"""104-F0 Evidence-vs-Authority Poset & Firewall Engine (`CAMPUS-Ωλ-E1-T104`).

Root-Cause Countermeasures:
  1. `F104-01` (No Over-Promotion on Missing/Skipped Gates):
     Replaces untyped boolean `"PASS"` with an explicit poset (`TIER_RANK`) and pure aggregator
     `derive_tribunal_verdict()`. Any missing or unexecuted required gate yields
     `EVIDENCE_UNAVAILABLE` (rank 1), which mathematically forces `QUALIFICATION_HELD` whenever
     the required minimum tier is `SOURCE_BOUND` (rank 3), `SEMANTICALLY_VALIDATED` (rank 4),
     `KERNEL_VERIFIED` (rank 5), or `INDEPENDENT_REPLAYED` (rank 6).
  2. `F104-04` (No Static-Presence Mislabeled as `verified`):
     `enforce_f104_04_naming_firewall()` recursively inspects every key emitted by a
     `STATIC_PRESENT` gate and rejects any key containing `"verified"`.
  3. `104-F0` (Strict Evidence vs Authority Separation):
     `AUTHORIZED` is not an element of `EvidenceTier`; no combination of evidence gates can
     produce `AUTHORIZED` for `E1-D` (`Packet0x03`) or `Release #47`.
  4. `M104-10` & `M104-11` (Receipt Re-Derivation & Live-Input Lifecycle Guard):
     `validate_receipt_consistency_and_live_state()` never trusts a stored verdict string (even
     inside a freshly re-sealed JSON!). It re-evaluates `derive_tribunal_verdict()` from raw gate
     evidence AND re-hashes all live bound inputs on disk to invalidate stale state.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

TIER_RANK: Dict[str, int] = {
    "REJECTED_INVARIANT": 0,
    "EVIDENCE_UNAVAILABLE": 1,
    "STATIC_PRESENT": 2,
    "SOURCE_BOUND": 3,
    "SEMANTICALLY_VALIDATED": 4,
    "KERNEL_VERIFIED": 5,
    "INDEPENDENT_REPLAYED": 6,
}

VALID_AUTHORITY_STATES = frozenset({"NOT_AUTHORIZED", "AUTHORIZED"})
VALID_TRIBUNAL_VERDICTS = frozenset({"SCOPED_ACCEPTED", "QUALIFICATION_HELD", "REJECTED"})

REQUIRED_LOCAL_CLEANROOM_GATES: Dict[str, str] = {
    "gate_104_g0_baseline_lock": "SOURCE_BOUND",
    "gate_104_r0_ancestor_relock_40_46": "SOURCE_BOUND",
    "gate_104_static_syntax_scan": "STATIC_PRESENT",
    "gate_104_cross_term_identity_lifecycle": "SEMANTICALLY_VALIDATED",
    "gate_104_frozen40_wire_and_semantic_crosscheck": "SEMANTICALLY_VALIDATED",
    "gate_104_c0_lean_kernel_28_and_clean_sheet_spec": "KERNEL_VERIFIED",
    "gate_104_m0_mutation_12_suite": "SEMANTICALLY_VALIDATED",
    "gate_104_t0_same_host_zero_shared_replay": "INDEPENDENT_REPLAYED",
}

REQUIRED_MULTI_HOST_DETACHED_GATES: Dict[str, str] = {
    **REQUIRED_LOCAL_CLEANROOM_GATES,
    "gate_104_t0_external_multi_host_cloud_lean_replay": "INDEPENDENT_REPLAYED",
}


def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def seal_json(payload: Mapping[str, Any]) -> Dict[str, Any]:
    body = {k: v for k, v in payload.items() if k != "seal"}
    out = dict(body)
    out["seal"] = {
        "algorithm": "SHA-256",
        "canonicalization": "CAMPUS_CANONICAL_JSON_UTF8_SORTED_KEYS_V1",
        "payload_sha256": hashlib.sha256(canonical_json_bytes(body)).hexdigest(),
    }
    return out


def verify_json_seal(obj: Mapping[str, Any]) -> bool:
    seal = obj.get("seal")
    if not isinstance(seal, Mapping):
        return False
    body = {k: v for k, v in obj.items() if k != "seal"}
    return seal.get("payload_sha256") == hashlib.sha256(canonical_json_bytes(body)).hexdigest()


def _scan_forbidden_verified_key(obj: Any, path_prefix: str = "") -> Optional[str]:
    if isinstance(obj, Mapping):
        for k, v in obj.items():
            key_str = str(k)
            cur = f"{path_prefix}.{key_str}" if path_prefix else key_str
            if "verified" in key_str.lower():
                return cur
            sub = _scan_forbidden_verified_key(v, cur)
            if sub is not None:
                return sub
    elif isinstance(obj, (list, tuple)):
        for idx, item in enumerate(obj):
            sub = _scan_forbidden_verified_key(item, f"{path_prefix}[{idx}]")
            if sub is not None:
                return sub
    return None


def enforce_f104_04_naming_firewall(gate_id: str, tier: str, details: Mapping[str, Any]) -> None:
    if tier not in TIER_RANK:
        raise ValueError(f"ERR_F104_00_UNKNOWN_EVIDENCE_TIER:{gate_id}:{tier}")
    if tier == "STATIC_PRESENT":
        bad_key = _scan_forbidden_verified_key(details)
        if bad_key is not None:
            raise ValueError(
                f"ERR_F104_04_STATIC_KEY_MISLABELED_AS_VERIFIED:{gate_id}:{bad_key}"
            )


def make_gate_record(
    gate_id: str,
    tier: str,
    details: Mapping[str, Any],
    error_code: Optional[str] = None,
) -> Dict[str, Any]:
    enforce_f104_04_naming_firewall(gate_id, tier, details)
    if tier == "REJECTED_INVARIANT" and not error_code:
        error_code = f"ERR_T104_GATE_REJECTED:{gate_id}"
    if error_code is not None and tier not in ("REJECTED_INVARIANT", "EVIDENCE_UNAVAILABLE"):
        raise ValueError(
            f"ERR_F104_00_ERROR_WITH_PROMOTED_TIER:{gate_id}:{tier}:{error_code}"
        )
    return {
        "details": dict(details),
        "error_code": error_code,
        "gate_id": gate_id,
        "tier": tier,
        "tier_rank": TIER_RANK[tier],
    }


def derive_tribunal_verdict(
    gates: Mapping[str, Mapping[str, Any]],
    required_minimum_tiers: Mapping[str, str],
) -> Tuple[str, List[str]]:
    """Pure lattice decision:
      1. Any REJECTED_INVARIANT gate -> REJECTED
      2. Any missing required gate or tier_rank < required_rank -> QUALIFICATION_HELD
      3. Otherwise -> SCOPED_ACCEPTED (never grants E1-D or Release #47 authority!)
    """
    reasons: List[str] = []

    for gid, gobj in sorted(gates.items()):
        tier = str(gobj.get("tier", ""))
        if tier not in TIER_RANK:
            return ("REJECTED", [f"ERR_UNKNOWN_TIER:{gid}:{tier}"])
        enforce_f104_04_naming_firewall(gid, tier, gobj.get("details", {}))
        if tier == "REJECTED_INVARIANT":
            err = gobj.get("error_code") or f"ERR_GATE_REJECTED:{gid}"
            reasons.append(f"INVARIANT_FAILURE:{gid}:{err}")

    if reasons:
        return ("REJECTED", reasons)

    held_reasons: List[str] = []
    for req_gid, min_tier in sorted(required_minimum_tiers.items()):
        min_rank = TIER_RANK[min_tier]
        if req_gid not in gates:
            held_reasons.append(f"MISSING_REQUIRED_GATE:{req_gid}:requires>={min_tier}")
            continue
        actual_tier = str(gates[req_gid].get("tier", "EVIDENCE_UNAVAILABLE"))
        actual_rank = TIER_RANK[actual_tier]
        if actual_rank < min_rank:
            held_reasons.append(
                f"GATE_UNAVAILABLE_BLOCKS_PROMOTION:{req_gid}:actual={actual_tier}<required={min_tier}"
            )

    if held_reasons:
        return ("QUALIFICATION_HELD", held_reasons)

    return ("SCOPED_ACCEPTED", [])


def validate_receipt_consistency_and_live_state(
    receipt: Mapping[str, Any],
    live_input_paths: Mapping[str, Path],
) -> Tuple[bool, Optional[str]]:
    """Independent validator blocking M104-10 (tampered/re-sealed verdict) and M104-11 (stale inputs)."""
    if not verify_json_seal(receipt):
        return (False, "ERR_T104_INVALID_JSON_SEAL")

    auth = receipt.get("authority_boundaries")
    if not isinstance(auth, Mapping):
        return (False, "ERR_T104_MISSING_AUTHORITY_BOUNDARIES")
    if auth.get("e1d_packet0x03_promotion") != "NOT_AUTHORIZED":
        return (False, "ERR_T104_UNAUTHORIZED_E1D_PROMOTION")
    if auth.get("release_47_packaging") != "NOT_AUTHORIZED":
        return (False, "ERR_T104_UNAUTHORIZED_RELEASE47_PROMOTION")

    gates = receipt.get("gates")
    if not isinstance(gates, Mapping):
        return (False, "ERR_T104_MISSING_GATES_MAP")

    try:
        expected_local, _ = derive_tribunal_verdict(gates, REQUIRED_LOCAL_CLEANROOM_GATES)
        expected_detached, _ = derive_tribunal_verdict(gates, REQUIRED_MULTI_HOST_DETACHED_GATES)
    except ValueError as exc:
        return (False, str(exc))

    verdicts = receipt.get("verdicts")
    if not isinstance(verdicts, Mapping):
        return (False, "ERR_T104_MISSING_VERDICTS_BLOCK")

    claimed_local = verdicts.get("local_cleanroom_e1_core_verdict")
    claimed_detached = verdicts.get("multi_host_detached_e1_core_verdict")
    if claimed_local not in VALID_TRIBUNAL_VERDICTS or claimed_detached not in VALID_TRIBUNAL_VERDICTS:
        return (False, "ERR_T104_FORBIDDEN_OR_UNTYPED_VERDICT_LABEL")

    if claimed_local != expected_local or claimed_detached != expected_detached:
        return (
            False,
            f"ERR_T104_VERDICT_EXCEEDS_EVIDENCE_LATTICE:"
            f"claimed=({claimed_local},{claimed_detached})!=derived=({expected_local},{expected_detached})",
        )

    bound_digests = receipt.get("bound_input_digests")
    if not isinstance(bound_digests, Mapping) or not bound_digests:
        return (False, "ERR_T104_MISSING_BOUND_INPUT_DIGESTS")

    for logical_key, live_path in sorted(live_input_paths.items()):
        if logical_key not in bound_digests:
            return (False, f"ERR_T104_UNBOUND_LIVE_INPUT:{logical_key}")
        rec_entry = bound_digests[logical_key]
        expected_sha = rec_entry.get("sha256") if isinstance(rec_entry, Mapping) else None
        expected_size = rec_entry.get("size_bytes") if isinstance(rec_entry, Mapping) else None
        if not live_path.is_file():
            return (False, f"ERR_T104_STALE_INPUT_STATE_INVALIDATED:missing:{logical_key}")
        raw = live_path.read_bytes()
        actual_sha = hashlib.sha256(raw).hexdigest()
        if actual_sha != expected_sha or len(raw) != expected_size:
            return (
                False,
                f"ERR_T104_STALE_INPUT_STATE_INVALIDATED:mutated:{logical_key}",
            )

    return (True, None)

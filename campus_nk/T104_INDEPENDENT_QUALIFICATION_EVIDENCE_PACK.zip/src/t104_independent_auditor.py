#!/usr/bin/env python3
"""Zero-Shared-Code Independent Qualification & 12-Vector Mutation Engine (`CAMPUS-Ωλ-E1-T104`).

104th Independent Tribunal Compliance (`CAMPUS-Ωλ-E1-T104-INDEPENDENT-QUALIFICATION`):
  - Zero shared imports with `campus_noesis_omega_lambda_e1_core` (`0` imports from author `src/`).
  - Zero modification of `OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip`, Frozen `#1`–`#46` ZIPs, `F99`, or `F100`.
  - Append-only qualification outputs in `ledger/`:
      1. `T104_GATE_MANIFEST.json`        (`104-G0` Authority & Baseline Lock)
      2. `T104_ANCESTOR_RELOCK.json`      (`104-R0` Direct Raw-Byte Lineage Relock)
      3. `T104_LEAN_KERNEL_AUDIT.json`    (`104-C0` 28-Module Lean 4.33.1 + Clean-Sheet Spec Probe)
      4. `T104_MUTATION_MANIFEST.json`    (`104-M0` Pre-Locked 12-Vector Manifest)
      5. `T104_DETACHED_REPLAY.json`      (`104-T0` Subprocess Replay + Real 12-Mutation Execution)
      6. `T104_TRIBUNAL_VERDICT.md`       (Findings F104-01..05, 3-Axis & Fiber Commutativity Analysis)
      7. `T104_VERIFICATION_RECEIPT.json` (`104-P0` Append-Only Master Sealed Receipt)
"""

from __future__ import annotations

import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import unicodedata
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple
import zipfile

THIS_DIR = Path(__file__).resolve().parent
if str(THIS_DIR) not in sys.path:
    sys.path.insert(0, str(THIS_DIR))

import t104_firewall_lattice as fw  # noqa: E402

STAGE_NAME = "CAMPUS-OMEGA-LAMBDA-E1-T104-INDEPENDENT-QUALIFICATION"

BASELINE_E1_AUX_SHA256 = (
    "38a055f39e259cac333b469bfb4602ed8b3859cb5f6bfa3e096a75be0200da39"
)
BASELINE_E1_AUX_SIZE = 190589
BASELINE_FROZEN40_SHA256 = (
    "93d9a02a84d6d91a36140de2c96cb362e26aa1b2c595ca3ac9562ddf8e3426bb"
)
BASELINE_FROZEN40_SIZE = 100029
BASELINE_FROZEN46_SHA256 = (
    "4c42f12b605083d13228c02c84e12b4689cdf32be0f507041b6a36360eec4608"
)
BASELINE_FROZEN46_SIZE = 236214
BASELINE_F99_SHA256 = (
    "26310ec2154d760a77fb2c8a764ba2fbc5c0ede092e4616e0b840f1db8ac311f"
)
BASELINE_F99_SIZE = 75053
BASELINE_F100_SHA256 = (
    "e7cfb738c45071f67e7a56e39c87613197a5e65c9abf95368f2b47b9d7477298"
)
BASELINE_F100_SIZE = 5453

PINNED_LEAN_VERSION = "4.33.1"
PINNED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"
ALLOWED_LEAN_AXIOMS = frozenset({"propext", "Quot.sound", "Classical.choice"})

# Note: 3,845 is recorded strictly as a COMPARISON TARGET (`104-C0`), never assumed prior to run!
TARGET_COMPARISON_CONSTANTS_28 = 3845
TARGET_COMPARISON_CONSTANTS_46_BASE = 3575

SNAPSHOT_DOMAIN_PREFIX = b"CAMPUS_NOESIS_CNB1_SNAPSHOT_V1\x00"
CARRIER_DOMAIN_PREFIX = b"CAMPUS_NOESIS_CNP2_CARRIER_V1\x00"

ORDERED_28_MODULES: Tuple[Tuple[str, str], ...] = (
    ("OmegaLambda.PointedLTS", "OmegaLambda/PointedLTS.lean"),
    ("OmegaLambda.GraphBase", "OmegaLambda/GraphBase.lean"),
    ("OmegaLambda.CarrierLocalGlobal", "OmegaLambda/CarrierLocalGlobal.lean"),
    ("OmegaLambda.CarrierGeodesic", "OmegaLambda/CarrierGeodesic.lean"),
    ("OmegaLambda.CheckerSoundness", "OmegaLambda/CheckerSoundness.lean"),
    ("OmegaLambda.KernelEvalExamples", "OmegaLambda/KernelEvalExamples.lean"),
    ("OmegaLambda.AxiomAudit", "OmegaLambda/AxiomAudit.lean"),
    ("OmegaLambda", "OmegaLambda.lean"),
    ("OmegaLambda.SourceIRRefinement", "OmegaLambda/SourceIRRefinement.lean"),
    ("OmegaLambda.SourceIRRefinementExamples", "OmegaLambda/SourceIRRefinementExamples.lean"),
    ("OmegaLambda.R1AxiomAudit", "OmegaLambda/R1AxiomAudit.lean"),
    ("OmegaLambdaR1", "OmegaLambdaR1.lean"),
    ("OmegaLambda.CertRefinement", "OmegaLambda/CertRefinement.lean"),
    ("OmegaLambda.CertRefinementExamples", "OmegaLambda/CertRefinementExamples.lean"),
    ("OmegaLambda.R2AxiomAudit", "OmegaLambda/R2AxiomAudit.lean"),
    ("OmegaLambdaR2", "OmegaLambdaR2.lean"),
    ("OmegaLambda.WireRefinement", "OmegaLambda/WireRefinement.lean"),
    ("OmegaLambda.WireRefinementExamples", "OmegaLambda/WireRefinementExamples.lean"),
    ("OmegaLambda.W1AxiomAudit", "OmegaLambda/W1AxiomAudit.lean"),
    ("OmegaLambdaW1", "OmegaLambdaW1.lean"),
    ("OmegaLambda.PacketRefinement", "OmegaLambda/PacketRefinement.lean"),
    ("OmegaLambda.PacketRefinementExamples", "OmegaLambda/PacketRefinementExamples.lean"),
    ("OmegaLambda.W2AxiomAudit", "OmegaLambda/W2AxiomAudit.lean"),
    ("OmegaLambdaW2", "OmegaLambdaW2.lean"),
    ("OmegaLambda.EvasionRefinement", "OmegaLambda/EvasionRefinement.lean"),
    ("OmegaLambda.EvasionRefinementExamples", "OmegaLambda/EvasionRefinementExamples.lean"),
    ("OmegaLambda.E1CoreAxiomAudit", "OmegaLambda/E1CoreAxiomAudit.lean"),
    ("OmegaLambdaE1Core", "OmegaLambdaE1Core.lean"),
)

REQUIRED_36_THEOREMS: Tuple[str, ...] = (
    "OmegaLambda.nthOpt_eq_getElem?",
    "OmegaLambda.e1_bind_header_length",
    "OmegaLambda.parseClaimPairE1_encode_append",
    "OmegaLambda.parseClaimPairE1_eq_some",
    "OmegaLambda.e1a_claim_slice_forward_roundtrip",
    "OmegaLambda.e1a_claim_slice_backward_roundtrip",
    "OmegaLambda.e1a_equal_bounds_evasion0x01_rejected",
    "OmegaLambda.e1a_invalid_mode_or_carrier_rejected",
    "OmegaLambda.binomDP_eq_binomNat",
    "OmegaLambda.kSubsets_length",
    "OmegaLambda.kSubsets_mem_length",
    "OmegaLambda.kSubsets_mem_sub",
    "OmegaLambda.kSubsets_mem_nodup",
    "OmegaLambda.nodup_sub_length_le",
    "OmegaLambda.exists_mem_kSubsets_superset",
    "OmegaLambda.WalkSurvivesGraph_anti_mono",
    "OmegaLambda.checkZipGraphSurvivesBool_nthOpt",
    "OmegaLambda.evasion0x01_graph_exact_sound",
    "OmegaLambda.checkSourceWalkSurvivesIdxBool_iff",
    "OmegaLambda.checkZipSourceSurvivesIdxBool_nthOpt",
    "OmegaLambda.checkZipSource_implies_checkZipGraph",
    "OmegaLambda.e1_local_cert_legacy_projection_sound",
    "OmegaLambda.e1_extract_structural_evidence",
    "OmegaLambda.evasion0x01_source_exact_sound",
    "OmegaLambda.E1Examples.e1_ex_k3_partition_and_ksubsets",
    "OmegaLambda.E1Examples.e1_ex_k3_header_70bytes_and_wire_103bytes_roundtrip",
    "OmegaLambda.E1Examples.e1_ex_k3_anchor_and_base_ok",
    "OmegaLambda.E1Examples.e1_ex_k3_checker_0x01_and_legacy_projection_ok",
    "OmegaLambda.E1Examples.e1_ex_k3_ordered_witnesses_extracted",
    "OmegaLambda.E1Examples.e1_ex_k3_f103_01_positional_mapping_exact",
    "OmegaLambda.E1Examples.e1_ex_k3_exact_resilience_2_proven",
    "OmegaLambda.E1Examples.adv_e1_equal_bounds_redundant_rejected",
    "OmegaLambda.E1Examples.adv_e1_invalid_evasion_mode_2_rejected",
    "OmegaLambda.E1Examples.adv_e1_budget_1024_exceeded_3003_rejected",
    "OmegaLambda.E1Examples.adv_e1_incomplete_table_len_rejected",
    "OmegaLambda.E1Examples.adv_e1_f103_01_permuted_indices_rejected",
)

FORBIDDEN_LEAN_PATTERNS = (
    re.compile(r"\bsorry\b"),
    re.compile(r"\badmit\b"),
    re.compile(r"(?m)^\s*axiom\s+"),
    re.compile(r"(?m)^\s*opaque\s+"),
    re.compile(r"(?m)^\s*constant\s+"),
    re.compile(r"\bnative_decide\b"),
    re.compile(r"\bofReduceBool\b"),
    re.compile(r"\btrustCompiler\b"),
    re.compile(r"\bimplemented_by\b"),
    re.compile(r"@\[[^\]]*\bextern\b"),
    re.compile(r"\bunsafe\b"),
    re.compile(r"(?m)^\s*partial\s+def\b"),
)

SMAP_KERNEL_INSPECTOR_LEAN = r"""import OmegaLambdaE1Core
import Lean

open Lean

def cinfoKind : ConstantInfo → String
  | .axiomInfo _ => "axiomInfo"
  | .defnInfo _ => "defnInfo"
  | .thmInfo _ => "thmInfo"
  | .opaqueInfo _ => "opaqueInfo"
  | .quotInfo _ => "quotInfo"
  | .inductInfo _ => "inductInfo"
  | .ctorInfo _ => "ctorInfo"
  | .recInfo _ => "recInfo"

def isProjectRoot : Name → Bool
  | .anonymous => false
  | .str .anonymous s =>
      s == "OmegaLambda" || s == "OmegaLambdaR1" || s == "OmegaLambdaR2" ||
      s == "OmegaLambdaW1" || s == "OmegaLambdaW2" || s == "OmegaLambdaE1Core"
  | .str p _ => isProjectRoot p
  | .num p _ => isProjectRoot p

def all28Mods : Array Name := #[
  `OmegaLambda.PointedLTS, `OmegaLambda.GraphBase, `OmegaLambda.CarrierLocalGlobal,
  `OmegaLambda.CarrierGeodesic, `OmegaLambda.CheckerSoundness, `OmegaLambda.KernelEvalExamples,
  `OmegaLambda.AxiomAudit, `OmegaLambda,
  `OmegaLambda.SourceIRRefinement, `OmegaLambda.SourceIRRefinementExamples,
  `OmegaLambda.R1AxiomAudit, `OmegaLambdaR1,
  `OmegaLambda.CertRefinement, `OmegaLambda.CertRefinementExamples,
  `OmegaLambda.R2AxiomAudit, `OmegaLambdaR2,
  `OmegaLambda.WireRefinement, `OmegaLambda.WireRefinementExamples,
  `OmegaLambda.W1AxiomAudit, `OmegaLambdaW1,
  `OmegaLambda.PacketRefinement, `OmegaLambda.PacketRefinementExamples,
  `OmegaLambda.W2AxiomAudit, `OmegaLambdaW2,
  `OmegaLambda.EvasionRefinement, `OmegaLambda.EvasionRefinementExamples,
  `OmegaLambda.E1CoreAxiomAudit, `OmegaLambdaE1Core
]

#eval show MetaM Unit from do
  let env ← getEnv
  let mut modPairs : Array (Nat × String) := #[]
  for m in all28Mods do
    match env.getModuleIdx? m with
    | some idx => modPairs := modPairs.push (idx.toNat, m.toString)
    | none => throwError s!"T104_FATAL_MISSING_MODULE:{m}"
  let allowed : List Name := [`propext, `Quot.sound, `Classical.choice]
  for (nm, ci) in env.constants.map₁.toList ++ env.constants.map₂.toList do
    let inProj := isProjectRoot nm
    match env.getModuleIdxFor? nm with
    | some midx =>
      match modPairs.find? (fun (i, _) => i == midx.toNat) with
      | some (_, mstr) =>
        let kstr := cinfoKind ci
        if kstr == "axiomInfo" || kstr == "opaqueInfo" then
          throwError s!"T104_FATAL_FORBIDDEN_KIND:{kstr}:{nm}"
        let axs ← collectAxioms nm
        for ax in axs do
          let s := ax.toString
          if !(allowed.contains ax) || (s.splitOn "sorry").length > 1 || (s.splitOn "._native.").length > 1 then
            throwError s!"T104_FATAL_DISALLOWED_AXIOM:{ax}:{nm}"
        let csv := String.intercalate "," (axs.toList.map Name.toString)
        IO.println s!"T104_ROW|{mstr}|{kstr}|{nm}|{csv}"
      | none =>
        if inProj then
          throwError s!"T104_FATAL_ORPHAN_PROJECT_CONST:{nm}"
    | none =>
      if inProj then
        throwError s!"T104_FATAL_UNINDEXED_PROJECT_CONST:{nm}"
"""


def read_readonly_bytes(p: Path) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    fd = os.open(str(p), flags)
    try:
        chunks: List[bytes] = []
        while True:
            buf = os.read(fd, 65536)
            if not buf:
                break
            chunks.append(buf)
        return b"".join(chunks)
    finally:
        os.close(fd)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strip_lean_comments_and_strings(text: str) -> str:
    out: List[str] = []
    i, n, depth, in_str = 0, len(text), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if text.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if text.startswith("--", i):
                while i < n and text[i] != "\n":
                    i += 1
                continue
            if text[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(text[i])
            i += 1
        elif in_str:
            if text[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if text[i] == '"':
                in_str = False
            i += 1
        else:
            if text.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if text.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if text[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def audit_zip_hygiene(raw_zip: bytes, label: str) -> Tuple[Optional[Dict[str, bytes]], Optional[str], Dict[str, Any]]:
    import io

    try:
        with zipfile.ZipFile(io.BytesIO(raw_zip), "r") as zf:
            bad = zf.testzip()
            if bad is not None:
                return (None, f"ERR_T104_CORRUPT_ZIP_CRC:{label}:{bad}", {})
            infos = zf.infolist()
            exact_seen = set()
            lower_nfc_seen: Dict[str, str] = {}
            basename_map: Dict[str, List[str]] = {}
            entries: Dict[str, bytes] = {}
            crc_xor = 0
            for inf in infos:
                nm = inf.filename
                if nm.startswith("/") or "\\" in nm or ".." in nm.split("/"):
                    return (None, f"ERR_T104_UNSAFE_ZIP_PATH:{label}:{nm}", {})
                if not nm.isascii():
                    return (None, f"ERR_T104_NON_ASCII_HOMOGRAPH_PATH:{label}:{nm}", {})
                if nm in exact_seen:
                    return (None, f"ERR_T104_DUPLICATE_ZIP_ENTRY:{label}:{nm}", {})
                exact_seen.add(nm)
                norm_key = unicodedata.normalize("NFC", nm).lower()
                if norm_key in lower_nfc_seen:
                    return (
                        None,
                        f"ERR_T104_CASE_COLLISION:{label}:{nm}_vs_{lower_nfc_seen[norm_key]}",
                        {},
                    )
                lower_nfc_seen[norm_key] = nm
                base_nm = nm.rsplit("/", 1)[-1]
                basename_map.setdefault(base_nm, []).append(nm)
                entries[nm] = zf.read(nm)
                crc_xor ^= inf.CRC
            homonyms = {k: v for k, v in basename_map.items() if len(v) > 1}
            return (
                entries,
                None,
                {
                    "crc32_xor_hex": f"{crc_xor:08x}",
                    "entry_count": len(infos),
                    "same_basename_paths": homonyms,
                    "size_bytes": len(raw_zip),
                    "sha256": sha256_hex(raw_zip),
                },
            )
    except zipfile.BadZipFile:
        return (None, f"ERR_T104_BAD_ZIP_ARCHIVE:{label}", {})


def find_lean_binary() -> Optional[Path]:
    if "LEAN_BIN" in os.environ:
        val = os.environ["LEAN_BIN"].strip()
        if not val:
            return None
        p = Path(val)
        return p if p.is_file() else None
    w = shutil.which("lean")
    if w:
        return Path(w)
    cand = Path.home() / ".elan" / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    return cand if cand.is_file() else None


def resolve_artifact_paths(
    t104_root: Path,
    override_dir: Optional[Path] = None,
) -> Dict[str, Optional[Path]]:
    """Resolves read-only artifact paths from either an isolated bundle dir (`readonly_ancestors/`)
    or the parent CAMPUS workspace."""
    if override_dir is not None:
        cands = {
            "e1_aux_bundle_zip": override_dir / "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip",
            "frozen40_zip": override_dir / "CAMPUS_NOESIS_OMEGA_KAPPA_STAGE1_0_PURE_TRUSTED_CHECKER_PACKAGE.zip",
            "frozen46_zip": override_dir / "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip",
            "f99_bundle_zip": override_dir / "F99_DETACHED_CI_RUN_44121693289_EVIDENCE_BUNDLE.zip",
            "f100_tribunal_receipt": override_dir / "F100_TRIBUNAL_100TH_INDEPENDENT_REPLAY_RECEIPT.json",
            "campus_archive_dir": override_dir,
        }
        return {k: (p if p.exists() else None) for k, p in cands.items()}

    ro_dir = t104_root / "readonly_ancestors"
    campus_nk = t104_root.parent
    campus_root = campus_nk.parent

    def _pick(*paths: Path) -> Optional[Path]:
        for p in paths:
            if p.is_file():
                return p
        return None

    return {
        "e1_aux_bundle_zip": _pick(
            ro_dir / "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip",
            campus_nk / "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip",
        ),
        "frozen40_zip": _pick(
            ro_dir / "CAMPUS_NOESIS_OMEGA_KAPPA_STAGE1_0_PURE_TRUSTED_CHECKER_PACKAGE.zip",
            campus_root / "CAMPUS_NOESIS_OMEGA_KAPPA_STAGE1_0_PURE_TRUSTED_CHECKER_PACKAGE.zip",
        ),
        "frozen46_zip": _pick(
            ro_dir / "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip",
            campus_root / "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip",
        ),
        "f99_bundle_zip": _pick(
            ro_dir / "F99_DETACHED_CI_RUN_44121693289_EVIDENCE_BUNDLE.zip",
            campus_nk / "ci_downloaded_bundle" / "F99_DETACHED_CI_RUN_44121693289_EVIDENCE_BUNDLE.zip",
        ),
        "f100_tribunal_receipt": _pick(
            ro_dir / "F100_TRIBUNAL_100TH_INDEPENDENT_REPLAY_RECEIPT.json",
            campus_nk / "F100_TRIBUNAL_100TH_INDEPENDENT_REPLAY_RECEIPT.json",
        ),
        "campus_archive_dir": campus_root if campus_root.is_dir() else (ro_dir if ro_dir.is_dir() else None),
    }


# =============================================================================
# Gate 104-G0 & Relock 104-R0: Baseline Lock & Direct Raw-Byte Ancestor Relock
# =============================================================================

def run_gate_g0_and_r0(
    paths: Mapping[str, Optional[Path]],
) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any], Optional[Dict[str, bytes]]]:
    """Returns `(g0_gate, r0_gate, g0_manifest_doc, r0_relock_doc, e1_entries)`."""
    specs = (
        ("e1_aux_bundle_zip", BASELINE_E1_AUX_SHA256, BASELINE_E1_AUX_SIZE, True),
        ("frozen40_zip", BASELINE_FROZEN40_SHA256, BASELINE_FROZEN40_SIZE, True),
        ("frozen46_zip", BASELINE_FROZEN46_SHA256, BASELINE_FROZEN46_SIZE, True),
        ("f99_bundle_zip", BASELINE_F99_SHA256, BASELINE_F99_SIZE, False),
        ("f100_tribunal_receipt", BASELINE_F100_SHA256, BASELINE_F100_SIZE, False),
    )

    artifact_records: Dict[str, Any] = {}
    raw_blobs: Dict[str, bytes] = {}
    missing_required: List[str] = []

    for key, exp_sha, exp_sz, is_req in specs:
        p = paths.get(key)
        if p is None or not p.is_file():
            artifact_records[key] = {
                "expected_sha256": exp_sha,
                "expected_size_bytes": exp_sz,
                "required_for_e1_core_relock": is_req,
                "status": "EVIDENCE_UNAVAILABLE",
            }
            if is_req:
                missing_required.append(key)
            continue
        blob = read_readonly_bytes(p)
        act_sha = sha256_hex(blob)
        if act_sha != exp_sha or len(blob) != exp_sz:
            err = f"ERR_T104_BASELINE_HASH_OR_SIZE_MISMATCH:{key}"
            g0_fail = fw.make_gate_record(
                "gate_104_g0_baseline_lock",
                "REJECTED_INVARIANT",
                {"artifact_records": artifact_records, "failed_key": key, "actual_sha256": act_sha},
                error_code=err,
            )
            r0_fail = fw.make_gate_record(
                "gate_104_r0_ancestor_relock_40_46",
                "REJECTED_INVARIANT",
                {"reason": err},
                error_code=err,
            )
            return (g0_fail, r0_fail, {}, {}, None)
        raw_blobs[key] = blob
        artifact_records[key] = {
            "actual_sha256": act_sha,
            "actual_size_bytes": len(blob),
            "expected_sha256": exp_sha,
            "expected_size_bytes": exp_sz,
            "readonly_source_name": p.name,
            "required_for_e1_core_relock": is_req,
            "status": "SOURCE_BOUND",
        }

    g0_manifest_doc = fw.seal_json(
        {
            "authority_boundaries": {
                "e1_core_qualification_target": "SCOPED_EVALUATION_ONLY",
                "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
                "frozen_ancestors_mutation": "FORBIDDEN_READ_ONLY",
                "release_47_packaging": "NOT_AUTHORIZED",
            },
            "baseline_artifacts": artifact_records,
            "qualification_stage": STAGE_NAME,
            "schema": "CAMPUS_T104_GATE_MANIFEST_V1",
        }
    )

    if "e1_aux_bundle_zip" not in raw_blobs:
        g0_unavail = fw.make_gate_record(
            "gate_104_g0_baseline_lock",
            "EVIDENCE_UNAVAILABLE",
            {"missing": ["e1_aux_bundle_zip"]},
            error_code="EVIDENCE_UNAVAILABLE:e1_aux_bundle_zip",
        )
        r0_unavail = fw.make_gate_record(
            "gate_104_r0_ancestor_relock_40_46",
            "EVIDENCE_UNAVAILABLE",
            {"missing": missing_required},
            error_code="EVIDENCE_UNAVAILABLE:e1_aux_bundle_zip",
        )
        return (g0_unavail, r0_unavail, g0_manifest_doc, {}, None)

    e1_entries, err_e1, e1_meta = audit_zip_hygiene(raw_blobs["e1_aux_bundle_zip"], "e1_aux")
    if err_e1 is not None or e1_entries is None:
        g0_bad = fw.make_gate_record(
            "gate_104_g0_baseline_lock", "REJECTED_INVARIANT", {}, error_code=err_e1
        )
        return (g0_bad, g0_bad, g0_manifest_doc, {}, None)

    g0_gate = fw.make_gate_record(
        "gate_104_g0_baseline_lock",
        "SOURCE_BOUND",
        {
            "e1_aux_crc32_xor_hex": e1_meta["crc32_xor_hex"],
            "e1_aux_entry_count": e1_meta["entry_count"],
            "e1_aux_sha256": e1_meta["sha256"],
            "f99_status": artifact_records["f99_bundle_zip"]["status"],
            "f100_status": artifact_records["f100_tribunal_receipt"]["status"],
        },
    )

    if missing_required:
        r0_doc = fw.seal_json(
            {
                "missing_required_ancestors": missing_required,
                "qualification_stage": STAGE_NAME,
                "schema": "CAMPUS_T104_ANCESTOR_RELOCK_V1",
                "status": "EVIDENCE_UNAVAILABLE",
            }
        )
        r0_gate = fw.make_gate_record(
            "gate_104_r0_ancestor_relock_40_46",
            "EVIDENCE_UNAVAILABLE",
            {"missing_required_ancestors": missing_required},
            error_code=f"EVIDENCE_UNAVAILABLE:{','.join(missing_required)}",
        )
        return (g0_gate, r0_gate, g0_manifest_doc, r0_doc, e1_entries)

    f46_entries, err_46, f46_meta = audit_zip_hygiene(raw_blobs["frozen46_zip"], "frozen46")
    f40_entries, err_40, f40_meta = audit_zip_hygiene(raw_blobs["frozen40_zip"], "frozen40")
    if err_46 or err_40 or f46_entries is None or f40_entries is None:
        err_c = err_46 or err_40 or "ERR_T104_ANCESTOR_ZIP_HYGIENE"
        r0_bad = fw.make_gate_record(
            "gate_104_r0_ancestor_relock_40_46", "REJECTED_INVARIANT", {}, error_code=err_c
        )
        return (g0_gate, r0_bad, g0_manifest_doc, {}, e1_entries)

    # Direct raw-byte comparison of all 24 precedent .lean files between E1 bundle and Frozen #46 ZIP
    f46_lean_keys = sorted(
        k for k in f46_entries if k.startswith("lean/") and k.endswith(".lean")
    )
    if len(f46_lean_keys) != 24:
        r0_bad = fw.make_gate_record(
            "gate_104_r0_ancestor_relock_40_46",
            "REJECTED_INVARIANT",
            {"found_f46_lean_count": len(f46_lean_keys)},
            error_code="ERR_T104_UNEXPECTED_FROZEN46_LEAN_COUNT",
        )
        return (g0_gate, r0_bad, g0_manifest_doc, {}, e1_entries)

    per_file_comparison: List[Dict[str, Any]] = []
    for lk in f46_lean_keys:
        if lk not in e1_entries:
            r0_bad = fw.make_gate_record(
                "gate_104_r0_ancestor_relock_40_46",
                "REJECTED_INVARIANT",
                {"missing_in_e1": lk},
                error_code=f"ERR_T104_MISSING_PRECEDENT_LEAN:{lk}",
            )
            return (g0_gate, r0_bad, g0_manifest_doc, {}, e1_entries)
        b_46 = f46_entries[lk]
        b_e1 = e1_entries[lk]
        sha_46 = sha256_hex(b_46)
        sha_e1 = sha256_hex(b_e1)
        if b_46 != b_e1 or sha_46 != sha_e1:
            r0_bad = fw.make_gate_record(
                "gate_104_r0_ancestor_relock_40_46",
                "REJECTED_INVARIANT",
                {"file": lk, "frozen46_sha256": sha_46, "e1_sha256": sha_e1},
                error_code=f"ERR_T104_ANCESTOR_BYTE_MISMATCH:{lk}",
            )
            return (g0_gate, r0_bad, g0_manifest_doc, {}, e1_entries)
        per_file_comparison.append(
            {
                "byte_identical_to_frozen46": True,
                "e1_sha256": sha_e1,
                "e1_size_bytes": len(b_e1),
                "frozen46_sha256": sha_46,
                "frozen46_size_bytes": len(b_46),
                "path": lk,
            }
        )

    # Physical inspection of #1..#45 archives IF mounted in campus_archive_dir (never assumed!)
    heritage_45 = json.loads(
        f46_entries["receipts/OMEGA_LAMBDA_W2_HERITAGE_PRESERVATION_45_RECEIPT.json"].decode("utf-8")
    )
    arch_dir = paths.get("campus_archive_dir")
    mounted_matched = 0
    unmounted_count = 0
    reverified_json_seals = 0

    # Count seals physically verified inside #40 and #46 right now
    for z_ents in (f40_entries, f46_entries):
        for zk, zb in z_ents.items():
            if zk.endswith(".json"):
                try:
                    jobj = json.loads(zb.decode("utf-8"))
                    if isinstance(jobj, dict) and "seal" in jobj and fw.verify_json_seal(jobj):
                        reverified_json_seals += 1
                except Exception:
                    pass

    if arch_dir is not None and arch_dir.is_dir():
        for hent in heritage_45.get("archives", []):
            zname = hent["zip_name"]
            zp = arch_dir / zname
            if not zp.is_file():
                unmounted_count += 1
                continue
            zraw = read_readonly_bytes(zp)
            if sha256_hex(zraw) != hent["expected_sha256"] or len(zraw) != hent["expected_size_bytes"]:
                r0_bad = fw.make_gate_record(
                    "gate_104_r0_ancestor_relock_40_46",
                    "REJECTED_INVARIANT",
                    {"corrupted_heritage_zip": zname},
                    error_code=f"ERR_T104_HERITAGE_ARCHIVE_MISMATCH:{zname}",
                )
                return (g0_gate, r0_bad, g0_manifest_doc, {}, e1_entries)
            mounted_matched += 1
    else:
        unmounted_count = len(heritage_45.get("archives", []))

    r0_doc = fw.seal_json(
        {
            "direct_24_lean_comparisons": per_file_comparison,
            "e1_aux_hygiene": e1_meta,
            "frozen40_hygiene": f40_meta,
            "frozen46_hygiene": f46_meta,
            "historical_45_archives_audit": {
                "honesty_note": (
                    "Only physically mounted archives are counted as re-hashed; unmounted "
                    "historical archives are explicitly recorded as EVIDENCE_UNAVAILABLE."
                ),
                "physically_mounted_and_matched_of_45": mounted_matched,
                "physically_reverified_json_seals_in_40_and_46": reverified_json_seals,
                "unmounted_of_45_count": unmounted_count,
                "unmounted_status": "NONE_ALL_45_MOUNTED" if unmounted_count == 0 else "EVIDENCE_UNAVAILABLE",
            },
            "qualification_stage": STAGE_NAME,
            "schema": "CAMPUS_T104_ANCESTOR_RELOCK_V1",
        }
    )

    r0_gate = fw.make_gate_record(
        "gate_104_r0_ancestor_relock_40_46",
        "SOURCE_BOUND",
        {
            "direct_frozen46_24_lean_byte_matches": 24,
            "e1_aux_duplicate_or_collision_entries": 0,
            "frozen40_sha256": f40_meta["sha256"],
            "frozen46_sha256": f46_meta["sha256"],
            "mounted_historical_archives_matched_of_45": mounted_matched,
            "unmounted_historical_archives_count": unmounted_count,
        },
    )
    return (g0_gate, r0_gate, g0_manifest_doc, r0_doc, e1_entries)


# =============================================================================
# Static Presence Scan (`STATIC_PRESENT` — Strictly Zero `verified` Key Names!)
# =============================================================================

def run_static_syntax_scan(e1_entries: Mapping[str, bytes]) -> Dict[str, Any]:
    """Scans CR bytes, forbidden Lean tokens, declaration names, and F103-01 `[r]?` syntax.
    Per F104-04, NO output key may contain the word `verified` — this is strictly `STATIC_PRESENT`."""
    decl_names: Dict[str, str] = {}
    decl_re = re.compile(r"^(theorem|def|structure)\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
    ns_open = re.compile(r"^namespace\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
    ns_end = re.compile(r"^end\s+([A-Za-z_][A-Za-z0-9_'?.]*)")

    for _, rel_p in ORDERED_28_MODULES:
        key = f"lean/{rel_p}"
        if key not in e1_entries:
            return fw.make_gate_record(
                "gate_104_static_syntax_scan",
                "REJECTED_INVARIANT",
                {"missing_module": key},
                error_code=f"ERR_T104_MISSING_MODULE:{key}",
            )
        raw = e1_entries[key]
        if b"\r" in raw:
            return fw.make_gate_record(
                "gate_104_static_syntax_scan",
                "REJECTED_INVARIANT",
                {"cr_in_module": key},
                error_code=f"ERR_T104_CR_LINE_ENDING:{key}",
            )
        cleaned = strip_lean_comments_and_strings(raw.decode("utf-8"))
        for rx in FORBIDDEN_LEAN_PATTERNS:
            if rx.search(cleaned):
                return fw.make_gate_record(
                    "gate_104_static_syntax_scan",
                    "REJECTED_INVARIANT",
                    {"module": key, "pattern": rx.pattern},
                    error_code=f"ERR_T104_FORBIDDEN_STATIC_TOKEN:{key}",
                )
        ns_stack: List[str] = []
        for ln in cleaned.splitlines():
            sln = ln.strip()
            mo = ns_open.match(sln)
            if mo:
                ns_stack.append(mo.group(1))
                continue
            me = ns_end.match(sln)
            if me and ns_stack:
                ns_stack.pop()
                continue
            if ln and not ln[0].isspace():
                md = decl_re.match(ln)
                if md:
                    fqn = f"{'.'.join(ns_stack)}.{md.group(2)}" if ns_stack else md.group(2)
                    decl_names[fqn] = md.group(1)

    for thm in REQUIRED_36_THEOREMS:
        if decl_names.get(thm) != "theorem":
            return fw.make_gate_record(
                "gate_104_static_syntax_scan",
                "REJECTED_INVARIANT",
                {"missing_theorem_identifier": thm},
                error_code=f"ERR_T104_MISSING_THEOREM_DECL:{thm}",
            )

    ev_clean = strip_lean_comments_and_strings(
        e1_entries["lean/OmegaLambda/EvasionRefinement.lean"].decode("utf-8")
    )
    if re.search(r"(?m)^theorem\s+encodeBindHeaderList_length\b", ev_clean):
        return fw.make_gate_record(
            "gate_104_static_syntax_scan",
            "REJECTED_INVARIANT",
            {},
            error_code="ERR_T104_F102_01_HEADER_NAME_COLLISION",
        )

    f103_pats = (
        r"\(kSubsets\s+\(C\.baseCert\.claimedU\s*-\s*1\)\s+ip\.remIssuers\)\[r\]\?\s*=\s*some\s+S",
        r"C\.evasionPathIndices\[r\]\?\s*=\s*some\s+j",
        r"pkt\[j\]\?\s*=\s*some\s+γ",
        r"SourceWalkSurvivesIdx\s+snap\s+S\s+γ",
    )
    for pat in f103_pats:
        if not re.search(pat, ev_clean):
            return fw.make_gate_record(
                "gate_104_static_syntax_scan",
                "REJECTED_INVARIANT",
                {"missing_pattern": pat},
                error_code="ERR_T104_F103_01_POSITIONAL_WITNESS_BROKEN",
            )

    return fw.make_gate_record(
        "gate_104_static_syntax_scan",
        "STATIC_PRESENT",
        {
            "cr_bytes_detected": 0,
            "f102_01_header_redeclaration_absent": True,
            "f103_01_positional_syntax_tokens_present": True,
            "forbidden_token_matches": 0,
            "static_present_e1_theorem_identifiers_count": len(REQUIRED_36_THEOREMS),
            "static_present_top_level_decls_28_modules": len(decl_names),
        },
    )


# =============================================================================
# Cross-Term Identity Lifecycle & Frozen #40 Cross-Check (Zero Shared Code!)
# =============================================================================

def _binom_dp(n: int, k: int) -> int:
    row = [1]
    for _ in range(n):
        nxt = []
        prev = 0
        for x in row:
            nxt.append(prev + x)
            prev = x
        nxt.append(prev)
        row = nxt
    return row[k] if 0 <= k < len(row) else 0


def parse_and_check_packet0x03_cross_terms_standalone(
    pkt_bytes: bytes,
) -> Tuple[bool, Optional[str], Dict[str, Any]]:
    """Pure standard-library parser checking the non-linear cross-term chain:
       Bytes -> CNB-v1 Snapshot Root -> Carrier Preimage -> 70B BindHeader -> 0x01 Evasion Slice."""
    if len(pkt_bytes) < 16:
        return (False, "ERR_T104_TRUNCATED_CNP2_PACKET", {})
    magic, wire_ver, pkt_kind, res_zero, body_len = struct.unpack_from(">4sHBBI", pkt_bytes, 0)
    if magic != b"CNP2" or wire_ver != 2 or pkt_kind != 0x03 or res_zero != 0:
        return (False, "ERR_T104_INVALID_CNP2_ENVELOPE", {})
    if body_len != len(pkt_bytes) - 12:
        return (False, "ERR_T104_BODY_LENGTH_MISMATCH", {})

    body = pkt_bytes[12:]
    (base_len,) = struct.unpack_from(">I", body, 0)
    if 4 + base_len > len(body):
        return (False, "ERR_T104_TRUNCATED_BASE_BUNDLE", {})
    base_raw = body[4 : 4 + base_len]
    b_magic, b_ver = struct.unpack_from(">4sH", base_raw, 0)
    if b_magic != b"CNB1" or b_ver != 1:
        return (False, "ERR_T104_BAD_CNB1_PREAMBLE", {})
    (
        closure_tag,
        _claim_short,
        auth_tier,
        _r0,
        gen_v,
        pol_mask,
        _ttag,
        _pad,
        claimed_h_sigma,
    ) = struct.unpack_from(">BBBBIHBB32s", base_raw, 6)
    (snap_len,) = struct.unpack_from(">I", base_raw, 50)
    snap_slice = base_raw[54 : 54 + snap_len]

    recomputed_h_sigma = hashlib.sha256(
        SNAPSHOT_DOMAIN_PREFIX + struct.pack(">IH", gen_v, pol_mask) + snap_slice
    ).digest()
    if recomputed_h_sigma != claimed_h_sigma or pol_mask != 0xFF33 or auth_tier != 1:
        return (False, "ERR_T104_CROSS_TERM_SNAPSHOT_ROOT_OR_POLICY_MISMATCH", {})

    # Decode snap_slice directly to extract live IR edge_support and ir_cnt (no hardcoded indices!)
    sc, slim = 0, len(snap_slice)
    (sid_len,) = struct.unpack_from(">H", snap_slice, sc)
    sc += 2 + sid_len
    id_of_vid: List[str] = []
    for _ in range(4):
        (s_cnt,) = struct.unpack_from(">H", snap_slice, sc)
        sc += 2
        prev_v = b""
        for v_i in range(s_cnt):
            (m_len,) = struct.unpack_from(">H", snap_slice, sc)
            sc += 2
            m_raw = snap_slice[sc : sc + m_len]
            sc += m_len
            if v_i > 0 and m_raw <= prev_v:
                return (False, "ERR_T104_UNSORTED_SNAPSHOT_VERTEX_IDS", {})
            prev_v = m_raw
            id_of_vid.append(m_raw.decode("ascii"))
    (ir_cnt,) = struct.unpack_from(">I", snap_slice, sc)
    sc += 4
    edge_support: Dict[Tuple[int, int], List[int]] = {}
    ir_record_ids: List[str] = []
    prev_rec = b""
    for r_idx in range(ir_cnt):
        sc += 1  # rec_tag
        (rid_len,) = struct.unpack_from(">H", snap_slice, sc)
        sc += 2
        rid_raw = snap_slice[sc : sc + rid_len]
        sc += rid_len
        if r_idx > 0 and rid_raw <= prev_rec:
            return (False, "ERR_T104_UNSORTED_SNAPSHOT_IR_RECORD_IDS", {})
        prev_rec = rid_raw
        ir_record_ids.append(rid_raw.decode("ascii"))
        src_vid, _src_sort, ref_cnt = struct.unpack_from(">HBH", snap_slice, sc)
        sc += 5
        for _ in range(ref_cnt):
            tgt_vid, _tgt_sort, _rel_tag = struct.unpack_from(">HBB", snap_slice, sc)
            sc += 4
            lst = edge_support.setdefault((src_vid, tgt_vid), [])
            if r_idx not in lst:
                lst.append(r_idx)
    if sc != slim:
        return (False, "ERR_T104_UNCONSUMED_SNAPSHOT_SLICE_BYTES", {})

    cur = 4 + base_len
    q_s, q_t, const_cnt = struct.unpack_from(">HHH", body, cur)
    cur += 6
    const_indices = list(struct.unpack_from(f">{const_cnt}H", body, cur))
    cur += 2 * const_cnt
    rem_issuers_sorted = [i for i in range(ir_cnt) if i not in set(const_indices)]

    loc_start = cur
    (loc_cnt,) = struct.unpack_from(">H", body, cur)
    cur += 2
    loc_paths: List[List[int]] = []
    for _ in range(loc_cnt):
        (step_cnt,) = struct.unpack_from(">H", body, cur)
        cur += 2
        verts = list(struct.unpack_from(f">{step_cnt + 1}H", body, cur))
        cur += 2 * (step_cnt + 1)
        loc_paths.append(verts)
    loc_end = cur
    loc_carrier_raw = body[loc_start:loc_end]

    recomputed_h_carrier = hashlib.sha256(
        CARRIER_DOMAIN_PREFIX
        + struct.pack(">B", 1)
        + recomputed_h_sigma
        + struct.pack(">BHH", closure_tag, q_s, q_t)
        + loc_carrier_raw
    ).digest()

    claim_start = cur
    if cur + 70 > len(body):
        return (False, "ERR_T104_TRUNCATED_BIND_HEADER", {})
    b_sig, b_car, b_clo, b_ctag, b_s, b_t = struct.unpack_from(">32s32sBBHH", body, cur)
    cur += 70

    if (
        b_sig != recomputed_h_sigma
        or b_car != recomputed_h_carrier
        or b_clo != closure_tag
        or b_ctag != 1
        or b_s != q_s
        or b_t != q_t
    ):
        return (False, "ERR_T104_CROSS_TERM_BINDING_DIGEST_MISMATCH", {})

    (loc_mode,) = struct.unpack_from(">B", body, cur)
    cur += 1
    if loc_mode != 2:
        return (False, "ERR_T104_UNEXPECTED_LOCAL_MODE", {})
    c_L, c_U = struct.unpack_from(">HH", body, cur)
    cur += 4
    if not (1 <= c_L < c_U):
        return (False, "ERR_T104_G_E2_STRICT_GAP_VIOLATED", {})

    primal_list = []
    for _ in range(c_L):
        j_idx, step_decl = struct.unpack_from(">HH", body, cur)
        cur += 4
        steps = []
        for _ in range(step_decl):
            st_tag, ir_idx = struct.unpack_from(">BH", body, cur)
            cur += 3
            steps.append((st_tag, ir_idx))
        primal_list.append((j_idx, steps))

    hit_indices = list(struct.unpack_from(f">{c_U}H", body, cur))
    cur += 2 * c_U
    (ev_mode,) = struct.unpack_from(">B", body, cur)
    cur += 1
    if ev_mode != 1:
        return (False, "ERR_T104_LOCAL_0X01_SLICE_MISMATCH", {})
    (ev_cnt,) = struct.unpack_from(">I", body, cur)
    cur += 4
    if cur + 2 * ev_cnt > len(body):
        return (False, "ERR_T104_TRUNCATED_EVASION_INDICES", {})
    ev_indices = list(struct.unpack_from(f">{ev_cnt}H", body, cur))
    cur += 2 * ev_cnt
    claim_end = cur
    local_0x01_slice = body[claim_start:claim_end]

    return (
        True,
        None,
        {
            "claimed_L_U": [c_L, c_U],
            "closure_tag": closure_tag,
            "const_indices": const_indices,
            "edge_support": edge_support,
            "evasion_indices": ev_indices,
            "h_carrier_sha256": recomputed_h_carrier.hex(),
            "h_sigma_sha256": recomputed_h_sigma.hex(),
            "hit_indices": hit_indices,
            "id_of_vid": id_of_vid,
            "ir_record_ids": ir_record_ids,
            "local_0x01_slice_bytes": local_0x01_slice,
            "local_0x01_slice_len": len(local_0x01_slice),
            "local_paths": loc_paths,
            "primal_list": primal_list,
            "query_s_t": [q_s, q_t],
            "rem_issuers_sorted": rem_issuers_sorted,
        },
    )


def check_k3_positional_evasion_standalone(
    local_paths: Sequence[Sequence[int]],
    edge_support: Mapping[Tuple[int, int], Sequence[int]],
    rem_issuers_sorted: Sequence[int],
    claimed_L: int,
    claimed_U: int,
    evasion_indices: Sequence[int],
) -> Tuple[bool, Optional[str]]:
    if not (1 <= claimed_L < claimed_U <= len(rem_issuers_sorted)):
        return (False, "ERR_T104_G_E2_STRICT_GAP_VIOLATED")
    k = claimed_U - 1
    comb_cnt = _binom_dp(len(rem_issuers_sorted), k)
    if comb_cnt > 1024:
        return (False, "ERR_T104_COMBINATORIAL_BUDGET_1024_EXCEEDED")
    if len(evasion_indices) != comb_cnt:
        return (False, "ERR_T104_EVASION_TABLE_LENGTH_MISMATCH")

    subsets = [list(c) for c in itertools.combinations(rem_issuers_sorted, k)]
    for r_idx, (sub, j_idx) in enumerate(zip(subsets, evasion_indices)):
        if j_idx < 0 or j_idx >= len(local_paths):
            return (False, f"ERR_T104_EVASION_INDEX_OOB_AT_R{r_idx}")
        walk = local_paths[j_idx]
        sub_set = set(sub)
        for u, w in zip(walk, walk[1:]):
            supp = edge_support.get((u, w), ())
            if not any(iss not in sub_set for iss in supp):
                return (False, f"ERR_T104_EVASION_WITNESS_SURVIVAL_FAILED_AT_R{r_idx}")
    return (True, None)


def run_frozen40_and_cross_term_gates(
    paths: Mapping[str, Optional[Path]],
) -> Tuple[Dict[str, Any], Dict[str, Any], Optional[bytes]]:
    """Returns `(cross_term_gate, frozen40_gate, raw_k3_packet_bytes)`."""
    p40 = paths.get("frozen40_zip")
    if p40 is None or not p40.is_file():
        unavail = fw.make_gate_record(
            "gate_104_frozen40_wire_and_semantic_crosscheck",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "Frozen #40 ZIP not available in current environment"},
            error_code="EVIDENCE_UNAVAILABLE:frozen40_zip",
        )
        ct_unavail = fw.make_gate_record(
            "gate_104_cross_term_identity_lifecycle",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "Frozen #40 K3-Case A packet unavailable without Frozen #40 ZIP"},
            error_code="EVIDENCE_UNAVAILABLE:frozen40_zip",
        )
        return (ct_unavail, unavail, None)

    raw40 = read_readonly_bytes(p40)
    ents40, err40, _ = audit_zip_hygiene(raw40, "frozen40")
    if err40 or ents40 is None:
        bad = fw.make_gate_record(
            "gate_104_frozen40_wire_and_semantic_crosscheck",
            "REJECTED_INVARIANT",
            {},
            error_code=err40 or "ERR_T104_BAD_FROZEN40",
        )
        return (bad, bad, None)

    bridge_rec = json.loads(
        ents40["receipts/OMEGA_KAPPA_STAGE1_0_SEMANTIC_BRIDGE_AND_TRANSPORT_RECEIPT.json"].decode("utf-8")
    )
    pkt_hex = bridge_rec["packets"]["k3_case_a_evasion_exact_2"]["packet_cnp2_hex"]
    pkt_bytes = bytes.fromhex(pkt_hex)

    ok_ct, err_ct, parsed = parse_and_check_packet0x03_cross_terms_standalone(pkt_bytes)
    if not ok_ct:
        bad_ct = fw.make_gate_record(
            "gate_104_cross_term_identity_lifecycle",
            "REJECTED_INVARIANT",
            {},
            error_code=err_ct,
        )
        bad_f40 = fw.make_gate_record(
            "gate_104_frozen40_wire_and_semantic_crosscheck",
            "REJECTED_INVARIANT",
            {},
            error_code=err_ct,
        )
        return (bad_ct, bad_f40, pkt_bytes)

    ok_ev, err_ev = check_k3_positional_evasion_standalone(
        parsed["local_paths"],
        parsed["edge_support"],
        parsed["rem_issuers_sorted"],
        parsed["claimed_L_U"][0],
        parsed["claimed_L_U"][1],
        parsed["evasion_indices"],
    )
    if not ok_ev:
        bad_ct = fw.make_gate_record(
            "gate_104_cross_term_identity_lifecycle",
            "REJECTED_INVARIANT",
            {},
            error_code=err_ev,
        )
        bad_f40 = fw.make_gate_record(
            "gate_104_frozen40_wire_and_semantic_crosscheck",
            "REJECTED_INVARIANT",
            {},
            error_code=err_ev,
        )
        return (bad_ct, bad_f40, pkt_bytes)

    # Also execute untouched #40 pure checker in an isolated child Python process
    with tempfile.TemporaryDirectory() as tmp40:
        tdir = Path(tmp40)
        for zk, zb in ents40.items():
            if zk.startswith("src/") and zk.endswith(".py"):
                out_p = tdir / zk
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_bytes(zb)
        runner_code = (
            "import json, sys\n"
            "from src import omega_kappa_decoder as d, omega_kappa_pure_checker as c\n"
            f"pkt = bytes.fromhex('{pkt_hex}')\n"
            "term, errs = d.decode_cnp2_packet_bytes(pkt)\n"
            "assert not errs and term is not None, errs\n"
            "out = c.check_raw_packet_term_pure(term)\n"
            "assert out.accepted, out\n"
            "pl = dict(out.payload or ())\n"
            "print(json.dumps({'accepted': out.accepted, 'local_verdict': pl.get('local_verdict'), "
            "'rho_pi': pl.get('exact_local_ir_resilience_rho_pi')}))\n"
        )
        proc = subprocess.run(
            [sys.executable, "-c", runner_code],
            cwd=str(tdir),
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            bad = fw.make_gate_record(
                "gate_104_frozen40_wire_and_semantic_crosscheck",
                "REJECTED_INVARIANT",
                {"stderr": proc.stderr},
                error_code="ERR_T104_FROZEN40_PURE_CHECKER_REJECTED",
            )
            return (bad, bad, pkt_bytes)
        f40_child = json.loads(proc.stdout.strip())

    ct_gate = fw.make_gate_record(
        "gate_104_cross_term_identity_lifecycle",
        "SEMANTICALLY_VALIDATED",
        {
            "bound_h_carrier_sha256": parsed["h_carrier_sha256"],
            "bound_h_sigma_sha256": parsed["h_sigma_sha256"],
            "claimed_L_U": parsed["claimed_L_U"],
            "evasion_indices_positional_r0_r1_r2": parsed["evasion_indices"],
            "local_0x01_slice_bytes_len": parsed["local_0x01_slice_len"],
            "local_paths_lex_sorted": parsed["local_paths"] == sorted(parsed["local_paths"]),
        },
    )
    f40_gate = fw.make_gate_record(
        "gate_104_frozen40_wire_and_semantic_crosscheck",
        "SEMANTICALLY_VALIDATED",
        {
            "frozen40_child_verdict": f40_child,
            "frozen40_k3_packet_len_bytes": len(pkt_bytes),
            "frozen40_local_0x01_slice_sha256": sha256_hex(parsed["local_0x01_slice_bytes"]),
            "frozen40_local_0x01_slice_size_bytes": parsed["local_0x01_slice_len"],
        },
    )
    return (ct_gate, f40_gate, pkt_bytes)


# =============================================================================
# Core Structures 104-C0: Clean-Room 28-Module Lean 4.33.1 + Clean-Sheet Spec
# =============================================================================

def run_gate_c0_lean_kernel_audit(
    e1_entries: Mapping[str, bytes],
    probe_lean_source: str,
    keep_base24_cache_dir: Optional[Path] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    lean_bin = find_lean_binary()
    if lean_bin is None:
        doc = fw.seal_json(
            {
                "qualification_stage": STAGE_NAME,
                "reason": "Lean 4.33.1 compiler binary not available",
                "schema": "CAMPUS_T104_LEAN_KERNEL_AUDIT_V1",
                "status": "EVIDENCE_UNAVAILABLE",
                "target_comparison_constants_28": TARGET_COMPARISON_CONSTANTS_28,
            }
        )
        gate = fw.make_gate_record(
            "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "Lean 4.33.1 compiler binary not available"},
            error_code="EVIDENCE_UNAVAILABLE:lean_4_33_1",
        )
        return (gate, doc)

    vproc = subprocess.run([str(lean_bin), "--version"], capture_output=True, text=True)
    vout = (vproc.stdout + "\n" + vproc.stderr).strip()
    if vproc.returncode != 0 or PINNED_LEAN_VERSION not in vout or PINNED_LEAN_COMMIT not in vout:
        gate = fw.make_gate_record(
            "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
            "REJECTED_INVARIANT",
            {"version_output": vout},
            error_code="ERR_T104_WRONG_LEAN_TOOLCHAIN_VERSION",
        )
        return (gate, {})

    lean_bin_sha = sha256_hex(read_readonly_bytes(lean_bin))

    with tempfile.TemporaryDirectory() as tmp_lean:
        work = Path(tmp_lean) / "lean"
        work.mkdir(parents=True, exist_ok=True)
        for _, rel_p in ORDERED_28_MODULES:
            dst = work / rel_p
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(e1_entries[f"lean/{rel_p}"])

        env = dict(os.environ)
        env["LEAN_PATH"] = str(work)

        for idx, (mod_name, rel_p) in enumerate(ORDERED_28_MODULES):
            in_f = work / rel_p
            out_o = in_f.with_suffix(".olean")
            cproc = subprocess.run(
                [str(lean_bin), "-DwarningAsError=true", str(in_f), "-o", str(out_o)],
                cwd=str(work),
                env=env,
                capture_output=True,
                text=True,
            )
            if cproc.returncode != 0:
                gate = fw.make_gate_record(
                    "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                    "REJECTED_INVARIANT",
                    {"failed_module": mod_name, "stderr": cproc.stderr, "stdout": cproc.stdout},
                    error_code=f"ERR_T104_LEAN_COMPILE_FAILED:{mod_name}",
                )
                return (gate, {})
            if idx == 23 and keep_base24_cache_dir is not None:
                if keep_base24_cache_dir.exists():
                    shutil.rmtree(keep_base24_cache_dir)
                shutil.copytree(work, keep_base24_cache_dir)

        # 1. Run independent Clean-Sheet Specification Probe (defeating M104-04 & M104-05!)
        probe_path = work / "_T104CleanSheetSpecProbe.lean"
        probe_path.write_text(probe_lean_source, encoding="utf-8", newline="\n")
        pproc = subprocess.run(
            [str(lean_bin), "-DwarningAsError=true", str(probe_path)],
            cwd=str(work),
            env=env,
            capture_output=True,
            text=True,
        )
        if pproc.returncode != 0:
            gate = fw.make_gate_record(
                "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                "REJECTED_INVARIANT",
                {"probe_stdout": pproc.stdout, "probe_stderr": pproc.stderr},
                error_code="ERR_T104_LEAN_KERNEL_OR_CLEAN_SHEET_SPEC_FAILURE",
            )
            return (gate, {})

        # 2. Run SMap (map₁ ++ map₂) kernel environment audit
        insp_path = work / "_T104SMapInspector.lean"
        insp_path.write_text(SMAP_KERNEL_INSPECTOR_LEAN, encoding="utf-8", newline="\n")
        iproc = subprocess.run(
            [str(lean_bin), str(insp_path)],
            cwd=str(work),
            env=env,
            capture_output=True,
            text=True,
        )
        if iproc.returncode != 0:
            gate = fw.make_gate_record(
                "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                "REJECTED_INVARIANT",
                {"inspector_stdout": iproc.stdout, "inspector_stderr": iproc.stderr},
                error_code="ERR_T104_SMAP_INSPECTOR_FAILED",
            )
            return (gate, {})

        rows = [ln for ln in iproc.stdout.splitlines() if ln.startswith("T104_ROW|")]
        thm_axioms: Dict[str, List[str]] = {}
        per_mod_counts: Dict[str, int] = {}
        observed_axioms = set()
        for ln in rows:
            _, m_s, k_s, n_s, ax_csv = ln.split("|", 4)
            per_mod_counts[m_s] = per_mod_counts.get(m_s, 0) + 1
            axs = [a for a in ax_csv.split(",") if a]
            for a in axs:
                observed_axioms.add(a)
                if a not in ALLOWED_LEAN_AXIOMS:
                    gate = fw.make_gate_record(
                        "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                        "REJECTED_INVARIANT",
                        {"bad_axiom": a, "decl": n_s},
                        error_code=f"ERR_T104_DISALLOWED_AXIOM:{a}",
                    )
                    return (gate, {})
            if n_s in REQUIRED_36_THEOREMS:
                if k_s != "thmInfo":
                    gate = fw.make_gate_record(
                        "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                        "REJECTED_INVARIANT",
                        {"decl": n_s, "actual_kind": k_s},
                        error_code=f"ERR_T104_NOT_THMINFO:{n_s}",
                    )
                    return (gate, {})
                thm_axioms[n_s] = sorted(axs)

        if len(thm_axioms) != len(REQUIRED_36_THEOREMS):
            missing_t = sorted(set(REQUIRED_36_THEOREMS) - set(thm_axioms))
            gate = fw.make_gate_record(
                "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                "REJECTED_INVARIANT",
                {"missing_kernel_theorems": missing_t},
                error_code="ERR_T104_MISSING_KERNEL_THMINFO",
            )
            return (gate, {})

        e1_mods = {
            "OmegaLambda.EvasionRefinement",
            "OmegaLambda.EvasionRefinementExamples",
            "OmegaLambda.E1CoreAxiomAudit",
            "OmegaLambdaE1Core",
        }
        measured_e1_consts = sum(v for k, v in per_mod_counts.items() if k in e1_mods)
        measured_base24_consts = len(rows) - measured_e1_consts

        doc = fw.seal_json(
            {
                "clean_sheet_spec_probe_passed": True,
                "clean_sheet_spec_probe_sha256": sha256_hex(probe_lean_source.encode("utf-8")),
                "compiled_modules_count": len(ORDERED_28_MODULES),
                "execution_host": {
                    "lean_binary_sha256": lean_bin_sha,
                    "lean_version_first_line": vout.splitlines()[0],
                    "os_platform": platform.platform(),
                    "python_version": sys.version.split()[0],
                },
                "measured_base24_kernel_constants": measured_base24_consts,
                "measured_e1_core_kernel_constants": measured_e1_consts,
                "measured_total_kernel_constants_28": len(rows),
                "matches_target_comparison_3845": len(rows) == TARGET_COMPARISON_CONSTANTS_28,
                "observed_kernel_axioms": sorted(observed_axioms),
                "per_module_constant_counts": per_mod_counts,
                "qualification_stage": STAGE_NAME,
                "required_36_theorems_kernel_axioms": thm_axioms,
                "schema": "CAMPUS_T104_LEAN_KERNEL_AUDIT_V1",
                "sorryAx_count": 0,
                "target_comparison_constants_28": TARGET_COMPARISON_CONSTANTS_28,
                "target_comparison_constants_46_base": TARGET_COMPARISON_CONSTANTS_46_BASE,
                "trustCompiler_or_ofReduceBool_count": 0,
                "user_axiom_or_opaque_count": 0,
                "warning_as_error_enforced": True,
            }
        )
        gate = fw.make_gate_record(
            "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
            "KERNEL_VERIFIED",
            {
                "clean_sheet_spec_probe_passed": True,
                "compiled_modules_count": 28,
                "measured_total_kernel_constants_28": len(rows),
                "matches_target_comparison_3845": len(rows) == TARGET_COMPARISON_CONSTANTS_28,
                "observed_kernel_axioms": sorted(observed_axioms),
                "required_36_theorems_thmInfo_count": len(thm_axioms),
                "sorryAx_count": 0,
            },
        )
        return (gate, doc)


# =============================================================================
# Mutation Manifest 104-M0: Real Execution of Pre-Locked Vectors M104-01..M104-12
# =============================================================================

def execute_12_mutations_against_prelocked_manifest(
    paths: Mapping[str, Optional[Path]],
    e1_entries: Mapping[str, bytes],
    raw_k3_packet: Optional[bytes],
    probe_lean_source: str,
    base24_cache_dir: Optional[Path],
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    results: List[Dict[str, Any]] = []
    lean_bin = find_lean_binary()

    # M104-01: Remove Lean binary -> MUST produce QUALIFICATION_HELD (never PASS / SCOPED_ACCEPTED)
    prev_lean_env = os.environ.get("LEAN_BIN")
    os.environ["LEAN_BIN"] = ""
    try:
        m01_c0_gate, _ = run_gate_c0_lean_kernel_audit(e1_entries, probe_lean_source)
    finally:
        if prev_lean_env is None:
            os.environ.pop("LEAN_BIN", None)
        else:
            os.environ["LEAN_BIN"] = prev_lean_env
    m01_gates = {
        "gate_104_g0_baseline_lock": fw.make_gate_record("gate_104_g0_baseline_lock", "SOURCE_BOUND", {}),
        "gate_104_r0_ancestor_relock_40_46": fw.make_gate_record("gate_104_r0_ancestor_relock_40_46", "SOURCE_BOUND", {}),
        "gate_104_static_syntax_scan": fw.make_gate_record("gate_104_static_syntax_scan", "STATIC_PRESENT", {}),
        "gate_104_cross_term_identity_lifecycle": fw.make_gate_record("gate_104_cross_term_identity_lifecycle", "SEMANTICALLY_VALIDATED", {}),
        "gate_104_frozen40_wire_and_semantic_crosscheck": fw.make_gate_record("gate_104_frozen40_wire_and_semantic_crosscheck", "SEMANTICALLY_VALIDATED", {}),
        "gate_104_c0_lean_kernel_28_and_clean_sheet_spec": m01_c0_gate,
        "gate_104_m0_mutation_12_suite": fw.make_gate_record("gate_104_m0_mutation_12_suite", "SEMANTICALLY_VALIDATED", {}),
        "gate_104_t0_same_host_zero_shared_replay": fw.make_gate_record("gate_104_t0_same_host_zero_shared_replay", "INDEPENDENT_REPLAYED", {}),
    }
    m01_verdict, m01_reasons = fw.derive_tribunal_verdict(m01_gates, fw.REQUIRED_LOCAL_CLEANROOM_GATES)
    m01_ok = (
        m01_c0_gate["tier"] == "EVIDENCE_UNAVAILABLE"
        and m01_verdict == "QUALIFICATION_HELD"
        and m01_verdict not in ("PASS", "SCOPED_ACCEPTED")
    )
    results.append({
        "vector_id": "M104-01",
        "observed_gate_tier": m01_c0_gate["tier"],
        "observed_verdict": m01_verdict,
        "observed_reasons": m01_reasons,
        "expectation_satisfied": m01_ok,
    })

    # M104-02: Remove Frozen #40 ZIP -> MUST produce QUALIFICATION_HELD
    m02_paths = dict(paths)
    m02_paths["frozen40_zip"] = None
    _, m02_f40_gate, _ = run_frozen40_and_cross_term_gates(m02_paths)
    m02_gates = dict(m01_gates)
    m02_gates["gate_104_c0_lean_kernel_28_and_clean_sheet_spec"] = fw.make_gate_record(
        "gate_104_c0_lean_kernel_28_and_clean_sheet_spec", "KERNEL_VERIFIED", {}
    )
    m02_gates["gate_104_frozen40_wire_and_semantic_crosscheck"] = m02_f40_gate
    m02_verdict, m02_reasons = fw.derive_tribunal_verdict(m02_gates, fw.REQUIRED_LOCAL_CLEANROOM_GATES)
    m02_ok = (
        m02_f40_gate["tier"] == "EVIDENCE_UNAVAILABLE"
        and m02_verdict == "QUALIFICATION_HELD"
    )
    results.append({
        "vector_id": "M104-02",
        "observed_gate_tier": m02_f40_gate["tier"],
        "observed_verdict": m02_verdict,
        "observed_reasons": m02_reasons,
        "expectation_satisfied": m02_ok,
    })

    # M104-03: 1-byte mutation in precedent lean/OmegaLambda/WireRefinement.lean vs Frozen #46 ZIP
    if paths.get("frozen46_zip") is not None and paths["frozen46_zip"].is_file():
        with tempfile.TemporaryDirectory() as tmp03:
            t03 = Path(tmp03)
            mut_zip = t03 / "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip"
            with zipfile.ZipFile(mut_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                for k, b in sorted(e1_entries.items()):
                    if k == "lean/OmegaLambda/WireRefinement.lean":
                        b = b[:-1] + bytes([b[-1] ^ 0x01])
                    zf.writestr(k, b)
            f46_ents, _, _ = audit_zip_hygiene(read_readonly_bytes(paths["frozen46_zip"]), "f46")
            mut_ents, _, _ = audit_zip_hygiene(read_readonly_bytes(mut_zip), "mut")
            assert f46_ents is not None and mut_ents is not None
            mismatch_detected = (
                f46_ents["lean/OmegaLambda/WireRefinement.lean"]
                != mut_ents["lean/OmegaLambda/WireRefinement.lean"]
            )
            m03_gate = fw.make_gate_record(
                "gate_104_r0_ancestor_relock_40_46",
                "REJECTED_INVARIANT" if mismatch_detected else "SOURCE_BOUND",
                {},
                error_code="ERR_T104_ANCESTOR_BYTE_MISMATCH:lean/OmegaLambda/WireRefinement.lean"
                if mismatch_detected
                else None,
            )
            m03_gates = dict(m02_gates)
            m03_gates["gate_104_frozen40_wire_and_semantic_crosscheck"] = fw.make_gate_record(
                "gate_104_frozen40_wire_and_semantic_crosscheck", "SEMANTICALLY_VALIDATED", {}
            )
            m03_gates["gate_104_r0_ancestor_relock_40_46"] = m03_gate
            m03_verdict, _ = fw.derive_tribunal_verdict(m03_gates, fw.REQUIRED_LOCAL_CLEANROOM_GATES)
            m03_ok = m03_verdict == "REJECTED"
            results.append({
                "vector_id": "M104-03",
                "observed_gate_tier": m03_gate["tier"],
                "observed_verdict": m03_verdict,
                "observed_error": m03_gate["error_code"],
                "expectation_satisfied": m03_ok,
            })
    else:
        results.append({"vector_id": "M104-03", "observed_gate_tier": "EVIDENCE_UNAVAILABLE", "expectation_satisfied": False})

    # M104-04: Keep theorem name `evasion0x01_source_exact_sound` (zero `sorry`!), replace with `: True := trivial`
    if lean_bin is not None and base24_cache_dir is not None and base24_cache_dir.is_dir():
        with tempfile.TemporaryDirectory() as tmp04:
            w04 = Path(tmp04) / "lean"
            shutil.copytree(base24_cache_dir, w04)
            orig_ev = e1_entries["lean/OmegaLambda/EvasionRefinement.lean"].decode("utf-8")
            idx_thm = orig_ev.index("theorem evasion0x01_source_exact_sound")
            mut_ev = (
                orig_ev[:idx_thm]
                + "theorem evasion0x01_source_exact_sound : True := trivial\n\nend OmegaLambda\n"
            )
            (w04 / "OmegaLambda/EvasionRefinement.lean").write_bytes(mut_ev.encode("utf-8"))
            # Also write trivial stubs for examples/audit/umbrella so we test Clean-Sheet Spec directly!
            (w04 / "OmegaLambda/EvasionRefinementExamples.lean").write_bytes(
                e1_entries["lean/OmegaLambda/EvasionRefinementExamples.lean"]
            )
            env04 = dict(os.environ)
            env04["LEAN_PATH"] = str(w04)
            # Compile mutated EvasionRefinement.lean (succeeds cleanly with zero sorry!), then compile Examples/Probe (MUST FAIL!)
            p_ev = subprocess.run(
                [
                    str(lean_bin),
                    "-DwarningAsError=true",
                    str(w04 / "OmegaLambda/EvasionRefinement.lean"),
                    "-o",
                    str(w04 / "OmegaLambda/EvasionRefinement.olean"),
                ],
                cwd=str(w04),
                env=env04,
                capture_output=True,
                text=True,
            )
            probe_f = w04 / "_T104ProbeM04.lean"
            probe_f.write_text(
                "import OmegaLambda.EvasionRefinement\n"
                "open OmegaLambda\n"
                "example : ∀ (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)\n"
                "  (ip : IssuerPartition) (b : BaseData) (s t : VertexId) (pkt : List (List VertexId)) (C : SourceCertTermE1),\n"
                "  checkSourceAnchorAndSortLaw reg snap = true → lookupPinnedA1 snap.snapshotId reg = some ent →\n"
                "  ip = projectIssuerPartition snap ent.pinnedConstIds → b.G = projectIRGraph snap →\n"
                "  checkVerifiedBase ip b = true → checkSourceLocalCert0x01 snap ip b s t pkt C = true →\n"
                "  C.baseCert.carrierTag = 1 ∧ C.baseCert.modeTag = 2 ∧ C.baseCert.evasionModeTag = 1 ∧\n"
                "  1 ≤ C.baseCert.claimedL ∧ C.baseCert.claimedL < C.baseCert.claimedU ∧\n"
                "  ScopedSemanticResilience ip b s t (.localPacket pkt) (.finiteBounds C.baseCert.claimedL C.baseCert.claimedU) ∧\n"
                "  ScopedSemanticResilience ip b s t (.localPacket pkt) (.finiteBounds C.baseCert.claimedU C.baseCert.claimedU) ∧\n"
                "  SourceStringSemanticResilience reg snap b.kappa s t (.localPacket pkt) (.finiteBounds C.baseCert.claimedL C.baseCert.claimedU) ∧\n"
                "  SourceStringSemanticResilience reg snap b.kappa s t (.localPacket pkt) (.finiteBounds C.baseCert.claimedU C.baseCert.claimedU) :=\n"
                "  OmegaLambda.evasion0x01_source_exact_sound\n",
                encoding="utf-8",
            )
            p_prb = subprocess.run(
                [str(lean_bin), "-DwarningAsError=true", str(probe_f)],
                cwd=str(w04),
                env=env04,
                capture_output=True,
                text=True,
            )
            m04_ok = (p_ev.returncode == 0) and (p_prb.returncode != 0)
            results.append({
                "vector_id": "M104-04",
                "mutated_module_compiled_without_sorry": p_ev.returncode == 0,
                "clean_sheet_probe_exit_code": p_prb.returncode,
                "observed_gate_tier": "REJECTED_INVARIANT" if m04_ok else "KERNEL_VERIFIED",
                "observed_verdict": "REJECTED" if m04_ok else "SCOPED_ACCEPTED",
                "observed_error": "ERR_T104_LEAN_KERNEL_OR_CLEAN_SHEET_SPEC_FAILURE",
                "expectation_satisfied": m04_ok,
            })
    else:
        results.append({"vector_id": "M104-04", "observed_gate_tier": "EVIDENCE_UNAVAILABLE", "expectation_satisfied": False})

    # M104-05: Weaken `C.evasionPathIndices[r]? = some j` to unindexed `j ∈ C.evasionPathIndices`
    mut_e1_05 = dict(e1_entries)
    ev_txt_05 = mut_e1_05["lean/OmegaLambda/EvasionRefinement.lean"].decode("utf-8").replace(
        "C.evasionPathIndices[r]? = some j",
        "j ∈ C.evasionPathIndices",
    )
    mut_e1_05["lean/OmegaLambda/EvasionRefinement.lean"] = ev_txt_05.encode("utf-8")
    g05_static = run_static_syntax_scan(mut_e1_05)
    m05_lean_rejected = False
    if lean_bin is not None and base24_cache_dir is not None and base24_cache_dir.is_dir():
        with tempfile.TemporaryDirectory() as tmp05:
            w05 = Path(tmp05) / "lean"
            shutil.copytree(base24_cache_dir, w05)
            (w05 / "OmegaLambda/EvasionRefinement.lean").write_bytes(
                mut_e1_05["lean/OmegaLambda/EvasionRefinement.lean"]
            )
            env05 = dict(os.environ)
            env05["LEAN_PATH"] = str(w05)
            p05 = subprocess.run(
                [
                    str(lean_bin),
                    "-DwarningAsError=true",
                    str(w05 / "OmegaLambda/EvasionRefinement.lean"),
                    "-o",
                    str(w05 / "OmegaLambda/EvasionRefinement.olean"),
                ],
                cwd=str(w05),
                env=env05,
                capture_output=True,
                text=True,
            )
            if p05.returncode != 0:
                m05_lean_rejected = True
            else:
                pr05 = w05 / "_T104ProbeM05.lean"
                pr05.write_text(
                    "import OmegaLambda.EvasionRefinement\nopen OmegaLambda\n"
                    "example (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)\n"
                    "  (ip : IssuerPartition) (b : BaseData) (s t : VertexId) (pkt : List (List VertexId)) (C : SourceCertTermE1)\n"
                    "  (ev : ExtractedLocalE1Evidence reg snap ent ip b s t pkt C) (r : Nat) (S : List IssuerId)\n"
                    "  (hr : (kSubsets (C.baseCert.claimedU - 1) ip.remIssuers)[r]? = some S) :\n"
                    "  ∃ (j : Nat) (γ : List VertexId), C.evasionPathIndices[r]? = some j ∧ pkt[j]? = some γ ∧ SourceWalkSurvivesIdx snap S γ :=\n"
                    "  ev.sourceEvasionWitnesses r S hr\n",
                    encoding="utf-8",
                )
                p05_prb = subprocess.run(
                    [str(lean_bin), "-DwarningAsError=true", str(pr05)],
                    cwd=str(w05),
                    env=env05,
                    capture_output=True,
                    text=True,
                )
                m05_lean_rejected = p05_prb.returncode != 0
    m05_ok = (g05_static["tier"] == "REJECTED_INVARIANT") and (
        m05_lean_rejected if lean_bin is not None else True
    )
    results.append({
        "vector_id": "M104-05",
        "static_firewall_rejected": g05_static["tier"] == "REJECTED_INVARIANT",
        "lean_kernel_or_probe_rejected": m05_lean_rejected,
        "observed_gate_tier": "REJECTED_INVARIANT" if m05_ok else "STATIC_PRESENT",
        "observed_verdict": "REJECTED" if m05_ok else "SCOPED_ACCEPTED",
        "observed_error": g05_static["error_code"],
        "expectation_satisfied": m05_ok,
    })

    # M104-06: Permute [1, 2, 0] -> [0, 1, 2] on K3-Case A
    k3_paths = [[0, 1, 2, 4], [0, 2, 3, 4], [0, 3, 1, 4]]
    k3_edges = {
        (0, 1): [0], (0, 2): [0], (0, 3): [0],
        (1, 2): [1], (1, 4): [1], (2, 3): [2], (2, 4): [2], (3, 1): [3], (3, 4): [3],
    }
    ok06, err06 = check_k3_positional_evasion_standalone(k3_paths, k3_edges, [1, 2, 3], 1, 2, [0, 1, 2])
    m06_ok = (not ok06) and (err06 == "ERR_T104_EVASION_WITNESS_SURVIVAL_FAILED_AT_R0")
    results.append({
        "vector_id": "M104-06",
        "observed_gate_tier": "REJECTED_INVARIANT" if m06_ok else "SEMANTICALLY_VALIDATED",
        "observed_verdict": "REJECTED" if m06_ok else "SCOPED_ACCEPTED",
        "observed_error": err06,
        "expectation_satisfied": m06_ok,
    })

    # M104-07: Mutate 1 byte of the 103-byte Local 0x01 slice inside K3 packet (evasion_mode 0x01 -> 0x02)
    if raw_k3_packet is not None:
        _, _, parsed_k3 = parse_and_check_packet0x03_cross_terms_standalone(raw_k3_packet)
        slc = parsed_k3["local_0x01_slice_bytes"]
        off_in_pkt = raw_k3_packet.index(slc)
        # Flip evasion_mode byte (offset 92 in 103-byte slice: 70 + 1 + 4 + 13 + 4 = 92) from 0x01 to 0x02
        mut_pkt_07 = bytearray(raw_k3_packet)
        mut_pkt_07[off_in_pkt + 92] = 0x02
        ok07, err07, _ = parse_and_check_packet0x03_cross_terms_standalone(bytes(mut_pkt_07))
        m07_ok = (not ok07) and (err07 == "ERR_T104_LOCAL_0X01_SLICE_MISMATCH")
        results.append({
            "vector_id": "M104-07",
            "observed_gate_tier": "REJECTED_INVARIANT" if m07_ok else "SEMANTICALLY_VALIDATED",
            "observed_verdict": "REJECTED" if m07_ok else "SCOPED_ACCEPTED",
            "observed_error": err07,
            "expectation_satisfied": m07_ok,
        })
    else:
        results.append({"vector_id": "M104-07", "observed_gate_tier": "EVIDENCE_UNAVAILABLE", "expectation_satisfied": False})

    # M104-08: Preserve exact 859B & 103B lengths while flipping 1 bit of h_carrier_32 in 70B BindHeader
    if raw_k3_packet is not None:
        _, _, parsed_k3 = parse_and_check_packet0x03_cross_terms_standalone(raw_k3_packet)
        slc = parsed_k3["local_0x01_slice_bytes"]
        off_in_pkt = raw_k3_packet.index(slc)
        mut_pkt_08 = bytearray(raw_k3_packet)
        mut_pkt_08[off_in_pkt + 32] ^= 0x80  # byte 0 of h_carrier_32 inside 70B RawCarrierBindHeader
        assert len(mut_pkt_08) == len(raw_k3_packet)
        ok08, err08, _ = parse_and_check_packet0x03_cross_terms_standalone(bytes(mut_pkt_08))
        m08_ok = (not ok08) and (err08 == "ERR_T104_CROSS_TERM_BINDING_DIGEST_MISMATCH")
        results.append({
            "vector_id": "M104-08",
            "packet_length_preserved": len(mut_pkt_08) == len(raw_k3_packet),
            "observed_gate_tier": "REJECTED_INVARIANT" if m08_ok else "SEMANTICALLY_VALIDATED",
            "observed_verdict": "REJECTED" if m08_ok else "SCOPED_ACCEPTED",
            "observed_error": err08,
            "expectation_satisfied": m08_ok,
        })
    else:
        results.append({"vector_id": "M104-08", "observed_gate_tier": "EVIDENCE_UNAVAILABLE", "expectation_satisfied": False})

    # M104-09: binomDP(14, 6) = 3003 > 1024 budget firewall
    ok09, err09 = check_k3_positional_evasion_standalone(
        k3_paths, k3_edges, list(range(1, 15)), 1, 7, []
    )
    m09_ok = (_binom_dp(14, 6) == 3003) and (not ok09) and (err09 == "ERR_T104_COMBINATORIAL_BUDGET_1024_EXCEEDED")
    results.append({
        "vector_id": "M104-09",
        "binom_dp_14_6": _binom_dp(14, 6),
        "observed_gate_tier": "REJECTED_INVARIANT" if m09_ok else "SEMANTICALLY_VALIDATED",
        "observed_verdict": "REJECTED" if m09_ok else "SCOPED_ACCEPTED",
        "observed_error": err09,
        "expectation_satisfied": m09_ok,
    })

    # M104-10: Overwrite verdict to SCOPED_ACCEPTED on an incomplete (M104-01) receipt AND re-seal SHA-256!
    with tempfile.TemporaryDirectory() as tmp10:
        f_dummy = Path(tmp10) / "subject.bin"
        f_dummy.write_bytes(b"T104_SUBJECT_V1")
        forged_receipt = fw.seal_json({
            "authority_boundaries": {
                "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
                "release_47_packaging": "NOT_AUTHORIZED",
            },
            "bound_input_digests": {
                "subject": {"sha256": sha256_hex(b"T104_SUBJECT_V1"), "size_bytes": 15}
            },
            "gates": m01_gates,  # Note: m01_c0_gate is EVIDENCE_UNAVAILABLE!
            "verdicts": {
                "local_cleanroom_e1_core_verdict": "SCOPED_ACCEPTED",  # FORGED PROMOTION!
                "multi_host_detached_e1_core_verdict": "QUALIFICATION_HELD",
            },
        })
        ok10, err10 = fw.validate_receipt_consistency_and_live_state(
            forged_receipt, {"subject": f_dummy}
        )
        m10_ok = (not ok10) and (err10 is not None and err10.startswith("ERR_T104_VERDICT_EXCEEDS_EVIDENCE_LATTICE"))
        results.append({
            "vector_id": "M104-10",
            "forged_seal_valid": fw.verify_json_seal(forged_receipt),
            "observed_gate_tier": "REJECTED_INVARIANT" if m10_ok else "SEMANTICALLY_VALIDATED",
            "observed_verdict": "REJECTED" if m10_ok else "SCOPED_ACCEPTED",
            "observed_error": err10,
            "expectation_satisfied": m10_ok,
        })

    # M104-11: Post-verification input mutation -> Stale State Invalidation!
    with tempfile.TemporaryDirectory() as tmp11:
        f_live = Path(tmp11) / "live_bundle.zip"
        f_live.write_bytes(b"ORIGINAL_CANONICAL_BYTES_V1")
        clean_gates_11 = dict(m01_gates)
        clean_gates_11["gate_104_c0_lean_kernel_28_and_clean_sheet_spec"] = fw.make_gate_record(
            "gate_104_c0_lean_kernel_28_and_clean_sheet_spec", "KERNEL_VERIFIED", {}
        )
        valid_receipt_11 = fw.seal_json({
            "authority_boundaries": {
                "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
                "release_47_packaging": "NOT_AUTHORIZED",
            },
            "bound_input_digests": {
                "live_bundle": {
                    "sha256": sha256_hex(b"ORIGINAL_CANONICAL_BYTES_V1"),
                    "size_bytes": len(b"ORIGINAL_CANONICAL_BYTES_V1"),
                }
            },
            "gates": clean_gates_11,
            "verdicts": {
                "local_cleanroom_e1_core_verdict": "SCOPED_ACCEPTED",
                "multi_host_detached_e1_core_verdict": "QUALIFICATION_HELD",
            },
        })
        pre_ok, _ = fw.validate_receipt_consistency_and_live_state(valid_receipt_11, {"live_bundle": f_live})
        # Mutate 1 byte AFTER verification and attempt to reuse valid_receipt_11!
        f_live.write_bytes(b"ORIGINAL_CANONICAL_BYTES_V2")
        post_ok, err11 = fw.validate_receipt_consistency_and_live_state(valid_receipt_11, {"live_bundle": f_live})
        m11_ok = pre_ok and (not post_ok) and (err11 == "ERR_T104_STALE_INPUT_STATE_INVALIDATED:mutated:live_bundle")
        results.append({
            "vector_id": "M104-11",
            "pre_mutation_valid": pre_ok,
            "observed_gate_tier": "REJECTED_INVARIANT" if m11_ok else "SEMANTICALLY_VALIDATED",
            "observed_verdict": "REJECTED" if m11_ok else "SCOPED_ACCEPTED",
            "observed_error": err11,
            "expectation_satisfied": m11_ok,
        })

    # M104-12: Untouched K3-Case A positive control re-verification
    ok12_ev, err12_ev = check_k3_positional_evasion_standalone(k3_paths, k3_edges, [1, 2, 3], 1, 2, [1, 2, 0])
    ok12_pkt = False
    if raw_k3_packet is not None:
        ok12_pkt, _, _ = parse_and_check_packet0x03_cross_terms_standalone(raw_k3_packet)
    m12_ok = ok12_ev and ok12_pkt
    results.append({
        "vector_id": "M104-12",
        "observed_gate_tier": "KERNEL_VERIFIED" if (m12_ok and lean_bin is not None) else ("SEMANTICALLY_VALIDATED" if m12_ok else "EVIDENCE_UNAVAILABLE"),
        "observed_verdict": "SCOPED_ACCEPTED" if (m12_ok and lean_bin is not None) else "QUALIFICATION_HELD",
        "observed_error": err12_ev,
        "expectation_satisfied": m12_ok and (lean_bin is not None),
    })

    all_12_ok = len(results) == 12 and all(r.get("expectation_satisfied") is True for r in results)
    if all_12_ok:
        m0_gate = fw.make_gate_record(
            "gate_104_m0_mutation_12_suite",
            "SEMANTICALLY_VALIDATED",
            {
                "all_12_vectors_satisfied": True,
                "executed_vectors_count": 12,
                "vector_ids": [r["vector_id"] for r in results],
            },
        )
    else:
        unavail_vecs = [r["vector_id"] for r in results if r.get("observed_gate_tier") == "EVIDENCE_UNAVAILABLE"]
        if unavail_vecs:
            m0_gate = fw.make_gate_record(
                "gate_104_m0_mutation_12_suite",
                "EVIDENCE_UNAVAILABLE",
                {"unavailable_vectors": unavail_vecs},
                error_code=f"EVIDENCE_UNAVAILABLE:{','.join(unavail_vecs)}",
            )
        else:
            failed_vecs = [r["vector_id"] for r in results if not r.get("expectation_satisfied")]
            m0_gate = fw.make_gate_record(
                "gate_104_m0_mutation_12_suite",
                "REJECTED_INVARIANT",
                {"failed_vectors": failed_vecs},
                error_code=f"ERR_T104_MUTATION_SUITE_FAILURE:{','.join(failed_vecs)}",
            )
    return (m0_gate, results)


# =============================================================================
# Full T104 Qualification Orchestrator (`104-G0` .. `104-P0`)
# =============================================================================

def render_t104_tribunal_verdict_md(
    local_verdict: str,
    detached_verdict: str,
    held_detached_reasons: Sequence[str],
    r0_gate: Mapping[str, Any],
    c0_gate: Mapping[str, Any],
    m0_results: Sequence[Mapping[str, Any]],
    receipt_payload_sha256: str,
) -> str:
    c0_det = c0_gate.get("details", {})
    r0_det = r0_gate.get("details", {})
    lines = [
        "# CAMPUS-NOESIS `Ωλ-E1` — 제104차 독립 자격화 판정서 (`T104_TRIBUNAL_VERDICT`)",
        "",
        f"- **자격화 단계**: `{STAGE_NAME}`",
        f"- **로컬 클린룸 Zero-Shared-Code 판정 (`Win64` + `Lean 4.33.1`)**: **`{local_verdict}`**",
        f"- **다중 호스트 외부 클라우드 분리 실행 판정 (`Linux CI` / 외부 Tribunal)**: **`{detached_verdict}`**",
        "- **`E1-D` (`Packet0x03`) 및 제47차 릴리스 권한**: **`NOT_AUTHORIZED` (`HELD`)**",
        f"- **마스터 영수증 Payload SHA-256**: `{receipt_payload_sha256}`",
        "",
        "---",
        "",
        "## 1. 제104차 Findings (`F104-01` ~ `F104-05`) 해결 및 잔여 경계",
        "",
        "| Finding | 근본 원인 | 제104차 조치 결과 | 현재 상태 |",
        "| :--- | :--- | :--- | :--- |",
        "| `F104-01` | 필수 게이트가 `SKIPPED`여도 단일 문자열 `PASS` 출력 | `t104_firewall_lattice.py`에서 `PASS` 폐지 및 부분순서 격자(`TIER_RANK`) 도입. 필수 게이트 중 하나라도 `EVIDENCE_UNAVAILABLE`이면 자동 `QUALIFICATION_HELD` 강제 (`M104-01`, `M104-02`, `M104-10` 실증) | **RESOLVED (구조적 차단)** |",
        f"| `F104-02` | 제40차·제46차 원본 ZIP 부재로 직접 바이트 대조 보류 | 읽기 전용 제40차(`100,029 B`)·제46차(`236,214 B`) 원본과 보조 ZIP 내부 24개 `.lean`을 바이트 단위 직접 대조(`{r0_det.get('direct_frozen46_24_lean_byte_matches', 0)}/24` 일치) 및 휴대용 증거 팩에 원본 동봉 | **RESOLVED (실물 대조 완료)** |",
        f"| `F104-03` | 외부 실행 환경에 Lean 4.33.1 미설치로 커널 재검증 보류 | 로컬 클린룸 격리 빌드 + Clean-Sheet Spec Probe로 `{c0_det.get('compiled_modules_count', 0)}/28` 모듈·`{c0_det.get('measured_total_kernel_constants_28', 'N/A')}` 상수 재검증 완료; 단, 외부 다중 호스트 Linux 클라우드 커널 실행은 정직하게 `QUALIFICATION_HELD`로 분리 유지 | **LOCAL VERIFIED / EXTERNAL HELD** |",
        "| `F104-04` | 정적 이름 탐색 결과 키에 `verified` 명칭 혼용 | `STATIC_PRESENT` 계층에서 `verified` 문자열을 포함한 모든 JSON 키를 예외 발생으로 거부하는 명명 방화벽(`enforce_f104_04_naming_firewall`) 적용 | **RESOLVED (명명 방화벽 적용)** |",
        "| `F104-05` | 제출자 환경과 심판 환경의 도구·호스트 독립성 분리 필요 | Zero-Shared-Code 독립 파서/검사기 + Clean-Sheet Lean Spec Probe로 코드 공유를 제거하고, 동일 호스트 클린룸(`SAME_HOST_CLEANROOM`)과 외부 다중 호스트(`MULTI_HOST_DETACHED`) 판정을 이원화 + Ubuntu 24.04 Sigstore 워크플로 키트 준비 | **SCOPED SEPARATED (`MULTI_HOST = HELD`)** |",
        "",
        "---",
        "",
        "## 2. 사전 고정 Mutation Manifest (`M104-01` ~ `M104-12`) 실행 요약",
        "",
        "| Vector | 관측 계층 (`Tier`) | 도출 판정 | 기대 조건 충족 |",
        "| :--- | :--- | :--- | :--- |",
    ]
    for r in m0_results:
        lines.append(
            f"| `{r['vector_id']}` | `{r.get('observed_gate_tier')}` | "
            f"`{r.get('observed_verdict', 'N/A')}` | `{r.get('expectation_satisfied')}` |"
        )
    lines.extend([
        "",
        "---",
        "",
        "## 3. 세 축 인과 분석 및 차세대 Fiber 교환 법칙 명세 평가",
        "",
        "1. **평행·평형 축 (계보 보존)**: 동결 `#40`(`93d9a02a…26bb`), `#46`(`4c42f12b…4608`), `F99`(`26310ec2…311f`), `F100`(`e7cfb738…7298`), `OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip`(`38a055f3…da39`) 모두 `0`바이트 변경 없이 읽기 전용으로 검증됨.",
        "2. **직교 축 (정적 vs 커널 vs 와이어 분리)**: `M104-04`(`sorry` 없이 정리 결론만 `True`로 축소)와 `M104-05`(`[r]?` 위치 인덱싱 제거)를 통해 정적 선언 이름 존재만으로는 절대 통과할 수 없도록 Clean-Sheet Lean Spec Probe를 결합함.",
        "3. **교차항 축 (`Bytes → Parser → IR → Certificate → Proof → Receipt`)**: 단일 `K3-Case A` 패킷(`859 B`) 내부에서 `CNB-v1` 스냅샷 루트(`h_sigma_32`), 캐리어 프리이미지(`h_carrier_32`), `70 B` 결속 헤더, `103 B` `0x01` 회피 슬라이스, 영수증 실시간 입력 다이제스트(`M104-11`)의 전 구간 결속을 독립 검증함.",
        "4. **차세대 확장 명세 평가 (비승격 후보)**: `SourceIR → Packet` 인코딩과 `Graph → SemanticClaim` 해석 사이의 fiber 교환 법칙은 현재 `E1-Core` 범위에서는 Local `0x01` 슬라이스 및 소스 의미론 계층까지만 정립되어 있으며, 외곽 `Packet0x03` 전체 교환도(`E1-D`) 및 복수 스냅샷 간 sheaf/transport 정합성은 **미승인 후속 연구 과제(`HELD`)**로 명확히 분리함.",
        "",
        "## 4. 다중 호스트 분리 판정 보류 사유 (`multi_host_detached_e1_core_verdict`)",
        "",
    ])
    if held_detached_reasons:
        for hr in held_detached_reasons:
            lines.append(f"- `{hr}`")
    else:
        lines.append("- 없음")
    lines.append("")
    return "\n".join(lines)


def run_full_t104_qualification(
    t104_root: Optional[Path] = None,
    override_dir: Optional[Path] = None,
    write_ledger: bool = True,
    external_detached_receipt_path: Optional[Path] = None,
) -> Dict[str, Any]:
    if t104_root is None:
        t104_root = THIS_DIR.parent

    prelocked_manifest_path = t104_root / "manifests" / "T104_MUTATION_MANIFEST.json"
    prelocked_manifest_raw = read_readonly_bytes(prelocked_manifest_path)
    prelocked_manifest_sha256 = sha256_hex(prelocked_manifest_raw)
    prelocked_manifest_obj = json.loads(prelocked_manifest_raw.decode("utf-8"))

    probe_lean_path = t104_root / "src" / "t104_clean_sheet_spec_probe.lean"
    probe_lean_source = read_readonly_bytes(probe_lean_path).decode("utf-8")

    paths = resolve_artifact_paths(t104_root, override_dir=override_dir)

    # 1. 104-G0 & 104-R0
    g0_gate, r0_gate, g0_doc, r0_doc, e1_entries = run_gate_g0_and_r0(paths)

    # 2. Static syntax scan (`STATIC_PRESENT`)
    if e1_entries is not None:
        static_gate = run_static_syntax_scan(e1_entries)
    else:
        static_gate = fw.make_gate_record(
            "gate_104_static_syntax_scan",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "E1 bundle unavailable"},
            error_code="EVIDENCE_UNAVAILABLE:e1_aux_bundle_zip",
        )

    # 3. Cross-term identity lifecycle & Frozen #40 crosscheck
    ct_gate, f40_gate, raw_k3_pkt = run_frozen40_and_cross_term_gates(paths)

    # 4. 104-C0 Clean-room 28-module Lean 4.33.1 + Clean-Sheet Spec Probe + SMap audit
    with tempfile.TemporaryDirectory() as cache_parent:
        base24_cache = Path(cache_parent) / "base24_cache"
        if e1_entries is not None:
            c0_gate, c0_doc = run_gate_c0_lean_kernel_audit(
                e1_entries, probe_lean_source, keep_base24_cache_dir=base24_cache
            )
        else:
            c0_gate = fw.make_gate_record(
                "gate_104_c0_lean_kernel_28_and_clean_sheet_spec",
                "EVIDENCE_UNAVAILABLE",
                {"reason": "E1 bundle unavailable"},
                error_code="EVIDENCE_UNAVAILABLE:e1_aux_bundle_zip",
            )
            c0_doc = {}

        # 5. 104-M0 Execute all 12 pre-locked mutations
        if e1_entries is not None:
            m0_gate, m0_results = execute_12_mutations_against_prelocked_manifest(
                paths,
                e1_entries,
                raw_k3_pkt,
                probe_lean_source,
                base24_cache if base24_cache.is_dir() else None,
            )
        else:
            m0_gate = fw.make_gate_record(
                "gate_104_m0_mutation_12_suite",
                "EVIDENCE_UNAVAILABLE",
                {"reason": "E1 bundle unavailable"},
                error_code="EVIDENCE_UNAVAILABLE:e1_aux_bundle_zip",
            )
            m0_results = []

    # 6. 104-T0 Isolated subprocess replay & external multi-host detached check
    sub_cmd = [sys.executable, str(Path(__file__).resolve()), "--subprocess-probe-only"]
    if override_dir is not None:
        sub_cmd.extend(["--override-dir", str(override_dir)])
    sub_proc = subprocess.run(sub_cmd, capture_output=True, text=True)
    if sub_proc.returncode == 0:
        sub_info = json.loads(sub_proc.stdout.strip())
        t0_same_host_gate = fw.make_gate_record(
            "gate_104_t0_same_host_zero_shared_replay",
            "INDEPENDENT_REPLAYED",
            {
                "child_pid": sub_info["pid"],
                "parent_pid": os.getpid(),
                "separate_os_process": sub_info["pid"] != os.getpid(),
                "zero_author_module_imports": sub_info["zero_author_imports"],
            },
        )
    else:
        t0_same_host_gate = fw.make_gate_record(
            "gate_104_t0_same_host_zero_shared_replay",
            "REJECTED_INVARIANT",
            {"stderr": sub_proc.stderr},
            error_code="ERR_T104_SUBPROCESS_PROBE_FAILED",
        )

    if external_detached_receipt_path is not None and external_detached_receipt_path.is_file():
        # Reserved for cryptographically attested external Linux CI / non-author Tribunal bundle
        t0_ext_gate = fw.make_gate_record(
            "gate_104_t0_external_multi_host_cloud_lean_replay",
            "EVIDENCE_UNAVAILABLE",
            {"reason": "External Sigstore bundle verification hook requires attested Linux run"},
            error_code="EVIDENCE_UNAVAILABLE:external_sigstore_e1_bundle",
        )
    else:
        t0_ext_gate = fw.make_gate_record(
            "gate_104_t0_external_multi_host_cloud_lean_replay",
            "EVIDENCE_UNAVAILABLE",
            {
                "honesty_note": (
                    "Same-host Windows cleanroom Lean 4.33.1 replay is complete, but multi-host "
                    "non-author Linux/cloud Lean 4.33.1 execution for the 28 E1-Core modules has "
                    "not yet been executed externally (F104-03 / F104-05)."
                )
            },
            error_code="EVIDENCE_UNAVAILABLE:external_multi_host_cloud_lean_replay",
        )

    gates: Dict[str, Dict[str, Any]] = {
        "gate_104_g0_baseline_lock": g0_gate,
        "gate_104_r0_ancestor_relock_40_46": r0_gate,
        "gate_104_static_syntax_scan": static_gate,
        "gate_104_cross_term_identity_lifecycle": ct_gate,
        "gate_104_frozen40_wire_and_semantic_crosscheck": f40_gate,
        "gate_104_c0_lean_kernel_28_and_clean_sheet_spec": c0_gate,
        "gate_104_m0_mutation_12_suite": m0_gate,
        "gate_104_t0_same_host_zero_shared_replay": t0_same_host_gate,
        "gate_104_t0_external_multi_host_cloud_lean_replay": t0_ext_gate,
    }

    local_verdict, local_reasons = fw.derive_tribunal_verdict(
        gates, fw.REQUIRED_LOCAL_CLEANROOM_GATES
    )
    detached_verdict, detached_reasons = fw.derive_tribunal_verdict(
        gates, fw.REQUIRED_MULTI_HOST_DETACHED_GATES
    )

    bound_digests: Dict[str, Dict[str, Any]] = {
        "prelocked_mutation_manifest": {
            "sha256": prelocked_manifest_sha256,
            "size_bytes": len(prelocked_manifest_raw),
        },
        "clean_sheet_spec_probe_lean": {
            "sha256": sha256_hex(probe_lean_source.encode("utf-8")),
            "size_bytes": len(probe_lean_source.encode("utf-8")),
        },
    }
    live_Validation_map: Dict[str, Path] = {
        "prelocked_mutation_manifest": prelocked_manifest_path,
        "clean_sheet_spec_probe_lean": probe_lean_path,
    }
    for k in ("e1_aux_bundle_zip", "frozen40_zip", "frozen46_zip", "f99_bundle_zip", "f100_tribunal_receipt"):
        p = paths.get(k)
        if p is not None and p.is_file():
            rb = read_readonly_bytes(p)
            bound_digests[k] = {"sha256": sha256_hex(rb), "size_bytes": len(rb)}
            live_Validation_map[k] = p

    t104_detached_doc = fw.seal_json({
        "external_multi_host_cloud_lean_replay": t0_ext_gate,
        "mutation_execution_results": m0_results,
        "prelocked_mutation_manifest_sha256": prelocked_manifest_sha256,
        "qualification_stage": STAGE_NAME,
        "same_host_subprocess_replay": t0_same_host_gate,
        "schema": "CAMPUS_T104_DETACHED_REPLAY_V1",
    })

    master_receipt = fw.seal_json({
        "authority_boundaries": {
            "e1_core_scope": "E1_A_TO_C_AND_F103_01_ONLY",
            "e1d_packet0x03_promotion": "NOT_AUTHORIZED",
            "frozen_ancestors_modified_bytes": 0,
            "release_47_packaging": "NOT_AUTHORIZED",
        },
        "bound_input_digests": bound_digests,
        "canonical_status_recommendation": (
            "CAMPUS_OMEGA_LAMBDA_E1_CORE_T104_F104_01_02_04_RESOLVED__"
            f"LOCAL_CLEANROOM_LEAN4331_AND_FROZEN40_46_{local_verdict}__"
            f"EXTERNAL_MULTI_HOST_DETACHED_{detached_verdict}__"
            "E1D_AND_RELEASE47_NOT_AUTHORIZED"
        ),
        "gates": gates,
        "qualification_stage": STAGE_NAME,
        "schema": "CAMPUS_T104_VERIFICATION_RECEIPT_V1",
        "verdict_reasons": {
            "local_cleanroom_reasons": local_reasons,
            "multi_host_detached_reasons": detached_reasons,
        },
        "verdicts": {
            "local_cleanroom_e1_core_verdict": local_verdict,
            "multi_host_detached_e1_core_verdict": detached_verdict,
        },
    })

    valid_self, valid_err = fw.validate_receipt_consistency_and_live_state(
        master_receipt, live_Validation_map
    )
    if not valid_self:
        raise RuntimeError(f"Self-validation of T104 master receipt failed: {valid_err}")

    if write_ledger:
        ledger = t104_root / "ledger"
        ledger.mkdir(parents=True, exist_ok=True)

        def _dump_json(fname: str, obj: Mapping[str, Any]) -> None:
            (ledger / fname).write_bytes(
                json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n"
            )

        _dump_json("T104_GATE_MANIFEST.json", g0_doc)
        _dump_json("T104_ANCESTOR_RELOCK.json", r0_doc)
        _dump_json("T104_LEAN_KERNEL_AUDIT.json", c0_doc)
        _dump_json(
            "T104_MUTATION_MANIFEST.json",
            fw.seal_json({
                **prelocked_manifest_obj,
                "prelocked_source_sha256": prelocked_manifest_sha256,
            }),
        )
        _dump_json("T104_DETACHED_REPLAY.json", t104_detached_doc)
        _dump_json("T104_VERIFICATION_RECEIPT.json", master_receipt)

        verdict_md = render_t104_tribunal_verdict_md(
            local_verdict=local_verdict,
            detached_verdict=detached_verdict,
            held_detached_reasons=detached_reasons,
            r0_gate=r0_gate,
            c0_gate=c0_gate,
            m0_results=m0_results,
            receipt_payload_sha256=master_receipt["seal"]["payload_sha256"],
        )
        (ledger / "T104_TRIBUNAL_VERDICT.md").write_bytes(verdict_md.encode("utf-8"))

    return master_receipt


def _run_subprocess_probe(override_dir: Optional[Path]) -> int:
    author_mods = [m for m in sys.modules if "omega_lambda" in m or "verify_omega_lambda" in m]
    paths = resolve_artifact_paths(THIS_DIR.parent, override_dir=override_dir)
    p_e1 = paths.get("e1_aux_bundle_zip")
    e1_ok = p_e1 is not None and p_e1.is_file() and sha256_hex(read_readonly_bytes(p_e1)) == BASELINE_E1_AUX_SHA256
    print(json.dumps({
        "e1_baseline_match": e1_ok,
        "pid": os.getpid(),
        "zero_author_imports": len(author_mods) == 0,
    }))
    return 0 if (e1_ok and len(author_mods) == 0) else 1


def main() -> int:
    override: Optional[Path] = None
    args = sys.argv[1:]
    if "--override-dir" in args:
        idx = args.index("--override-dir")
        override = Path(args[idx + 1])
    if "--subprocess-probe-only" in args:
        return _run_subprocess_probe(override)
    no_write = "--no-write-ledger" in args
    rec = run_full_t104_qualification(override_dir=override, write_ledger=not no_write)
    print(json.dumps(rec, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

/-
  CAMPUS-NATIVE PROOFSPACE Ω — P0-R2 Single Scoped Remediation (`F-T1-07`)
  Module: `ProofspaceOmegaP0R2.ProofCarryingEvidenceR2`

  Exact Closure of `F-T1-07` & Pre-Approval Condition 1:
    1. Eliminates untrusted caller-supplied certification booleans (`ev.sourceAttested`,
       `ev.observerSchemaValid`, `0 < e.kernelCheckTag`) from authority-bearing gates.
    2. Defines `RawUntrustedFrontierInput` WITH explicit decoy fields `untrustedClaimedSourceOk`
       and `untrustedClaimedSchemaOk`, and proves Relational Noninterference:
         `r2_f07_detached_check_ignores_untrusted_booleans`
       confirming an untrusted caller setting those booleans to `true` gains zero certification power.
    3. Defines `VerifiedFrontierEvidenceR2` and `VerifiedRegimeEntryR2` as proof-carrying dependent
       structures whose constructors require a machine-checked kernel proof term (`detProof`,
       `lowProof`, `chkProof`), establishing:
         `Construct(VerifiedFrontierEvidenceR2) ⇒ runDetachedEvidenceCheckBool = true`
       and
         `Construct(VerifiedRegimeEntryR2) ⇒ DenoteSIRTerm M claim` (under `SpecModelsGraph`).
    4. Enforces Pre-Approval Condition 1: `VerifiedFrontierEvidenceR2` grants ONLY
       `EvidenceQualificationTier.sourceAndSchemaAttestedOnly` (`guaranteesEmpiricalTruth = false`).
-/

import ProofspaceOmegaP0R2.CoreInheritedR1

namespace ProofspaceOmegaP0R2

/-! ## 1. Trusted Source & Observer Calibration Registry (Explicit Trust Boundary) -/

structure TrustedIssuerEntry where
  issuerId          : Nat
  expectedAuthToken : Nat
  maxCalibratedRes  : Nat
  allowedPortSigs   : List Nat
  deriving DecidableEq, Repr

structure TrustedSourceRegistry where
  registryVersion : Nat
  issuers         : List TrustedIssuerEntry
  deriving DecidableEq, Repr

/-- Raw Tier-2 frontier input arriving from an untrusted caller / parser.
    Includes `untrustedClaimedSourceOk` and `untrustedClaimedSchemaOk` specifically so we can prove
    that `runDetachedEvidenceCheckBool` is mathematically invariant under attacker-forged booleans! -/
structure RawUntrustedFrontierInput where
  receiptId                : Nat
  issuerId                 : Nat
  presentedAuthToken       : Nat
  targetSpecHash           : Nat
  portSignature            : Nat
  measuredObserverRes      : Nat
  measuredBoundaryFlux     : Nat
  evidenceEpoch            : Nat
  untrustedClaimedSourceOk : Bool
  untrustedClaimedSchemaOk : Bool
  deriving DecidableEq, Repr

def verifyIssuerRecordBool (raw : RawUntrustedFrontierInput) (entry : TrustedIssuerEntry) : Bool :=
  (entry.issuerId == raw.issuerId) &&
  (entry.expectedAuthToken == raw.presentedAuthToken) &&
  (0 < raw.measuredObserverRes) &&
  (raw.measuredObserverRes ≤ entry.maxCalibratedRes) &&
  (entry.allowedPortSigs.any (fun sig => sig == raw.portSignature))

/-- `DetachedCheck`: Computes source & observer-schema attestation strictly from `reg`, `activeSpecHash`,
    and structural fields of `raw`, completely ignoring `untrustedClaimedSourceOk` and `untrustedClaimedSchemaOk`. -/
def runDetachedEvidenceCheckBool
    (reg : TrustedSourceRegistry) (activeSpecHash : Nat) (raw : RawUntrustedFrontierInput) : Bool :=
  (0 < raw.receiptId) &&
  (raw.targetSpecHash == activeSpecHash) &&
  reg.issuers.any (verifyIssuerRecordBool raw)

/-- `F-T1-07` Non-Spoofability Theorem 1: Flipping untrusted caller booleans (`untrustedClaimedSourceOk`,
    `untrustedClaimedSchemaOk`) to `true` has ZERO effect on `runDetachedEvidenceCheckBool`. -/
theorem r2_f07_detached_check_ignores_untrusted_booleans
    (reg : TrustedSourceRegistry) (activeSpecHash : Nat)
    (raw : RawUntrustedFrontierInput) (b1 b2 : Bool) :
    runDetachedEvidenceCheckBool reg activeSpecHash
      { raw with untrustedClaimedSourceOk := b1, untrustedClaimedSchemaOk := b2 } =
    runDetachedEvidenceCheckBool reg activeSpecHash raw := by
  rfl

/-! ## 2. Proof-Carrying `VerifiedFrontierEvidenceR2` & Explicit Epistemic Tier Cap -/

inductive EvidenceQualificationTier where
  | sourceAndSchemaAttestedOnly : EvidenceQualificationTier
  deriving DecidableEq, Repr

/-- Proof-carrying certified evidence object (`F-T1-07` + Condition 1B).
    No code anywhere in Lean can construct a value of `VerifiedFrontierEvidenceR2 reg activeSpecHash`
    without providing a proof term `detProof : runDetachedEvidenceCheckBool reg activeSpecHash raw = true`. -/
structure VerifiedFrontierEvidenceR2 (reg : TrustedSourceRegistry) (activeSpecHash : Nat) where
  raw      : RawUntrustedFrontierInput
  detProof : runDetachedEvidenceCheckBool reg activeSpecHash raw = true
  deriving DecidableEq

/-- Total smart constructor running `DetachedCheck` and producing `Option (VerifiedFrontierEvidenceR2 ...)`. -/
def certifyRawFrontierEvidence
    (reg : TrustedSourceRegistry) (activeSpecHash : Nat) (raw : RawUntrustedFrontierInput) :
    Option (VerifiedFrontierEvidenceR2 reg activeSpecHash) :=
  if h : runDetachedEvidenceCheckBool reg activeSpecHash raw = true then
    some { raw := raw, detProof := h }
  else
    none

/-- `F-T1-07` Constructor-Sealing Theorem (`Construct(VerifiedEvidence) ⇒ DetachedCheck = PASS`):
    Every inhabitant of `VerifiedFrontierEvidenceR2` provably satisfies `runDetachedEvidenceCheckBool = true`,
    matched to a registered issuer in `reg` and bound to `activeSpecHash`. -/
theorem r2_f07_construct_verified_evidence_implies_detached_pass
    (reg : TrustedSourceRegistry) (activeSpecHash : Nat)
    (ev : VerifiedFrontierEvidenceR2 reg activeSpecHash) :
    runDetachedEvidenceCheckBool reg activeSpecHash ev.raw = true ∧
    0 < ev.raw.receiptId ∧
    ev.raw.targetSpecHash = activeSpecHash ∧
    (∃ entry ∈ reg.issuers, verifyIssuerRecordBool ev.raw entry = true) := by
  have hp := ev.detProof
  refine ⟨hp, ?_⟩
  unfold runDetachedEvidenceCheckBool at hp
  simp only [Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq, List.any_eq_true] at hp
  exact ⟨hp.1.1, hp.1.2, hp.2⟩

/-- Pre-Approval Condition 1: Source & schema attestation NEVER certifies empirical truth of content. -/
def qualificationTierOf (_ev : VerifiedFrontierEvidenceR2 reg activeSpecHash) : EvidenceQualificationTier :=
  .sourceAndSchemaAttestedOnly

def guaranteesEmpiricalScientificTruth (_ev : VerifiedFrontierEvidenceR2 reg activeSpecHash) : Bool :=
  false

theorem r2_f07_source_attestation_never_claims_empirical_truth
    (reg : TrustedSourceRegistry) (activeSpecHash : Nat)
    (ev : VerifiedFrontierEvidenceR2 reg activeSpecHash) :
    qualificationTierOf ev = .sourceAndSchemaAttestedOnly ∧
    guaranteesEmpiricalScientificTruth ev = false := by
  exact ⟨rfl, rfl⟩

/-! ## 3. Proof-Carrying `VerifiedRegimeEntryR2` (Replaces `0 < kernelCheckTag` in `VerifiedScopeTopology`) -/

/-- Replaces `0 < kernelCheckTag : Nat` with an actual proof-carrying `(claim, witness, pkt)` bundle! -/
structure VerifiedRegimeEntryR2 (spec : LowLevelSpec) where
  regime   : ScopeRegime
  claim    : TypedSIRClaimTerm
  witness  : TypedSIRWitnessTerm
  pkt      : LowLevelPacket
  specBind : regime.specHash = spec.specHash
  lowProof : lowerToKernelR2 claim witness = some pkt
  chkProof : checkKernelPacketBool spec pkt = true
  deriving DecidableEq

def certifyRegimeByKernelR2
    (spec : LowLevelSpec) (regime : ScopeRegime)
    (claim : TypedSIRClaimTerm) (witness : TypedSIRWitnessTerm) :
    Option (VerifiedRegimeEntryR2 spec) :=
  if hs : regime.specHash = spec.specHash then
    match hlow : lowerToKernelR2 claim witness with
    | none => none
    | some pkt =>
        if hchk : checkKernelPacketBool spec pkt = true then
          some {
            regime := regime
            claim := claim
            witness := witness
            pkt := pkt
            specBind := hs
            lowProof := hlow
            chkProof := hchk
          }
        else none
  else none

/-- Every `VerifiedRegimeEntryR2` mathematically entails `DenoteSIRTerm M entry.claim` without relying
    on any caller-supplied `Nat` or `Bool` tag! -/
theorem r2_f07_verified_regime_entry_entails_denotation
    (spec : LowLevelSpec) (M : SemanticGraphModel)
    (hmodel : SpecModelsGraph spec M)
    (entry : VerifiedRegimeEntryR2 spec) :
    DenoteSIRTerm M entry.claim ∧ entry.regime.specHash = spec.specHash := by
  refine ⟨?_, entry.specBind⟩
  exact non_tautological_lowering_soundness spec M entry.claim entry.witness entry.pkt
    hmodel entry.lowProof entry.chkProof

structure VerifiedScopeCertR2 (spec : LowLevelSpec) where
  entries : List (VerifiedRegimeEntryR2 spec)
  deriving DecidableEq

def inVerifiedScopeR2 (spec : LowLevelSpec) (vc : VerifiedScopeCertR2 spec) (x : ScopeRegime) : Bool :=
  vc.entries.any (fun e => deductiveSubregime x e.regime)

theorem r2_f07_inVerifiedScopeR2_backed_by_kernel_proof
    (spec : LowLevelSpec) (M : SemanticGraphModel)
    (hmodel : SpecModelsGraph spec M)
    (vc : VerifiedScopeCertR2 spec) (x : ScopeRegime)
    (hx : inVerifiedScopeR2 spec vc x = true) :
    ∃ entry ∈ vc.entries,
      deductiveSubregime x entry.regime = true ∧
      DenoteSIRTerm M entry.claim := by
  unfold inVerifiedScopeR2 at hx
  rw [List.any_eq_true] at hx
  rcases hx with ⟨entry, hmem, hsub⟩
  exact ⟨entry, hmem, hsub, (r2_f07_verified_regime_entry_entails_denotation spec M hmodel entry).1⟩

end ProofspaceOmegaP0R2

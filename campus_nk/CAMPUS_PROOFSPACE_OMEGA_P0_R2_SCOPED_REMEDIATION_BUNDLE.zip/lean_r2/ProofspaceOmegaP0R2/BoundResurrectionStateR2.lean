/-
  CAMPUS-NATIVE PROOFSPACE Ω — P0-R2 Single Scoped Remediation (`F-T1-06` & `F-T1-07`)
  Module: `ProofspaceOmegaP0R2.BoundResurrectionStateR2`

  Exact Closure of `F-T1-06` & Pre-Approval Condition 2:
    1. 5-Conjunct Candidate–Seed–Port–Scope–Freshness Binding (`bindCandidateR2Bool`):
       - `cand.targetSeedId == seed.seedId` (Candidate ↔ Seed target binding)
       - `cand.targetPortId == seed.rupturePortId` (Candidate ↔ Rupture-Port binding)
       - `ev.raw.portSignature == seed.expectedPortSignature` (Evidence ↔ Port semantic signature match)
       - `scopeCompatibleR2Bool P.activeSpec seed ev.raw` (Spec hash, observer resolution, boundary flux, premise)
       - `freshEvidenceR2Bool P seed ev.raw` (`ev.raw.evidenceEpoch > seed.haltedEpoch ∧ ev.raw.receiptId ∉ P.consumedReceipts`)
    2. Atomic Sequential State Consumption (`stepBoundResurrectionR2`):
       Reactivating `seed` atomically appends `ev.raw.receiptId` to `P'.consumedReceipts`, ensuring
       immediate replay of the same evidence receipt is deterministically rejected (`r2_f06_replay_rejected`).
       (OS/multi-process concurrent CAS atomicity is explicitly documented as out-of-scope `HELD`.)
    3. Computed Kernel Proof for Learning Reward (`computeLearningRewardR2`):
       Removes `kernelProofAccepted : Bool`; ignores any `untrustedClaimedKernelOk : Bool`; grants
       `positiveTruthCredit = 1` IF AND ONLY IF `seed.reactivated = true` AND an actual `(claim, witness)`
       pair lowers and passes `checkKernelPacketBool P.activeSpec`.
-/

import ProofspaceOmegaP0R2.ProofCarryingEvidenceR2

namespace ProofspaceOmegaP0R2

/-! ## 1. Dormant Seed, Topological Candidate & Resurrection State `P` -/

structure DormantSeedR2 where
  seedId                : Nat
  rupturePortId         : Nat
  expectedPortSignature : Nat
  specHashBound         : Nat
  requiredObsRes        : Nat
  maxAllowedFlux        : Nat
  requiredPremise       : Nat
  haltedEpoch           : Nat
  sourceProvenanceId    : Nat
  targetClaim           : TypedSIRClaimTerm
  reactivated           : Bool
  deriving DecidableEq, Repr

structure UntrustedTopologicalCandidateR2 where
  candidateId       : Nat
  targetSeedId      : Nat
  targetPortId      : Nat
  authorityRank     : Nat := 0
  deriving DecidableEq, Repr

structure ResurrectionLedgerEntryR2 where
  stepIndex         : Nat
  seedId            : Nat
  portId            : Nat
  consumedReceiptId : Nat
  specHash          : Nat
  deriving DecidableEq, Repr

/-- State `P` binding `activeSpec`, `seeds`, `consumedReceipts` (for state-bound replay prevention),
    and append-only `resurrectionLog`. -/
structure ResurrectionStateR2 where
  activeSpec       : LowLevelSpec
  registry         : TrustedSourceRegistry
  seeds            : List DormantSeedR2
  consumedReceipts : List Nat
  resurrectionLog  : List ResurrectionLedgerEntryR2
  deriving DecidableEq, Repr

/-! ## 2. 5-Conjunct `BindCandidate` (`F-T1-06` + Pre-Approval Conditions 1.A & 2) -/

def scopeCompatibleR2Bool
    (spec : LowLevelSpec) (seed : DormantSeedR2) (raw : RawUntrustedFrontierInput) : Bool :=
  (raw.targetSpecHash == spec.specHash) &&
  (seed.specHashBound == spec.specHash) &&
  (seed.requiredObsRes ≤ raw.measuredObserverRes) &&
  (raw.measuredBoundaryFlux ≤ seed.maxAllowedFlux) &&
  (spec.premises.any (fun p => p == seed.requiredPremise))

def freshEvidenceR2Bool
    (P : ResurrectionStateR2) (seed : DormantSeedR2) (raw : RawUntrustedFrontierInput) : Bool :=
  (seed.haltedEpoch < raw.evidenceEpoch) &&
  !(P.consumedReceipts.any (fun rid => rid == raw.receiptId))

/-- Full 5-conjunct binding check `BindCandidate(cand, seed, ev, P)`. -/
def bindCandidateR2Bool
    (P : ResurrectionStateR2)
    (cand : UntrustedTopologicalCandidateR2)
    (seed : DormantSeedR2)
    (ev : VerifiedFrontierEvidenceR2 P.registry P.activeSpec.specHash) : Bool :=
  (cand.targetSeedId == seed.seedId) &&
  (cand.targetPortId == seed.rupturePortId) &&
  (ev.raw.portSignature == seed.expectedPortSignature) &&
  scopeCompatibleR2Bool P.activeSpec seed ev.raw &&
  freshEvidenceR2Bool P seed ev.raw

def findSeedById (seeds : List DormantSeedR2) (sid : Nat) : Option DormantSeedR2 :=
  seeds.find? (fun s => s.seedId == sid)

def markSeedReactivated (seeds : List DormantSeedR2) (sid : Nat) : List DormantSeedR2 :=
  seeds.map (fun s => if s.seedId == sid then { s with reactivated := true } else s)

/-- `stepBoundResurrectionR2`: Admits ONLY a proof-carrying `VerifiedFrontierEvidenceR2`, enforces the
    5-conjunct `bindCandidateR2Bool` against the specific requested `targetSeedId`, and atomically records
    `ev.raw.receiptId` in `consumedReceipts` + appends an audit log record. -/
def stepBoundResurrectionR2
    (P : ResurrectionStateR2)
    (requestedSeedId : Nat)
    (cand : UntrustedTopologicalCandidateR2)
    (evOpt : Option (VerifiedFrontierEvidenceR2 P.registry P.activeSpec.specHash)) :
    Except String ResurrectionStateR2 :=
  match evOpt with
  | none => .error "ERR_R2_MISSING_VERIFIED_FRONTIER_EVIDENCE"
  | some ev =>
      match findSeedById P.seeds requestedSeedId with
      | none => .error "ERR_R2_UNKNOWN_TARGET_SEED"
      | some seed =>
          if bindCandidateR2Bool P cand seed ev then
            let entry : ResurrectionLedgerEntryR2 := {
              stepIndex := P.resurrectionLog.length
              seedId := seed.seedId
              portId := seed.rupturePortId
              consumedReceiptId := ev.raw.receiptId
              specHash := P.activeSpec.specHash
            }
            .ok { P with
              seeds := markSeedReactivated P.seeds seed.seedId
              consumedReceipts := P.consumedReceipts ++ [ev.raw.receiptId]
              resurrectionLog := P.resurrectionLog ++ [entry]
            }
          else
            .error "ERR_R2_CANDIDATE_SEED_PORT_SCOPE_OR_FRESHNESS_MISMATCH"

/-! ## 3. Core `F-T1-06` & Replay-Prevention Soundness Theorems -/

/-- `F-T1-06` Theorem 1: Any admitted resurrection provably satisfies ALL 5 binding conjuncts AND
    verified detached-check attestation (`detProof`), while leaving non-target seeds untouched. -/
theorem r2_f06_admitted_resurrection_enforces_5way_binding
    (P P' : ResurrectionStateR2)
    (requestedSeedId : Nat)
    (cand : UntrustedTopologicalCandidateR2)
    (ev : VerifiedFrontierEvidenceR2 P.registry P.activeSpec.specHash)
    (hadm : stepBoundResurrectionR2 P requestedSeedId cand (some ev) = .ok P') :
    ∃ seed,
      findSeedById P.seeds requestedSeedId = some seed ∧
      cand.targetSeedId = seed.seedId ∧
      cand.targetPortId = seed.rupturePortId ∧
      ev.raw.portSignature = seed.expectedPortSignature ∧
      scopeCompatibleR2Bool P.activeSpec seed ev.raw = true ∧
      seed.haltedEpoch < ev.raw.evidenceEpoch ∧
      (P.consumedReceipts.any (fun rid => rid == ev.raw.receiptId)) = false ∧
      runDetachedEvidenceCheckBool P.registry P.activeSpec.specHash ev.raw = true ∧
      List.IsPrefix P.resurrectionLog P'.resurrectionLog := by
  unfold stepBoundResurrectionR2 at hadm
  cases hfind : findSeedById P.seeds requestedSeedId with
  | none => simp [hfind] at hadm
  | some seed =>
      simp only [hfind] at hadm
      split at hadm
      · rename_i hbind
        injection hadm with hP'
        subst hP'
        unfold bindCandidateR2Bool freshEvidenceR2Bool at hbind
        simp only [Bool.and_eq_true, Bool.not_eq_true', beq_iff_eq, decide_eq_true_eq] at hbind
        rcases hbind with ⟨⟨⟨⟨hsid, hpid⟩, hsig⟩, hscope⟩, ⟨hepoch, hfresh⟩⟩
        exact ⟨seed, rfl, hsid, hpid, hsig, hscope, hepoch, hfresh, ev.detProof, ⟨[_], rfl⟩⟩
      · cases hadm

/-- `F-T1-06` Theorem 2 (`M-T1-11` General Guarantee): Mismatched `cand.targetSeedId ≠ seed.seedId` or
    mismatched `cand.targetPortId ≠ seed.rupturePortId` or mismatched `portSignature` is ALWAYS rejected,
    even when `ev` is a 100% valid `VerifiedFrontierEvidenceR2`. -/
theorem r2_f06_mismatched_candidate_or_port_always_rejected
    (P : ResurrectionStateR2)
    (requestedSeedId : Nat)
    (seed : DormantSeedR2)
    (cand : UntrustedTopologicalCandidateR2)
    (ev : VerifiedFrontierEvidenceR2 P.registry P.activeSpec.specHash)
    (hfind : findSeedById P.seeds requestedSeedId = some seed)
    (hmis : cand.targetSeedId ≠ seed.seedId ∨
            cand.targetPortId ≠ seed.rupturePortId ∨
            ev.raw.portSignature ≠ seed.expectedPortSignature) :
    (stepBoundResurrectionR2 P requestedSeedId cand (some ev)).isOk = false := by
  unfold stepBoundResurrectionR2
  rw [hfind]
  have hbindFalse : bindCandidateR2Bool P cand seed ev = false := by
    unfold bindCandidateR2Bool
    rcases hmis with (h1 | h2 | h3)
    · have hb : (cand.targetSeedId == seed.seedId) = false := beq_false_of_ne h1
      simp [hb]
    · have hb : (cand.targetPortId == seed.rupturePortId) = false := beq_false_of_ne h2
      simp [hb]
    · have hb : (ev.raw.portSignature == seed.expectedPortSignature) = false := beq_false_of_ne h3
      simp [hb]
  simp [hbindFalse, Except.isOk, Except.toBool]

/-- Pre-Approval Condition 2 Theorem (State-Bound Replay Prevention):
    Once `ev` is consumed to transition `P → P'`, `P'.activeSpec = P.activeSpec` and `P'.registry = P.registry`,
    and ANY subsequent attempt to replay `ev` on `P'` (for ANY seed ID or ANY candidate!) is rejected. -/
theorem r2_f06_consumed_receipt_replay_rejected
    (P P' : ResurrectionStateR2)
    (req1 req2 : Nat)
    (cand1 cand2 : UntrustedTopologicalCandidateR2)
    (ev : VerifiedFrontierEvidenceR2 P.registry P.activeSpec.specHash)
    (hadm1 : stepBoundResurrectionR2 P req1 cand1 (some ev) = .ok P') :
    ∃ (hSpec : P'.activeSpec = P.activeSpec) (hReg : P'.registry = P.registry),
      (stepBoundResurrectionR2 P' req2 cand2 (some (hSpec ▸ hReg ▸ ev))).isOk = false := by
  unfold stepBoundResurrectionR2 at hadm1
  cases hfind1 : findSeedById P.seeds req1 with
  | none => simp [hfind1] at hadm1
  | some s1 =>
      simp only [hfind1] at hadm1
      split at hadm1
      · injection hadm1 with hP'
        subst hP'
        refine ⟨rfl, rfl, ?_⟩
        dsimp only
        unfold stepBoundResurrectionR2
        cases hfind2 : findSeedById (markSeedReactivated P.seeds s1.seedId) req2 with
        | none => simp [Except.isOk, Except.toBool]
        | some s2 =>
            dsimp only
            let Pnext : ResurrectionStateR2 := {
              P with
              seeds := markSeedReactivated P.seeds s1.seedId
              consumedReceipts := P.consumedReceipts ++ [ev.raw.receiptId]
              resurrectionLog := P.resurrectionLog ++ [{
                stepIndex := P.resurrectionLog.length
                seedId := s1.seedId
                portId := s1.rupturePortId
                consumedReceiptId := ev.raw.receiptId
                specHash := P.activeSpec.specHash }] }
            have hmem : (Pnext.consumedReceipts.any (fun rid => rid == ev.raw.receiptId)) = true := by
              dsimp [Pnext]
              rw [List.any_append]
              simp
            have hfreshFalse : freshEvidenceR2Bool Pnext s2 ev.raw = false := by
              unfold freshEvidenceR2Bool
              simp [hmem]
            have hbind2 : bindCandidateR2Bool Pnext cand2 s2 ev = false := by
              unfold bindCandidateR2Bool
              simp [hfreshFalse]
            have hnot : ¬(bindCandidateR2Bool Pnext cand2 s2 ev = true) := by simp [hbind2]
            rw [if_neg hnot]
            rfl
      · cases hadm1

/-! ## 4. Computed Kernel Proof for Learning Reward (`F-T1-07` Reward Closure) -/

structure LearningRewardReceiptR2 where
  positiveTruthCredit   : Nat
  prioritizesSearchOnly : Bool
  boundSpecHash         : Nat
  deriving DecidableEq, Repr

/-- Replaces caller-supplied `kernelProofAccepted : Bool` with actual kernel execution on `seed.targetClaim`
    and `witnessOpt`, while explicitly ignoring any attacker-supplied `untrustedClaimedKernelAccepted : Bool`. -/
def computeLearningRewardR2
    (spec : LowLevelSpec)
    (seed : DormantSeedR2)
    (witnessOpt : Option TypedSIRWitnessTerm)
    (_untrustedClaimedKernelAccepted : Bool) :
    LearningRewardReceiptR2 :=
  if seed.reactivated && (seed.specHashBound == spec.specHash) then
    match witnessOpt with
    | none =>
        { positiveTruthCredit := 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }
    | some W =>
        match lowerToKernelR2 seed.targetClaim W with
        | none =>
            { positiveTruthCredit := 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }
        | some pkt =>
            if checkKernelPacketBool spec pkt then
              { positiveTruthCredit := 1, prioritizesSearchOnly := false, boundSpecHash := spec.specHash }
            else
              { positiveTruthCredit := 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }
  else
    { positiveTruthCredit := 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }

theorem r2_f07_reward_ignores_untrusted_kernel_boolean
    (spec : LowLevelSpec) (seed : DormantSeedR2)
    (witnessOpt : Option TypedSIRWitnessTerm) (b1 b2 : Bool) :
    computeLearningRewardR2 spec seed witnessOpt b1 =
    computeLearningRewardR2 spec seed witnessOpt b2 := by
  rfl

/-- `F-T1-07` Reward Soundness Theorem: `positiveTruthCredit = 1` is mathematically impossible unless
    `seed.reactivated = true` AND a concrete witness `W` lowers and passes `checkKernelPacketBool`,
    which by `non_tautological_lowering_soundness` guarantees `DenoteSIRTerm M seed.targetClaim`! -/
theorem r2_f07_positive_truth_credit_entails_semantic_truth
    (spec : LowLevelSpec) (M : SemanticGraphModel)
    (hmodel : SpecModelsGraph spec M)
    (seed : DormantSeedR2)
    (witnessOpt : Option TypedSIRWitnessTerm)
    (untrustedFlag : Bool)
    (hpos : (computeLearningRewardR2 spec seed witnessOpt untrustedFlag).positiveTruthCredit = 1) :
    seed.reactivated = true ∧
    seed.specHashBound = spec.specHash ∧
    DenoteSIRTerm M seed.targetClaim := by
  unfold computeLearningRewardR2 at hpos
  split at hpos
  · rename_i hreact
    simp only [Bool.and_eq_true, beq_iff_eq] at hreact
    cases hw : witnessOpt with
    | none => simp [hw] at hpos
    | some W =>
        simp only [hw] at hpos
        cases hlow : lowerToKernelR2 seed.targetClaim W with
        | none => simp [hlow] at hpos
        | some pkt =>
            simp only [hlow] at hpos
            split at hpos
            · rename_i hchk
              exact ⟨hreact.1, hreact.2,
                non_tautological_lowering_soundness spec M seed.targetClaim W pkt hmodel hlow hchk⟩
            · simp at hpos
  · simp at hpos

end ProofspaceOmegaP0R2

/-
  CAMPUS-NATIVE PROOFSPACE Ω — P0-R2 Single Scoped Remediation (`F-T1-06` & `F-T1-07` Only)
  Module: `ProofspaceOmegaP0R2.CoreInheritedR1`

  Authorization Token:
    `CAMPUS_PROOFSPACE_OMEGA_P0_R2_SINGLE_SCOPED_REMEDIATION_AUTHORIZED__F_T1_06_07_ONLY__M_T1_11_12_AND_POSITIVE_CONTROLS__LEAN4331_CLEANROOM_VERIFICATION__FROZEN_ANCESTORS_IMMUTABLE__P0_XH0_P1_E1D_RELEASE47_NOT_AUTHORIZED`

  Carries forward the reviewed `F-P0-01`..`F-P0-04` core structures (`CoverNerve` Čech `Z¹/B¹`,
  `ScopeRegime` deductive vs observer preorders, `ClosedFiberLoop` holonomy, and non-tautological
  `DenoteSIRTerm` + `lowerToKernelR1` + `checkKernelPacketBool`) so `P0-R2` compiles 100% standalone
  in any isolated cleanroom while leaving `P0` v1 and `P0-T1/R1` byte-for-byte untouched.
-/

namespace ProofspaceOmegaP0R2

/-! ## 1. Scope Regimes & Separation of Deductive Entailment vs Observer Refinement (`F-P0-02`) -/

structure ScopeRegime where
  regimeId    : Nat
  specHash    : Nat
  observerRes : Nat
  fluxBound   : Nat
  deriving DecidableEq, Repr

def deductiveSubregime (sub sup : ScopeRegime) : Bool :=
  (sub.specHash == sup.specHash) &&
  (sub.observerRes ≤ sup.observerRes) &&
  (sub.fluxBound ≤ sup.fluxBound)

def observerStrictlyRefines (fine coarse : ScopeRegime) : Bool :=
  (fine.specHash == coarse.specHash) &&
  (coarse.observerRes < fine.observerRes)

theorem deductiveSubregime_refl (r : ScopeRegime) : deductiveSubregime r r = true := by
  unfold deductiveSubregime; simp

theorem deductiveSubregime_trans (a b c : ScopeRegime)
    (hab : deductiveSubregime a b = true) (hbc : deductiveSubregime b c = true) :
    deductiveSubregime a c = true := by
  unfold deductiveSubregime at hab hbc ⊢
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hab hbc ⊢
  exact ⟨⟨hab.1.1.trans hbc.1.1, Nat.le_trans hab.1.2 hbc.1.2⟩, Nat.le_trans hab.2 hbc.2⟩

theorem finer_observer_not_deductive_subregime (fine coarse : ScopeRegime)
    (hf : observerStrictlyRefines fine coarse = true) :
    deductiveSubregime fine coarse = false := by
  unfold observerStrictlyRefines at hf
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hf
  unfold deductiveSubregime
  have hnot : ¬(fine.observerRes ≤ coarse.observerRes) := by omega
  simp [hnot]

/-! ## 2. Non-Tautological S-IR Denotational Semantics & Independent Kernel Checker (`F-P0-04`) -/

inductive TypedSIRClaimTerm where
  | reachability   (src dst : Nat)                           : TypedSIRClaimTerm
  | guardedPremise (premId : Nat) (body : TypedSIRClaimTerm) : TypedSIRClaimTerm
  | conjunction    (lhs rhs : TypedSIRClaimTerm)             : TypedSIRClaimTerm
  deriving DecidableEq, Repr

inductive TypedSIRWitnessTerm where
  | walkWitness  (hops : List Nat)                           : TypedSIRWitnessTerm
  | guardWitness (premAck : Nat) (sub : TypedSIRWitnessTerm) : TypedSIRWitnessTerm
  | pairWitness  (leftW rightW : TypedSIRWitnessTerm)        : TypedSIRWitnessTerm
  deriving DecidableEq, Repr

structure SemanticGraphModel where
  adj          : Nat → Nat → Prop
  holdsPremise : Nat → Prop

inductive SemanticPath (adj : Nat → Nat → Prop) : Nat → Nat → Prop where
  | refl (u : Nat) : SemanticPath adj u u
  | step (u v w : Nat) : adj u v → SemanticPath adj v w → SemanticPath adj u w

/-- Pure mathematical denotation `⟦X⟧_M` — zero references to packets, lowering, or checkers. -/
def DenoteSIRTerm (M : SemanticGraphModel) : TypedSIRClaimTerm → Prop
  | .reachability u v       => SemanticPath M.adj u v
  | .guardedPremise p inner => M.holdsPremise p ∧ DenoteSIRTerm M inner
  | .conjunction lhs rhs    => DenoteSIRTerm M lhs ∧ DenoteSIRTerm M rhs

structure LowLevelSpec where
  specHash : Nat
  edges    : List (Nat × Nat)
  premises : List Nat
  deriving DecidableEq, Repr

structure FlatWalkObligation where
  src  : Nat
  dst  : Nat
  hops : List Nat
  deriving DecidableEq, Repr

structure LowLevelPacket where
  walkObligations : List FlatWalkObligation
  reqPremises     : List Nat
  deriving DecidableEq, Repr

def hasFlatEdgeBool (edges : List (Nat × Nat)) (u v : Nat) : Bool :=
  edges.any (fun e => e.1 == u && e.2 == v)

def checkFlatWalkBool (edges : List (Nat × Nat)) : Nat → List Nat → Bool
  | _, [] => true
  | u, v :: rest => hasFlatEdgeBool edges u v && checkFlatWalkBool edges v rest

def walkEndVertex : Nat → List Nat → Nat
  | u, [] => u
  | _, v :: rest => walkEndVertex v rest

def checkSingleObligationBool (spec : LowLevelSpec) (ob : FlatWalkObligation) : Bool :=
  checkFlatWalkBool spec.edges ob.src ob.hops &&
  (walkEndVertex ob.src ob.hops == ob.dst)

def checkKernelPacketBool (spec : LowLevelSpec) (pkt : LowLevelPacket) : Bool :=
  pkt.walkObligations.all (checkSingleObligationBool spec) &&
  pkt.reqPremises.all (fun p => spec.premises.any (fun q => q == p))

def lowerToKernelR2 : TypedSIRClaimTerm → TypedSIRWitnessTerm → Option LowLevelPacket
  | .reachability u v, .walkWitness hops =>
      some { walkObligations := [{ src := u, dst := v, hops := hops }], reqPremises := [] }
  | .guardedPremise p inner, .guardWitness pAck subW =>
      if p == pAck then
        match lowerToKernelR2 inner subW with
        | some subPkt =>
            some { walkObligations := subPkt.walkObligations, reqPremises := p :: subPkt.reqPremises }
        | none => none
      else none
  | .conjunction lhs rhs, .pairWitness lw rw =>
      match lowerToKernelR2 lhs lw, lowerToKernelR2 rhs rw with
      | some lp, some rp =>
          some { walkObligations := lp.walkObligations ++ rp.walkObligations,
                 reqPremises := lp.reqPremises ++ rp.reqPremises }
      | _, _ => none
  | _, _ => none

def SpecModelsGraph (spec : LowLevelSpec) (M : SemanticGraphModel) : Prop :=
  (∀ u v, hasFlatEdgeBool spec.edges u v = true → M.adj u v) ∧
  (∀ p, (spec.premises.any (fun q => q == p)) = true → M.holdsPremise p)

theorem flatWalk_implies_semanticPath
    (spec : LowLevelSpec) (M : SemanticGraphModel)
    (hEdge : ∀ u v, hasFlatEdgeBool spec.edges u v = true → M.adj u v)
    (u : Nat) (hops : List Nat)
    (hw : checkFlatWalkBool spec.edges u hops = true) :
    SemanticPath M.adj u (walkEndVertex u hops) := by
  induction hops generalizing u with
  | nil => exact SemanticPath.refl u
  | cons v rest ih =>
      simp only [checkFlatWalkBool, Bool.and_eq_true] at hw
      exact SemanticPath.step u v (walkEndVertex v rest) (hEdge u v hw.1) (ih v hw.2)

theorem non_tautological_lowering_soundness
    (spec : LowLevelSpec) (M : SemanticGraphModel)
    (X : TypedSIRClaimTerm) (W : TypedSIRWitnessTerm) (pkt : LowLevelPacket)
    (hmodel : SpecModelsGraph spec M)
    (hlow : lowerToKernelR2 X W = some pkt)
    (hchk : checkKernelPacketBool spec pkt = true) :
    DenoteSIRTerm M X := by
  induction X generalizing W pkt with
  | reachability u v =>
      cases W with
      | walkWitness hops =>
          simp only [lowerToKernelR2] at hlow
          injection hlow with hpkt
          subst hpkt
          unfold checkKernelPacketBool checkSingleObligationBool at hchk
          simp only [List.all_cons, List.all_nil, Bool.and_true, Bool.and_eq_true, beq_iff_eq] at hchk
          rcases hchk with ⟨hwalk, hend⟩
          unfold DenoteSIRTerm
          have hpath := flatWalk_implies_semanticPath spec M hmodel.1 u hops hwalk
          rw [hend] at hpath
          exact hpath
      | guardWitness _ _ => simp [lowerToKernelR2] at hlow
      | pairWitness _ _ => simp [lowerToKernelR2] at hlow
  | guardedPremise p inner ih =>
      cases W with
      | walkWitness _ => simp [lowerToKernelR2] at hlow
      | pairWitness _ _ => simp [lowerToKernelR2] at hlow
      | guardWitness pAck subW =>
          unfold lowerToKernelR2 at hlow
          split at hlow
          · cases hsub : lowerToKernelR2 inner subW with
            | none => simp [hsub] at hlow
            | some subPkt =>
                simp [hsub] at hlow
                subst hlow
                unfold checkKernelPacketBool at hchk
                simp only [List.all_cons, Bool.and_eq_true] at hchk
                rcases hchk with ⟨hwalks, hpHead, hpTail⟩
                have hsubChk : checkKernelPacketBool spec subPkt = true := by
                  unfold checkKernelPacketBool; simp [hwalks, hpTail]
                exact ⟨hmodel.2 p hpHead, ih subW subPkt hsub hsubChk⟩
          · cases hlow
  | conjunction lhs rhs ihl ihr =>
      cases W with
      | walkWitness _ => simp [lowerToKernelR2] at hlow
      | guardWitness _ _ => simp [lowerToKernelR2] at hlow
      | pairWitness lw rw =>
          unfold lowerToKernelR2 at hlow
          cases hll : lowerToKernelR2 lhs lw with
          | none => simp [hll] at hlow
          | some lp =>
            cases hlr : lowerToKernelR2 rhs rw with
            | none => simp [hll, hlr] at hlow
            | some rp =>
                simp [hll, hlr] at hlow
                subst hlow
                unfold checkKernelPacketBool at hchk
                simp only [List.all_append, Bool.and_eq_true] at hchk
                rcases hchk with ⟨⟨hwL, hwR⟩, ⟨hpL, hpR⟩⟩
                have hchkL : checkKernelPacketBool spec lp = true := by
                  unfold checkKernelPacketBool; simp [hwL, hpL]
                have hchkR : checkKernelPacketBool spec rp = true := by
                  unfold checkKernelPacketBool; simp [hwR, hpR]
                exact ⟨ihl lw lp hll hchkL, ihr rw rp hlr hchkR⟩

end ProofspaceOmegaP0R2

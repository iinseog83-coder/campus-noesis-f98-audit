#!/usr/bin/env python3
"""Scoped Remediation Verifier & Cleanroom Lean 4.33.1 Auditor for `P0-R2` (`F-T1-06` & `F-T1-07`).

Key Architectural Guarantees:
  - Zero shared imports with `P0` v1 or `P0-T1/R1`.
  - Separates three orthogonal verification tracks without ever promoting `EVIDENCE_UNAVAILABLE`:
      1. `self_contained_offline_verdict`: Verifies embedded `P0` v1 + `P0-T1/R1` ZIPs (`0` modified bytes),
         source hygiene of `P0-R2`, and Python independent reference tests for `M-T1-11`, `M-T1-12`,
         positive resurrection control, and reward control (`100%` self-contained inside the bundle).
      2. `lean_cleanroom_verdict`: Runs isolated `Lean 4.33.1` compilation of all 6 `ProofspaceOmegaP0R2`
         modules + independent Clean-Sheet Probe + `SMap` audit + 4 live Lean kernel mutation probes
         (`M_R2_LEAN_01`..`04`). Reports `EVIDENCE_UNAVAILABLE` honestly if Lean is not installed.
      3. `external_host_ancestors_verdict`: Checks optional host-mounted `#40`, `#46`, `E1_AUX`, `T104`,
         `T105` archives. Reports `EVIDENCE_UNAVAILABLE` honestly if unmounted in an isolated sandbox.
  - `overall_poset_verdict` is the strict `104-F0` poset meet of all three tracks (`EVIDENCE_UNAVAILABLE`
    is NEVER promoted to `VERIFIED` or `PASS`).
"""

from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple
import zipfile

STAGE_ID = "CAMPUS_PROOFSPACE_OMEGA_P0_R2_SINGLE_SCOPED_REMEDIATION"
AUTHORIZATION_TOKEN = (
    "CAMPUS_PROOFSPACE_OMEGA_P0_R2_SINGLE_SCOPED_REMEDIATION_AUTHORIZED__"
    "F_T1_06_07_ONLY__M_T1_11_12_AND_POSITIVE_CONTROLS__LEAN4331_CLEANROOM_VERIFICATION__"
    "FROZEN_ANCESTORS_IMMUTABLE__P0_XH0_P1_E1D_RELEASE47_NOT_AUTHORIZED"
)

PINNED_LEAN_VERSION = "4.33.1"
PINNED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"
ALLOWED_LEAN_AXIOMS = frozenset({"propext", "Quot.sound", "Classical.choice"})

STATUS_FAILED = "FAILED_INVALID"
STATUS_EVIDENCE_UNAVAILABLE = "EVIDENCE_UNAVAILABLE"
STATUS_SELF_CONTAINED_VERIFIED = "SELF_CONTAINED_OFFLINE_VERIFIED"
STATUS_LOCAL_CLEANROOM_VERIFIED = "LOCAL_CLEANROOM_VERIFIED"

POSET_RANK = {
    STATUS_FAILED: 0,
    STATUS_EVIDENCE_UNAVAILABLE: 1,
    STATUS_SELF_CONTAINED_VERIFIED: 2,
    STATUS_LOCAL_CLEANROOM_VERIFIED: 3,
}

EMBEDDED_P0_LINEAGE: Tuple[Tuple[str, str, str, int], ...] = (
    (
        "p0_v1_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_STATIC_FOUNDATION_BUNDLE.zip",
        "2d5076cd60f3e22b912d8e236880a472298336ebbde452486ca4556844e3da1f",
        55616,
    ),
    (
        "p0_t1_r1_bundle_zip",
        "CAMPUS_PROOFSPACE_OMEGA_P0_T1_AND_R1_COMPLETE_BUNDLE.zip",
        "e17f719d761cd02d813fd778a723c5f934b837734c3c2cad1bfc13ca68c4a643",
        96081,
    ),
)

EXTERNAL_HOST_ANCESTORS: Tuple[Tuple[str, str, str, int], ...] = (
    (
        "release_40_zip",
        "CAMPUS_NOESIS_OMEGA_KAPPA_STAGE1_0_PURE_TRUSTED_CHECKER_PACKAGE.zip",
        "93d9a02a84d6d91a36140de2c96cb362e26aa1b2c595ca3ac9562ddf8e3426bb",
        100029,
    ),
    (
        "release_46_zip",
        "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip",
        "4c42f12b605083d13228c02c84e12b4689cdf32be0f507041b6a36360eec4608",
        236214,
    ),
    (
        "e1_core_aux_zip",
        "OMEGA_LAMBDA_E1_CORE_AUX_BUNDLE.zip",
        "38a055f39e259cac333b469bfb4602ed8b3859cb5f6bfa3e096a75be0200da39",
        190589,
    ),
    (
        "t104_qualification_pack_zip",
        "T104_INDEPENDENT_QUALIFICATION_EVIDENCE_PACK.zip",
        "71091172fbb4ba1ddccf05ea5694ed9df049057b5eeb8f7de97c199ce581f1b1",
        650086,
    ),
    (
        "t105_complete_bundle_zip",
        "T105_SUBMISSION_T104_AND_XH0_COMPLETE_EVIDENCE_BUNDLE.zip",
        "b78abf1c788b8d2c554f48562f218b81c48df8fee9e14175e9592f67d22f8aae",
        1359070,
    ),
    (
        "t105_closure_receipt_json",
        "T105_E1_CORE_CLOSURE_AND_FREEZE_RECEIPT.json",
        "cb03ec9ee02eb2fe666a918bd874fa0d1258191f5c3103e9ed29969129339dcb",
        6489,
    ),
)

ORDERED_R2_MODULES: Tuple[Tuple[str, str], ...] = (
    ("ProofspaceOmegaP0R2.CoreInheritedR1", "ProofspaceOmegaP0R2/CoreInheritedR1.lean"),
    ("ProofspaceOmegaP0R2.ProofCarryingEvidenceR2", "ProofspaceOmegaP0R2/ProofCarryingEvidenceR2.lean"),
    ("ProofspaceOmegaP0R2.BoundResurrectionStateR2", "ProofspaceOmegaP0R2/BoundResurrectionStateR2.lean"),
    ("ProofspaceOmegaP0R2.R2ControlsAndCounterexamples", "ProofspaceOmegaP0R2/R2ControlsAndCounterexamples.lean"),
    ("ProofspaceOmegaP0R2.P0R2AxiomAudit", "ProofspaceOmegaP0R2/P0R2AxiomAudit.lean"),
    ("ProofspaceOmegaP0R2", "ProofspaceOmegaP0R2.lean"),
)

REQUIRED_15_R2_THEOREMS: Tuple[str, ...] = (
    "ProofspaceOmegaP0R2.finer_observer_not_deductive_subregime",
    "ProofspaceOmegaP0R2.non_tautological_lowering_soundness",
    "ProofspaceOmegaP0R2.r2_f07_detached_check_ignores_untrusted_booleans",
    "ProofspaceOmegaP0R2.r2_f07_construct_verified_evidence_implies_detached_pass",
    "ProofspaceOmegaP0R2.r2_f07_source_attestation_never_claims_empirical_truth",
    "ProofspaceOmegaP0R2.r2_f07_verified_regime_entry_entails_denotation",
    "ProofspaceOmegaP0R2.r2_f07_inVerifiedScopeR2_backed_by_kernel_proof",
    "ProofspaceOmegaP0R2.r2_f06_admitted_resurrection_enforces_5way_binding",
    "ProofspaceOmegaP0R2.r2_f06_mismatched_candidate_or_port_always_rejected",
    "ProofspaceOmegaP0R2.r2_f06_consumed_receipt_replay_rejected",
    "ProofspaceOmegaP0R2.r2_f07_reward_ignores_untrusted_kernel_boolean",
    "ProofspaceOmegaP0R2.r2_f07_positive_truth_credit_entails_semantic_truth",
    "ProofspaceOmegaP0R2.Controls.m_t1_11_cross_seed_port_stale_and_replay_rejected",
    "ProofspaceOmegaP0R2.Controls.m_t1_12_forged_booleans_blocked_everywhere",
    "ProofspaceOmegaP0R2.Controls.r2_positive_resurrection_and_reward_controls",
)

FORBIDDEN_LEAN_PATTERNS = (
    re.compile(r"\bsorry\b"),
    re.compile(r"\badmit\b"),
    re.compile(r"(?m)^\s*axiom\s+"),
    re.compile(r"(?m)^\s*opaque\s+"),
    re.compile(r"\bnative_decide\b"),
    re.compile(r"\bofReduceBool\b"),
    re.compile(r"\btrustCompiler\b"),
    re.compile(r"\bimplemented_by\b"),
    re.compile(r"@\[[^\]]*\bextern\b"),
    re.compile(r"\bunsafe\b"),
    re.compile(r"(?m)^\s*partial\s+def\b"),
)

SMAP_R2_INSPECTOR = r"""import ProofspaceOmegaP0R2
import r2_independent_clean_sheet_probe
import Lean

open Lean

def isR2Target : Name → Bool
  | .anonymous => false
  | .str .anonymous s => s == "ProofspaceOmegaP0R2" || s == "P0R2IndependentCleanSheetProbe"
  | .str p _ => isR2Target p
  | .num p _ => isR2Target p

#eval show MetaM Unit from do
  let env ← getEnv
  let mut consts : Nat := 0
  let mut thms : Nat := 0
  let mut sorryCnt : Nat := 0
  let mut userAxCnt : Nat := 0
  let mut opaqueCnt : Nat := 0
  let mut reduceBoolCnt : Nat := 0
  for (nm, ci) in env.constants.map₁.toList ++ env.constants.map₂.toList do
    if isR2Target nm then
      consts := consts + 1
      match ci with
      | .thmInfo _ => thms := thms + 1
      | .axiomInfo _ => userAxCnt := userAxCnt + 1
      | .opaqueInfo _ => opaqueCnt := opaqueCnt + 1
      | _ => pure ()
      for u in ci.getUsedConstantsAsSet.toList do
        if u == ``sorryAx then sorryCnt := sorryCnt + 1
        if u == ``Lean.ofReduceBool || u == ``Lean.trustCompiler then
          reduceBoolCnt := reduceBoolCnt + 1
  IO.println s!"P0_R2_SMAP|constants={consts}|theorems={thms}|sorry={sorryCnt}|userAxioms={userAxCnt}|opaque={opaqueCnt}|reduceBool={reduceBoolCnt}"
"""


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def meet_poset(statuses: Iterable[str]) -> str:
    items = list(statuses)
    if not items:
        return STATUS_EVIDENCE_UNAVAILABLE
    for s in items:
        if s not in POSET_RANK:
            raise ValueError(f"Unknown status token: {s}")
    if STATUS_FAILED in items:
        return STATUS_FAILED
    if STATUS_EVIDENCE_UNAVAILABLE in items:
        return STATUS_EVIDENCE_UNAVAILABLE
    return min(items, key=lambda s: POSET_RANK[s])


def strip_lean_comments(src: str) -> str:
    out: List[str] = []
    i, n, depth, in_str = 0, len(src), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if src.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if src.startswith("--", i):
                while i < n and src[i] != "\n":
                    i += 1
                continue
            if src[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(src[i])
            i += 1
        elif in_str:
            if src[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if src[i] == '"':
                in_str = False
            i += 1
        else:
            if src.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if src.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if src[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def find_lean_exe() -> Optional[Path]:
    override = os.environ.get("P0_R2_LEAN_BIN")
    if override is not None:
        if override == "":
            return None
        p = Path(override)
        return p if p.is_file() else None
    w = shutil.which("lean")
    if w:
        return Path(w)
    cand = Path.home() / ".elan" / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    return cand if cand.is_file() else None


# =============================================================================
# Independent Python Reference Model for F-T1-06 & F-T1-07 (Self-Contained Oracle)
# =============================================================================

class _SealToken:
    pass


_DETACHED_SEAL = _SealToken()


class VerifiedFrontierEvidencePy:
    """Constructor-sealed Python reference counterpart of `VerifiedFrontierEvidenceR2`."""

    __slots__ = ("raw", "qualification_tier", "guarantees_empirical_truth")

    def __init__(self, seal: object, raw: Mapping[str, Any]) -> None:
        if seal is not _DETACHED_SEAL:
            raise PermissionError("ERR_FORGED_VERIFIED_EVIDENCE_CONSTRUCTOR_BLOCKED")
        self.raw = dict(raw)
        self.qualification_tier = "SOURCE_AND_SCHEMA_ATTESTED_ONLY"
        self.guarantees_empirical_truth = False


def run_detached_evidence_check_py(
    registry: Mapping[int, Mapping[str, Any]],
    active_spec_hash: int,
    raw: Mapping[str, Any],
) -> Optional[VerifiedFrontierEvidencePy]:
    # Deliberately ignores raw.get("untrustedClaimedSourceOk") & raw.get("untrustedClaimedSchemaOk")!
    if raw.get("receiptId", 0) <= 0:
        return None
    if raw.get("targetSpecHash") != active_spec_hash:
        return None
    issuer = registry.get(raw.get("issuerId", -1))
    if issuer is None:
        return None
    if issuer["expectedAuthToken"] != raw.get("presentedAuthToken"):
        return None
    obs_res = raw.get("measuredObserverRes", 0)
    if not (0 < obs_res <= issuer["maxCalibratedRes"]):
        return None
    if raw.get("portSignature") not in issuer["allowedPortSigs"]:
        return None
    return VerifiedFrontierEvidencePy(_DETACHED_SEAL, raw)


def step_bound_resurrection_py(
    state: Mapping[str, Any],
    requested_seed_id: int,
    cand: Mapping[str, Any],
    ev: Optional[VerifiedFrontierEvidencePy],
) -> Tuple[bool, str, Dict[str, Any]]:
    if not isinstance(ev, VerifiedFrontierEvidencePy):
        return (False, "ERR_R2_MISSING_VERIFIED_FRONTIER_EVIDENCE", dict(state))
    seeds = [dict(s) for s in state["seeds"]]
    target = next((s for s in seeds if s["seedId"] == requested_seed_id), None)
    if target is None:
        return (False, "ERR_R2_UNKNOWN_TARGET_SEED", dict(state))
    spec = state["activeSpec"]
    raw = ev.raw
    bind_ok = (
        cand["targetSeedId"] == target["seedId"]
        and cand["targetPortId"] == target["rupturePortId"]
        and raw["portSignature"] == target["expectedPortSignature"]
        and raw["targetSpecHash"] == spec["specHash"]
        and target["specHashBound"] == spec["specHash"]
        and target["requiredObsRes"] <= raw["measuredObserverRes"]
        and raw["measuredBoundaryFlux"] <= target["maxAllowedFlux"]
        and target["requiredPremise"] in spec["premises"]
        and target["haltedEpoch"] < raw["evidenceEpoch"]
        and raw["receiptId"] not in state["consumedReceipts"]
    )
    if not bind_ok:
        return (False, "ERR_R2_CANDIDATE_SEED_PORT_SCOPE_OR_FRESHNESS_MISMATCH", dict(state))
    for s in seeds:
        if s["seedId"] == requested_seed_id:
            s["reactivated"] = True
    next_state = {
        "activeSpec": spec,
        "seeds": seeds,
        "consumedReceipts": list(state["consumedReceipts"]) + [raw["receiptId"]],
    }
    return (True, "OK", next_state)


def compute_learning_reward_py(
    spec: Mapping[str, Any],
    seed: Mapping[str, Any],
    witness_hops: Optional[List[int]],
    untrusted_claimed_kernel_ok: bool,
) -> int:
    _ = untrusted_claimed_kernel_ok  # Explicitly ignored!
    if not seed.get("reactivated", False) or seed.get("specHashBound") != spec["specHash"]:
        return 0
    if seed["requiredPremise"] not in spec["premises"]:
        return 0
    if witness_hops is None:
        return 0
    cur = seed["src"]
    edges = set(spec["edges"])
    for nxt in witness_hops:
        if (cur, nxt) not in edges:
            return 0
        cur = nxt
    return 1 if cur == seed["dst"] else 0


# =============================================================================
# Track 1: Self-Contained Offline Verification (Zero External Host Dependencies)
# =============================================================================

def run_self_contained_offline_audit(r2_root: Path) -> Dict[str, Any]:
    ro_dir = r2_root / "readonly_p0_lineage"
    lineage_records: Dict[str, Any] = {}
    for key, fname, exp_sha, exp_sz in EMBEDDED_P0_LINEAGE:
        fp = ro_dir / fname
        if not fp.is_file():
            return {"verdict": STATUS_FAILED, "error": f"Missing embedded lineage file: {fname}"}
        raw = fp.read_bytes()
        act_sha = sha256_hex(raw)
        act_sz = len(raw)
        if act_sha != exp_sha or act_sz != exp_sz:
            return {"verdict": STATUS_FAILED, "error": f"Digest mismatch on {fname}"}
        with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
            if zf.testzip() is not None:
                return {"verdict": STATUS_FAILED, "error": f"Corrupt ZIP CRC on {fname}"}
            entry_cnt = len(zf.infolist())
        lineage_records[key] = {
            "filename": fname,
            "sha256": act_sha,
            "size_bytes": act_sz,
            "entries": entry_cnt,
            "modified_bytes": 0,
        }

    # Static hygiene scan of all R2 Lean files & clean-sheet probe
    lean_digests: Dict[str, str] = {}
    for mod_name, rel in ORDERED_R2_MODULES:
        fp = r2_root / "lean_r2" / rel
        if not fp.is_file():
            return {"verdict": STATUS_FAILED, "error": f"Missing Lean file: {rel}"}
        stripped = strip_lean_comments(fp.read_text(encoding="utf-8"))
        for pat in FORBIDDEN_LEAN_PATTERNS:
            if pat.search(stripped):
                return {"verdict": STATUS_FAILED, "error": f"Forbidden token `{pat.pattern}` in {rel}"}
        lean_digests[mod_name] = sha256_hex(fp.read_bytes())

    probe_fp = r2_root / "probes" / "r2_independent_clean_sheet_probe.lean"
    if not probe_fp.is_file():
        return {"verdict": STATUS_FAILED, "error": "Missing R2 clean-sheet probe"}
    probe_stripped = strip_lean_comments(probe_fp.read_text(encoding="utf-8"))
    for pat in FORBIDDEN_LEAN_PATTERNS:
        if pat.search(probe_stripped):
            return {"verdict": STATUS_FAILED, "error": f"Forbidden token `{pat.pattern}` in probe"}
    lean_digests["P0R2IndependentCleanSheetProbe"] = sha256_hex(probe_fp.read_bytes())

    # Offline Python Oracle Verification of M-T1-11, M-T1-12, Positive Control & Reward Control
    reg = {77: {"expectedAuthToken": 991122, "maxCalibratedRes": 6, "allowedPortSigs": {301, 302}}}
    spec = {"specHash": 2026, "edges": [(0, 2), (2, 4), (1, 3)], "premises": {500, 600}}
    state0 = {
        "activeSpec": spec,
        "seeds": [
            {
                "seedId": 10,
                "rupturePortId": 1,
                "expectedPortSignature": 301,
                "specHashBound": 2026,
                "requiredObsRes": 4,
                "maxAllowedFlux": 5,
                "requiredPremise": 500,
                "haltedEpoch": 12,
                "src": 0,
                "dst": 4,
                "reactivated": False,
            },
            {
                "seedId": 20,
                "rupturePortId": 2,
                "expectedPortSignature": 302,
                "specHashBound": 2026,
                "requiredObsRes": 4,
                "maxAllowedFlux": 5,
                "requiredPremise": 600,
                "haltedEpoch": 12,
                "src": 1,
                "dst": 3,
                "reactivated": False,
            },
        ],
        "consumedReceipts": [],
    }
    raw_valid_a = {
        "receiptId": 90001,
        "issuerId": 77,
        "presentedAuthToken": 991122,
        "targetSpecHash": 2026,
        "portSignature": 301,
        "measuredObserverRes": 5,
        "measuredBoundaryFlux": 3,
        "evidenceEpoch": 15,
        "untrustedClaimedSourceOk": False,
        "untrustedClaimedSchemaOk": False,
    }
    ev_a = run_detached_evidence_check_py(reg, 2026, raw_valid_a)
    assert ev_a is not None
    cand_a = {"targetSeedId": 10, "targetPortId": 1}

    # M-T1-11 checks: wrong seed (20), wrong port (99), stale epoch (10), and replay after valid commit
    ok_wrong_seed, _, _ = step_bound_resurrection_py(state0, 20, cand_a, ev_a)
    ok_wrong_port, _, _ = step_bound_resurrection_py(state0, 10, {"targetSeedId": 10, "targetPortId": 99}, ev_a)
    ev_stale = run_detached_evidence_check_py(reg, 2026, {**raw_valid_a, "receiptId": 90002, "evidenceEpoch": 10})
    ok_stale, _, _ = step_bound_resurrection_py(state0, 10, cand_a, ev_stale)
    ok_pos, _, state1 = step_bound_resurrection_py(state0, 10, cand_a, ev_a)
    ok_replay, _, _ = step_bound_resurrection_py(state1, 10, cand_a, ev_a)
    m_t1_11_pass = (not ok_wrong_seed) and (not ok_wrong_port) and (not ok_stale) and ok_pos and (not ok_replay)

    # M-T1-12 checks: forged booleans + direct constructor forgery attempt + fake reward flag
    forged_raw = {
        **raw_valid_a,
        "receiptId": 99999,
        "issuerId": 666,
        "presentedAuthToken": 0,
        "untrustedClaimedSourceOk": True,
        "untrustedClaimedSchemaOk": True,
    }
    forged_ev = run_detached_evidence_check_py(reg, 2026, forged_raw)
    ctor_blocked = False
    try:
        VerifiedFrontierEvidencePy(object(), forged_raw)
    except PermissionError:
        ctor_blocked = True
    seed_a_after = state1["seeds"][0]
    rew_pre_proof = compute_learning_reward_py(spec, seed_a_after, None, True)
    rew_bad_walk = compute_learning_reward_py(spec, seed_a_after, [3, 4], True)
    rew_valid_proof = compute_learning_reward_py(spec, seed_a_after, [2, 4], False)
    m_t1_12_pass = (
        (forged_ev is None)
        and ctor_blocked
        and (rew_pre_proof == 0)
        and (rew_bad_walk == 0)
        and (rew_valid_proof == 1)
        and (not ev_a.guarantees_empirical_truth)
    )

    if not (m_t1_11_pass and m_t1_12_pass):
        return {
            "verdict": STATUS_FAILED,
            "m_t1_11_pass": m_t1_11_pass,
            "m_t1_12_pass": m_t1_12_pass,
        }

    return {
        "verdict": STATUS_SELF_CONTAINED_VERIFIED,
        "embedded_p0_lineage": lineage_records,
        "r2_source_sha256": lean_digests,
        "offline_oracle_controls": {
            "M_T1_11_cross_seed_port_stale_and_replay_blocked": m_t1_11_pass,
            "M_T1_12_forged_booleans_and_ctor_forgery_blocked": m_t1_12_pass,
            "positive_resurrection_control_passed": ok_pos and (not state1["seeds"][1]["reactivated"]),
            "reward_control_0_pre_proof_1_post_proof": (rew_pre_proof == 0 and rew_valid_proof == 1),
        },
    }


# =============================================================================
# Track 2: Cleanroom Lean 4.33.1 Compilation, SMap Audit & Live Kernel Mutations
# =============================================================================

def _run_lean_r2_mutation(
    lean_bin: Path,
    lean_r2_dir: Path,
    up_to_idx: int,
    rel_target: str,
    old_str: str,
    new_str: str,
) -> Tuple[bool, int]:
    with tempfile.TemporaryDirectory(prefix="p0_r2_mut_") as tmp:
        tp = Path(tmp)
        scp = tp / "lean_r2"
        bld = tp / "bld"
        shutil.copytree(lean_r2_dir, scp)
        (bld / "ProofspaceOmegaP0R2").mkdir(parents=True, exist_ok=True)
        tf = scp / rel_target
        orig = tf.read_text(encoding="utf-8")
        mut = orig.replace(old_str, new_str, 1)
        assert mut != orig, f"Snippet not found in {rel_target}"
        tf.write_text(mut, encoding="utf-8")
        env = dict(os.environ)
        env["LEAN_PATH"] = str(bld)
        for _, rel in ORDERED_R2_MODULES[: up_to_idx + 1]:
            proc = subprocess.run(
                [str(lean_bin), "-o", str(bld / Path(rel).with_suffix(".olean")), rel],
                cwd=str(scp),
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            if proc.returncode != 0:
                return (True, proc.returncode)
        return (False, 0)


def run_lean_cleanroom_and_mutations(r2_root: Path) -> Dict[str, Any]:
    lean_bin = find_lean_exe()
    if lean_bin is None:
        return {
            "verdict": STATUS_EVIDENCE_UNAVAILABLE,
            "reason": "Lean 4.33.1 binary not installed in current environment; held per 104-F0 firewall.",
        }

    ver = subprocess.run([str(lean_bin), "--version"], capture_output=True, text=True, check=False)
    ver_out = (ver.stdout or "") + (ver.stderr or "")
    if PINNED_LEAN_VERSION not in ver_out or PINNED_LEAN_COMMIT not in ver_out:
        return {"verdict": STATUS_FAILED, "error": f"Toolchain mismatch: {ver_out.strip()}"}

    lean_r2_dir = r2_root / "lean_r2"
    probe_file = r2_root / "probes" / "r2_independent_clean_sheet_probe.lean"

    with tempfile.TemporaryDirectory(prefix="p0_r2_cleanroom_") as tmp:
        tp = Path(tmp)
        scp = tp / "lean_r2"
        bld = tp / "build"
        shutil.copytree(lean_r2_dir, scp)
        shutil.copy2(probe_file, scp / "r2_independent_clean_sheet_probe.lean")
        (bld / "ProofspaceOmegaP0R2").mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["LEAN_PATH"] = str(bld)

        axiom_raw = ""
        for mod_name, rel in ORDERED_R2_MODULES:
            proc = subprocess.run(
                [str(lean_bin), "-o", str(bld / Path(rel).with_suffix(".olean")), rel],
                cwd=str(scp),
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            if proc.returncode != 0:
                return {"verdict": STATUS_FAILED, "failed_module": mod_name, "stderr": proc.stdout + proc.stderr}
            if mod_name == "ProofspaceOmegaP0R2.P0R2AxiomAudit":
                axiom_raw = proc.stdout

        p_proc = subprocess.run(
            [str(lean_bin), "-o", str(bld / "r2_independent_clean_sheet_probe.olean"), "r2_independent_clean_sheet_probe.lean"],
            cwd=str(scp),
            capture_output=True,
            text=True,
            env=env,
            check=False,
        )
        if p_proc.returncode != 0:
            return {"verdict": STATUS_FAILED, "failed_module": "r2_independent_clean_sheet_probe", "stderr": p_proc.stdout + p_proc.stderr}

        thm_axioms: Dict[str, List[str]] = {}
        for m in re.finditer(
            r"'([^']+)'\s+(?:(does not depend on any axioms)|depends on axioms:\s*\[([^\]]+)\])",
            axiom_raw,
            flags=re.DOTALL,
        ):
            tnm = m.group(1).strip()
            if m.group(2) is not None:
                thm_axioms[tnm] = []
            else:
                axs = [a.strip() for a in m.group(3).replace("\n", " ").split(",") if a.strip()]
                for ax in axs:
                    if ax not in ALLOWED_LEAN_AXIOMS:
                        return {"verdict": STATUS_FAILED, "error": f"Disallowed axiom {ax} on {tnm}"}
                thm_axioms[tnm] = axs

        missing = [t for t in REQUIRED_15_R2_THEOREMS if t not in thm_axioms]
        if missing:
            return {"verdict": STATUS_FAILED, "error": f"Missing audited R2 theorems: {missing}"}

        insp_path = scp / "R2SMapInspector.lean"
        insp_path.write_text(SMAP_R2_INSPECTOR, encoding="utf-8")
        insp = subprocess.run(
            [str(lean_bin), "R2SMapInspector.lean"],
            cwd=str(scp),
            capture_output=True,
            text=True,
            env=env,
            check=False,
        )
        if insp.returncode != 0:
            return {"verdict": STATUS_FAILED, "error": f"SMap inspector failed: {insp.stdout} {insp.stderr}"}
        smap_ln = next((ln.strip() for ln in insp.stdout.splitlines() if ln.startswith("P0_R2_SMAP|")), "")
        if not smap_ln:
            return {"verdict": STATUS_FAILED, "error": "Missing P0_R2_SMAP output"}
        smap = {k: int(v) for k, v in (seg.split("=", 1) for seg in smap_ln.split("|")[1:])}
        if smap["sorry"] != 0 or smap["userAxioms"] != 0 or smap["opaque"] != 0 or smap["reduceBool"] != 0:
            return {"verdict": STATUS_FAILED, "error": f"SMap soundness violation: {smap}"}

    # 4 Live Lean 4.33.1 Kernel Mutations specifically locking F-T1-06 / M-T1-11 and F-T1-07 / M-T1-12
    c1, rc1 = _run_lean_r2_mutation(
        lean_bin,
        lean_r2_dir,
        3,
        "ProofspaceOmegaP0R2/BoundResurrectionStateR2.lean",
        "(cand.targetSeedId == seed.seedId) &&",
        "true &&",
    )
    c2, rc2 = _run_lean_r2_mutation(
        lean_bin,
        lean_r2_dir,
        3,
        "ProofspaceOmegaP0R2/BoundResurrectionStateR2.lean",
        "!(P.consumedReceipts.any (fun rid => rid == raw.receiptId))",
        "true",
    )
    c3, rc3 = _run_lean_r2_mutation(
        lean_bin,
        lean_r2_dir,
        3,
        "ProofspaceOmegaP0R2/ProofCarryingEvidenceR2.lean",
        "reg.issuers.any (verifyIssuerRecordBool raw)",
        "raw.untrustedClaimedSourceOk",
    )
    c4, rc4 = _run_lean_r2_mutation(
        lean_bin,
        lean_r2_dir,
        3,
        "ProofspaceOmegaP0R2/BoundResurrectionStateR2.lean",
        "| none =>\n        { positiveTruthCredit := 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }",
        "| none =>\n        { positiveTruthCredit := if _untrustedClaimedKernelAccepted then 1 else 0, prioritizesSearchOnly := true, boundSpecHash := spec.specHash }",
    )
    lean_mutations = [
        {"id": "M_R2_LEAN_11A", "target": "F-T1-06 / M-T1-11", "desc": "Dropping cand.targetSeedId == seed.seedId breaks Lean proofs", "caught": c1, "rc": rc1},
        {"id": "M_R2_LEAN_11B", "target": "F-T1-06 / Replay", "desc": "Dropping consumedReceipts replay guard breaks Lean proofs", "caught": c2, "rc": rc2},
        {"id": "M_R2_LEAN_12A", "target": "F-T1-07 / M-T1-12", "desc": "Trusting raw.untrustedClaimedSourceOk breaks noninterference & m_t1_12 proofs", "caught": c3, "rc": rc3},
        {"id": "M_R2_LEAN_12B", "target": "F-T1-07 / Reward", "desc": "Trusting _untrustedClaimedKernelAccepted on none witness breaks reward soundness", "caught": c4, "rc": rc4},
    ]
    if not all(m["caught"] for m in lean_mutations):
        return {"verdict": STATUS_FAILED, "error": "Uncaught Lean mutation", "lean_mutations": lean_mutations}

    return {
        "verdict": STATUS_LOCAL_CLEANROOM_VERIFIED,
        "lean_toolchain": ver_out.strip(),
        "modules_plus_probe_compiled": len(ORDERED_R2_MODULES) + 1,
        "required_r2_theorems_audited": len(REQUIRED_15_R2_THEOREMS),
        "zero_axiom_theorems_count": sum(1 for v in thm_axioms.values() if len(v) == 0),
        "classical_choice_theorems_count": sum(1 for v in thm_axioms.values() if "Classical.choice" in v),
        "standard_axioms_observed": sorted({ax for axs in thm_axioms.values() for ax in axs}),
        "smap_metrics": smap,
        "theorem_axiom_footprints": thm_axioms,
        "live_lean_mutations": lean_mutations,
    }


# =============================================================================
# Track 3: Optional External Host Ancestor Mount Check (Never Promoted if Absent)
# =============================================================================

def audit_external_host_ancestors(r2_root: Path, allow_parent_search: bool = True) -> Dict[str, Any]:
    search_dirs: List[Path] = []
    if allow_parent_search:
        campus_nk = r2_root.parent
        campus_root = campus_nk.parent
        search_dirs = [
            campus_root,
            campus_nk,
            campus_nk / "campus_omega_lambda_e1_t105_closure_freeze" / "ledger",
        ]
    records: Dict[str, Any] = {}
    statuses: List[str] = []
    for key, fname, exp_sha, exp_sz in EXTERNAL_HOST_ANCESTORS:
        found = next((d / fname for d in search_dirs if (d / fname).is_file()), None)
        if found is None:
            records[key] = {"filename": fname, "status": STATUS_EVIDENCE_UNAVAILABLE}
            statuses.append(STATUS_EVIDENCE_UNAVAILABLE)
            continue
        raw = found.read_bytes()
        ok = (sha256_hex(raw) == exp_sha) and (len(raw) == exp_sz)
        st = STATUS_LOCAL_CLEANROOM_VERIFIED if ok else STATUS_FAILED
        records[key] = {
            "filename": fname,
            "expected_sha256": exp_sha,
            "actual_sha256": sha256_hex(raw),
            "size_bytes": len(raw),
            "modified_bytes": 0 if ok else abs(len(raw) - exp_sz),
            "status": st,
        }
        statuses.append(st)
    return {
        "verdict": meet_poset(statuses),
        "records": records,
    }


def execute_p0_r2_audit(
    r2_root: Path,
    write_ledger: bool = True,
    allow_parent_search: bool = True,
) -> Dict[str, Any]:
    self_doc = run_self_contained_offline_audit(r2_root)
    lean_doc = run_lean_cleanroom_and_mutations(r2_root)
    ext_doc = audit_external_host_ancestors(r2_root, allow_parent_search=allow_parent_search)

    def _norm(v: str) -> str:
        return STATUS_LOCAL_CLEANROOM_VERIFIED if v == STATUS_SELF_CONTAINED_VERIFIED else v

    p0_r2_core_verdict = meet_poset([_norm(self_doc["verdict"]), lean_doc["verdict"]])
    overall_poset_verdict = meet_poset([_norm(self_doc["verdict"]), lean_doc["verdict"], ext_doc["verdict"]])

    payload = {
        "schema": "CAMPUS_PROOFSPACE_OMEGA_P0_R2_SCOPED_REMEDIATION_RECEIPT_V1",
        "stage_id": STAGE_ID,
        "authorization_token": AUTHORIZATION_TOKEN,
        "host_platform": f"{platform.system()}-{platform.release()}-{platform.machine()}",
        "verdicts": {
            "self_contained_offline_verdict": self_doc["verdict"],
            "lean_cleanroom_verdict": lean_doc["verdict"],
            "p0_r2_core_verdict": p0_r2_core_verdict,
            "external_host_ancestors_verdict": ext_doc["verdict"],
            "overall_poset_verdict": overall_poset_verdict,
        },
        "explicit_holds_and_boundaries": {
            "trusted_source_registry_scope": "SOURCE_AND_SCHEMA_ATTESTED_ONLY__NOT_EMPIRICAL_TRUTH_OR_EXTERNAL_PKI",
            "concurrent_multi_worker_cas_atomicity": "HELD_SEQUENTIAL_STATE_REPLAY_PROVED_ONLY",
            "p0_xh0_external_ci_replay": "NOT_AUTHORIZED_IN_R2",
            "p1_raw_wire_bridge": "NOT_AUTHORIZED_IN_R2",
            "e1d_and_release_47": "NOT_AUTHORIZED",
        },
        "self_contained_offline_audit": self_doc,
        "lean_cleanroom_and_mutation_audit": lean_doc,
        "external_host_ancestors_audit": ext_doc,
    }
    seal_sha = sha256_hex(canonical_json(payload))
    receipt = {
        **payload,
        "seal": {
            "algorithm": "SHA-256",
            "canonicalization": "CAMPUS_CANONICAL_JSON_UTF8_SORTED_KEYS_V1",
            "payload_sha256": seal_sha,
        },
    }
    if write_ledger:
        ldir = r2_root / "ledger"
        ldir.mkdir(parents=True, exist_ok=True)
        (ldir / "P0_R2_SCOPED_REMEDIATION_RECEIPT.json").write_bytes(
            json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n"
        )
    return receipt


if __name__ == "__main__":
    root_dir = Path(__file__).resolve().parent.parent
    rcpt = execute_p0_r2_audit(root_dir, write_ledger=True, allow_parent_search=True)
    print(
        json.dumps(
            {
                "stage_id": rcpt["stage_id"],
                "verdicts": rcpt["verdicts"],
                "smap_metrics": rcpt["lean_cleanroom_and_mutation_audit"].get("smap_metrics"),
                "live_lean_mutations_caught": len(
                    rcpt["lean_cleanroom_and_mutation_audit"].get("live_lean_mutations", [])
                ),
                "payload_sha256": rcpt["seal"]["payload_sha256"],
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    sys.exit(0 if rcpt["verdicts"]["self_contained_offline_verdict"] == STATUS_SELF_CONTAINED_VERIFIED else 1)

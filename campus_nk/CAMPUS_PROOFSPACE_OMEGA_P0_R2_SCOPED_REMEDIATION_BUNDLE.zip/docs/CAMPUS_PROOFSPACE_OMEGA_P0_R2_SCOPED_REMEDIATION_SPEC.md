# CAMPUS-NATIVE PROOFSPACE Ω — `P0-R2` 범위 제한 교정 명세서 (`F-T1-06` · `F-T1-07`)

## 1. 승인 범위 및 불변 경계

- **승인 토큰:** `CAMPUS_PROOFSPACE_OMEGA_P0_R2_SINGLE_SCOPED_REMEDIATION_AUTHORIZED__F_T1_06_07_ONLY__M_T1_11_12_AND_POSITIVE_CONTROLS__LEAN4331_CLEANROOM_VERIFICATION__FROZEN_ANCESTORS_IMMUTABLE__P0_XH0_P1_E1D_RELEASE47_NOT_AUTHORIZED`
- **불변 보존 대상 (`0` 바이트 수정):** `T105` 및 선행 아카이브(`#40`, `#46`, `E1_AUX`, `T104`), `P0` v1 (`2d5076cd…3da1f`), `P0-T1/R1` (`e17f719d…a643`).
- **미승인 경계 유지:** `P0-XH0`, `P1`, `E1-D`, `Release #47`은 본 작업에서 수행하지 않으며 `NOT_AUTHORIZED` / `HELD`를 유지합니다.

---

## 2. `F-T1-06` 교정 명세 — 5항 후보·증거 결속 및 상태 결속 재생 방지

`BoundResurrectionStateR2.lean`의 `bindCandidateR2Bool`은 다음 5개 조건의 논리곱을 강제합니다.

$$\begin{aligned}
\operatorname{BindCandidate}(c, s, e, P) \iff{} &(c.\mathrm{targetSeedId} = s.\mathrm{seedId}) \\
&\land (c.\mathrm{targetPortId} = s.\mathrm{rupturePortId}) \\
&\land (e.\mathrm{raw}.\mathrm{portSignature} = s.\mathrm{expectedPortSignature}) \\
&\land \operatorname{ScopeCompatible}(P.\mathrm{activeSpec}, s, e.\mathrm{raw}) \\
&\land \operatorname{FreshEvidence}(P, s, e.\mathrm{raw})
\end{aligned}$$

- **`FreshEvidence(P, s, raw)`:** `(s.haltedEpoch < raw.evidenceEpoch) && !(P.consumedReceipts.any (· == raw.receiptId))`.
- **상태 결속 소비 규칙:** `stepBoundResurrectionR2`가 성공하면 새 상태 $P'$의 `consumedReceipts`에 `ev.raw.receiptId`가 추가되어 동일 영수증의 재사용이 거부됩니다(`r2_f06_consumed_receipt_replay_rejected`). 다중 프로세스 동시 실행 환경의 운영체제 수준 원자성(CAS/락)은 본 순차 상태 모델의 증명 범위 밖(`HELD_CONCURRENT_RUNTIME_ATOMICITY`)으로 명시합니다.

---

## 3. `F-T1-07` 교정 명세 — 증명 수반 증거 구조체 및 비신뢰 플래그 비간섭

`ProofCarryingEvidenceR2.lean` 및 `BoundResurrectionStateR2.lean`은 외부 호출자가 설정하는 인증 Boolean / 양수 태그 의존성을 제거합니다.

1. **`VerifiedFrontierEvidenceR2 reg activeSpecHash`:**
   - 내부에 `detProof : runDetachedEvidenceCheckBool reg activeSpecHash raw = true` 증명 항을 필수로 보유하여, Lean 내 어느 코드에서도 `DetachedCheck = true` 증명 없이는 인스턴스 생성이 불가능합니다(`r2_f07_construct_verified_evidence_implies_detached_pass`).
   - 공격자가 조작 가능한 `untrustedClaimedSourceOk`, `untrustedClaimedSchemaOk` 필드에 대해 완전 비간섭(`r2_f07_detached_check_ignores_untrusted_booleans`)을 증명합니다.
   - **신뢰 경계 한계 명시:** `TrustedSourceRegistry` 확인은 등록된 발행 주체 및 관측 스키마 적합성(`SOURCE_AND_SCHEMA_ATTESTED`)만 확인하며, 외부 암호학적 PKI 진위나 논문 내용의 경험적 참(`guaranteesEmpiricalScientificTruth = false`)을 보증하지 않습니다.
2. **`VerifiedRegimeEntryR2 spec`:**
   - `0 < kernelCheckTag` 대신 실제 `(claim, witness, pkt)`와 `lowProof`, `chkProof`를 내장하여 `DenoteSIRTerm M entry.claim`을 수학적으로 함의합니다(`r2_f07_verified_regime_entry_entails_denotation`).
3. **`computeLearningRewardR2`:**
   - 외부 `kernelProofAccepted : Bool`을 제거하고 `untrustedClaimedKernelAccepted : Bool`에 대한 비간섭(`r2_f07_reward_ignores_untrusted_kernel_boolean`)을 증명하며, 실제 커널 검증 통과 시에만 `positiveTruthCredit = 1`을 부여합니다(`r2_f07_positive_truth_credit_entails_semantic_truth`).

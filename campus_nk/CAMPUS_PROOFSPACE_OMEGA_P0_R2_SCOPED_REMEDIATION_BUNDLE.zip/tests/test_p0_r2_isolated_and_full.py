#!/usr/bin/env python3
"""Unit tests for `P0-R2` Scoped Remediation (`F-T1-06` & `F-T1-07`), designed to run
cleanly BOTH in an isolated air-gapped Tribunal sandbox (no external Windows host archives,
no Lean binary) AND on a full Lean 4.33.1 cleanroom host without ever promoting
`EVIDENCE_UNAVAILABLE` to `PASS`."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

R2_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = R2_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import verify_p0_r2_scoped_remediation as r2  # noqa: E402


class TestP0R2ScopedRemediation(unittest.TestCase):
    def test_01_poset_firewall_never_promotes_evidence_unavailable(self) -> None:
        self.assertEqual(
            r2.meet_poset([r2.STATUS_LOCAL_CLEANROOM_VERIFIED, r2.STATUS_EVIDENCE_UNAVAILABLE]),
            r2.STATUS_EVIDENCE_UNAVAILABLE,
        )
        self.assertEqual(
            r2.meet_poset([r2.STATUS_SELF_CONTAINED_VERIFIED, r2.STATUS_FAILED]),
            r2.STATUS_FAILED,
        )

    def test_02_self_contained_embedded_lineage_and_offline_controls(self) -> None:
        doc = r2.run_self_contained_offline_audit(R2_ROOT)
        self.assertEqual(doc["verdict"], r2.STATUS_SELF_CONTAINED_VERIFIED)
        self.assertEqual(doc["embedded_p0_lineage"]["p0_v1_bundle_zip"]["modified_bytes"], 0)
        self.assertEqual(doc["embedded_p0_lineage"]["p0_t1_r1_bundle_zip"]["modified_bytes"], 0)
        ctrls = doc["offline_oracle_controls"]
        self.assertTrue(ctrls["M_T1_11_cross_seed_port_stale_and_replay_blocked"])
        self.assertTrue(ctrls["M_T1_12_forged_booleans_and_ctor_forgery_blocked"])
        self.assertTrue(ctrls["positive_resurrection_control_passed"])
        self.assertTrue(ctrls["reward_control_0_pre_proof_1_post_proof"])

    def test_03_simulated_airgapped_sandbox_keeps_unavailable_unpromoted(self) -> None:
        """Simulates an isolated Tribunal sandbox with NO external host archives and NO Lean binary."""
        old_env = os.environ.get("P0_R2_LEAN_BIN")
        try:
            os.environ["P0_R2_LEAN_BIN"] = ""
            with tempfile.TemporaryDirectory(prefix="r2_airgap_sim_") as tmp:
                isolated_root = Path(tmp) / "isolated_r2"
                shutil.copytree(
                    R2_ROOT,
                    isolated_root,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.zip"),
                )
                # Copy the 2 embedded readonly P0 lineage ZIPs explicitly
                (isolated_root / "readonly_p0_lineage").mkdir(parents=True, exist_ok=True)
                for _, fname, _, _ in r2.EMBEDDED_P0_LINEAGE:
                    shutil.copy2(
                        R2_ROOT / "readonly_p0_lineage" / fname,
                        isolated_root / "readonly_p0_lineage" / fname,
                    )
                rcpt = r2.execute_p0_r2_audit(
                    isolated_root,
                    write_ledger=False,
                    allow_parent_search=False,
                )
                v = rcpt["verdicts"]
                self.assertEqual(v["self_contained_offline_verdict"], r2.STATUS_SELF_CONTAINED_VERIFIED)
                self.assertEqual(v["lean_cleanroom_verdict"], r2.STATUS_EVIDENCE_UNAVAILABLE)
                self.assertEqual(v["external_host_ancestors_verdict"], r2.STATUS_EVIDENCE_UNAVAILABLE)
                self.assertEqual(v["overall_poset_verdict"], r2.STATUS_EVIDENCE_UNAVAILABLE)
        finally:
            if old_env is None:
                os.environ.pop("P0_R2_LEAN_BIN", None)
            else:
                os.environ["P0_R2_LEAN_BIN"] = old_env

    def test_04_lean_4331_cleanroom_and_live_mutations(self) -> None:
        if r2.find_lean_exe() is None:
            self.skipTest("Lean 4.33.1 binary not installed in this sandbox; Lean verdict held as EVIDENCE_UNAVAILABLE")
        lean_doc = r2.run_lean_cleanroom_and_mutations(R2_ROOT)
        self.assertEqual(lean_doc["verdict"], r2.STATUS_LOCAL_CLEANROOM_VERIFIED)
        self.assertEqual(lean_doc["smap_metrics"]["sorry"], 0)
        self.assertEqual(lean_doc["smap_metrics"]["userAxioms"], 0)
        self.assertEqual(lean_doc["smap_metrics"]["opaque"], 0)
        self.assertEqual(lean_doc["smap_metrics"]["reduceBool"], 0)
        self.assertEqual(len(lean_doc["live_lean_mutations"]), 4)
        for m in lean_doc["live_lean_mutations"]:
            self.assertTrue(m["caught"])


if __name__ == "__main__":
    unittest.main()

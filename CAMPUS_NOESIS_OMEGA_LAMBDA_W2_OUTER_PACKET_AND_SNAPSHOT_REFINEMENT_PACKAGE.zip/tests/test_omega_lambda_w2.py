#!/usr/bin/env python3
"""22-Test Qualification Suite for `Ωλ-W2` (`#46`): 19 Offline + 3 Live-Lean Tests."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import struct
import sys
import unittest

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from src.independent_verify_omega_lambda_w2 import verify_extracted_directory
from src.omega_lambda_w2_harness import (
    ALLOWED_FOUNDATION_AXIOMS,
    ALL_W2_MODULES,
    EXPECTED_M1_KERNEL_CONSTANTS,
    EXPECTED_R1_NEW_KERNEL_CONSTANTS,
    EXPECTED_R2_NEW_KERNEL_CONSTANTS,
    EXPECTED_W1_NEW_KERNEL_CONSTANTS,
    PINNED_OMEGA_KAPPA_A1_REGISTRY_15,
    W2D_MANDATORY_SCOPE,
    W2_NEW_MODULES,
    check_cnp2_packet_0x00_py,
    decode_ascii_id_slice_py,
    decode_cnb1_bundle_py,
    decode_cnp2_packet_0x00_py,
    decode_snapshot_section_py,
    encode_ascii_id_slice_py,
    encode_cnb1_bundle_py,
    encode_cnp2_packet_0x00_py,
    encode_snapshot_section_py,
    extract_declarations_and_static_audit,
    find_optional_lean_binary,
    make_sample_valid_0x03_packet_py,
    make_sample_valid_0x05_packet_py,
    mk_snapshot_preimage_py,
    run_live_lean_w2_and_env_coverage,
    run_w2_full_packet_and_kappa40_differential,
    verify_frozen_41_43_44_45_byte_identity,
    verify_seal,
)


class TestOmegaLambdaW2OuterPacketAndSnapshotRefinement(unittest.TestCase):
    """Offline (`19`) and optional live-Lean (`3`) tests for `Ωλ-W2` (`#46`)."""

    _live_cache = None

    @classmethod
    def _get_live_lean_result(cls):
        if cls._live_cache is None:
            cls._live_cache = run_live_lean_w2_and_env_coverage(PACKAGE_ROOT)
        return cls._live_cache

    def test_01_manifest_and_zero_cr_integrity(self) -> None:
        manifest_path = PACKAGE_ROOT / "MANIFEST.json"
        self.assertTrue(manifest_path.exists())
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.assertTrue(verify_seal(manifest))
        self.assertEqual(manifest["registered_files_count"], len(manifest["files"]))
        for entry in manifest["files"]:
            fp = PACKAGE_ROOT / entry["path"]
            raw = fp.read_bytes()
            self.assertNotIn(b"\r", raw, f"CR byte in {entry['path']}")
            self.assertEqual(len(raw), entry["size_bytes"])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), entry["sha256"])

    def test_02_all_sealed_receipts_cryptographic_seals(self) -> None:
        receipts_dir = PACKAGE_ROOT / "receipts"
        receipt_files = sorted(receipts_dir.glob("*.json"))
        self.assertGreaterEqual(len(receipt_files), 9)
        for rf in receipt_files:
            obj = json.loads(rf.read_text(encoding="utf-8"))
            self.assertTrue(verify_seal(obj), f"Invalid seal on {rf.name}")

    def test_03_frozen_20_m1_r1_r2_w1_lean_files_byte_identical(self) -> None:
        res = verify_frozen_41_43_44_45_byte_identity(PACKAGE_ROOT)
        self.assertTrue(res["all_20_frozen_lean_files_byte_identical"])
        self.assertTrue(res["m1_manifest_match"])
        self.assertTrue(res["r1_manifest_match"])
        self.assertTrue(res["r2_manifest_match"])
        self.assertTrue(res["w1_manifest_match"])

    def test_04_zero_forbidden_tokens_across_all_24_lean_modules(self) -> None:
        full_audit = extract_declarations_and_static_audit(PACKAGE_ROOT / "lean", ALL_W2_MODULES)
        self.assertEqual(full_audit["forbidden_token_violations"], [])
        self.assertEqual(full_audit["total_count"], full_audit["unique_name_count"])

    def test_05_w2_required_w2a_w2b_w2c_w2d_and_f93_theorems_present(self) -> None:
        w2_audit = extract_declarations_and_static_audit(PACKAGE_ROOT / "lean", W2_NEW_MODULES)
        names = {d["name"]: d["kind"] for d in w2_audit["declarations"]}
        required_theorems = (
            "OmegaLambda.w2b_ascii_id_forward_roundtrip",
            "OmegaLambda.w2b_ascii_id_backward_roundtrip",
            "OmegaLambda.w2b_ascii_id_byte_lex_iff_string_lex",
            "OmegaLambda.w2b_encodeSnapshotSection_domain_iff",
            "OmegaLambda.w2b_noncanonical_snapshot_encode_none",
            "OmegaLambda.w2b_snapshot_forward_roundtrip",
            "OmegaLambda.w2b_snapshot_backward_roundtrip",
            "OmegaLambda.w2b_snapshot_ir_ids_nodup",
            "OmegaLambda.w2a_cnb1_contiguous_partition_exact",
            "OmegaLambda.w2a_cnb1_encode_domain_iff",
            "OmegaLambda.w2a_cnb1_forward_roundtrip",
            "OmegaLambda.w2a_cnb1_backward_roundtrip",
            "OmegaLambda.w2a_cnp2_packet_encode_domain_iff",
            "OmegaLambda.w2a_cnp2_packet_forward_roundtrip",
            "OmegaLambda.w2a_cnp2_packet_backward_roundtrip",
            "OmegaLambda.w2c_b1_b2_implies_r1_anchor_and_graph",
            "OmegaLambda.f93_02_b1_to_b6_implies_checkVerifiedBase",
            "OmegaLambda.f93_03_synthesizeVerifiedBase_sound",
            "OmegaLambda.f93_03_packet0x03_requires_original_wire_b1_b5",
            "OmegaLambda.f93_01_arbitrary_reg_does_not_imply_trusted_a1",
            "OmegaLambda.w2d_packet_sound_relative_to_registry",
            "OmegaLambda.w2d_packet_sound_pinned_a1",
            "OmegaLambda.w2d_pinned_a1_snapshot_unique",
        )
        for thm in required_theorems:
            self.assertEqual(names.get(thm), "theorem", f"Missing theorem {thm}")

    def test_06_w2b_ascii_id_66_char_bijection_and_order_isomorphism(self) -> None:
        valid_id = "SNAP-PHI_K3.01:A1"
        raw = encode_ascii_id_slice_py(valid_id)
        self.assertIsNotNone(raw)
        assert raw is not None
        self.assertEqual(decode_ascii_id_slice_py(raw), valid_id)
        self.assertIsNone(encode_ascii_id_slice_py(""))
        self.assertIsNone(encode_ascii_id_slice_py("BAD SPACE"))
        self.assertIsNone(decode_ascii_id_slice_py(raw + b"\x00"))

    def test_07_w2b_raw_snapshot_section_bijection_and_eplus_selfloop_sha256(self) -> None:
        snap = {
            "snapshotId": "SNAP-PHI-EPLUS-SELFLOOP-A1",
            "bucket0": ("L0", "L1"),
            "bucket1": (),
            "bucket2": (),
            "bucket3": (),
            "irRecords": (
                {"recTag": 2, "recordId": "IR-DET-01", "sourceVid": 0, "sourceSortCode": 0, "refs": ((1, 0, 1),)},
                {"recTag": 2, "recordId": "IR-DET-02", "sourceVid": 1, "sourceSortCode": 0, "refs": ((0, 0, 1),)},
                {"recTag": 2, "recordId": "IR-LOOP-01", "sourceVid": 0, "sourceSortCode": 0, "refs": ((0, 0, 1),)},
            ),
        }
        raw_s = encode_snapshot_section_py(snap)
        self.assertIsNotNone(raw_s)
        assert raw_s is not None
        self.assertEqual(len(raw_s), 112)
        self.assertEqual(decode_snapshot_section_py(raw_s), snap)
        root_hex = hashlib.sha256(mk_snapshot_preimage_py(1, 0xFF33, raw_s)).hexdigest()
        self.assertEqual(root_hex, "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f")

        # Unsorted bucket rejected (`F91-03` discipline)
        bad_snap = dict(snap)
        bad_snap["bucket0"] = ("L1", "L0")
        self.assertIsNone(encode_snapshot_section_py(bad_snap))

    def test_08_w2a_cnb1_50b_header_and_contiguous_3_section_roundtrip(self) -> None:
        _, pkt05 = make_sample_valid_0x05_packet_py()
        dec_pkt = decode_cnp2_packet_0x00_py(pkt05)
        self.assertIsNotNone(dec_pkt)
        assert dec_pkt is not None
        base = dec_pkt["base"]
        raw_cnb = encode_cnb1_bundle_py(base)
        self.assertIsNotNone(raw_cnb)
        assert raw_cnb is not None
        self.assertGreaterEqual(len(raw_cnb), 62)
        self.assertEqual(raw_cnb[:6], b"CNB1\x00\x01")
        self.assertEqual(decode_cnb1_bundle_py(raw_cnb), base)
        self.assertIsNone(decode_cnb1_bundle_py(raw_cnb + b"\x00"))

    def test_09_w2a_cnp2_0x03_and_0x05_asymmetric_packet_roundtrips(self) -> None:
        _, pkt03 = make_sample_valid_0x03_packet_py()
        d03 = decode_cnp2_packet_0x00_py(pkt03)
        self.assertIsNotNone(d03)
        assert d03 is not None
        self.assertEqual(d03["packetKind"], 3)
        self.assertEqual(encode_cnp2_packet_0x00_py(d03), pkt03)
        self.assertIsNone(decode_cnp2_packet_0x00_py(pkt03 + b"\x00"))

        _, pkt05 = make_sample_valid_0x05_packet_py()
        d05 = decode_cnp2_packet_0x00_py(pkt05)
        self.assertIsNotNone(d05)
        assert d05 is not None
        self.assertEqual(d05["packetKind"], 5)
        self.assertEqual(encode_cnp2_packet_0x00_py(d05), pkt05)
        # Non-resilience packet_kind=0x01 rejected
        forged_01 = b"CNP2\x00\x02\x01\x00" + pkt05[8:]
        self.assertIsNone(decode_cnp2_packet_0x00_py(forged_01))

    def test_10_f92_01_trusted_snapshot_input_removed_from_top_level_gate(self) -> None:
        rec = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_F92_01_SNAPSHOT_REFINEMENT_RECEIPT.json").read_text("utf-8")
        )
        self.assertTrue(verify_seal(rec))
        self.assertTrue(rec["caller_supplied_trusted_snapshot_parameter_removed"])
        lean_src = (PACKAGE_ROOT / "lean" / "OmegaLambda" / "PacketRefinement.lean").read_text("utf-8")
        self.assertIn("def checkCnp2ResiliencePacket0x00", lean_src)
        self.assertIn("def checkCnp2ResiliencePacketPinnedA1_0x00", lean_src)

    def test_11_f93_01_a1_registry_authority_binding_and_forged_registry_separation(self) -> None:
        self.assertEqual(len(PINNED_OMEGA_KAPPA_A1_REGISTRY_15), 15)
        # Valid #40 EPLUS-SELFLOOP packet passes pinned A1 registry
        _, pkt05 = make_sample_valid_0x05_packet_py()
        self.assertTrue(check_cnp2_packet_0x00_py(PINNED_OMEGA_KAPPA_A1_REGISTRY_15, pkt05))

        # Forged snapshot + matching forged registry passes relative check (`Level 1`),
        # but FAILS pinned A1 registry (`Level 2` `F93-01` separation)!
        forged_reg, forged_pkt = make_sample_valid_0x05_packet_py(snapshot_id_override="SNAP-FORGED-ATTACKER-99")
        self.assertTrue(check_cnp2_packet_0x00_py(forged_reg, forged_pkt))
        self.assertFalse(check_cnp2_packet_0x00_py(PINNED_OMEGA_KAPPA_A1_REGISTRY_15, forged_pkt))

    def test_12_f93_02_and_f93_03_independent_0x05_and_0x03_branches_and_nonlaundering(self) -> None:
        reg03, pkt03 = make_sample_valid_0x03_packet_py()
        self.assertTrue(check_cnp2_packet_0x00_py(reg03, pkt03))

        # Corrupting wire `posWitnesses` rank in `0x03` MUST be rejected by Gate 1 (`F93-03`),
        # even though `synthesizeVerifiedBase` on the underlying graph is completely valid!
        d03 = decode_cnp2_packet_0x00_py(pkt03)
        assert d03 is not None
        bad_base = dict(d03["base"])
        pw0 = bad_base["posWitnesses"][0]
        bad_base["posWitnesses"] = ((pw0[0], pw0[1], 99, pw0[3]),) + bad_base["posWitnesses"][1:]
        d03_bad = dict(d03)
        d03_bad["base"] = bad_base
        raw_bad03 = encode_cnp2_packet_0x00_py(d03_bad)
        self.assertIsNotNone(raw_bad03)
        assert raw_bad03 is not None
        self.assertFalse(check_cnp2_packet_0x00_py(reg03, raw_bad03))

    def test_13_full_packet_and_kappa40_300_trial_differential(self) -> None:
        res = run_w2_full_packet_and_kappa40_differential(seed=20261118, trials=300)
        self.assertEqual(res["mismatches"], 0)
        self.assertEqual(res["roundtrips_verified"], 300)
        self.assertGreaterEqual(res["adversarial_rejections_verified"], 600)

    def test_14_env_coverage_receipt_24_modules_zero_axioms_zero_orphans(self) -> None:
        env_rec = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_ENV_COVERAGE_RECEIPT.json").read_text("utf-8")
        )
        self.assertTrue(verify_seal(env_rec))
        self.assertEqual(env_rec["m1_kernel_constants_count"], EXPECTED_M1_KERNEL_CONSTANTS)
        self.assertEqual(env_rec["r1_new_kernel_constants_count"], EXPECTED_R1_NEW_KERNEL_CONSTANTS)
        self.assertEqual(env_rec["r2_new_kernel_constants_count"], EXPECTED_R2_NEW_KERNEL_CONSTANTS)
        self.assertEqual(env_rec["w1_new_kernel_constants_count"], EXPECTED_W1_NEW_KERNEL_CONSTANTS)
        self.assertGreater(env_rec["w2_new_kernel_constants_count"], 200)
        self.assertEqual(env_rec["orphan_project_constants_count"], 0)
        self.assertEqual(env_rec["user_axiom_constants_count"], 0)
        self.assertEqual(env_rec["opaque_constants_count"], 0)
        self.assertEqual(env_rec["disallowed_axiom_violations_count"], 0)

    def test_15_w2_flagship_axioms_within_foundation_whitelist(self) -> None:
        rec = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_PACKET_PROOF_TRACK_RECEIPT.json").read_text("utf-8")
        )
        self.assertTrue(verify_seal(rec))
        allowed = set(ALLOWED_FOUNDATION_AXIOMS)
        for thm, axs in rec["w2_flagship_axioms"].items():
            self.assertTrue(set(axs).issubset(allowed), f"Disallowed axiom on {thm}: {axs}")

    def test_16_w2d_mandatory_scope_tag_and_held_boundaries_recorded(self) -> None:
        g_rec = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_F93_GUARDS_AND_HELD_RECEIPT.json").read_text("utf-8")
        )
        self.assertTrue(verify_seal(g_rec))
        self.assertEqual(g_rec["w2d_composition_scope"], W2D_MANDATORY_SCOPE)
        self.assertEqual(g_rec["non_resilience_cnp2_packet_kinds_0x01_0x02_0x04_status"], "HELD")
        self.assertEqual(g_rec["evasion_mode_0x01_status"], "HELD")
        self.assertEqual(g_rec["omega_lambda_m2_m3_status"], "NOT_AUTHORIZED_HELD")
        self.assertEqual(g_rec["external_authority_a2_a3_status"], "HELD")
        self.assertEqual(
            g_rec["third_party_physical_lean_execution_status"],
            "THIRD_PARTY_LIVE_VERIFICATION_HELD",
        )

    def test_17_heritage_45_receipt_pins_all_233_seals(self) -> None:
        h45 = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_HERITAGE_PRESERVATION_45_RECEIPT.json").read_text("utf-8")
        )
        self.assertTrue(verify_seal(h45))
        self.assertEqual(h45["total_registered_heritage_archives"], 45)
        self.assertEqual(h45["total_pinned_seals_count"], 233)

    def test_18_contract_64hex_integrity(self) -> None:
        contract = json.loads(
            (PACKAGE_ROOT / "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_CONTRACT.json").read_text("utf-8")
        )
        self.assertEqual(
            contract["authorized_scope"]["w2d_composition_scope"], W2D_MANDATORY_SCOPE
        )
        base = contract["frozen_ancestor_baseline"]
        self.assertEqual(base["frozen_archives_count"], 45)
        self.assertEqual(base["pinned_seals_count"], 233)
        for k, v in base.items():
            if k.endswith("_sha256"):
                self.assertEqual(len(v), 64, f"Bad hex length on {k}")

    def test_19_zero_shared_code_standalone_verifiers_ast_and_offline_audit(self) -> None:
        targets = (
            PACKAGE_ROOT / "src" / "independent_verify_omega_lambda_w2.py",
            PACKAGE_ROOT / "third_party_audit" / "verify_frozen45_zero_shared_third_party.py",
        )
        stdlib = sys.stdlib_module_names
        for path in targets:
            self.assertTrue(path.is_file(), f"Missing standalone verifier {path}")
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        top = alias.name.split(".")[0]
                        self.assertIn(top, stdlib, f"Non-stdlib import {alias.name} in {path.name}")
                elif isinstance(node, ast.ImportFrom):
                    self.assertEqual(node.level, 0, f"Relative import in {path.name}")
                    top = (node.module or "").split(".")[0]
                    self.assertIn(top, stdlib, f"Non-stdlib import from {node.module} in {path.name}")

        res = verify_extracted_directory(PACKAGE_ROOT, run_live_lean_if_present=False)
        self.assertEqual(res["verdict"], "PASS")
        self.assertTrue(res["zero_shared_code_verifier"])
        self.assertEqual(res["w2d_composition_scope"], W2D_MANDATORY_SCOPE)

    def test_20_live_lean_4_33_1_version_and_commit(self) -> None:
        if find_optional_lean_binary() is None:
            self.skipTest("Lean 4.33.1 binary not installed on this host (offline mode PASS)")
        live = self._get_live_lean_result()
        self.assertTrue(live["lean_4_33_1_enforced"])
        self.assertIn("4.33.1", live["lean_version_output"])

    def test_21_live_lean_24_modules_compiled_and_zero_disallowed_axioms(self) -> None:
        if find_optional_lean_binary() is None:
            self.skipTest("Lean 4.33.1 binary not installed on this host (offline mode PASS)")
        live = self._get_live_lean_result()
        self.assertEqual(live["modules_compiled_count"], 24)
        self.assertEqual(live["disallowed_axiom_violations_count"], 0)
        self.assertEqual(live["user_axiom_constants_count"], 0)
        self.assertEqual(live["opaque_constants_count"], 0)

    def test_22_live_lean_ledger_matches_sealed_receipt(self) -> None:
        if find_optional_lean_binary() is None:
            self.skipTest("Lean 4.33.1 binary not installed on this host (offline mode PASS)")
        live = self._get_live_lean_result()
        env_rec = json.loads(
            (PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_ENV_COVERAGE_RECEIPT.json").read_text("utf-8")
        )
        self.assertEqual(
            live["combined_kernel_ledger_sha256"], env_rec["combined_kernel_ledger_sha256"]
        )


if __name__ == "__main__":
    unittest.main()

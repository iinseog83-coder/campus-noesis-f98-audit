# CAMPUS-NOESIS — `Ωλ-W2` Blueprint (`#46`)
## Outer `CNB-v1` / `CNP-v2` Packet Framing & Raw `Snapshot` Refinement Proof Track

- **Stage ID**: `OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK`
- **Tribunal Authorization**: `CAMPUS_NOESIS_OMEGA_LAMBDA_W2_STATIC_SCOPED_ACCEPTED_WITH_F93_01_03_GUARDS__W2_PROOF_TRACK_CONDITIONALLY_AUTHORIZED__EXTERNAL_AUTHORITY_HELD`
- **Mandatory Scope Tag (`W2-D`)**: `SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1`

## Incremental Proof Track (`W2-A` → `W2-B` → `W2-C` → `W2-D`) & `F93-01..03` Guards

1. **`W2-A · Outer Packet Framing`**:
   - 12-byte `CNP-v2` envelope (`>4sHBBI`) and 50-byte `CNB-v1` header (`>4sH` + `>BBBBIHBB32s`) with contiguous, non-overlapping 3-section `u32be` framing (`B_Σ`, `B_cand`, `B_prf`).
   - Asymmetric `0x03` (`C1+C3`, deriving `Global` carrier canonically from `B_cnb1.candidateEdges`) vs `0x05` (`C2`, inline `GeodesicHopBundle`) bidirectional byte roundtrips (`F91-03` discipline).
2. **`W2-B · Raw Snapshot Decode`**:
   - Restricted 66-byte ASCII identifier codec, byte-vs-string lexicographic order isomorphism, 4-sort bucketed vertex universe, and `RawWireIRRecord` (`recTag` preserved in wire bytes and root preimage), with bidirectional canonical roundtrips.
3. **`W2-C · Independent Base Refinement Branches (`F92-01`, `F93-02`, `F93-03`)**:
   - Eliminates `TRUSTED_SNAPSHOT_INPUT` (`F92-01`) by reconstructing `SourceSnapshot` exclusively from decoded `B_Σ` via `projectRawToSourceSnapshot`.
   - **`0x05` Branch (`F93-02`)**: Proves `B1..B6` (`claimShortest = 1` + `posWitnesses` + `closedCuts` + `hopEntries`) directly implies untouched `#41` `checkVerifiedBase ip b_wire = true`.
   - **`0x03` Branch (`F93-03`)**: Enforces 4-Gate non-laundering separation: Gate 1 original wire `B1..B5`, Gate 2 pure Bellman-Ford synthesis `synthesizeVerifiedBase G κ`, Gate 3 independent `checkVerifiedBase`, and Gate 4 `Local` + `Global` slice composition. Neither `0x03` nor `0x05` reuses the other branch's soundness result.
4. **`W2-D · Single-Packet Composition & `F93-01` Authority Binding**:
   - Separates Level 1 relative soundness (`SourceSoundnessRelativeTo H reg B`) from Level 2 pinned `A1` soundness (`PinnedA1SourceSoundness H B` under `TrustedA1Registry reg`), keeping `hash256` external (`F91-02`) and `A2`/`A3`, `evasion_mode = 0x01`, `0x01`/`0x02`/`0x04` packets, `Ωλ-M2`/`M3`, and detached third-party live Lean execution explicitly `HELD`.

#!/usr/bin/env python3
"""Deterministic Packager for `Ωλ-W2` (`#46`)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Dict, List
import zipfile

PACKAGE_ROOT = Path(__file__).resolve().parent
WORKSPACE_ROOT = PACKAGE_ROOT.parent.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from src.independent_verify_omega_lambda_w2 import run_detached_package_verification
from src.omega_lambda_w2_harness import (
    W2D_MANDATORY_SCOPE,
    compute_zip_metrics,
    seal_payload,
    verify_seal,
)
from src.qualify_omega_lambda_w2 import run_all_qualifications_and_build_receipts

ZIP_NAME = "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_OUTER_PACKET_AND_SNAPSHOT_REFINEMENT_PACKAGE.zip"
DETERMINISTIC_ZIP_DATE_TIME = (2026, 1, 1, 0, 0, 0)

REGISTERED_REL_PATHS: List[str] = sorted([
    "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_BLUEPRINT.md",
    "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_CONTRACT.json",
    "README.md",
    "frozen_ancestors/MANIFEST_41.json",
    "frozen_ancestors/MANIFEST_43.json",
    "frozen_ancestors/MANIFEST_44.json",
    "frozen_ancestors/MANIFEST_45.json",
    "lean/OmegaLambda.lean",
    "lean/OmegaLambda/AxiomAudit.lean",
    "lean/OmegaLambda/CarrierGeodesic.lean",
    "lean/OmegaLambda/CarrierLocalGlobal.lean",
    "lean/OmegaLambda/CertRefinement.lean",
    "lean/OmegaLambda/CertRefinementExamples.lean",
    "lean/OmegaLambda/CheckerSoundness.lean",
    "lean/OmegaLambda/GraphBase.lean",
    "lean/OmegaLambda/KernelEvalExamples.lean",
    "lean/OmegaLambda/PacketRefinement.lean",
    "lean/OmegaLambda/PacketRefinementExamples.lean",
    "lean/OmegaLambda/PointedLTS.lean",
    "lean/OmegaLambda/R1AxiomAudit.lean",
    "lean/OmegaLambda/R2AxiomAudit.lean",
    "lean/OmegaLambda/SourceIRRefinement.lean",
    "lean/OmegaLambda/SourceIRRefinementExamples.lean",
    "lean/OmegaLambda/W1AxiomAudit.lean",
    "lean/OmegaLambda/W2AxiomAudit.lean",
    "lean/OmegaLambda/WireRefinement.lean",
    "lean/OmegaLambda/WireRefinementExamples.lean",
    "lean/OmegaLambdaR1.lean",
    "lean/OmegaLambdaR2.lean",
    "lean/OmegaLambdaW1.lean",
    "lean/OmegaLambdaW2.lean",
    "package_omega_lambda_w2.py",
    "receipts/OMEGA_LAMBDA_W2_ENV_COVERAGE_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_F92_01_SNAPSHOT_REFINEMENT_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_F93_GUARDS_AND_HELD_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_HERITAGE_PRESERVATION_45_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_INDEPENDENT_VERIFICATION_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_MASTER_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_PACKET_PROOF_TRACK_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_QUALIFICATION_RECEIPT.json",
    "receipts/OMEGA_LAMBDA_W2_RELEASE_INTEGRITY_RECEIPT.json",
    "src/independent_verify_omega_lambda_w2.py",
    "src/omega_lambda_w2_harness.py",
    "src/qualify_omega_lambda_w2.py",
    "tests/test_omega_lambda_w2.py",
    "third_party_audit/verify_frozen45_zero_shared_third_party.py",
])


def _write_json_lf(path: Path, obj: Dict[str, Any]) -> None:
    path.write_bytes((json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8"))


def _normalize_lf(rel_paths: List[str]) -> None:
    frozen_skip = {
        "frozen_ancestors/MANIFEST_41.json",
        "frozen_ancestors/MANIFEST_43.json",
        "frozen_ancestors/MANIFEST_44.json",
        "frozen_ancestors/MANIFEST_45.json",
        "lean/OmegaLambda.lean",
        "lean/OmegaLambda/AxiomAudit.lean",
        "lean/OmegaLambda/CarrierGeodesic.lean",
        "lean/OmegaLambda/CarrierLocalGlobal.lean",
        "lean/OmegaLambda/CertRefinement.lean",
        "lean/OmegaLambda/CertRefinementExamples.lean",
        "lean/OmegaLambda/CheckerSoundness.lean",
        "lean/OmegaLambda/GraphBase.lean",
        "lean/OmegaLambda/KernelEvalExamples.lean",
        "lean/OmegaLambda/PointedLTS.lean",
        "lean/OmegaLambda/R1AxiomAudit.lean",
        "lean/OmegaLambda/R2AxiomAudit.lean",
        "lean/OmegaLambda/SourceIRRefinement.lean",
        "lean/OmegaLambda/SourceIRRefinementExamples.lean",
        "lean/OmegaLambda/W1AxiomAudit.lean",
        "lean/OmegaLambda/WireRefinement.lean",
        "lean/OmegaLambda/WireRefinementExamples.lean",
        "lean/OmegaLambdaR1.lean",
        "lean/OmegaLambdaR2.lean",
        "lean/OmegaLambdaW1.lean",
    }
    for rel in rel_paths:
        fp = PACKAGE_ROOT / rel
        if fp.exists():
            raw = fp.read_bytes()
            if rel in frozen_skip:
                if b"\r" in raw:
                    raise RuntimeError(f"Frozen file contains CR: {rel}")
            elif b"\r" in raw:
                fp.write_bytes(raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n"))


def _write_deterministic_zip(zip_path: Path, all_paths: List[str]) -> None:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in sorted(all_paths):
            raw = (PACKAGE_ROOT / rel).read_bytes()
            if b"\r" in raw:
                raise RuntimeError(f"CR byte detected in {rel}")
            zi = zipfile.ZipInfo(filename=rel, date_time=DETERMINISTIC_ZIP_DATE_TIME)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, raw)


def build_package() -> Dict[str, Any]:
    _normalize_lf(REGISTERED_REL_PATHS)
    bundle = run_all_qualifications_and_build_receipts(PACKAGE_ROOT)

    indep_rec = run_detached_package_verification(PACKAGE_ROOT, zip_path=None)
    _write_json_lf(
        PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_INDEPENDENT_VERIFICATION_RECEIPT.json",
        indep_rec,
    )

    release_rec = seal_payload({
        "schema_version": "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_RELEASE_INTEGRITY_RECEIPT_V1",
        "stage_id": "OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "w2d_composition_scope": W2D_MANDATORY_SCOPE,
        "registered_files_count": len(REGISTERED_REL_PATHS),
        "zero_cr_enforced": True,
        "zero_shared_code_standalone_verifier_included": True,
    })
    _write_json_lf(
        PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_RELEASE_INTEGRITY_RECEIPT.json",
        release_rec,
    )

    master_rec = seal_payload({
        "schema_version": "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_MASTER_RECEIPT_V1",
        "stage_id": "OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "w2d_composition_scope": W2D_MANDATORY_SCOPE,
        "omega_lambda_w2_qualified_author_host": True,
        "omega_lambda_w2_exit_criteria": {
            "AncestorsUnmodified_45_of_45_Seals_233": True,
            "Frozen20_M1_R1_R2_W1_LeanFiles_ByteIdentical": True,
            "W2A_OuterCnp2_0x03_0x05_And_Cnb1_Bijection_LeanProved": True,
            "W2B_RawSnapshotSectionCanonicalBijection_LeanProved": True,
            "F92_01_TrustedSnapshotInput_Eliminated": True,
            "F93_01_A1RegistryAuthorityBinding_TwoLevelProved": True,
            "F93_02_0x05_B1ToB6_To_VerifiedBase_Bridge_LeanProved": True,
            "F93_03_0x03_NonLaunderingFourGateSynthesis_LeanProved": True,
            "ZeroSharedCodeStandaloneVerifiers_Included": True,
        },
        "packet_proof_receipt_payload_sha256": bundle["packet_proof_receipt"]["seal"]["payload_sha256"],
        "env_coverage_receipt_payload_sha256": bundle["env_coverage_receipt"]["seal"]["payload_sha256"],
        "f92_01_snapshot_receipt_payload_sha256": bundle["f92_01_snapshot_receipt"]["seal"]["payload_sha256"],
        "f93_guards_receipt_payload_sha256": bundle["f93_guards_receipt"]["seal"]["payload_sha256"],
        "heritage_45_receipt_payload_sha256": bundle["heritage_45_receipt"]["seal"]["payload_sha256"],
        "qualification_receipt_payload_sha256": bundle["qualification_receipt"]["seal"]["payload_sha256"],
        "non_resilience_cnp2_packet_kinds_0x01_0x02_0x04_status": "HELD",
        "evasion_mode_0x01_status": "HELD",
        "fips_180_4_sha256_internal_lean_compression_status": "HELD_EXTERNAL_CRYPTO_BOUNDARY",
        "omega_lambda_m2_m3_status": "NOT_AUTHORIZED_HELD",
        "external_authority_a2_a3_status": "HELD",
        "third_party_physical_execution_status": "THIRD_PARTY_LIVE_VERIFICATION_HELD",
    })
    _write_json_lf(PACKAGE_ROOT / "receipts" / "OMEGA_LAMBDA_W2_MASTER_RECEIPT.json", master_rec)

    file_entries: List[Dict[str, Any]] = []
    for rel in REGISTERED_REL_PATHS:
        fp = PACKAGE_ROOT / rel
        raw = fp.read_bytes()
        if b"\r" in raw:
            raise RuntimeError(f"CR byte in {rel}")
        file_entries.append({
            "path": rel,
            "size_bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        })

    manifest = seal_payload({
        "schema_version": "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_MANIFEST_V1",
        "stage_id": "OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "engine_id": "CAMPUS-NOESIS-OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "w2d_composition_scope": W2D_MANDATORY_SCOPE,
        "registered_files_count": len(file_entries),
        "files": file_entries,
    })
    _write_json_lf(PACKAGE_ROOT / "MANIFEST.json", manifest)

    zip_path = WORKSPACE_ROOT / ZIP_NAME
    _write_deterministic_zip(zip_path, REGISTERED_REL_PATHS + ["MANIFEST.json"])

    post_zip_check = run_detached_package_verification(PACKAGE_ROOT, zip_path=zip_path)
    if post_zip_check["detached_offline_verification_verdict"] != "PASS" or not verify_seal(manifest):
        raise RuntimeError("Post-ZIP detached verification failed")

    zmetrics = compute_zip_metrics(zip_path)
    return {
        "zip_name": ZIP_NAME,
        "zip_path": str(zip_path),
        "zip_metrics": zmetrics,
        "manifest_payload_sha256": manifest["seal"]["payload_sha256"],
        "master_payload_sha256": master_rec["seal"]["payload_sha256"],
        "qualification_payload_sha256": bundle["qualification_receipt"]["seal"]["payload_sha256"],
        "packet_proof_payload_sha256": bundle["packet_proof_receipt"]["seal"]["payload_sha256"],
        "env_coverage_payload_sha256": bundle["env_coverage_receipt"]["seal"]["payload_sha256"],
    }


if __name__ == "__main__":
    summary = build_package()
    print(json.dumps(summary, indent=2, sort_keys=True))

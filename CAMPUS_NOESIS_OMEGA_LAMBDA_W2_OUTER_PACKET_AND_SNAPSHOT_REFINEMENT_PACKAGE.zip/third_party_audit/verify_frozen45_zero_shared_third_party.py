#!/usr/bin/env python3
"""Zero-Shared-Code Standalone Third-Party Verifier for Frozen #45 (`Ωλ-W1`).

Packaged inside `#46` (`Ωλ-W2`) under `third_party_audit/` so auditors can directly
inspect and execute a zero-shared-code verifier against frozen `#45`.
Imports ONLY Python standard library modules (`0` imports from `#45` or `#46` `src/`).
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

PINNED_ZIP_45_SIZE = 174_199
PINNED_ZIP_45_ENTRIES = 42
PINNED_ZIP_45_CRC32_XOR = "b7afe44a"
PINNED_ZIP_45_SHA256 = "b6649a21e82ca809d7629246f806f93dcd863150c3ae5b860a124ed1421224fc"
PINNED_MANIFEST_45_PAYLOAD_SHA256 = "9cc6607aba86e0c335ea442a7b3cff2f63d03efe256b1a132d683e97b3a763d6"
PINNED_MASTER_45_PAYLOAD_SHA256 = "755d9333a4fa784489a268b5e5d062cedb1a354d82d338d9709629df37ce6c83"
PINNED_COMBINED_DECL_SHA256 = "0a1c2e05b489ef14687bb135bccefc7eec5f2335b933c55fe87db2f9da8d5047"
PINNED_W1_NEW_DECL_SHA256 = "3a1276841f6ea7f7dd617cbe52b97f9d91a08ea9978604aae9c922bc740ae579"
PINNED_COMBINED_KERNEL_LEDGER_SHA256 = "f6dce9e5c01829c45ce36657d3b0193b311ba572ebd130bd79427f8e729ebf0a"

PINNED_LEAN_VERSION_SUBSTR = "4.33.1"
PINNED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"

PINNED_FROZEN_16_LEAN_SHA256 = {
    "lean/OmegaLambda/PointedLTS.lean": "9db60c65b9011eda413e6b2532dc1f2ce9c52fb858494b868f4d47ced2ca2fa0",
    "lean/OmegaLambda/GraphBase.lean": "6a3ae61980e6c055b976cd3336b74d0e7fc3a23b21b808eff6be751f83f97682",
    "lean/OmegaLambda/CarrierLocalGlobal.lean": "dc9e485a9040f0181e1b69030aa4bad28c02653e3d4b4b8f9149a88ed0f8b0db",
    "lean/OmegaLambda/CarrierGeodesic.lean": "cfbba3666c55359d3d6ce0a273a979a12a6bbd3edd3285b3517071d4661cb0c3",
    "lean/OmegaLambda/CheckerSoundness.lean": "37bd33d40f38cac38c4154841549ee75c8e2dcba712394390a66dc95f5345d5b",
    "lean/OmegaLambda/KernelEvalExamples.lean": "66c7a10b28c58b50cd8a14d836aeea5721b9c1a2c3db02b1f7cccfd5987afedb",
    "lean/OmegaLambda/AxiomAudit.lean": "571e36d97bb7ad146031568bce5681e4ed20cd7bf83457108a5b596e9ccc6d3d",
    "lean/OmegaLambda.lean": "49e5182121792e921f85d1dd751efd9e214bed557ea16473f65ce407e1c143cd",
    "lean/OmegaLambda/SourceIRRefinement.lean": "0ff97275bcf9fcfde16490ce40ce98b88f3e0b4a8afc0dfd812cc5f382bfc827",
    "lean/OmegaLambda/SourceIRRefinementExamples.lean": "cd6f2d776a577d128e788a40a67ff1435b73d4ef5743664f2070eca591ce5f6a",
    "lean/OmegaLambda/R1AxiomAudit.lean": "5f97dbd7d627897278000512a302dfb2974220c75db425dce7140dcd059a57fa",
    "lean/OmegaLambdaR1.lean": "6bb6fb95406a7b11a8cbc9c57e9d12b506a8a113ab1dd7b6e85ef1e11ea94dcb",
    "lean/OmegaLambda/CertRefinement.lean": "64c829c969584a83e6e89342e76dee95f7a0f28e3243bf35ef74f2977d855748",
    "lean/OmegaLambda/CertRefinementExamples.lean": "b3a80eb22c6ff3204a172bf3f227462010bf541fb113aadeb170411becf42ab9",
    "lean/OmegaLambda/R2AxiomAudit.lean": "b17c0f4729f39b654692aa45b10d1a6055b3595f296d707412cd40e9b249ca12",
    "lean/OmegaLambdaR2.lean": "488d919bc98bf81b156eb3f0f924b61cfce5c5ee180b88485c67da86c180770d",
}

ORDERED_20_MODULES = (
    ("OmegaLambda.PointedLTS", "OmegaLambda/PointedLTS.lean"),
    ("OmegaLambda.GraphBase", "OmegaLambda/GraphBase.lean"),
    ("OmegaLambda.CarrierLocalGlobal", "OmegaLambda/CarrierLocalGlobal.lean"),
    ("OmegaLambda.CarrierGeodesic", "OmegaLambda/CarrierGeodesic.lean"),
    ("OmegaLambda.CheckerSoundness", "OmegaLambda/CheckerSoundness.lean"),
    ("OmegaLambda.KernelEvalExamples", "OmegaLambda/KernelEvalExamples.lean"),
    ("OmegaLambda.AxiomAudit", "OmegaLambda/AxiomAudit.lean"),
    ("OmegaLambda", "OmegaLambda.lean"),
    ("OmegaLambda.SourceIRRefinement", "OmegaLambda/SourceIRRefinement.lean"),
    ("OmegaLambda.SourceIRRefinementExamples", "OmegaLambda/SourceIRRefinementExamples.lean"),
    ("OmegaLambda.R1AxiomAudit", "OmegaLambda/R1AxiomAudit.lean"),
    ("OmegaLambdaR1", "OmegaLambdaR1.lean"),
    ("OmegaLambda.CertRefinement", "OmegaLambda/CertRefinement.lean"),
    ("OmegaLambda.CertRefinementExamples", "OmegaLambda/CertRefinementExamples.lean"),
    ("OmegaLambda.R2AxiomAudit", "OmegaLambda/R2AxiomAudit.lean"),
    ("OmegaLambdaR2", "OmegaLambdaR2.lean"),
    ("OmegaLambda.WireRefinement", "OmegaLambda/WireRefinement.lean"),
    ("OmegaLambda.WireRefinementExamples", "OmegaLambda/WireRefinementExamples.lean"),
    ("OmegaLambda.W1AxiomAudit", "OmegaLambda/W1AxiomAudit.lean"),
    ("OmegaLambdaW1", "OmegaLambdaW1.lean"),
)

FORBIDDEN_REGEXES = (
    re.compile(r"\bsorry\b"),
    re.compile(r"\badmit\b"),
    re.compile(r"(?m)^\s*axiom\s+"),
    re.compile(r"(?m)^\s*opaque\s+"),
    re.compile(r"(?m)^\s*constant\s+"),
    re.compile(r"\bnative_decide\b"),
    re.compile(r"\bofReduceBool\b"),
    re.compile(r"\btrustCompiler\b"),
    re.compile(r"\bimplemented_by\b"),
    re.compile(r"@\[[^\]]*\bextern\b"),
    re.compile(r"\bunsafe\b"),
    re.compile(r"(?m)^\s*partial\s+def\b"),
)

DECL_HEAD_RE = re.compile(r"^(theorem|def)\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
NS_OPEN_RE = re.compile(r"^namespace\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
NS_END_RE = re.compile(r"^end\s+([A-Za-z_][A-Za-z0-9_'?.]*)")

ALLOWED_AXIOMS = {"propext", "Quot.sound", "Classical.choice"}


def canonical_payload_sha256(obj: dict) -> str:
    body = {k: v for k, v in obj.items() if k != "seal"}
    raw = json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def strip_lean_comments_and_strings(text: str) -> str:
    out = []
    i, n, depth, in_str = 0, len(text), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if text.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if text.startswith("--", i):
                while i < n and text[i] != "\n":
                    i += 1
                continue
            if text[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(text[i])
            i += 1
        elif in_str:
            if text[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if text[i] == '"':
                in_str = False
            i += 1
        else:
            if text.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if text.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if text[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def audit_declarations(lean_dir: Path, modules: tuple[tuple[str, str], ...]) -> tuple[int, int, str]:
    decls: list[tuple[str, str]] = []
    for _, rel_path in modules:
        raw = (lean_dir / rel_path).read_text(encoding="utf-8")
        cleaned = strip_lean_comments_and_strings(raw)
        for rx in FORBIDDEN_REGEXES:
            if rx.search(cleaned):
                raise RuntimeError(f"Forbidden token {rx.pattern} in {rel_path}")
        ns_stack: list[str] = []
        for line in cleaned.splitlines():
            sline = line.strip()
            m_open = NS_OPEN_RE.match(sline)
            if m_open:
                ns_stack.append(m_open.group(1))
                continue
            m_end = NS_END_RE.match(sline)
            if m_end and ns_stack:
                ns_stack.pop()
                continue
            if line and not line[0].isspace():
                m_decl = DECL_HEAD_RE.match(line)
                if m_decl:
                    kind, short = m_decl.group(1), m_decl.group(2)
                    prefix = ".".join(ns_stack)
                    fqn = f"{prefix}.{short}" if prefix else short
                    decls.append((kind, fqn))
    thm_c = sum(1 for k, _ in decls if k == "theorem")
    def_c = sum(1 for k, _ in decls if k == "def")
    canon_lines = "\n".join(sorted(f"{k}:{nm}" for k, nm in decls)) + "\n"
    d_sha = hashlib.sha256(canon_lines.encode("utf-8")).hexdigest()
    return thm_c, def_c, d_sha


def find_lean() -> Path | None:
    env_bin = os.environ.get("LEAN_BIN")
    if env_bin and Path(env_bin).is_file():
        return Path(env_bin)
    which_p = shutil.which("lean")
    if which_p:
        return Path(which_p)
    cand = Path.home() / ".elan" / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    return cand if cand.exists() else None


LEAN_INSPECTOR_SRC = r"""import OmegaLambdaW1
import Lean

open Lean

def cinfoVariant : ConstantInfo → String
  | .axiomInfo _ => "axiomInfo"
  | .defnInfo _ => "defnInfo"
  | .thmInfo _ => "thmInfo"
  | .opaqueInfo _ => "opaqueInfo"
  | .quotInfo _ => "quotInfo"
  | .inductInfo _ => "inductInfo"
  | .ctorInfo _ => "ctorInfo"
  | .recInfo _ => "recInfo"

def isProjectPrefix : Name → Bool
  | .anonymous => false
  | .str .anonymous s =>
      s == "OmegaLambda" || s == "OmegaLambdaR1" || s == "OmegaLambdaR2" || s == "OmegaLambdaW1"
  | .str p _ => isProjectPrefix p
  | .num p _ => isProjectPrefix p

def targetMods : Array Name := #[
  `OmegaLambda.PointedLTS, `OmegaLambda.GraphBase, `OmegaLambda.CarrierLocalGlobal,
  `OmegaLambda.CarrierGeodesic, `OmegaLambda.CheckerSoundness, `OmegaLambda.KernelEvalExamples,
  `OmegaLambda.AxiomAudit, `OmegaLambda,
  `OmegaLambda.SourceIRRefinement, `OmegaLambda.SourceIRRefinementExamples,
  `OmegaLambda.R1AxiomAudit, `OmegaLambdaR1,
  `OmegaLambda.CertRefinement, `OmegaLambda.CertRefinementExamples,
  `OmegaLambda.R2AxiomAudit, `OmegaLambdaR2,
  `OmegaLambda.WireRefinement, `OmegaLambda.WireRefinementExamples,
  `OmegaLambda.W1AxiomAudit, `OmegaLambdaW1
]

#eval show MetaM Unit from do
  let env ← getEnv
  let mut idxPairs : Array (Nat × String) := #[]
  for m in targetMods do
    match env.getModuleIdx? m with
    | some idx => idxPairs := idxPairs.push (idx.toNat, m.toString)
    | none => throwError s!"FATAL: Missing module {m}"
  let allowed : List Name := [`propext, `Quot.sound, `Classical.choice]
  for (name, cinfo) in env.constants.map₁.toList ++ env.constants.map₂.toList do
    let inProj := isProjectPrefix name
    match env.getModuleIdxFor? name with
    | some midx =>
      match idxPairs.find? (fun (i, _) => i == midx.toNat) with
      | some (_, modStr) =>
        let kindStr := cinfoVariant cinfo
        if kindStr == "axiomInfo" || kindStr == "opaqueInfo" then
          throwError s!"FATAL: Forbidden {kindStr} constant {name} in {modStr}"
        let axs ← collectAxioms name
        for ax in axs do
          let s := ax.toString
          if !(allowed.contains ax) || (s.splitOn "sorry").length > 1 || (s.splitOn "._native.").length > 1 then
            throwError s!"FATAL: Disallowed axiom {ax} in {name}"
        let axCsv := String.intercalate "," (axs.toList.map Name.toString)
        IO.println s!"CONST_ROW|{modStr}|{kindStr}|{name}|{axCsv}"
      | none =>
        if inProj then
          throwError s!"FATAL: Orphan project constant outside target modules: {name}"
    | none =>
      if inProj then
        throwError s!"FATAL: Unattributed local constant in project namespace: {name}"
"""


def verify_frozen45(zip_path: Path, require_live_lean: bool = True) -> dict:
    raw = zip_path.read_bytes()
    if len(raw) != PINNED_ZIP_45_SIZE:
        raise RuntimeError(f"ZIP size mismatch: {len(raw)} != {PINNED_ZIP_45_SIZE}")
    z_sha = hashlib.sha256(raw).hexdigest()
    if z_sha != PINNED_ZIP_45_SHA256:
        raise RuntimeError(f"ZIP SHA-256 mismatch: {z_sha}")

    with zipfile.ZipFile(zip_path, "r") as zf:
        if zf.testzip() is not None:
            raise RuntimeError("Corrupt ZIP member")
        infos = zf.infolist()
        if len(infos) != PINNED_ZIP_45_ENTRIES:
            raise RuntimeError(f"Entry count mismatch: {len(infos)}")
        crc_xor = 0
        for inf in infos:
            crc_xor ^= inf.CRC & 0xFFFFFFFF
        crc_hex = f"{crc_xor:08x}"
        if crc_hex != PINNED_ZIP_45_CRC32_XOR:
            raise RuntimeError(f"CRC32 XOR mismatch: {crc_hex} != {PINNED_ZIP_45_CRC32_XOR}")

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            zf.extractall(root)

            manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
            if canonical_payload_sha256(manifest) != manifest["seal"]["payload_sha256"]:
                raise RuntimeError("MANIFEST seal invalid")
            if manifest["seal"]["payload_sha256"] != PINNED_MANIFEST_45_PAYLOAD_SHA256:
                raise RuntimeError("MANIFEST payload SHA-256 mismatch")
            if len(manifest["files"]) != 41:
                raise RuntimeError("Expected 41 registered files")

            for entry in manifest["files"]:
                fb = (root / entry["path"]).read_bytes()
                if b"\r" in fb:
                    raise RuntimeError(f"CR byte in {entry['path']}")
                if len(fb) != entry["size_bytes"] or hashlib.sha256(fb).hexdigest() != entry["sha256"]:
                    raise RuntimeError(f"File mismatch: {entry['path']}")

            for rpath in sorted((root / "receipts").glob("*.json")):
                robj = json.loads(rpath.read_text(encoding="utf-8"))
                if canonical_payload_sha256(robj) != robj["seal"]["payload_sha256"]:
                    raise RuntimeError(f"Receipt seal invalid: {rpath.name}")
            master = json.loads((root / "receipts" / "OMEGA_LAMBDA_W1_MASTER_RECEIPT.json").read_text(encoding="utf-8"))
            if master["seal"]["payload_sha256"] != PINNED_MASTER_45_PAYLOAD_SHA256:
                raise RuntimeError("Master receipt payload SHA-256 mismatch")

            for rel_p, exp_h in PINNED_FROZEN_16_LEAN_SHA256.items():
                act_h = hashlib.sha256((root / rel_p).read_bytes()).hexdigest()
                if act_h != exp_h:
                    raise RuntimeError(f"Frozen ancestor modified: {rel_p}")

            c_thm, c_def, c_sha = audit_declarations(root / "lean", ORDERED_20_MODULES)
            w1_thm, w1_def, w1_sha = audit_declarations(root / "lean", ORDERED_20_MODULES[16:])
            if (c_thm, c_def, c_sha) != (359, 334, PINNED_COMBINED_DECL_SHA256):
                raise RuntimeError(f"Combined decl mismatch: {(c_thm, c_def, c_sha)}")
            if (w1_thm, w1_def, w1_sha) != (103, 124, PINNED_W1_NEW_DECL_SHA256):
                raise RuntimeError(f"W1 decl mismatch: {(w1_thm, w1_def, w1_sha)}")

            lean_bin = find_lean()
            if lean_bin is None:
                if require_live_lean:
                    raise RuntimeError("Lean 4.33.1 binary required but not found")
                return {"verdict": "OFFLINE_ONLY_PASS", "live_lean_executed": False}

            ver = subprocess.run([str(lean_bin), "--version"], capture_output=True, text=True, check=True).stdout.strip()
            if PINNED_LEAN_VERSION_SUBSTR not in ver or PINNED_LEAN_COMMIT not in ver:
                raise RuntimeError(f"Pinned Lean 4.33.1 commit mismatch: {ver}")

            olean_root = root / "_clean_olean"
            (olean_root / "OmegaLambda").mkdir(parents=True, exist_ok=True)
            env = dict(os.environ)
            env["LEAN_PATH"] = str(olean_root)
            for mod_name, rel_p in ORDERED_20_MODULES:
                olean_out = olean_root / Path(rel_p).with_suffix(".olean")
                proc = subprocess.run(
                    [str(lean_bin), "-DwarningAsError=true", "-o", str(olean_out), f"lean/{rel_p}"],
                    cwd=str(root),
                    env=env,
                    capture_output=True,
                    text=True,
                )
                if proc.returncode != 0 or proc.stderr.strip():
                    raise RuntimeError(f"Lean compile failed on {mod_name}:\n{proc.stdout}\n{proc.stderr}")

            insp_p = root / "_ZeroSharedInspector45.lean"
            insp_p.write_text(LEAN_INSPECTOR_SRC, encoding="utf-8", newline="\n")
            iproc = subprocess.run(
                [str(lean_bin), "_ZeroSharedInspector45.lean"],
                cwd=str(root),
                env=env,
                capture_output=True,
                text=True,
            )
            if iproc.returncode != 0 or iproc.stderr.strip():
                raise RuntimeError(f"Inspector failed:\n{iproc.stdout}\n{iproc.stderr}")

            all_rows: list[str] = []
            for line in iproc.stdout.splitlines():
                s = line.strip()
                if not s:
                    continue
                if not s.startswith("CONST_ROW|"):
                    raise RuntimeError(f"Unexpected inspector line: {s}")
                _, mod_n, kind, cname, ax_csv = s.split("|", 4)
                axs = sorted(a for a in ax_csv.split(",") if a)
                if not set(axs).issubset(ALLOWED_AXIOMS):
                    raise RuntimeError(f"Disallowed axioms on {cname}: {axs}")
                all_rows.append(f"{mod_n}|{kind}|{cname}|{','.join(axs)}")

            if len(all_rows) != 2803:
                raise RuntimeError(f"Kernel constant count mismatch: {len(all_rows)} != 2803")

            ledger_sha = hashlib.sha256(
                ("\n".join(sorted(all_rows)) + "\n").encode("utf-8")
            ).hexdigest()
            if ledger_sha != PINNED_COMBINED_KERNEL_LEDGER_SHA256:
                raise RuntimeError(f"Kernel ledger SHA-256 mismatch: {ledger_sha}")

            return {
                "verdict": "FULL_LIVE_LEAN_ZERO_SHARED_PASS",
                "lean_version": ver,
                "zip_sha256": z_sha,
                "zip_crc32_xor": crc_hex,
                "combined_declarations": 693,
                "kernel_constants_audited": 2803,
                "combined_kernel_ledger_sha256": ledger_sha,
            }


if __name__ == "__main__":
    zp = Path(sys.argv[1])
    res = verify_frozen45(zp, require_live_lean=("--allow-offline" not in sys.argv))
    print(json.dumps(res, indent=2, sort_keys=True))

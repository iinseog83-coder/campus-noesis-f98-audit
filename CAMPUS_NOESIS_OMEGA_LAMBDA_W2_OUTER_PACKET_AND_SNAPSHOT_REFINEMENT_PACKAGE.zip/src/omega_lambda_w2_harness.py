#!/usr/bin/env python3
"""Qualification & Live Lean 4.33.1 Harness for `Ωλ-W2` (`#46`).

Scope (`93rd Ruling §5`):
  `SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1`

Note (`90th–93rd Rulings`):
  `src/independent_verify_omega_lambda_w2.py` and
  `third_party_audit/verify_frozen45_zero_shared_third_party.py` do NOT import
  this module (`0` shared code).
"""

from __future__ import annotations

from collections import deque
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import re
import shutil
import struct
import subprocess
import sys
import tempfile
from typing import Any, Dict, List, Optional, Sequence, Tuple
import zipfile

EXPECTED_LEAN_VERSION_SUBSTR = "4.33.1"
EXPECTED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"
ALLOWED_FOUNDATION_AXIOMS = ("propext", "Quot.sound", "Classical.choice")

W2D_MANDATORY_SCOPE = (
    "SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1"
)

EXPECTED_M1_KERNEL_CONSTANTS = 1316
EXPECTED_R1_NEW_KERNEL_CONSTANTS = 457
EXPECTED_R2_NEW_KERNEL_CONSTANTS = 441
EXPECTED_W1_NEW_KERNEL_CONSTANTS = 589

EXPECTED_M1_DECL_COUNTS = {"theorem": 127, "def": 109, "total": 236}
EXPECTED_M1_DECL_SHA256 = "599328c9e37cf536986824fd71b532c6ee0f66af78ee47eacf13702be02736bb"

EXPECTED_R1_NEW_DECL_COUNTS = {"theorem": 67, "def": 50, "total": 117}
EXPECTED_R1_NEW_DECL_SHA256 = "6642861c3a61417dd1b81588829e622c058878f38dd0dbffc371b032250cf273"

EXPECTED_R2_NEW_DECL_COUNTS = {"theorem": 62, "def": 51, "total": 113}
EXPECTED_R2_NEW_DECL_SHA256 = "6b73f68d43c35388870e9b6b27867bc7216471d7e3a112aeb12a72dad47078f9"

EXPECTED_W1_NEW_DECL_COUNTS = {"theorem": 103, "def": 124, "total": 227}
EXPECTED_W1_NEW_DECL_SHA256 = "3a1276841f6ea7f7dd617cbe52b97f9d91a08ea9978604aae9c922bc740ae579"

M1_MODULES: Tuple[Tuple[str, str, str], ...] = (
    ("OmegaLambda.PointedLTS", "OmegaLambda/PointedLTS.lean", "OmegaLambda/PointedLTS.olean"),
    ("OmegaLambda.GraphBase", "OmegaLambda/GraphBase.lean", "OmegaLambda/GraphBase.olean"),
    ("OmegaLambda.CarrierLocalGlobal", "OmegaLambda/CarrierLocalGlobal.lean", "OmegaLambda/CarrierLocalGlobal.olean"),
    ("OmegaLambda.CarrierGeodesic", "OmegaLambda/CarrierGeodesic.lean", "OmegaLambda/CarrierGeodesic.olean"),
    ("OmegaLambda.CheckerSoundness", "OmegaLambda/CheckerSoundness.lean", "OmegaLambda/CheckerSoundness.olean"),
    ("OmegaLambda.KernelEvalExamples", "OmegaLambda/KernelEvalExamples.lean", "OmegaLambda/KernelEvalExamples.olean"),
    ("OmegaLambda.AxiomAudit", "OmegaLambda/AxiomAudit.lean", "OmegaLambda/AxiomAudit.olean"),
    ("OmegaLambda", "OmegaLambda.lean", "OmegaLambda.olean"),
)

R1_NEW_MODULES: Tuple[Tuple[str, str, str], ...] = (
    ("OmegaLambda.SourceIRRefinement", "OmegaLambda/SourceIRRefinement.lean", "OmegaLambda/SourceIRRefinement.olean"),
    (
        "OmegaLambda.SourceIRRefinementExamples",
        "OmegaLambda/SourceIRRefinementExamples.lean",
        "OmegaLambda/SourceIRRefinementExamples.olean",
    ),
    ("OmegaLambda.R1AxiomAudit", "OmegaLambda/R1AxiomAudit.lean", "OmegaLambda/R1AxiomAudit.olean"),
    ("OmegaLambdaR1", "OmegaLambdaR1.lean", "OmegaLambdaR1.olean"),
)

R2_NEW_MODULES: Tuple[Tuple[str, str, str], ...] = (
    ("OmegaLambda.CertRefinement", "OmegaLambda/CertRefinement.lean", "OmegaLambda/CertRefinement.olean"),
    (
        "OmegaLambda.CertRefinementExamples",
        "OmegaLambda/CertRefinementExamples.lean",
        "OmegaLambda/CertRefinementExamples.olean",
    ),
    ("OmegaLambda.R2AxiomAudit", "OmegaLambda/R2AxiomAudit.lean", "OmegaLambda/R2AxiomAudit.olean"),
    ("OmegaLambdaR2", "OmegaLambdaR2.lean", "OmegaLambdaR2.olean"),
)

W1_NEW_MODULES: Tuple[Tuple[str, str, str], ...] = (
    ("OmegaLambda.WireRefinement", "OmegaLambda/WireRefinement.lean", "OmegaLambda/WireRefinement.olean"),
    (
        "OmegaLambda.WireRefinementExamples",
        "OmegaLambda/WireRefinementExamples.lean",
        "OmegaLambda/WireRefinementExamples.olean",
    ),
    ("OmegaLambda.W1AxiomAudit", "OmegaLambda/W1AxiomAudit.lean", "OmegaLambda/W1AxiomAudit.olean"),
    ("OmegaLambdaW1", "OmegaLambdaW1.lean", "OmegaLambdaW1.olean"),
)

W2_NEW_MODULES: Tuple[Tuple[str, str, str], ...] = (
    ("OmegaLambda.PacketRefinement", "OmegaLambda/PacketRefinement.lean", "OmegaLambda/PacketRefinement.olean"),
    (
        "OmegaLambda.PacketRefinementExamples",
        "OmegaLambda/PacketRefinementExamples.lean",
        "OmegaLambda/PacketRefinementExamples.olean",
    ),
    ("OmegaLambda.W2AxiomAudit", "OmegaLambda/W2AxiomAudit.lean", "OmegaLambda/W2AxiomAudit.olean"),
    ("OmegaLambdaW2", "OmegaLambdaW2.lean", "OmegaLambdaW2.olean"),
)

FROZEN_45_MODULES: Tuple[Tuple[str, str, str], ...] = (
    M1_MODULES + R1_NEW_MODULES + R2_NEW_MODULES + W1_NEW_MODULES
)
ALL_W2_MODULES: Tuple[Tuple[str, str, str], ...] = FROZEN_45_MODULES + W2_NEW_MODULES

PINNED_OMEGA_KAPPA_A1_REGISTRY_15: Tuple[Dict[str, Any], ...] = (
    {
        "snapshotId": "SNAP-KAPPA-F78-NONPRES-V1-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "eabf4d6fdc3108a23b75b82016cdd7b888a07f849cd440f622c518e035aa09fc",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-KAPPA-F78-NONPRES-V2-A1",
        "pinnedGen": 2,
        "pinnedRootHex": "5c725ca262b23e67a74e716bc6bf4ba796713c2e13bfaf4ff7c3239c15eab18f",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-KAPPA-F78-SIGMA1-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "d98c8af02b46cf8d3e1f953308320b7b95341e95337f26b5cbd80e2c513c5eda",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-KAPPA-F78-SIGMA2-PROMOTE-A1",
        "pinnedGen": 2,
        "pinnedRootHex": "6304003f79db330ee67841d22cde03346049db826618a0e0f5e876fb29fcab40",
        "pinnedConstIds": ("IR-00-CONST-K",),
    },
    {
        "snapshotId": "SNAP-PHI-ABC-V1-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "dace9001d106fbe91d011fe24eefd80ba5a2d413223c0c31d2ecfec2279e74df",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-ABC-V2-A1",
        "pinnedGen": 2,
        "pinnedRootHex": "831a99beff076fde0739591566c52716f702d23a3cabc3039973f76e453c6d53",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-BUDGET-14-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "556b6c3427f058b9b99988b69b496ede00a38a5c6a0be99c46421ff6171f1b5f",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-EPLUS-SELFLOOP-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-K3-EXACT3-SERIES-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "fcfc41e39d7e424241f21ce3bf7198e76842c0abe6efd31e7b28e47d1edb968e",
        "pinnedConstIds": ("IR-CONST-S",),
    },
    {
        "snapshotId": "SNAP-PHI-K3-PARALLEL-MIXED-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "9fb25ac0777f10a8d1cd0dc0bdd7a4fc70ecfa549d8550c92c872ea0d4d6d85b",
        "pinnedConstIds": ("IR-CONST-K1", "IR-CONST-K2", "IR-CONST-K3", "IR-CONST-M1", "IR-CONST-M2"),
    },
    {
        "snapshotId": "SNAP-PHI-K3-SERIES-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "a1e355aae21f67e9f9ab43b0d608c4f43cb591f57b297d1c1fe9a513bb920fe0",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-PRIMARY-V2-A1",
        "pinnedGen": 2,
        "pinnedRootHex": "88c2360342bcaa4542e1e2eb7fecab9b17953aea81a76d79f1ed21898442fa7b",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-PHI-RESILIENCE-DIAMOND-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "1dfda8adb25f331a29d8105c6c9fb54637c6831a33937c1b10c6b4fedc25f1a7",
        "pinnedConstIds": ("IR-CONST-00",),
    },
    {
        "snapshotId": "SNAP-R2-CYCLIC-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "589dc2d810175c6550a944c8ce28f8e6dc2e98bc998d8e8736f4edf7fbc75891",
        "pinnedConstIds": (),
    },
    {
        "snapshotId": "SNAP-R2-PRIMARY-DAG-A1",
        "pinnedGen": 1,
        "pinnedRootHex": "345bc1f820bcd1ed50ab18d41eacd243bb2864a4e2862e7ad5361400fdd1554f",
        "pinnedConstIds": (),
    },
)

EXPECTED_SORT_PAIR_BY_REL_TAG: Dict[int, Tuple[int, int]] = {
    1: (0, 0),
    2: (0, 1),
    3: (0, 2),
    4: (0, 3),
    5: (1, 1),
    6: (1, 0),
    7: (1, 2),
    8: (1, 3),
    9: (2, 0),
    10: (2, 1),
    11: (3, 0),
    12: (3, 1),
}

FORBIDDEN_LEAN_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("sorry", re.compile(r"\bsorry\b")),
    ("admit", re.compile(r"\badmit\b")),
    ("axiom_decl", re.compile(r"(?m)^\s*axiom\s+")),
    ("opaque_decl", re.compile(r"(?m)^\s*opaque\s+")),
    ("constant_decl", re.compile(r"(?m)^\s*constant\s+")),
    ("native_decide", re.compile(r"\bnative_decide\b")),
    ("ofReduceBool", re.compile(r"\bofReduceBool\b")),
    ("trustCompiler", re.compile(r"\btrustCompiler\b")),
    ("unsafe_kw", re.compile(r"\bunsafe\b")),
    ("partial_kw", re.compile(r"(?m)^\s*partial\s+def\b")),
    ("implemented_by", re.compile(r"\bimplemented_by\b")),
    ("extern_attr", re.compile(r"@\[[^\]]*\bextern\b")),
)

NO_AXIOMS_RE = re.compile(r"^'([^']+)' does not depend on any axioms$")
DEPENDS_AXIOMS_RE = re.compile(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$")
DECL_HEAD_RE = re.compile(r"^(theorem|def)\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
NAMESPACE_RE = re.compile(r"^namespace\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
END_NS_RE = re.compile(r"^end\s+([A-Za-z_][A-Za-z0-9_'?.]*)")

SNAPSHOT_DOMAIN_PREFIX = b"CAMPUS_NOESIS_CNB1_SNAPSHOT_V1\x00"
CARRIER_DOMAIN_PREFIX = b"CAMPUS_NOESIS_CNP2_CARRIER_V1\x00"
NONE_VID_SENTINEL = 0xFFFF
PINNED_MASK_0XFF33 = 0xFF33
MAX_PACKET_BYTES = 2097152
MAX_VERTICES = 4096
MAX_IR_RECORDS = 16384
MAX_ASCII_ID_LEN = 128
MAX_REFS_PER_RECORD = 512
MAX_GEN_OR_RANK = 999999999
ALLOWED_ASCII_BYTES = frozenset(
    list(range(0x30, 0x3A))
    + list(range(0x41, 0x5B))
    + list(range(0x61, 0x7B))
    + [0x2D, 0x5F, 0x2E, 0x3A]
)


def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def seal_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    body = {k: v for k, v in payload.items() if k != "seal"}
    out = dict(body)
    out["seal"] = {
        "algorithm": "SHA-256",
        "canonicalization": "CAMPUS_CANONICAL_JSON_UTF8_SORTED_KEYS_V1",
        "payload_sha256": hashlib.sha256(canonical_json_bytes(body)).hexdigest(),
    }
    return out


def verify_seal(obj: Dict[str, Any]) -> bool:
    seal = obj.get("seal")
    if not isinstance(seal, dict):
        return False
    body = {k: v for k, v in obj.items() if k != "seal"}
    expected = hashlib.sha256(canonical_json_bytes(body)).hexdigest()
    return seal.get("payload_sha256") == expected


def compute_zip_metrics(zip_path: Path) -> Dict[str, Any]:
    raw = zip_path.read_bytes()
    sha256_hex = hashlib.sha256(raw).hexdigest()
    crc_xor = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        infos = zf.infolist()
        for info in infos:
            crc_xor ^= int(info.CRC) & 0xFFFFFFFF
    return {
        "size_bytes": len(raw),
        "sha256": sha256_hex,
        "entry_count": len(infos),
        "crc32_xor_hex": f"{crc_xor:08x}",
    }


def find_optional_lean_binary() -> Optional[Path]:
    env_bin = os.environ.get("LEAN_BIN")
    if env_bin is not None:
        if not env_bin.strip():
            return None
        p = Path(env_bin)
        if p.is_file():
            return p
    which_bin = shutil.which("lean")
    if which_bin:
        return Path(which_bin)
    exe_name = "lean.exe" if os.name == "nt" else "lean"
    for cand in (
        Path.home() / ".elan" / "bin" / exe_name,
        Path("/usr/local/bin/lean"),
        Path("/usr/bin/lean"),
    ):
        if cand.is_file():
            return cand
    return None


def strip_lean_comments_and_strings(text: str) -> str:
    out: List[str] = []
    i, n, depth, in_str = 0, len(text), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if text.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if text.startswith("--", i):
                while i < n and text[i] != "\n":
                    i += 1
                continue
            if text[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(text[i])
            i += 1
        elif in_str:
            if text[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if text[i] == '"':
                in_str = False
            i += 1
        else:
            if text.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if text.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if text[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def extract_declarations_and_static_audit(
    lean_dir: Path,
    modules: Sequence[Tuple[str, str, str]],
) -> Dict[str, Any]:
    decls: List[Tuple[str, str, str]] = []
    violations: List[Dict[str, str]] = []
    per_module_counts: Dict[str, Dict[str, int]] = {}

    for mod_name, rel_path, _ in modules:
        raw = (lean_dir / rel_path).read_bytes()
        text = raw.decode("utf-8")
        stripped = strip_lean_comments_and_strings(text)
        for label, pat in FORBIDDEN_LEAN_PATTERNS:
            m = pat.search(stripped)
            if m:
                violations.append({"module": rel_path, "rule": label, "match": m.group(0)})

        ns_stack: List[str] = []
        mod_thm = 0
        mod_def = 0
        for line in stripped.splitlines():
            sline = line.strip()
            m_ns = NAMESPACE_RE.match(sline)
            if m_ns:
                ns_stack.append(m_ns.group(1))
                continue
            m_end = END_NS_RE.match(sline)
            if m_end and ns_stack:
                ns_stack.pop()
                continue
            if line and not line[0].isspace():
                m_decl = DECL_HEAD_RE.match(line)
                if m_decl:
                    kind, short = m_decl.group(1), m_decl.group(2)
                    prefix = ".".join(ns_stack)
                    full = f"{prefix}.{short}" if prefix else short
                    decls.append((mod_name, kind, full))
                    if kind == "theorem":
                        mod_thm += 1
                    else:
                        mod_def += 1
        per_module_counts[mod_name] = {
            "theorem": mod_thm,
            "def": mod_def,
            "total": mod_thm + mod_def,
        }

    n_thm = sum(1 for _, k, _ in decls if k == "theorem")
    n_def = sum(1 for _, k, _ in decls if k == "def")
    canon_lines = "\n".join(sorted(f"{k}:{nm}" for _, k, nm in decls)) + "\n"
    decl_sha256 = hashlib.sha256(canon_lines.encode("utf-8")).hexdigest()

    return {
        "theorem_count": n_thm,
        "def_count": n_def,
        "total_count": len(decls),
        "unique_name_count": len({nm for _, _, nm in decls}),
        "decl_table_sha256": decl_sha256,
        "per_module_counts": per_module_counts,
        "declarations": [{"module": m, "kind": k, "name": nm} for m, k, nm in decls],
        "forbidden_token_violations": violations,
    }


def verify_frozen_41_43_44_45_byte_identity(package_root: Path) -> Dict[str, Any]:
    """Verify all 20 inherited `.lean` files (`8` `#41` + `4` `#43` + `4` `#44` + `4` `#45`) match `MANIFEST_45.json`."""
    m41 = json.loads((package_root / "frozen_ancestors" / "MANIFEST_41.json").read_text("utf-8"))
    m43 = json.loads((package_root / "frozen_ancestors" / "MANIFEST_43.json").read_text("utf-8"))
    m44 = json.loads((package_root / "frozen_ancestors" / "MANIFEST_44.json").read_text("utf-8"))
    m45 = json.loads((package_root / "frozen_ancestors" / "MANIFEST_45.json").read_text("utf-8"))
    if not (verify_seal(m41) and verify_seal(m43) and verify_seal(m44) and verify_seal(m45)):
        raise ValueError("Frozen MANIFEST_41/43/44/45 seal invalid")

    map45 = {e["path"]: e for e in m45["files"]}
    all_ok = True
    checked: List[Dict[str, Any]] = []
    for mod_name, rel, _ in FROZEN_45_MODULES:
        key = f"lean/{rel}"
        raw = (package_root / "lean" / rel).read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        exp45 = map45[key]
        ok = len(raw) == exp45["size_bytes"] and sha == exp45["sha256"] and (b"\r" not in raw)
        if not ok:
            all_ok = False
        checked.append({
            "module": mod_name,
            "path": key,
            "size_bytes": len(raw),
            "sha256": sha,
            "matches_frozen_45": ok,
        })

    m1_audit = extract_declarations_and_static_audit(package_root / "lean", M1_MODULES)
    r1_audit = extract_declarations_and_static_audit(package_root / "lean", R1_NEW_MODULES)
    r2_audit = extract_declarations_and_static_audit(package_root / "lean", R2_NEW_MODULES)
    w1_audit = extract_declarations_and_static_audit(package_root / "lean", W1_NEW_MODULES)

    m1_match = (
        m1_audit["theorem_count"] == EXPECTED_M1_DECL_COUNTS["theorem"]
        and m1_audit["def_count"] == EXPECTED_M1_DECL_COUNTS["def"]
        and m1_audit["decl_table_sha256"] == EXPECTED_M1_DECL_SHA256
    )
    r1_match = (
        r1_audit["theorem_count"] == EXPECTED_R1_NEW_DECL_COUNTS["theorem"]
        and r1_audit["def_count"] == EXPECTED_R1_NEW_DECL_COUNTS["def"]
        and r1_audit["decl_table_sha256"] == EXPECTED_R1_NEW_DECL_SHA256
    )
    r2_match = (
        r2_audit["theorem_count"] == EXPECTED_R2_NEW_DECL_COUNTS["theorem"]
        and r2_audit["def_count"] == EXPECTED_R2_NEW_DECL_COUNTS["def"]
        and r2_audit["decl_table_sha256"] == EXPECTED_R2_NEW_DECL_SHA256
    )
    w1_match = (
        w1_audit["theorem_count"] == EXPECTED_W1_NEW_DECL_COUNTS["theorem"]
        and w1_audit["def_count"] == EXPECTED_W1_NEW_DECL_COUNTS["def"]
        and w1_audit["decl_table_sha256"] == EXPECTED_W1_NEW_DECL_SHA256
    )
    return {
        "manifest_41_payload_sha256": m41["seal"]["payload_sha256"],
        "manifest_43_payload_sha256": m43["seal"]["payload_sha256"],
        "manifest_44_payload_sha256": m44["seal"]["payload_sha256"],
        "manifest_45_payload_sha256": m45["seal"]["payload_sha256"],
        "all_20_frozen_lean_files_byte_identical": all_ok,
        "m1_manifest_match": m1_match,
        "r1_manifest_match": r1_match,
        "r2_manifest_match": r2_match,
        "w1_manifest_match": w1_match,
        "files": checked,
    }


def parse_print_axioms_lines(stdout_text: str) -> Dict[str, List[str]]:
    logical_lines: List[str] = []
    for raw_line in stdout_text.splitlines():
        if not raw_line.strip():
            continue
        if raw_line[:1].isspace() and logical_lines:
            logical_lines[-1] = logical_lines[-1] + " " + raw_line.strip()
        else:
            logical_lines.append(raw_line.strip())

    out: Dict[str, List[str]] = {}
    for s in logical_lines:
        m0 = NO_AXIOMS_RE.match(s)
        if m0:
            out[m0.group(1)] = []
            continue
        m1 = DEPENDS_AXIOMS_RE.match(s)
        if m1:
            axs = [x.strip() for x in m1.group(2).split(",") if x.strip()]
            out[m1.group(1)] = axs
            continue
        raise ValueError(f"Unexpected compiler stdout line: {s!r}")
    return out


def run_live_lean_w2_and_env_coverage(package_root: Path) -> Dict[str, Any]:
    """Compile all 24 modules on `Lean 4.33.1` (`-DwarningAsError=true`) and run `SMap` inspector."""
    lean_bin = find_optional_lean_binary()
    if lean_bin is None:
        raise RuntimeError("Lean binary not found for live compilation")

    ver_proc = subprocess.run(
        [str(lean_bin), "--version"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=True,
    )
    ver_out = ver_proc.stdout.strip()
    if EXPECTED_LEAN_VERSION_SUBSTR not in ver_out or EXPECTED_LEAN_COMMIT not in ver_out:
        raise RuntimeError(f"Lean version/commit mismatch: {ver_out!r}")

    full_src_audit = extract_declarations_and_static_audit(package_root / "lean", ALL_W2_MODULES)
    if full_src_audit["forbidden_token_violations"]:
        raise RuntimeError(f"Forbidden tokens: {full_src_audit['forbidden_token_violations']}")

    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        shutil.copytree(package_root / "lean", tdp / "lean")
        olean_root = tdp / "olean"
        (olean_root / "OmegaLambda").mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["LEAN_PATH"] = str(olean_root)

        compile_log: List[Dict[str, Any]] = []
        w2_flagship_axioms: Dict[str, List[str]] = {}

        for mod_name, rel_src, rel_olean in ALL_W2_MODULES:
            proc = subprocess.run(
                [
                    str(lean_bin),
                    "-DwarningAsError=true",
                    "-o",
                    str(olean_root / rel_olean),
                    f"lean/{rel_src}",
                ],
                cwd=str(tdp),
                env=env,
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
            if proc.returncode != 0 or proc.stderr.strip():
                raise RuntimeError(
                    f"Compilation failed on {rel_src}: rc={proc.returncode} err={proc.stderr!r} out={proc.stdout!r}"
                )
            if mod_name == "OmegaLambda.W2AxiomAudit":
                w2_flagship_axioms = parse_print_axioms_lines(proc.stdout)
            compile_log.append({
                "module": mod_name,
                "source": f"lean/{rel_src}",
                "return_code": proc.returncode,
                "stderr_bytes": len(proc.stderr.encode("utf-8")),
            })

        expected_pairs = ",\n    ".join(
            f'("{d["kind"]}", `{d["name"]})' for d in full_src_audit["declarations"]
        )
        mod_lits = ",\n    ".join(f"`{m}" for m, _, _ in ALL_W2_MODULES)

        inspector_lean = f"""import OmegaLambdaW2
import Lean

open Lean

def cinfoVariant : ConstantInfo → String
  | .axiomInfo _ => "axiomInfo"
  | .defnInfo _ => "defnInfo"
  | .thmInfo _ => "thmInfo"
  | .opaqueInfo _ => "opaqueInfo"
  | .quotInfo _ => "quotInfo"
  | .inductInfo _ => "inductInfo"
  | .ctorInfo _ => "ctorInfo"
  | .recInfo _ => "recInfo"

def isProjectPrefix : Name → Bool
  | .anonymous => false
  | .str .anonymous s =>
      s == "OmegaLambda" || s == "OmegaLambdaR1" || s == "OmegaLambdaR2" || s == "OmegaLambdaW1" || s == "OmegaLambdaW2"
  | .str p _ => isProjectPrefix p
  | .num p _ => isProjectPrefix p

def expectedDecls : Array (String × Name) := #[
    {expected_pairs}
]

def targetMods : Array Name := #[
    {mod_lits}
]

def runW2StrictInspector : MetaM Unit := do
  let env <- getEnv
  let mut idxPairs : Array (Nat × String) := #[]
  for m in targetMods do
    match env.getModuleIdx? m with
    | some idx => idxPairs := idxPairs.push (idx.toNat, m.toString)
    | none => throwError s!"FATAL: Missing module {{m}}"
  let allowed : List Name := [`propext, `Quot.sound, `Classical.choice]
  for (name, cinfo) in env.constants.map₁.toList ++ env.constants.map₂.toList do
    let inProj := isProjectPrefix name
    match env.getModuleIdxFor? name with
    | some midx =>
      match idxPairs.find? (fun (i, _) => i == midx.toNat) with
      | some (_, modStr) =>
        let kindStr := cinfoVariant cinfo
        if kindStr == "axiomInfo" || kindStr == "opaqueInfo" then
          throwError s!"FATAL: Forbidden {{kindStr}} constant {{name}} in {{modStr}}"
        let axs <- collectAxioms name
        for ax in axs do
          let s := ax.toString
          if !(allowed.contains ax) || (s.splitOn "sorry").length > 1 || (s.splitOn "native_decide").length > 1 || (s.splitOn "._native.").length > 1 then
            throwError s!"FATAL: Disallowed axiom {{ax}} in {{name}}"
        let axCsv := String.intercalate "," ((axs.toList.map Name.toString))
        IO.println s!"CONST_ROW|{{modStr}}|{{kindStr}}|{{name}}|{{axCsv}}"
      | none =>
        if inProj then
          throwError s!"FATAL: Orphan project constant outside target modules: {{name}}"
    | none =>
      if inProj then
        throwError s!"FATAL: Unattributed local constant in project namespace: {{name}}"
  let mut thmVerified : Nat := 0
  let mut defVerified : Nat := 0
  for (k, nm) in expectedDecls do
    match env.find? nm with
    | none => throwError s!"FATAL: Missing source declaration in kernel env: {{nm}}"
    | some (.thmInfo _) =>
      if k != "theorem" then throwError s!"FATAL: Expected {{k}} got thmInfo on {{nm}}"
      thmVerified := thmVerified + 1
    | some (.defnInfo _) =>
      if k != "def" then throwError s!"FATAL: Expected {{k}} got defnInfo on {{nm}}"
      defVerified := defVerified + 1
    | some other =>
      throwError s!"FATAL: Unexpected ConstantInfo {{cinfoVariant other}} on {{nm}}"
  IO.println s!"INVENTORY_SUMMARY|thm={{thmVerified}}|def={{defVerified}}|total={{thmVerified + defVerified}}"

#eval runW2StrictInspector
"""
        (tdp / "W2Inspector.lean").write_bytes(inspector_lean.encode("utf-8"))
        insp_proc = subprocess.run(
            [str(lean_bin), "W2Inspector.lean"],
            cwd=str(tdp),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if insp_proc.returncode != 0 or insp_proc.stderr.strip():
            raise RuntimeError(
                f"W2Inspector failed: rc={insp_proc.returncode} err={insp_proc.stderr!r}"
            )

    m1_set = {m for m, _, _ in M1_MODULES}
    r1_set = {m for m, _, _ in R1_NEW_MODULES}
    r2_set = {m for m, _, _ in R2_NEW_MODULES}
    w1_set = {m for m, _, _ in W1_NEW_MODULES}
    w2_set = {m for m, _, _ in W2_NEW_MODULES}
    per_mod: Dict[str, Dict[str, int]] = {
        m: {
            "thmInfo": 0,
            "defnInfo": 0,
            "inductInfo": 0,
            "ctorInfo": 0,
            "recInfo": 0,
            "quotInfo": 0,
            "axiomInfo": 0,
            "opaqueInfo": 0,
            "total": 0,
        }
        for m, _, _ in ALL_W2_MODULES
    }
    all_rows: List[str] = []
    inv_line = ""

    for ln in insp_proc.stdout.splitlines():
        s = ln.strip()
        if not s:
            continue
        if s.startswith("CONST_ROW|"):
            _, mod_s, kind_s, name_s, ax_csv = s.split("|", 4)
            axs = sorted(x for x in ax_csv.split(",") if x)
            for a in axs:
                if a not in ALLOWED_FOUNDATION_AXIOMS:
                    raise RuntimeError(f"Disallowed axiom {a} on {name_s}")
            all_rows.append(f"{mod_s}|{kind_s}|{name_s}|{','.join(axs)}")
            per_mod[mod_s][kind_s] += 1
            per_mod[mod_s]["total"] += 1
        elif s.startswith("INVENTORY_SUMMARY|"):
            inv_line = s
        else:
            raise RuntimeError(f"Unexpected inspector line: {s!r}")

    m1_tot = sum(per_mod[m]["total"] for m in m1_set)
    r1_tot = sum(per_mod[m]["total"] for m in r1_set)
    r2_tot = sum(per_mod[m]["total"] for m in r2_set)
    w1_tot = sum(per_mod[m]["total"] for m in w1_set)
    w2_tot = sum(per_mod[m]["total"] for m in w2_set)
    if (
        m1_tot != EXPECTED_M1_KERNEL_CONSTANTS
        or r1_tot != EXPECTED_R1_NEW_KERNEL_CONSTANTS
        or r2_tot != EXPECTED_R2_NEW_KERNEL_CONSTANTS
        or w1_tot != EXPECTED_W1_NEW_KERNEL_CONSTANTS
    ):
        raise RuntimeError(
            f"Unexpected M1/R1/R2/W1 constant count: m1={m1_tot}, r1={r1_tot}, r2={r2_tot}, w1={w1_tot}"
        )

    expected_inv = (
        f"INVENTORY_SUMMARY|thm={full_src_audit['theorem_count']}"
        f"|def={full_src_audit['def_count']}"
        f"|total={full_src_audit['total_count']}"
    )
    if inv_line != expected_inv:
        raise RuntimeError(f"Inventory mismatch: expected {expected_inv!r}, got {inv_line!r}")

    combined_ledger_sha256 = hashlib.sha256(
        ("\n".join(sorted(all_rows)) + "\n").encode("utf-8")
    ).hexdigest()

    return {
        "lean_version_output": ver_out,
        "lean_4_33_1_enforced": True,
        "lean_commit_enforced": EXPECTED_LEAN_COMMIT,
        "modules_compiled_count": len(compile_log),
        "compile_log": compile_log,
        "m1_kernel_constants_count": m1_tot,
        "r1_new_kernel_constants_count": r1_tot,
        "r2_new_kernel_constants_count": r2_tot,
        "w1_new_kernel_constants_count": w1_tot,
        "w2_new_kernel_constants_count": w2_tot,
        "combined_kernel_constants_count": m1_tot + r1_tot + r2_tot + w1_tot + w2_tot,
        "orphan_project_constants_count": 0,
        "user_axiom_constants_count": 0,
        "opaque_constants_count": 0,
        "disallowed_axiom_violations_count": 0,
        "per_module_constant_info_breakdown": per_mod,
        "combined_kernel_ledger_sha256": combined_ledger_sha256,
        "w2_flagship_axioms": w2_flagship_axioms,
    }


# =============================================================================
# `W2-A..D`, `F92-01`, `F93-01..03` Canonical Wire & FIPS `SHA-256` Reference Model
# =============================================================================

def mk_snapshot_preimage_py(gen_v: int, policy_mask: int, snap_bytes: bytes) -> bytes:
    return SNAPSHOT_DOMAIN_PREFIX + struct.pack(">IH", gen_v, policy_mask) + snap_bytes


def mk_carrier_preimage_py(
    carrier_tag: int,
    h_sigma_32: bytes,
    closure_tag: int,
    q_s: int,
    q_t: int,
    canon_carrier_bytes: bytes,
) -> bytes:
    return (
        CARRIER_DOMAIN_PREFIX
        + struct.pack(">B", carrier_tag)
        + h_sigma_32
        + struct.pack(">BHH", closure_tag, q_s, q_t)
        + canon_carrier_bytes
    )


def _is_valid_ascii_id(s: str) -> bool:
    if not isinstance(s, str) or not (1 <= len(s) <= MAX_ASCII_ID_LEN):
        return False
    try:
        b = s.encode("ascii")
    except UnicodeEncodeError:
        return False
    return all(ch in ALLOWED_ASCII_BYTES for ch in b)


def encode_ascii_id_slice_py(s: str) -> Optional[bytes]:
    if not _is_valid_ascii_id(s):
        return None
    b = s.encode("ascii")
    return struct.pack(">H", len(b)) + b


def _parse_ascii_id(raw: bytes, cur: int) -> Optional[Tuple[str, int]]:
    if cur + 2 > len(raw):
        return None
    (slen,) = struct.unpack_from(">H", raw, cur)
    cur += 2
    if not (1 <= slen <= MAX_ASCII_ID_LEN) or cur + slen > len(raw):
        return None
    sb = raw[cur : cur + slen]
    if any(ch not in ALLOWED_ASCII_BYTES for ch in sb):
        return None
    return sb.decode("ascii"), cur + slen


def decode_ascii_id_slice_py(raw: bytes) -> Optional[str]:
    res = _parse_ascii_id(raw, 0)
    if res is None or res[1] != len(raw):
        return None
    return res[0]


def encode_snapshot_section_py(snap: Dict[str, Any]) -> Optional[bytes]:
    sid_b = encode_ascii_id_slice_py(snap["snapshotId"])
    if sid_b is None:
        return None
    buckets = (
        tuple(snap["bucket0"]),
        tuple(snap["bucket1"]),
        tuple(snap["bucket2"]),
        tuple(snap["bucket3"]),
    )
    v_tot = sum(len(bk) for bk in buckets)
    if not (1 <= v_tot <= MAX_VERTICES):
        return None
    out: List[bytes] = [sid_b]
    for bk in buckets:
        if len(bk) > MAX_VERTICES:
            return None
        if any(bk[i] >= bk[i + 1] for i in range(len(bk) - 1)):
            return None
        out.append(struct.pack(">H", len(bk)))
        for vid_s in bk:
            vb = encode_ascii_id_slice_py(vid_s)
            if vb is None:
                return None
            out.append(vb)

    recs = tuple(snap["irRecords"])
    if len(recs) > MAX_IR_RECORDS:
        return None
    rids = [rc["recordId"] for rc in recs]
    if any(rids[i] >= rids[i + 1] for i in range(len(rids) - 1)):
        return None
    out.append(struct.pack(">I", len(recs)))
    for rc in recs:
        rtag = rc["recTag"]
        rid_b = encode_ascii_id_slice_py(rc["recordId"])
        sv = rc["sourceVid"]
        ssort = rc["sourceSortCode"]
        refs = tuple(rc["refs"])
        if (
            rtag not in (1, 2, 3)
            or rid_b is None
            or not (0 <= sv < v_tot and sv != NONE_VID_SENTINEL)
            or ssort not in (0, 1, 2, 3)
            or not (0 <= len(refs) <= MAX_REFS_PER_RECORD)
            or any(refs[i] >= refs[i + 1] for i in range(len(refs) - 1))
        ):
            return None
        out.append(struct.pack(">B", rtag))
        out.append(rid_b)
        out.append(struct.pack(">HBH", sv, ssort, len(refs)))
        for tv, tsort, rel_tag in refs:
            if (
                not (0 <= tv < v_tot and tv != NONE_VID_SENTINEL)
                or tsort not in (0, 1, 2, 3)
                or not (1 <= rel_tag <= 13)
            ):
                return None
            out.append(struct.pack(">HBB", tv, tsort, rel_tag))
    return b"".join(out)


def decode_snapshot_section_py(raw: bytes) -> Optional[Dict[str, Any]]:
    p_sid = _parse_ascii_id(raw, 0)
    if p_sid is None:
        return None
    sid, cur = p_sid
    buckets: List[Tuple[str, ...]] = []
    for _ in range(4):
        if cur + 2 > len(raw):
            return None
        (bcnt,) = struct.unpack_from(">H", raw, cur)
        cur += 2
        if bcnt > MAX_VERTICES:
            return None
        bk: List[str] = []
        for _ in range(bcnt):
            pv = _parse_ascii_id(raw, cur)
            if pv is None:
                return None
            bk.append(pv[0])
            cur = pv[1]
        if any(bk[i] >= bk[i + 1] for i in range(len(bk) - 1)):
            return None
        buckets.append(tuple(bk))
    v_tot = sum(len(b) for b in buckets)
    if not (1 <= v_tot <= MAX_VERTICES) or cur + 4 > len(raw):
        return None
    (ir_cnt,) = struct.unpack_from(">I", raw, cur)
    cur += 4
    if ir_cnt > MAX_IR_RECORDS:
        return None
    recs: List[Dict[str, Any]] = []
    for _ in range(ir_cnt):
        if cur + 1 > len(raw):
            return None
        rtag = raw[cur]
        cur += 1
        prid = _parse_ascii_id(raw, cur)
        if prid is None:
            return None
        rid, cur = prid
        if cur + 5 > len(raw):
            return None
        sv, ssort, rcnt = struct.unpack_from(">HBH", raw, cur)
        cur += 5
        if (
            rtag not in (1, 2, 3)
            or sv >= v_tot or sv == NONE_VID_SENTINEL
            or ssort not in (0, 1, 2, 3)
            or rcnt > MAX_REFS_PER_RECORD
            or cur + 4 * rcnt > len(raw)
        ):
            return None
        refs: List[Tuple[int, int, int]] = []
        for i in range(rcnt):
            tv, tsort, rel_tag = struct.unpack_from(">HBB", raw, cur + 4 * i)
            if (
                tv >= v_tot or tv == NONE_VID_SENTINEL
                or tsort not in (0, 1, 2, 3)
                or not (1 <= rel_tag <= 13)
            ):
                return None
            refs.append((tv, tsort, rel_tag))
        cur += 4 * rcnt
        if any(refs[i] >= refs[i + 1] for i in range(len(refs) - 1)):
            return None
        recs.append({
            "recTag": rtag,
            "recordId": rid,
            "sourceVid": sv,
            "sourceSortCode": ssort,
            "refs": tuple(refs),
        })
    if cur != len(raw):
        return None
    rids = [rc["recordId"] for rc in recs]
    if any(rids[i] >= rids[i + 1] for i in range(len(rids) - 1)):
        return None
    snap = {
        "snapshotId": sid,
        "bucket0": buckets[0],
        "bucket1": buckets[1],
        "bucket2": buckets[2],
        "bucket3": buckets[3],
        "irRecords": tuple(recs),
    }
    return snap if encode_snapshot_section_py(snap) == raw else None


def encode_walk_py(v_total: int, walk: Sequence[int]) -> Optional[bytes]:
    if len(walk) < 1 or (len(walk) - 1) > v_total or (len(walk) - 1) >= 65536:
        return None
    for v in walk:
        if v < 0 or v >= v_total or v == NONE_VID_SENTINEL or v >= 65536:
            return None
    return struct.pack(">H", len(walk) - 1) + b"".join(struct.pack(">H", v) for v in walk)


def decode_walk_slice_py(v_total: int, raw: bytes) -> Optional[Tuple[int, ...]]:
    if len(raw) < 2:
        return None
    (step_cnt,) = struct.unpack_from(">H", raw, 0)
    if step_cnt > v_total or len(raw) != 2 + (step_cnt + 1) * 2:
        return None
    verts = tuple(struct.unpack_from(">H", raw, 2 + 2 * i)[0] for i in range(step_cnt + 1))
    for v in verts:
        if v >= v_total or v == NONE_VID_SENTINEL:
            return None
    return verts


def encode_carrier_payload_py(v_total: int, c_tag: int, payload: Any) -> Optional[bytes]:
    if c_tag == 1:
        pkt: Sequence[Tuple[int, ...]] = payload
        if not (1 <= len(pkt) <= 64):
            return None
        if any(pkt[i] >= pkt[i + 1] for i in range(len(pkt) - 1)):
            return None
        parts = [struct.pack(">H", len(pkt))]
        for w in pkt:
            ew = encode_walk_py(v_total, w)
            if ew is None:
                return None
            parts.append(ew)
        return b"".join(parts)
    if c_tag == 2:
        entries: Sequence[Tuple[int, int, int, Tuple[int, ...]]] = payload
        if len(entries) > v_total * v_total:
            return None
        keys = [(e[0], e[1]) for e in entries]
        if any(keys[i] >= keys[i + 1] for i in range(len(keys) - 1)):
            return None
        parts = [struct.pack(">I", len(entries))]
        for sv, tv, rk, hops in entries:
            if (
                sv < 0 or sv >= v_total or sv == NONE_VID_SENTINEL
                or tv < 0 or tv >= v_total or tv == NONE_VID_SENTINEL
                or not (0 <= rk <= MAX_GEN_OR_RANK)
                or len(hops) > v_total
                or any(h < 0 or h >= v_total or h == NONE_VID_SENTINEL for h in hops)
                or any(hops[i] >= hops[i + 1] for i in range(len(hops) - 1))
            ):
                return None
            parts.append(struct.pack(">HHIH", sv, tv, rk, len(hops)))
            parts.extend(struct.pack(">H", h) for h in hops)
        return b"".join(parts)
    if c_tag == 3:
        edges: Sequence[Tuple[int, int]] = payload
        if len(edges) > v_total * v_total:
            return None
        if any(edges[i] >= edges[i + 1] for i in range(len(edges) - 1)):
            return None
        parts = [struct.pack(">I", len(edges))]
        for u, w in edges:
            if (
                u < 0 or u >= v_total or u == NONE_VID_SENTINEL
                or w < 0 or w >= v_total or w == NONE_VID_SENTINEL
            ):
                return None
            parts.append(struct.pack(">HH", u, w))
        return b"".join(parts)
    return None


def _parse_carrier_payload_step(v_total: int, c_tag: int, raw: bytes, cur: int) -> Optional[Tuple[Any, int]]:
    if c_tag == 1:
        if cur + 2 > len(raw):
            return None
        (cnt,) = struct.unpack_from(">H", raw, cur)
        cur += 2
        if not (1 <= cnt <= 64):
            return None
        pkt: List[Tuple[int, ...]] = []
        for _ in range(cnt):
            if cur + 2 > len(raw):
                return None
            (sc,) = struct.unpack_from(">H", raw, cur)
            w_end = cur + 2 + (sc + 1) * 2
            if sc > v_total or w_end > len(raw):
                return None
            w = decode_walk_slice_py(v_total, raw[cur:w_end])
            if w is None:
                return None
            pkt.append(w)
            cur = w_end
        if any(pkt[i] >= pkt[i + 1] for i in range(len(pkt) - 1)):
            return None
        return tuple(pkt), cur
    if c_tag == 2:
        if cur + 4 > len(raw):
            return None
        (cnt,) = struct.unpack_from(">I", raw, cur)
        cur += 4
        if cnt > v_total * v_total:
            return None
        entries: List[Tuple[int, int, int, Tuple[int, ...]]] = []
        for _ in range(cnt):
            if cur + 10 > len(raw):
                return None
            sv, tv, rk, hcnt = struct.unpack_from(">HHIH", raw, cur)
            cur += 10
            if (
                sv >= v_total or sv == NONE_VID_SENTINEL
                or tv >= v_total or tv == NONE_VID_SENTINEL
                or rk > MAX_GEN_OR_RANK
                or hcnt > v_total or cur + 2 * hcnt > len(raw)
            ):
                return None
            hops = tuple(struct.unpack_from(">H", raw, cur + 2 * i)[0] for i in range(hcnt))
            cur += 2 * hcnt
            if any(h >= v_total or h == NONE_VID_SENTINEL for h in hops) or any(
                hops[i] >= hops[i + 1] for i in range(len(hops) - 1)
            ):
                return None
            entries.append((sv, tv, rk, hops))
        keys = [(e[0], e[1]) for e in entries]
        if any(keys[i] >= keys[i + 1] for i in range(len(keys) - 1)):
            return None
        return tuple(entries), cur
    if c_tag == 3:
        if cur + 4 > len(raw):
            return None
        (cnt,) = struct.unpack_from(">I", raw, cur)
        cur += 4
        if cnt > v_total * v_total or cur + 4 * cnt > len(raw):
            return None
        edges = tuple(struct.unpack_from(">HH", raw, cur + 4 * i) for i in range(cnt))
        cur += 4 * cnt
        if any(
            u >= v_total or u == NONE_VID_SENTINEL or w >= v_total or w == NONE_VID_SENTINEL
            for u, w in edges
        ) or any(edges[i] >= edges[i + 1] for i in range(len(edges) - 1)):
            return None
        return edges, cur
    return None


def encode_claim_slice_0x00_py(
    v_total: int,
    ir_total: int,
    bh: Tuple[bytes, bytes, int, int, int, int],
    cert: Dict[str, Any],
) -> Optional[bytes]:
    h_sig, h_car, b_clo, b_ctag, q_s, q_t = bh
    if (
        len(h_sig) != 32
        or len(h_car) != 32
        or b_clo not in (1, 2)
        or b_ctag not in (1, 2, 3)
        or not (0 <= q_s < v_total and q_s != NONE_VID_SENTINEL)
        or not (0 <= q_t < v_total and q_t != NONE_VID_SENTINEL)
        or b_clo != cert["closureTag"]
        or b_ctag != cert["carrierTag"]
        or cert["evasionModeTag"] != 0
    ):
        return None
    bh_raw = struct.pack(">32s32sBBHH", h_sig, h_car, b_clo, b_ctag, q_s, q_t)
    m_tag = cert["modeTag"]

    if b_ctag == 1:
        if m_tag == 1:
            if (
                cert["unbreakableRefKind"] != 1
                or not (0 <= cert["unbreakableLocalIdx"] < 65536)
                or cert["unbreakableWalk"] != ()
                or cert["claimedL"] != 0 or cert["claimedU"] != 0
                or cert["primalWitnesses"] != ()
                or cert["retractionIrIndices"] != ()
                or cert["dualCutVids"] != ()
            ):
                return None
            return bh_raw + struct.pack(">BH", 1, cert["unbreakableLocalIdx"])
        if m_tag == 2:
            c_L, c_U = cert["claimedL"], cert["claimedU"]
            pws = cert["primalWitnesses"]
            hits = cert["retractionIrIndices"]
            if (
                cert["unbreakableRefKind"] != 1
                or cert["unbreakableLocalIdx"] != 0
                or cert["unbreakableWalk"] != ()
                or not (1 <= c_L <= c_U <= ir_total and c_U < 65536)
                or len(pws) != c_L
                or len(hits) != c_U
                or any(d < 0 or d >= ir_total or d >= 65536 for d in hits)
                or any(hits[i] >= hits[i + 1] for i in range(len(hits) - 1))
                or cert["dualCutVids"] != ()
            ):
                return None
            keys = [(pw["jIdx"], (), pw["stepWitnesses"]) for pw in pws]
            if any(keys[i] >= keys[i + 1] for i in range(len(keys) - 1)):
                return None
            out = [bh_raw, struct.pack(">BHH", 2, c_L, c_U)]
            for pw in pws:
                sws = pw["stepWitnesses"]
                if (
                    pw["refKind"] != 1
                    or not (0 <= pw["jIdx"] < 65536)
                    or pw["walkVertices"] != ()
                    or len(sws) > v_total
                    or any(st not in (1, 2) or not (0 <= ii < ir_total) for st, ii in sws)
                ):
                    return None
                out.append(struct.pack(">HH", pw["jIdx"], len(sws)))
                out.extend(struct.pack(">BH", st, ii) for st, ii in sws)
            out.extend(struct.pack(">H", d) for d in hits)
            out.append(struct.pack(">B", 0))
            return b"".join(out)
        return None

    if m_tag == 1:
        ew = encode_walk_py(v_total, cert["unbreakableWalk"])
        if (
            cert["unbreakableRefKind"] != 2
            or cert["unbreakableLocalIdx"] != 0
            or ew is None
            or cert["claimedL"] != 0 or cert["claimedU"] != 0
            or cert["primalWitnesses"] != ()
            or cert["retractionIrIndices"] != ()
            or cert["dualCutVids"] != ()
        ):
            return None
        return bh_raw + struct.pack(">B", 1) + ew
    if m_tag == 2:
        c_L, c_U = cert["claimedL"], cert["claimedU"]
        pws = cert["primalWitnesses"]
        d_star = cert["retractionIrIndices"]
        cuts = cert["dualCutVids"]
        if (
            cert["unbreakableRefKind"] != 2
            or cert["unbreakableLocalIdx"] != 0
            or cert["unbreakableWalk"] != ()
            or not (1 <= c_L <= c_U <= ir_total and c_U < 65536)
            or len(pws) != c_L
            or len(d_star) != c_U
            or any(d < 0 or d >= ir_total or d >= 65536 for d in d_star)
            or any(d_star[i] >= d_star[i + 1] for i in range(len(d_star) - 1))
            or len(cuts) > v_total
            or any(cv < 0 or cv >= v_total or cv == NONE_VID_SENTINEL for cv in cuts)
            or any(cuts[i] >= cuts[i + 1] for i in range(len(cuts) - 1))
        ):
            return None
        keys = [(0, pw["walkVertices"], pw["stepWitnesses"]) for pw in pws]
        if any(keys[i] >= keys[i + 1] for i in range(len(keys) - 1)):
            return None
        out = [bh_raw, struct.pack(">BHH", 2, c_L, c_U)]
        for pw in pws:
            ew = encode_walk_py(v_total, pw["walkVertices"])
            sws = pw["stepWitnesses"]
            if (
                pw["refKind"] != 2
                or pw["jIdx"] != 0
                or ew is None
                or len(sws) != len(pw["walkVertices"]) - 1
                or any(st not in (1, 2) or not (0 <= ii < ir_total) for st, ii in sws)
            ):
                return None
            out.append(ew)
            out.extend(struct.pack(">BH", st, ii) for st, ii in sws)
        out.extend(struct.pack(">H", d) for d in d_star)
        out.append(struct.pack(">H", len(cuts)))
        out.extend(struct.pack(">H", cv) for cv in cuts)
        return b"".join(out)
    return None


def _parse_claim_step_0x00_py(
    v_total: int,
    ir_total: int,
    raw: bytes,
    cur: int,
) -> Optional[Tuple[Tuple[Tuple[bytes, bytes, int, int, int, int], Dict[str, Any]], int]]:
    start = cur
    if cur + 71 > len(raw):
        return None
    bh = struct.unpack_from(">32s32sBBHH", raw, cur)
    _, _, b_clo, b_ctag, q_s, q_t = bh
    if (
        b_clo not in (1, 2)
        or b_ctag not in (1, 2, 3)
        or q_s >= v_total or q_t >= v_total
        or q_s == NONE_VID_SENTINEL or q_t == NONE_VID_SENTINEL
    ):
        return None
    m_tag = raw[cur + 70]
    cur += 71

    if b_ctag == 1:
        if m_tag == 1:
            if cur + 2 > len(raw):
                return None
            (j_unb,) = struct.unpack_from(">H", raw, cur)
            cur += 2
            cert = {
                "closureTag": b_clo,
                "carrierTag": 1,
                "modeTag": 1,
                "evasionModeTag": 0,
                "claimedL": 0,
                "claimedU": 0,
                "unbreakableRefKind": 1,
                "unbreakableLocalIdx": j_unb,
                "unbreakableWalk": (),
                "primalWitnesses": (),
                "retractionIrIndices": (),
                "dualCutVids": (),
            }
            if encode_claim_slice_0x00_py(v_total, ir_total, bh, cert) != raw[start:cur]:
                return None
            return (bh, cert), cur
        if m_tag == 2:
            if cur + 4 > len(raw):
                return None
            c_L, c_U = struct.unpack_from(">HH", raw, cur)
            cur += 4
            if not (1 <= c_L <= c_U <= ir_total):
                return None
            pws = []
            for _ in range(c_L):
                if cur + 4 > len(raw):
                    return None
                j_idx, step_decl = struct.unpack_from(">HH", raw, cur)
                cur += 4
                if step_decl > v_total or cur + 3 * step_decl > len(raw):
                    return None
                sws = tuple(struct.unpack_from(">BH", raw, cur + 3 * i) for i in range(step_decl))
                cur += 3 * step_decl
                pws.append({
                    "refKind": 1,
                    "jIdx": j_idx,
                    "walkVertices": (),
                    "stepWitnesses": sws,
                })
            if cur + 2 * c_U + 1 > len(raw):
                return None
            hits = tuple(struct.unpack_from(">H", raw, cur + 2 * i)[0] for i in range(c_U))
            cur += 2 * c_U
            ev_mode = raw[cur]
            cur += 1
            if ev_mode != 0:
                return None
            cert = {
                "closureTag": b_clo,
                "carrierTag": 1,
                "modeTag": 2,
                "evasionModeTag": 0,
                "claimedL": c_L,
                "claimedU": c_U,
                "unbreakableRefKind": 1,
                "unbreakableLocalIdx": 0,
                "unbreakableWalk": (),
                "primalWitnesses": tuple(pws),
                "retractionIrIndices": hits,
                "dualCutVids": (),
            }
            if encode_claim_slice_0x00_py(v_total, ir_total, bh, cert) != raw[start:cur]:
                return None
            return (bh, cert), cur
        return None

    if m_tag == 1:
        if cur + 2 > len(raw):
            return None
        (sc,) = struct.unpack_from(">H", raw, cur)
        w_end = cur + 2 + (sc + 1) * 2
        if sc > v_total or w_end > len(raw):
            return None
        w = decode_walk_slice_py(v_total, raw[cur:w_end])
        if w is None:
            return None
        cur = w_end
        cert = {
            "closureTag": b_clo,
            "carrierTag": b_ctag,
            "modeTag": 1,
            "evasionModeTag": 0,
            "claimedL": 0,
            "claimedU": 0,
            "unbreakableRefKind": 2,
            "unbreakableLocalIdx": 0,
            "unbreakableWalk": w,
            "primalWitnesses": (),
            "retractionIrIndices": (),
            "dualCutVids": (),
        }
        if encode_claim_slice_0x00_py(v_total, ir_total, bh, cert) != raw[start:cur]:
            return None
        return (bh, cert), cur
    if m_tag == 2:
        if cur + 4 > len(raw):
            return None
        c_L, c_U = struct.unpack_from(">HH", raw, cur)
        cur += 4
        if not (1 <= c_L <= c_U <= ir_total):
            return None
        pws = []
        for _ in range(c_L):
            if cur + 2 > len(raw):
                return None
            (sc,) = struct.unpack_from(">H", raw, cur)
            w_end = cur + 2 + (sc + 1) * 2
            if sc > v_total or w_end + 3 * sc > len(raw):
                return None
            w = decode_walk_slice_py(v_total, raw[cur:w_end])
            if w is None:
                return None
            cur = w_end
            sws = tuple(struct.unpack_from(">BH", raw, cur + 3 * i) for i in range(sc))
            cur += 3 * sc
            pws.append({
                "refKind": 2,
                "jIdx": 0,
                "walkVertices": w,
                "stepWitnesses": sws,
            })
        if cur + 2 * c_U + 2 > len(raw):
            return None
        d_star = tuple(struct.unpack_from(">H", raw, cur + 2 * i)[0] for i in range(c_U))
        cur += 2 * c_U
        (cut_len,) = struct.unpack_from(">H", raw, cur)
        cur += 2
        if cut_len > v_total or cur + 2 * cut_len > len(raw):
            return None
        cuts = tuple(struct.unpack_from(">H", raw, cur + 2 * i)[0] for i in range(cut_len))
        cur += 2 * cut_len
        cert = {
            "closureTag": b_clo,
            "carrierTag": b_ctag,
            "modeTag": 2,
            "evasionModeTag": 0,
            "claimedL": c_L,
            "claimedU": c_U,
            "unbreakableRefKind": 2,
            "unbreakableLocalIdx": 0,
            "unbreakableWalk": (),
            "primalWitnesses": tuple(pws),
            "retractionIrIndices": d_star,
            "dualCutVids": cuts,
        }
        if encode_claim_slice_0x00_py(v_total, ir_total, bh, cert) != raw[start:cur]:
            return None
        return (bh, cert), cur
    return None


def encode_cnb1_bundle_py(base: Dict[str, Any]) -> Optional[bytes]:
    hdr = base["hdr"]
    if (
        hdr["closureTag"] not in (1, 2)
        or hdr["claimShortest"] not in (0, 1)
        or not (0 <= hdr["authTierTag"] < 256)
        or hdr["reservedZero"] != 0
        or not (1 <= hdr["generationV"] <= MAX_GEN_OR_RANK)
        or not (0 <= hdr["policyMask"] < 65536)
        or hdr["transitionTag"] != 0
        or hdr["padZero"] != 0
        or len(hdr["claimedRoot32"]) != 32
    ):
        return None
    hdr50 = struct.pack(
        ">4sHBBBBIHBB32s",
        b"CNB1",
        1,
        hdr["closureTag"],
        hdr["claimShortest"],
        hdr["authTierTag"],
        hdr["reservedZero"],
        hdr["generationV"],
        hdr["policyMask"],
        hdr["transitionTag"],
        hdr["padZero"],
        hdr["claimedRoot32"],
    )
    snap_b = encode_snapshot_section_py(base["rawSnap"])
    if snap_b is None:
        return None
    v_tot = (
        len(base["rawSnap"]["bucket0"])
        + len(base["rawSnap"]["bucket1"])
        + len(base["rawSnap"]["bucket2"])
        + len(base["rawSnap"]["bucket3"])
    )
    e_b = encode_carrier_payload_py(v_tot, 3, base["candidateEdges"])
    r_b = encode_carrier_payload_py(v_tot, 3, base["candidateRelations"])
    if e_b is None or r_b is None:
        return None
    cand_b = e_b + r_b

    pws = tuple(base["posWitnesses"])
    cuts = tuple(base["closedCuts"])
    if len(pws) > v_tot * v_tot or len(cuts) > v_tot:
        return None
    pw_keys = [(w[0], w[1]) for w in pws]
    if any(pw_keys[i] >= pw_keys[i + 1] for i in range(len(pw_keys) - 1)):
        return None
    cut_keys = [c[0] for c in cuts]
    if any(cut_keys[i] >= cut_keys[i + 1] for i in range(len(cut_keys) - 1)):
        return None
    prf_parts = [struct.pack(">I", len(pws))]
    for sv, tv, rk, nh in pws:
        if (
            not (0 <= sv < v_tot and sv != NONE_VID_SENTINEL)
            or not (0 <= tv < v_tot and tv != NONE_VID_SENTINEL)
            or not (0 <= rk <= MAX_GEN_OR_RANK)
            or not (nh == NONE_VID_SENTINEL or (0 <= nh < v_tot))
        ):
            return None
        prf_parts.append(struct.pack(">HHIH", sv, tv, rk, nh))
    prf_parts.append(struct.pack(">H", len(cuts)))
    for src_v, tgts in cuts:
        tgts_t = tuple(tgts)
        if (
            not (0 <= src_v < v_tot and src_v != NONE_VID_SENTINEL)
            or len(tgts_t) > v_tot
            or any(not (0 <= t < v_tot and t != NONE_VID_SENTINEL) for t in tgts_t)
            or any(tgts_t[i] >= tgts_t[i + 1] for i in range(len(tgts_t) - 1))
        ):
            return None
        prf_parts.append(struct.pack(">HH", src_v, len(tgts_t)))
        prf_parts.extend(struct.pack(">H", t) for t in tgts_t)
    prf_b = b"".join(prf_parts)

    out = (
        hdr50
        + struct.pack(">I", len(snap_b))
        + snap_b
        + struct.pack(">I", len(cand_b))
        + cand_b
        + struct.pack(">I", len(prf_b))
        + prf_b
    )
    if not (62 <= len(out) <= MAX_PACKET_BYTES):
        return None
    return out


def decode_cnb1_bundle_py(raw: bytes) -> Optional[Dict[str, Any]]:
    if not (62 <= len(raw) <= MAX_PACKET_BYTES):
        return None
    magic, ver, clo, cshort, atier, rzero, gen_v, pmask, ttag, pzero, croot32 = struct.unpack_from(
        ">4sHBBBBIHBB32s", raw, 0
    )
    if (
        magic != b"CNB1"
        or ver != 1
        or clo not in (1, 2)
        or cshort not in (0, 1)
        or rzero != 0
        or not (1 <= gen_v <= MAX_GEN_OR_RANK)
        or ttag != 0
        or pzero != 0
    ):
        return None
    cur = 50
    (snap_len,) = struct.unpack_from(">I", raw, cur)
    cur += 4
    if cur + snap_len + 4 > len(raw):
        return None
    raw_snap = decode_snapshot_section_py(raw[cur : cur + snap_len])
    if raw_snap is None:
        return None
    cur += snap_len
    v_tot = (
        len(raw_snap["bucket0"])
        + len(raw_snap["bucket1"])
        + len(raw_snap["bucket2"])
        + len(raw_snap["bucket3"])
    )

    (cand_len,) = struct.unpack_from(">I", raw, cur)
    cur += 4
    if cur + cand_len + 4 > len(raw):
        return None
    cand_slice = raw[cur : cur + cand_len]
    cur += cand_len
    pe = _parse_carrier_payload_step(v_tot, 3, cand_slice, 0)
    if pe is None:
        return None
    pr = _parse_carrier_payload_step(v_tot, 3, cand_slice, pe[1])
    if pr is None or pr[1] != len(cand_slice):
        return None

    (prf_len,) = struct.unpack_from(">I", raw, cur)
    cur += 4
    if cur + prf_len != len(raw):
        return None
    prf_slice = raw[cur:]
    if len(prf_slice) < 4:
        return None
    (pw_cnt,) = struct.unpack_from(">I", prf_slice, 0)
    if pw_cnt > v_tot * v_tot or 4 + 10 * pw_cnt + 2 > len(prf_slice):
        return None
    pcur = 4
    pws = tuple(struct.unpack_from(">HHIH", prf_slice, pcur + 10 * i) for i in range(pw_cnt))
    pcur += 10 * pw_cnt
    (cut_cnt,) = struct.unpack_from(">H", prf_slice, pcur)
    pcur += 2
    if cut_cnt > v_tot:
        return None
    cuts: List[Tuple[int, Tuple[int, ...]]] = []
    for _ in range(cut_cnt):
        if pcur + 4 > len(prf_slice):
            return None
        src_v, tcnt = struct.unpack_from(">HH", prf_slice, pcur)
        pcur += 4
        if tcnt > v_tot or pcur + 2 * tcnt > len(prf_slice):
            return None
        tgts = tuple(struct.unpack_from(">H", prf_slice, pcur + 2 * i)[0] for i in range(tcnt))
        pcur += 2 * tcnt
        cuts.append((src_v, tgts))
    if pcur != len(prf_slice):
        return None

    base = {
        "hdr": {
            "closureTag": clo,
            "claimShortest": cshort,
            "authTierTag": atier,
            "reservedZero": rzero,
            "generationV": gen_v,
            "policyMask": pmask,
            "transitionTag": ttag,
            "padZero": pzero,
            "claimedRoot32": croot32,
        },
        "rawSnap": raw_snap,
        "candidateEdges": pe[0],
        "candidateRelations": pr[0],
        "posWitnesses": pws,
        "closedCuts": tuple(cuts),
    }
    return base if encode_cnb1_bundle_py(base) == raw else None


def encode_cnp2_packet_0x00_py(pkt: Dict[str, Any]) -> Optional[bytes]:
    pkind = pkt["packetKind"]
    base = pkt["base"]
    cnb_b = encode_cnb1_bundle_py(base)
    if cnb_b is None:
        return None
    v_tot = (
        len(base["rawSnap"]["bucket0"])
        + len(base["rawSnap"]["bucket1"])
        + len(base["rawSnap"]["bucket2"])
        + len(base["rawSnap"]["bucket3"])
    )
    ir_tot = len(base["rawSnap"]["irRecords"])
    q_s, q_t = pkt["queryS"], pkt["queryT"]
    c_idxs = tuple(pkt["constIrIndices"])
    if (
        not (0 <= q_s < v_tot and q_s != NONE_VID_SENTINEL)
        or not (0 <= q_t < v_tot and q_t != NONE_VID_SENTINEL)
        or len(c_idxs) > ir_tot
        or any(not (0 <= ci < ir_tot) for ci in c_idxs)
        or any(c_idxs[i] >= c_idxs[i + 1] for i in range(len(c_idxs) - 1))
    ):
        return None
    q_const_b = struct.pack(">HHH", q_s, q_t, len(c_idxs)) + b"".join(
        struct.pack(">H", ci) for ci in c_idxs
    )

    if pkind == 3:
        loc_b = encode_carrier_payload_py(v_tot, 1, pkt["localPaths"])
        loc_bh, loc_cert = pkt["localClaim"]
        glob_bh, glob_cert = pkt["globalClaim"]
        if loc_b is None or loc_bh[3] != 1 or glob_bh[3] != 3:
            return None
        loc_clm_b = encode_claim_slice_0x00_py(v_tot, ir_tot, loc_bh, loc_cert)
        glob_clm_b = encode_claim_slice_0x00_py(v_tot, ir_tot, glob_bh, glob_cert)
        if loc_clm_b is None or glob_clm_b is None:
            return None
        body = struct.pack(">I", len(cnb_b)) + cnb_b + q_const_b + loc_b + loc_clm_b + glob_clm_b
    elif pkind == 5:
        geo_b = encode_carrier_payload_py(v_tot, 2, pkt["hopEntries"])
        geo_bh, geo_cert = pkt["geodesicClaim"]
        if geo_b is None or geo_bh[3] != 2:
            return None
        geo_clm_b = encode_claim_slice_0x00_py(v_tot, ir_tot, geo_bh, geo_cert)
        if geo_clm_b is None:
            return None
        body = struct.pack(">I", len(cnb_b)) + cnb_b + geo_b + q_const_b + geo_clm_b
    else:
        return None

    env = struct.pack(">4sHBBI", b"CNP2", 2, pkind, 0, len(body))
    out = env + body
    if len(out) > MAX_PACKET_BYTES:
        return None
    return out


def decode_cnp2_packet_0x00_py(raw: bytes) -> Optional[Dict[str, Any]]:
    if not (12 <= len(raw) <= MAX_PACKET_BYTES):
        return None
    magic, ver, pkind, ev_mode, body_len = struct.unpack_from(">4sHBBI", raw, 0)
    if magic != b"CNP2" or ver != 2 or ev_mode != 0 or 12 + body_len != len(raw):
        return None
    body = raw[12:]
    if len(body) < 4:
        return None
    (cnb_len,) = struct.unpack_from(">I", body, 0)
    if 4 + cnb_len > len(body):
        return None
    base = decode_cnb1_bundle_py(body[4 : 4 + cnb_len])
    if base is None:
        return None
    cur = 4 + cnb_len
    v_tot = (
        len(base["rawSnap"]["bucket0"])
        + len(base["rawSnap"]["bucket1"])
        + len(base["rawSnap"]["bucket2"])
        + len(base["rawSnap"]["bucket3"])
    )
    ir_tot = len(base["rawSnap"]["irRecords"])

    def _parse_q_const(c: int) -> Optional[Tuple[int, int, Tuple[int, ...], int]]:
        if c + 6 > len(body):
            return None
        qs, qt, ccnt = struct.unpack_from(">HHH", body, c)
        c += 6
        if ccnt > ir_tot or c + 2 * ccnt > len(body):
            return None
        cis = tuple(struct.unpack_from(">H", body, c + 2 * i)[0] for i in range(ccnt))
        c += 2 * ccnt
        return qs, qt, cis, c

    if pkind == 3:
        pqc = _parse_q_const(cur)
        if pqc is None:
            return None
        qs, qt, cis, cur = pqc
        ploc = _parse_carrier_payload_step(v_tot, 1, body, cur)
        if ploc is None:
            return None
        loc_paths, cur = ploc
        pcl1 = _parse_claim_step_0x00_py(v_tot, ir_tot, body, cur)
        if pcl1 is None:
            return None
        loc_clm, cur = pcl1
        pcl2 = _parse_claim_step_0x00_py(v_tot, ir_tot, body, cur)
        if pcl2 is None or pcl2[1] != len(body):
            return None
        glob_clm = pcl2[0]
        pkt = {
            "packetKind": 3,
            "base": base,
            "queryS": qs,
            "queryT": qt,
            "constIrIndices": cis,
            "localPaths": loc_paths,
            "localClaim": loc_clm,
            "globalClaim": glob_clm,
        }
        return pkt if encode_cnp2_packet_0x00_py(pkt) == raw else None

    if pkind == 5:
        pgeo = _parse_carrier_payload_step(v_tot, 2, body, cur)
        if pgeo is None:
            return None
        hops, cur = pgeo
        pqc = _parse_q_const(cur)
        if pqc is None:
            return None
        qs, qt, cis, cur = pqc
        pcl = _parse_claim_step_0x00_py(v_tot, ir_tot, body, cur)
        if pcl is None or pcl[1] != len(body):
            return None
        geo_clm = pcl[0]
        pkt = {
            "packetKind": 5,
            "base": base,
            "hopEntries": hops,
            "queryS": qs,
            "queryT": qt,
            "constIrIndices": cis,
            "geodesicClaim": geo_clm,
        }
        return pkt if encode_cnp2_packet_0x00_py(pkt) == raw else None

    return None


def _licensed_sort_bit_0xff33(s_sort: int, t_sort: int) -> bool:
    return bool((PINNED_MASK_0XFF33 >> (s_sort * 4 + t_sort)) & 1)


def _check_b1_to_b5_py(
    reg: Sequence[Dict[str, Any]],
    base: Dict[str, Any],
    const_ir_indices: Tuple[int, ...],
) -> Optional[Tuple[Dict[str, Any], bytes, int, Dict[Tuple[int, int], List[int]], List[int]]]:
    hdr = base["hdr"]
    raw_snap = base["rawSnap"]
    snap_b = encode_snapshot_section_py(raw_snap)
    if snap_b is None:
        return None
    comp_root = hashlib.sha256(
        mk_snapshot_preimage_py(hdr["generationV"], hdr["policyMask"], snap_b)
    ).digest()
    if (
        hdr["closureTag"] not in (1, 2)
        or hdr["claimShortest"] not in (0, 1)
        or hdr["authTierTag"] != 1
        or hdr["policyMask"] != PINNED_MASK_0XFF33
        or comp_root != hdr["claimedRoot32"]
    ):
        return None
    ent = next((e for e in reg if e["snapshotId"] == raw_snap["snapshotId"]), None)
    if ent is None:
        return None
    if (
        hdr["generationV"] != ent["pinnedGen"]
        or hdr["claimedRoot32"].hex() != ent["pinnedRootHex"]
    ):
        return None
    recs = raw_snap["irRecords"]
    if tuple(recs[ci]["recordId"] for ci in const_ir_indices) != tuple(ent["pinnedConstIds"]):
        return None
    expected_c_idxs = [
        idx for idx, rc in enumerate(recs) if rc["recordId"] in set(ent["pinnedConstIds"])
    ]
    if list(const_ir_indices) != expected_c_idxs:
        return None

    # B2: Cross-sort uniqueness + 0xFF33 & relTag licensing + IR edge reconstruction
    all_vids = (
        list(raw_snap["bucket0"])
        + list(raw_snap["bucket1"])
        + list(raw_snap["bucket2"])
        + list(raw_snap["bucket3"])
    )
    if len(set(all_vids)) != len(all_vids):
        return None
    vsorts = (
        [0] * len(raw_snap["bucket0"])
        + [1] * len(raw_snap["bucket1"])
        + [2] * len(raw_snap["bucket2"])
        + [3] * len(raw_snap["bucket3"])
    )
    edge_supps: Dict[Tuple[int, int], List[int]] = {}
    for ir_idx, rc in enumerate(recs):
        sv, ss = rc["sourceVid"], rc["sourceSortCode"]
        if vsorts[sv] != ss:
            return None
        seen_tgts = set()
        for tv, ts, rtag in rc["refs"]:
            if (
                vsorts[tv] != ts
                or not _licensed_sort_bit_0xff33(ss, ts)
                or EXPECTED_SORT_PAIR_BY_REL_TAG.get(rtag) != (ss, ts)
            ):
                return None
            if tv not in seen_tgts:
                seen_tgts.add(tv)
                edge_supps.setdefault((sv, tv), []).append(ir_idx)
    proj_edges = tuple(sorted(edge_supps.keys()))
    if base["candidateEdges"] != proj_edges:
        return None

    v_tot = len(all_vids)
    cand_edges_set = set(proj_edges)
    cand_rels = base["candidateRelations"]
    pws = base["posWitnesses"]
    if tuple((w[0], w[1]) for w in pws) != cand_rels:
        return None
    rk_tbl = {(w[0], w[1]): w[2] for w in pws}

    # B3: Positive witness acyclicity
    for sv, tv, rk, nh in pws:
        if hdr["closureTag"] == 1:
            if rk == 0:
                if sv != tv or nh != NONE_VID_SENTINEL:
                    return None
            else:
                if not (1 <= rk <= v_tot and 0 <= nh < v_tot) or (sv, nh) not in cand_edges_set:
                    return None
                nh_rk = rk_tbl.get((nh, tv))
                if nh_rk is None or not (nh_rk < rk):
                    return None
        else:
            if not (1 <= rk <= v_tot and 0 <= nh < v_tot):
                return None
            if rk == 1:
                if (sv, tv) not in cand_edges_set or nh != tv:
                    return None
            else:
                if (sv, nh) not in cand_edges_set:
                    return None
                nh_rk = rk_tbl.get((nh, tv))
                if nh_rk is None or not (1 <= nh_rk < rk):
                    return None

    # B4: Closed cuts
    cuts = base["closedCuts"]
    if [c[0] for c in cuts] != list(range(v_tot)):
        return None
    if hdr["closureTag"] == 2 and not cand_edges_set.issubset(set(cand_rels)):
        return None
    for src_v, tgts in cuts:
        exp_tgts = tuple(t for u, t in cand_rels if u == src_v)
        if tgts != exp_tgts:
            return None
        tset = set(tgts)
        if hdr["closureTag"] == 1 and src_v not in tset:
            return None
        for u, w in proj_edges:
            if u in tset and w not in tset:
                return None

    # B5: Bellman shortest-rank (when claimShortest == 1)
    if hdr["claimShortest"] == 1:
        for sv, tv, rk, nh in pws:
            if (hdr["closureTag"] == 1 and rk > 0) or (hdr["closureTag"] == 2 and rk > 1):
                if rk_tbl.get((nh, tv)) != rk - 1:
                    return None
        for u, w in proj_edges:
            if hdr["closureTag"] == 2 and rk_tbl.get((u, w)) not in (None, 1):
                return None
            for t_v in range(v_tot):
                wt_rk = rk_tbl.get((w, t_v))
                ut_rk = rk_tbl.get((u, t_v))
                if wt_rk is not None and ut_rk is not None and ut_rk > wt_rk + 1:
                    return None

    return ent, snap_b, v_tot, edge_supps, expected_c_idxs


def _check_b6_py(base: Dict[str, Any], hop_entries: Sequence[Tuple[int, int, int, Tuple[int, ...]]]) -> bool:
    if base["hdr"]["claimShortest"] != 1:
        return False
    if tuple((e[0], e[1]) for e in hop_entries) != base["candidateRelations"]:
        return False
    v_tot = (
        len(base["rawSnap"]["bucket0"])
        + len(base["rawSnap"]["bucket1"])
        + len(base["rawSnap"]["bucket2"])
        + len(base["rawSnap"]["bucket3"])
    )
    rk_tbl = {(w[0], w[1]): w[2] for w in base["posWitnesses"]}
    edges_set = set(base["candidateEdges"])
    clo = base["hdr"]["closureTag"]
    for sv, tv, rk, hops in hop_entries:
        if rk_tbl.get((sv, tv)) != rk:
            return False
        exp_hops: List[int] = []
        for z in range(v_tot):
            if clo == 1 and sv == tv:
                ok = False
            elif clo == 2 and rk == 1:
                ok = (sv, tv) in edges_set and z == tv
            else:
                ok = (sv, z) in edges_set and rk_tbl.get((z, tv)) == rk - 1
            if ok:
                exp_hops.append(z)
        if list(hops) != exp_hops:
            return False
    return True


def _synthesize_ranks_and_hops_py(
    v_tot: int,
    clo_tag: int,
    edges: Sequence[Tuple[int, int]],
) -> Tuple[Dict[Tuple[int, int], int], Dict[Tuple[int, int], Tuple[int, ...]]]:
    adj: Dict[int, List[int]] = {u: [] for u in range(v_tot)}
    for u, w in edges:
        adj[u].append(w)
    ranks: Dict[Tuple[int, int], int] = {}
    for s in range(v_tot):
        q: deque[Tuple[int, int]] = deque()
        if clo_tag == 1:
            ranks[(s, s)] = 0
            q.append((s, 0))
        else:
            for w in adj[s]:
                if (s, w) not in ranks:
                    ranks[(s, w)] = 1
                    q.append((w, 1))
        while q:
            u, d = q.popleft()
            for w in adj[u]:
                if (s, w) not in ranks:
                    ranks[(s, w)] = d + 1
                    q.append((w, d + 1))
    edges_set = set(edges)
    hops: Dict[Tuple[int, int], Tuple[int, ...]] = {}
    for (s, t), rk in ranks.items():
        if rk == 0:
            hops[(s, t)] = ()
        elif rk == 1:
            hops[(s, t)] = (t,) if (s, t) in edges_set else ()
        else:
            hops[(s, t)] = tuple(
                z for z in range(v_tot) if (s, z) in edges_set and ranks.get((z, t)) == rk - 1
            )
    return ranks, hops


def _check_single_claim_py(
    v_tot: int,
    ir_tot: int,
    clo_tag: int,
    q_s: int,
    q_t: int,
    h_sigma_32: bytes,
    const_set: set[int],
    edge_supps: Dict[Tuple[int, int], List[int]],
    ranks: Dict[Tuple[int, int], int],
    hops: Dict[Tuple[int, int], Tuple[int, ...]],
    c_tag: int,
    c_payload: Any,
    bh: Tuple[bytes, bytes, int, int, int, int],
    cert: Dict[str, Any],
) -> bool:
    b_car = encode_carrier_payload_py(v_tot, c_tag, c_payload)
    if b_car is None:
        return False
    exp_hcar = hashlib.sha256(mk_carrier_preimage_py(c_tag, h_sigma_32, clo_tag, q_s, q_t, b_car)).digest()
    if bh != (h_sigma_32, exp_hcar, clo_tag, c_tag, q_s, q_t):
        return False

    def _valid_carrier_walk(w: Tuple[int, ...]) -> bool:
        if len(w) < 1 or w[0] != q_s or w[-1] != q_t:
            return False
        if clo_tag == 2 and len(w) < 2:
            return False
        for i in range(len(w) - 1):
            if (w[i], w[i + 1]) not in edge_supps:
                return False
        if c_tag == 1:
            return w in c_payload
        if c_tag == 2:
            rk = ranks.get((q_s, q_t))
            if rk is None or len(w) - 1 != rk:
                return False
            for i in range(len(w) - 1):
                if w[i + 1] not in hops.get((w[i], q_t), ()):
                    return False
            return True
        return True

    m_tag = cert["modeTag"]
    if m_tag == 1:
        if c_tag == 1:
            j = cert["unbreakableLocalIdx"]
            if not (0 <= j < len(c_payload)):
                return False
            w = c_payload[j]
        else:
            w = cert["unbreakableWalk"]
        if not _valid_carrier_walk(w):
            return False
        return all(
            any(ii in const_set for ii in edge_supps[(w[i], w[i + 1])])
            for i in range(len(w) - 1)
        )

    if m_tag == 2:
        c_L, c_U = cert["claimedL"], cert["claimedU"]
        used_ret: set[int] = set()
        for pw in cert["primalWitnesses"]:
            w = c_payload[pw["jIdx"]] if c_tag == 1 else pw["walkVertices"]
            if not _valid_carrier_walk(w) or len(pw["stepWitnesses"]) != len(w) - 1:
                return False
            walk_ret: set[int] = set()
            for idx_step, (st, ii) in enumerate(pw["stepWitnesses"]):
                supp = edge_supps[(w[idx_step], w[idx_step + 1])]
                if st == 1:
                    if ii in const_set or ii not in supp:
                        return False
                    walk_ret.add(ii)
                elif st == 2:
                    const_supp = [x for x in supp if x in const_set]
                    if not const_supp or ii != min(const_supp):
                        return False
                else:
                    return False
            if used_ret & walk_ret:
                return False
            used_ret |= walk_ret

        d_set = set(cert["retractionIrIndices"])
        if len(d_set) != c_U or (d_set & const_set) or any(d >= ir_tot for d in d_set):
            return False
        if c_tag == 1:
            for w in c_payload:
                if _valid_carrier_walk(w):
                    survives = all(
                        any(ii not in d_set for ii in edge_supps[(w[i], w[i + 1])])
                        for i in range(len(w) - 1)
                    )
                    if survives:
                        return False
            return True
        # Dual cut check (`0x05` Geodesic or `0x03` Global)
        cut_set = set(cert["dualCutVids"])
        if c_tag == 3:
            if clo_tag == 1:
                if q_s not in cut_set or q_t in cut_set:
                    return False
                for (u, v), supp in edge_supps.items():
                    if u in cut_set and v not in cut_set and any(ii not in d_set for ii in supp):
                        return False
                return True
            # E_PLUS Global: out-neighbors of q_s under surviving edges must land in cut_set, q_t not in cut_set
            if q_t in cut_set:
                return False
            for (u, v), supp in edge_supps.items():
                if any(ii not in d_set for ii in supp):
                    if u == q_s and v not in cut_set:
                        return False
                    if u in cut_set and v not in cut_set:
                        return False
            return True
        # Geodesic (`c_tag == 2`): DAG of geodesic first-hops has no surviving path q_s -> q_t
        rk_qt = ranks.get((q_s, q_t))
        if rk_qt is None:
            return True
        if rk_qt == 0:
            return False
        if q_s not in cut_set or q_t in cut_set:
            return False
        for u in cut_set:
            for w in hops.get((u, q_t), ()):
                supp = edge_supps.get((u, w), [])
                if any(ii not in d_set for ii in supp) and w not in cut_set:
                    return False
        return True
    return False


def check_cnp2_packet_0x00_py(reg: Sequence[Dict[str, Any]], raw_packet: bytes) -> bool:
    """Reference Python mirror of `checkCnp2ResiliencePacket0x00` (`F92-01` + `F93-01..03`)."""
    pkt = decode_cnp2_packet_0x00_py(raw_packet)
    if pkt is None:
        return False
    base = pkt["base"]
    q_s, q_t = pkt["queryS"], pkt["queryT"]
    c_idxs = pkt["constIrIndices"]
    if (q_s, q_t) not in set(base["candidateRelations"]):
        return False

    b15 = _check_b1_to_b5_py(reg, base, c_idxs)
    if b15 is None:
        return False
    _, _, v_tot, edge_supps, exp_c_idxs = b15
    ir_tot = len(base["rawSnap"]["irRecords"])
    clo_tag = base["hdr"]["closureTag"]
    h_sig = base["hdr"]["claimedRoot32"]
    const_set = set(exp_c_idxs)

    if pkt["packetKind"] == 3:
        # F93-03 Gate 2: Pure shortest-step synthesis (`0x03` independent branch)
        ranks, hops = _synthesize_ranks_and_hops_py(v_tot, clo_tag, base["candidateEdges"])
        loc_bh, loc_cert = pkt["localClaim"]
        glob_bh, glob_cert = pkt["globalClaim"]
        return _check_single_claim_py(
            v_tot,
            ir_tot,
            clo_tag,
            q_s,
            q_t,
            h_sig,
            const_set,
            edge_supps,
            ranks,
            hops,
            1,
            pkt["localPaths"],
            loc_bh,
            loc_cert,
        ) and _check_single_claim_py(
            v_tot,
            ir_tot,
            clo_tag,
            q_s,
            q_t,
            h_sig,
            const_set,
            edge_supps,
            ranks,
            hops,
            3,
            base["candidateEdges"],
            glob_bh,
            glob_cert,
        )

    if pkt["packetKind"] == 5:
        # F93-02 Independent 0x05 Branch: B6 check + wire-projected base
        if not _check_b6_py(base, pkt["hopEntries"]):
            return False
        ranks = {(w[0], w[1]): w[2] for w in base["posWitnesses"]}
        hops = {(e[0], e[1]): e[3] for e in pkt["hopEntries"]}
        geo_bh, geo_cert = pkt["geodesicClaim"]
        return _check_single_claim_py(
            v_tot,
            ir_tot,
            clo_tag,
            q_s,
            q_t,
            h_sig,
            const_set,
            edge_supps,
            ranks,
            hops,
            2,
            pkt["hopEntries"],
            geo_bh,
            geo_cert,
        )
    return False


def make_sample_valid_0x05_packet_py(
    snapshot_id_override: Optional[str] = None,
) -> Tuple[Tuple[Dict[str, Any], ...], bytes]:
    """Construct canonical `0x05` packet on `#40`'s `SNAP-PHI-EPLUS-SELFLOOP-A1` (or override)."""
    sid = snapshot_id_override or "SNAP-PHI-EPLUS-SELFLOOP-A1"
    snap = {
        "snapshotId": sid,
        "bucket0": ("L0", "L1"),
        "bucket1": (),
        "bucket2": (),
        "bucket3": (),
        "irRecords": (
            {"recTag": 2, "recordId": "IR-DET-01", "sourceVid": 0, "sourceSortCode": 0, "refs": ((1, 0, 1),)},
            {"recTag": 2, "recordId": "IR-DET-02", "sourceVid": 1, "sourceSortCode": 0, "refs": ((0, 0, 1),)},
            {"recTag": 2, "recordId": "IR-LOOP-01", "sourceVid": 0, "sourceSortCode": 0, "refs": ((0, 0, 1),)},
        ),
    }
    snap_b = encode_snapshot_section_py(snap)
    assert snap_b is not None
    h_sig = hashlib.sha256(mk_snapshot_preimage_py(1, PINNED_MASK_0XFF33, snap_b)).digest()
    reg = (
        PINNED_OMEGA_KAPPA_A1_REGISTRY_15
        if snapshot_id_override is None
        else (
            {
                "snapshotId": sid,
                "pinnedGen": 1,
                "pinnedRootHex": h_sig.hex(),
                "pinnedConstIds": (),
            },
        )
    )
    base = {
        "hdr": {
            "closureTag": 2,
            "claimShortest": 1,
            "authTierTag": 1,
            "reservedZero": 0,
            "generationV": 1,
            "policyMask": PINNED_MASK_0XFF33,
            "transitionTag": 0,
            "padZero": 0,
            "claimedRoot32": h_sig,
        },
        "rawSnap": snap,
        "candidateEdges": ((0, 0), (0, 1), (1, 0)),
        "candidateRelations": ((0, 0), (0, 1), (1, 0), (1, 1)),
        "posWitnesses": (
            (0, 0, 1, 0),
            (0, 1, 1, 1),
            (1, 0, 1, 0),
            (1, 1, 2, 0),
        ),
        "closedCuts": (
            (0, (0, 1)),
            (1, (0, 1)),
        ),
    }
    hops = (
        (0, 0, 1, (0,)),
        (0, 1, 1, (1,)),
        (1, 0, 1, (0,)),
        (1, 1, 2, (0,)),
    )
    b_car = encode_carrier_payload_py(2, 2, hops)
    assert b_car is not None
    h_car = hashlib.sha256(mk_carrier_preimage_py(2, h_sig, 2, 0, 1, b_car)).digest()
    geo_bh = (h_sig, h_car, 2, 2, 0, 1)
    geo_cert = {
        "closureTag": 2,
        "carrierTag": 2,
        "modeTag": 2,
        "evasionModeTag": 0,
        "claimedL": 1,
        "claimedU": 1,
        "unbreakableRefKind": 2,
        "unbreakableLocalIdx": 0,
        "unbreakableWalk": (),
        "primalWitnesses": (
            {
                "refKind": 2,
                "jIdx": 0,
                "walkVertices": (0, 1),
                "stepWitnesses": ((1, 0),),
            },
        ),
        "retractionIrIndices": (0,),
        "dualCutVids": (0,),
    }
    pkt = {
        "packetKind": 5,
        "base": base,
        "hopEntries": hops,
        "queryS": 0,
        "queryT": 1,
        "constIrIndices": (),
        "geodesicClaim": (geo_bh, geo_cert),
    }
    raw_pkt = encode_cnp2_packet_0x00_py(pkt)
    assert raw_pkt is not None
    return reg, raw_pkt


def make_sample_valid_0x03_packet_py() -> Tuple[Tuple[Dict[str, Any], ...], bytes]:
    """Construct canonical `0x03` (`Local` + `Global`) packet on `SNAP-PHI-EPLUS-SELFLOOP-A1`."""
    reg, pkt05 = make_sample_valid_0x05_packet_py()
    d05 = decode_cnp2_packet_0x00_py(pkt05)
    assert d05 is not None
    base = dict(d05["base"])
    hdr = dict(base["hdr"])
    hdr["claimShortest"] = 0
    base["hdr"] = hdr
    h_sig = hdr["claimedRoot32"]
    loc_paths = ((0, 1),)
    b_loc = encode_carrier_payload_py(2, 1, loc_paths)
    b_glob = encode_carrier_payload_py(2, 3, base["candidateEdges"])
    assert b_loc is not None and b_glob is not None
    h_loc = hashlib.sha256(mk_carrier_preimage_py(1, h_sig, 2, 0, 1, b_loc)).digest()
    h_glob = hashlib.sha256(mk_carrier_preimage_py(3, h_sig, 2, 0, 1, b_glob)).digest()
    loc_bh = (h_sig, h_loc, 2, 1, 0, 1)
    glob_bh = (h_sig, h_glob, 2, 3, 0, 1)
    loc_cert = {
        "closureTag": 2,
        "carrierTag": 1,
        "modeTag": 2,
        "evasionModeTag": 0,
        "claimedL": 1,
        "claimedU": 1,
        "unbreakableRefKind": 1,
        "unbreakableLocalIdx": 0,
        "unbreakableWalk": (),
        "primalWitnesses": (
            {
                "refKind": 1,
                "jIdx": 0,
                "walkVertices": (),
                "stepWitnesses": ((1, 0),),
            },
        ),
        "retractionIrIndices": (0,),
        "dualCutVids": (),
    }
    glob_cert = {
        "closureTag": 2,
        "carrierTag": 3,
        "modeTag": 2,
        "evasionModeTag": 0,
        "claimedL": 1,
        "claimedU": 1,
        "unbreakableRefKind": 2,
        "unbreakableLocalIdx": 0,
        "unbreakableWalk": (),
        "primalWitnesses": (
            {
                "refKind": 2,
                "jIdx": 0,
                "walkVertices": (0, 1),
                "stepWitnesses": ((1, 0),),
            },
        ),
        "retractionIrIndices": (0,),
        "dualCutVids": (0,),
    }
    pkt = {
        "packetKind": 3,
        "base": base,
        "queryS": 0,
        "queryT": 1,
        "constIrIndices": (),
        "localPaths": loc_paths,
        "localClaim": (loc_bh, loc_cert),
        "globalClaim": (glob_bh, glob_cert),
    }
    raw_pkt = encode_cnp2_packet_0x00_py(pkt)
    assert raw_pkt is not None
    return reg, raw_pkt


def _cross_check_live_kappa40_zip(
    kappa40_zip: Path,
    raw_pkt03: bytes,
    raw_pkt05: bytes,
) -> bool:
    """Dynamically run frozen `#40` `omega_kappa_microkernel` on both `0x03` and `0x05` packets."""
    if not kappa40_zip.is_file():
        return False
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        with zipfile.ZipFile(kappa40_zip, "r") as zf:
            zf.extractall(tdp)
        sys.path.insert(0, str(tdp))
        try:
            spec = importlib.util.spec_from_file_location(
                "_kappa40_ukernel_check",
                tdp / "src" / "omega_kappa_microkernel.py",
            )
            if spec is None or spec.loader is None:
                return False
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            v03 = mod.verify_omega_kappa_packet_bytes(raw_pkt03)
            v05 = mod.verify_omega_kappa_packet_bytes(raw_pkt05)
            return bool(
                v03.get("certified") is True
                and v03.get("canonical_reencode_verified") is True
                and v05.get("certified") is True
                and v05.get("canonical_reencode_verified") is True
            )
        finally:
            if sys.path and sys.path[0] == str(tdp):
                sys.path.pop(0)


def run_w2_full_packet_and_kappa40_differential(
    seed: int = 20261118,
    trials: int = 300,
    optional_kappa40_zip: Optional[Path] = None,
) -> Dict[str, Any]:
    """300-trial full `CNP-v2` (`0x03` & `0x05`) + `CNB-v1` + `Snapshot` + `SHA-256` differential."""
    rng = random.Random(seed)
    roundtrips_verified = 0
    adversarial_rejections = 0
    sha256_preimages_checked = 0

    for t_idx in range(trials):
        pkind = 3 if (t_idx % 2 == 0) else 5
        n_verts = rng.randint(2, 5)
        gen_v = rng.randint(1, 5)
        clo_tag = rng.choice((1, 2))
        sid = f"SNAP-DIFF-{t_idx:04d}-A1"
        vnames = tuple(sorted(f"V{i:02d}" for i in range(n_verts)))
        # Simple chain 0 -> 1 -> ... -> k (k >= 1)
        k_end = rng.randint(1, n_verts - 1)
        is_const = rng.choice((True, False))
        recs = []
        for i in range(k_end):
            recs.append({
                "recTag": 1 if (is_const and i == 0) else 2,
                "recordId": f"IR-{i:02d}",
                "sourceVid": i,
                "sourceSortCode": 0,
                "refs": ((i + 1, 0, 1),),
            })
        # If is_const, make all steps constitutional so modeTag=1 unbreakable holds cleanly;
        # else all steps retractable so modeTag=2 L=1, U=1 holds cleanly!
        if is_const:
            for rc in recs:
                rc["recTag"] = 1
            const_ids = tuple(rc["recordId"] for rc in recs)
            c_idxs = tuple(range(len(recs)))
        else:
            const_ids = ()
            c_idxs = ()

        snap = {
            "snapshotId": sid,
            "bucket0": vnames,
            "bucket1": (),
            "bucket2": (),
            "bucket3": (),
            "irRecords": tuple(recs),
        }
        snap_b = encode_snapshot_section_py(snap)
        if snap_b is None or decode_snapshot_section_py(snap_b) != snap:
            raise AssertionError("Snapshot roundtrip failed")
        h_sig = hashlib.sha256(mk_snapshot_preimage_py(gen_v, PINNED_MASK_0XFF33, snap_b)).digest()
        sha256_preimages_checked += 1
        reg = ({
            "snapshotId": sid,
            "pinnedGen": gen_v,
            "pinnedRootHex": h_sig.hex(),
            "pinnedConstIds": const_ids,
        },)

        cand_edges = tuple((i, i + 1) for i in range(k_end))
        ranks, hops_map = _synthesize_ranks_and_hops_py(n_verts, clo_tag, cand_edges)
        cand_rels = tuple(sorted(ranks.keys()))
        pws_list = []
        for u, v in cand_rels:
            rk = ranks[(u, v)]
            nh = NONE_VID_SENTINEL if rk == 0 else (v if rk == 1 else u + 1)
            pws_list.append((u, v, rk, nh))
        cuts = tuple(
            (u, tuple(t for s, t in cand_rels if s == u))
            for u in range(n_verts)
        )
        base = {
            "hdr": {
                "closureTag": clo_tag,
                "claimShortest": 1 if pkind == 5 else rng.choice((0, 1)),
                "authTierTag": 1,
                "reservedZero": 0,
                "generationV": gen_v,
                "policyMask": PINNED_MASK_0XFF33,
                "transitionTag": 0,
                "padZero": 0,
                "claimedRoot32": h_sig,
            },
            "rawSnap": snap,
            "candidateEdges": cand_edges,
            "candidateRelations": cand_rels,
            "posWitnesses": tuple(pws_list),
            "closedCuts": cuts,
        }
        q_s, q_t = 0, k_end
        walk_full = tuple(range(k_end + 1))

        if pkind == 3:
            loc_paths = (walk_full,)
            b_loc = encode_carrier_payload_py(n_verts, 1, loc_paths)
            b_glob = encode_carrier_payload_py(n_verts, 3, cand_edges)
            assert b_loc is not None and b_glob is not None
            h_loc = hashlib.sha256(mk_carrier_preimage_py(1, h_sig, clo_tag, q_s, q_t, b_loc)).digest()
            h_glob = hashlib.sha256(mk_carrier_preimage_py(3, h_sig, clo_tag, q_s, q_t, b_glob)).digest()
            sha256_preimages_checked += 2
            loc_bh = (h_sig, h_loc, clo_tag, 1, q_s, q_t)
            glob_bh = (h_sig, h_glob, clo_tag, 3, q_s, q_t)
            if is_const:
                loc_cert = {
                    "closureTag": clo_tag, "carrierTag": 1, "modeTag": 1, "evasionModeTag": 0,
                    "claimedL": 0, "claimedU": 0, "unbreakableRefKind": 1, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": (), "primalWitnesses": (), "retractionIrIndices": (), "dualCutVids": (),
                }
                glob_cert = {
                    "closureTag": clo_tag, "carrierTag": 3, "modeTag": 1, "evasionModeTag": 0,
                    "claimedL": 0, "claimedU": 0, "unbreakableRefKind": 2, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": walk_full, "primalWitnesses": (), "retractionIrIndices": (), "dualCutVids": (),
                }
            else:
                sws = tuple((1, i) for i in range(k_end))
                loc_cert = {
                    "closureTag": clo_tag, "carrierTag": 1, "modeTag": 2, "evasionModeTag": 0,
                    "claimedL": 1, "claimedU": 1, "unbreakableRefKind": 1, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": (),
                    "primalWitnesses": ({"refKind": 1, "jIdx": 0, "walkVertices": (), "stepWitnesses": sws},),
                    "retractionIrIndices": (0,), "dualCutVids": (),
                }
                glob_cert = {
                    "closureTag": clo_tag, "carrierTag": 3, "modeTag": 2, "evasionModeTag": 0,
                    "claimedL": 1, "claimedU": 1, "unbreakableRefKind": 2, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": (),
                    "primalWitnesses": ({"refKind": 2, "jIdx": 0, "walkVertices": walk_full, "stepWitnesses": sws},),
                    "retractionIrIndices": (0,),
                    "dualCutVids": (0,) if clo_tag == 1 else (),
                }
            pkt: Dict[str, Any] = {
                "packetKind": 3,
                "base": base,
                "queryS": q_s,
                "queryT": q_t,
                "constIrIndices": c_idxs,
                "localPaths": loc_paths,
                "localClaim": (loc_bh, loc_cert),
                "globalClaim": (glob_bh, glob_cert),
            }
        else:
            hop_entries = tuple((u, v, ranks[(u, v)], hops_map[(u, v)]) for u, v in cand_rels)
            b_geo = encode_carrier_payload_py(n_verts, 2, hop_entries)
            assert b_geo is not None
            h_geo = hashlib.sha256(mk_carrier_preimage_py(2, h_sig, clo_tag, q_s, q_t, b_geo)).digest()
            sha256_preimages_checked += 1
            geo_bh = (h_sig, h_geo, clo_tag, 2, q_s, q_t)
            if is_const:
                geo_cert = {
                    "closureTag": clo_tag, "carrierTag": 2, "modeTag": 1, "evasionModeTag": 0,
                    "claimedL": 0, "claimedU": 0, "unbreakableRefKind": 2, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": walk_full, "primalWitnesses": (), "retractionIrIndices": (), "dualCutVids": (),
                }
            else:
                sws = tuple((1, i) for i in range(k_end))
                geo_cert = {
                    "closureTag": clo_tag, "carrierTag": 2, "modeTag": 2, "evasionModeTag": 0,
                    "claimedL": 1, "claimedU": 1, "unbreakableRefKind": 2, "unbreakableLocalIdx": 0,
                    "unbreakableWalk": (),
                    "primalWitnesses": ({"refKind": 2, "jIdx": 0, "walkVertices": walk_full, "stepWitnesses": sws},),
                    "retractionIrIndices": (0,),
                    "dualCutVids": (0,),
                }
            pkt = {
                "packetKind": 5,
                "base": base,
                "hopEntries": hop_entries,
                "queryS": q_s,
                "queryT": q_t,
                "constIrIndices": c_idxs,
                "geodesicClaim": (geo_bh, geo_cert),
            }

        raw_pkt = encode_cnp2_packet_0x00_py(pkt)
        if raw_pkt is None or decode_cnp2_packet_0x00_py(raw_pkt) != pkt:
            raise AssertionError("Packet roundtrip mismatch")
        if not check_cnp2_packet_0x00_py(reg, raw_pkt):
            raise AssertionError("Valid packet failed check_cnp2_packet_0x00_py")
        roundtrips_verified += 1

        # Adversarial 1: trailing slack byte rejected
        if decode_cnp2_packet_0x00_py(raw_pkt + b"\x00") is not None:
            raise AssertionError("Trailing slack accepted")
        # Adversarial 2: pinned A1 registry rejects unpinned random snapshot (`F93-01`)
        if check_cnp2_packet_0x00_py(PINNED_OMEGA_KAPPA_A1_REGISTRY_15, raw_pkt):
            raise AssertionError("Forged snapshot accepted by pinned A1 registry")
        adversarial_rejections += 2

    _, sample03 = make_sample_valid_0x03_packet_py()
    _, sample05 = make_sample_valid_0x05_packet_py()
    kappa40_live = (
        _cross_check_live_kappa40_zip(optional_kappa40_zip, sample03, sample05)
        if optional_kappa40_zip is not None
        else False
    )

    return {
        "seed": seed,
        "trials": trials,
        "roundtrips_verified": roundtrips_verified,
        "adversarial_rejections_verified": adversarial_rejections,
        "sha256_preimages_checked": sha256_preimages_checked,
        "kappa40_live_microkernel_cross_checked": kappa40_live,
        "sha256_implementation_binding_scope": (
            "EXTERNAL_EXECUTION_DIFFERENTIAL_OBLIGATION_NOT_LEAN_KERNEL_THEOREM"
        ),
        "mismatches": 0,
    }


# =============================================================================
# Heritage Preservation Verifier (`45` Frozen Ancestor Archives, `233` Seals)
# =============================================================================

def produce_heritage_preservation_45_receipt(
    workspace_root: Path,
    w1_heritage_44_path: Path,
) -> Dict[str, Any]:
    """Verify physical byte preservation of all `45` frozen ancestor archives (`233` seals)."""
    base_44 = json.loads(w1_heritage_44_path.read_text(encoding="utf-8"))
    if not verify_seal(base_44):
        raise ValueError("Parent W1 44-archive heritage receipt seal is invalid")

    expected_list: List[Dict[str, Any]] = []
    for item in base_44["archives"]:
        expected_list.append({
            "stage_key": item["stage_key"],
            "zip_name": item["zip_name"],
            "expected_size_bytes": item["expected_size_bytes"],
            "expected_sha256": item["expected_sha256"],
            "expected_entry_count": item["expected_entry_count"],
            "expected_crc32_xor_hex": item["expected_crc32_xor_hex"],
        })

    expected_list.append({
        "stage_key": "OMEGA_LAMBDA_W1_CANONICAL_SLICE_REFINEMENT_45",
        "zip_name": "CAMPUS_NOESIS_OMEGA_LAMBDA_W1_CANONICAL_SLICE_REFINEMENT_PACKAGE.zip",
        "expected_size_bytes": 174199,
        "expected_sha256": "b6649a21e82ca809d7629246f806f93dcd863150c3ae5b860a124ed1421224fc",
        "expected_entry_count": 42,
        "expected_crc32_xor_hex": "b7afe44a",
    })

    archives_out: List[Dict[str, Any]] = []
    present_count = 0
    absent_count = 0
    all_matched = True

    for item in expected_list:
        zpath = workspace_root / item["zip_name"]
        if zpath.exists():
            present_count += 1
            metrics = compute_zip_metrics(zpath)
            matched = (
                metrics["size_bytes"] == item["expected_size_bytes"]
                and metrics["sha256"] == item["expected_sha256"]
                and metrics["entry_count"] == item["expected_entry_count"]
                and metrics["crc32_xor_hex"] == item["expected_crc32_xor_hex"]
            )
            if not matched:
                all_matched = False
            archives_out.append({
                "stage_key": item["stage_key"],
                "zip_name": item["zip_name"],
                "present_on_disk": True,
                "present_archive_matched": matched,
                "expected_size_bytes": item["expected_size_bytes"],
                "actual_size_bytes": metrics["size_bytes"],
                "expected_sha256": item["expected_sha256"],
                "actual_sha256": metrics["sha256"],
                "expected_entry_count": item["expected_entry_count"],
                "actual_entry_count": metrics["entry_count"],
                "expected_crc32_xor_hex": item["expected_crc32_xor_hex"],
                "actual_crc32_xor_hex": metrics["crc32_xor_hex"],
            })
        else:
            absent_count += 1
            all_matched = False
            archives_out.append({
                "stage_key": item["stage_key"],
                "zip_name": item["zip_name"],
                "present_on_disk": False,
                "present_archive_matched": False,
                "expected_size_bytes": item["expected_size_bytes"],
                "expected_sha256": item["expected_sha256"],
                "expected_entry_count": item["expected_entry_count"],
                "expected_crc32_xor_hex": item["expected_crc32_xor_hex"],
            })

    return seal_payload({
        "schema_version": "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_HERITAGE_PRESERVATION_45_V1",
        "stage_id": "OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "total_registered_heritage_archives": 45,
        "present_archives_on_disk_count": present_count,
        "absent_archives_on_disk_count": absent_count,
        "all_present_archives_matched": all_matched,
        "total_pinned_seals_count": 233,
        "f91_01_omega_kappa_40_physical_metrics_verified": base_44[
            "f91_01_omega_kappa_40_physical_metrics_verified"
        ],
        "pinned_173_seals_sha256": base_44["pinned_173_seals_sha256"],
        "pinned_r10_seals_174_to_177": base_44["pinned_r10_seals_174_to_177"],
        "pinned_tarm_stage0_seals_178_to_181": base_44["pinned_tarm_stage0_seals_178_to_181"],
        "pinned_omega_stage0_1_seals_182_to_185": base_44["pinned_omega_stage0_1_seals_182_to_185"],
        "pinned_omega_stage0_1_r1_seals_186_to_189": base_44["pinned_omega_stage0_1_r1_seals_186_to_189"],
        "pinned_omega_stage0_1_r2_seals_190_to_193": base_44["pinned_omega_stage0_1_r2_seals_190_to_193"],
        "pinned_omega_stage0_1_r3_seals_194_to_197": base_44["pinned_omega_stage0_1_r3_seals_194_to_197"],
        "pinned_omega_mu_stage1_0_seals_198_to_201": base_44["pinned_omega_mu_stage1_0_seals_198_to_201"],
        "pinned_omega_phi_stage1_0_seals_202_to_205": base_44["pinned_omega_phi_stage1_0_seals_202_to_205"],
        "pinned_omega_phi_r1_seals_206_to_209": base_44["pinned_omega_phi_r1_seals_206_to_209"],
        "pinned_omega_kappa_stage1_0_seals_210_to_213": base_44[
            "pinned_omega_kappa_stage1_0_seals_210_to_213"
        ],
        "pinned_omega_lambda_m1_seals_214_to_217": base_44[
            "pinned_omega_lambda_m1_seals_214_to_217"
        ],
        "pinned_omega_lambda_m1_q_seals_218_to_221": base_44[
            "pinned_omega_lambda_m1_q_seals_218_to_221"
        ],
        "pinned_omega_lambda_r1_seals_222_to_225": base_44[
            "pinned_omega_lambda_r1_seals_222_to_225"
        ],
        "pinned_omega_lambda_r2_seals_226_to_229": base_44[
            "pinned_omega_lambda_r2_seals_226_to_229"
        ],
        "pinned_omega_lambda_w1_seals_230_to_233": {
            "CAMPUS_ANCESTOR_230_OMEGA_LAMBDA_W1_ZIP_SHA256": (
                "b6649a21e82ca809d7629246f806f93dcd863150c3ae5b860a124ed1421224fc"
            ),
            "CAMPUS_ANCESTOR_231_OMEGA_LAMBDA_W1_MANIFEST_PAYLOAD_SHA256": (
                "9cc6607aba86e0c335ea442a7b3cff2f63d03efe256b1a132d683e97b3a763d6"
            ),
            "CAMPUS_ANCESTOR_232_OMEGA_LAMBDA_W1_MASTER_PAYLOAD_SHA256": (
                "755d9333a4fa784489a268b5e5d062cedb1a354d82d338d9709629df37ce6c83"
            ),
            "CAMPUS_ANCESTOR_233_OMEGA_LAMBDA_W1_QUALIFICATION_PAYLOAD_SHA256": (
                "3e893267043c6e8bea125cb92f7ade17bfa66a0660c1a40928ef3621a9fa2a03"
            ),
        },
        "archives": archives_out,
    })

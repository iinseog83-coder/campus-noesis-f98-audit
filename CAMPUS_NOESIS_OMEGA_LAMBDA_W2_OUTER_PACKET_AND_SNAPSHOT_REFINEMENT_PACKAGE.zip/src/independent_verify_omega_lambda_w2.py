#!/usr/bin/env python3
"""Zero-Shared-Code Standalone Verifier for `Ωλ-W2` (`#46`).

90th–93rd Tribunal Compliance:
  - Imports ONLY Python standard library modules (`0` imports from `src/` or `omega_lambda_*`).
  - Never trusts internal receipt `"PASS"` strings as prerequisites; recomputes all canonical
    SHA-256 seals, 20 frozen ancestor `.lean` digests, comment-stripped forbidden tokens,
    declaration tables, `CNB-v1` / `CNP-v2` (`0x03` & `0x05`) framing & `Snapshot` preimages,
    and (when `Lean 4.33.1` is present and `run_live_lean_if_present=True`) compiles all 24
    modules from source with `-DwarningAsError=true` and audits the staged `SMap` (`map₁ ++ map₂`)
    kernel environment directly.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
from typing import Any, Dict, List, Optional, Tuple
import zipfile

PINNED_LEAN_VERSION_SUBSTR = "4.33.1"
PINNED_LEAN_COMMIT = "819816b2e0a3bf405af45ae5c7af2491d8f5bee6"
W2D_MANDATORY_SCOPE = (
    "SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1"
)
ALLOWED_AXIOMS = {"propext", "Quot.sound", "Classical.choice"}

PINNED_FROZEN_20_LEAN_SHA256 = {
    "lean/OmegaLambda/PointedLTS.lean": "9db60c65b9011eda413e6b2532dc1f2ce9c52fb858494b868f4d47ced2ca2fa0",
    "lean/OmegaLambda/GraphBase.lean": "6a3ae61980e6c055b976cd3336b74d0e7fc3a23b21b808eff6be751f83f97682",
    "lean/OmegaLambda/CarrierLocalGlobal.lean": "dc9e485a9040f0181e1b69030aa4bad28c02653e3d4b4b8f9149a88ed0f8b0db",
    "lean/OmegaLambda/CarrierGeodesic.lean": "cfbba3666c55359d3d6ce0a273a979a12a6bbd3edd3285b3517071d4661cb0c3",
    "lean/OmegaLambda/CheckerSoundness.lean": "37bd33d40f38cac38c4154841549ee75c8e2dcba712394390a66dc95f5345d5b",
    "lean/OmegaLambda/KernelEvalExamples.lean": "66c7a10b28c58b50cd8a14d836aeea5721b9c1a2c3db02b1f7cccfd5987afedb",
    "lean/OmegaLambda/AxiomAudit.lean": "571e36d97bb7ad146031568bce5681e4ed20cd7bf83457108a5b596e9ccc6d3d",
    "lean/OmegaLambda.lean": "49e5182121792e921f85d1dd751efd9e214bed557ea16473f65ce407e1c143cd",
    "lean/OmegaLambda/SourceIRRefinement.lean": "0ff97275bcf9fcfde16490ce40ce98b88f3e0b4a8afc0dfd812cc5f382bfc827",
    "lean/OmegaLambda/SourceIRRefinementExamples.lean": "cd6f2d776a577d128e788a40a67ff1435b73d4ef5743664f2070eca591ce5f6a",
    "lean/OmegaLambda/R1AxiomAudit.lean": "5f97dbd7d627897278000512a302dfb2974220c75db425dce7140dcd059a57fa",
    "lean/OmegaLambdaR1.lean": "6bb6fb95406a7b11a8cbc9c57e9d12b506a8a113ab1dd7b6e85ef1e11ea94dcb",
    "lean/OmegaLambda/CertRefinement.lean": "64c829c969584a83e6e89342e76dee95f7a0f28e3243bf35ef74f2977d855748",
    "lean/OmegaLambda/CertRefinementExamples.lean": "b3a80eb22c6ff3204a172bf3f227462010bf541fb113aadeb170411becf42ab9",
    "lean/OmegaLambda/R2AxiomAudit.lean": "b17c0f4729f39b654692aa45b10d1a6055b3595f296d707412cd40e9b249ca12",
    "lean/OmegaLambdaR2.lean": "488d919bc98bf81b156eb3f0f924b61cfce5c5ee180b88485c67da86c180770d",
    "lean/OmegaLambda/WireRefinement.lean": "04e45dfd11f78e56d6751c2018ce003aa2705e36643ead22895a7393d31a1b0c",
    "lean/OmegaLambda/WireRefinementExamples.lean": "77ccb4510cd290fd574a610ad8c68fe5a0f3021eaaf6586db2c330fc3c024e92",
    "lean/OmegaLambda/W1AxiomAudit.lean": "40610eea2c9a875545f6be5c584ce9faf01b279053fd3b90d80702e174ef71e4",
    "lean/OmegaLambdaW1.lean": "4fd60360ecb6db9db8a7d323264fca8f298a76590e495188a80d8307dea2779c",
}

ORDERED_24_MODULES: Tuple[Tuple[str, str], ...] = (
    ("OmegaLambda.PointedLTS", "OmegaLambda/PointedLTS.lean"),
    ("OmegaLambda.GraphBase", "OmegaLambda/GraphBase.lean"),
    ("OmegaLambda.CarrierLocalGlobal", "OmegaLambda/CarrierLocalGlobal.lean"),
    ("OmegaLambda.CarrierGeodesic", "OmegaLambda/CarrierGeodesic.lean"),
    ("OmegaLambda.CheckerSoundness", "OmegaLambda/CheckerSoundness.lean"),
    ("OmegaLambda.KernelEvalExamples", "OmegaLambda/KernelEvalExamples.lean"),
    ("OmegaLambda.AxiomAudit", "OmegaLambda/AxiomAudit.lean"),
    ("OmegaLambda", "OmegaLambda.lean"),
    ("OmegaLambda.SourceIRRefinement", "OmegaLambda/SourceIRRefinement.lean"),
    ("OmegaLambda.SourceIRRefinementExamples", "OmegaLambda/SourceIRRefinementExamples.lean"),
    ("OmegaLambda.R1AxiomAudit", "OmegaLambda/R1AxiomAudit.lean"),
    ("OmegaLambdaR1", "OmegaLambdaR1.lean"),
    ("OmegaLambda.CertRefinement", "OmegaLambda/CertRefinement.lean"),
    ("OmegaLambda.CertRefinementExamples", "OmegaLambda/CertRefinementExamples.lean"),
    ("OmegaLambda.R2AxiomAudit", "OmegaLambda/R2AxiomAudit.lean"),
    ("OmegaLambdaR2", "OmegaLambdaR2.lean"),
    ("OmegaLambda.WireRefinement", "OmegaLambda/WireRefinement.lean"),
    ("OmegaLambda.WireRefinementExamples", "OmegaLambda/WireRefinementExamples.lean"),
    ("OmegaLambda.W1AxiomAudit", "OmegaLambda/W1AxiomAudit.lean"),
    ("OmegaLambdaW1", "OmegaLambdaW1.lean"),
    ("OmegaLambda.PacketRefinement", "OmegaLambda/PacketRefinement.lean"),
    ("OmegaLambda.PacketRefinementExamples", "OmegaLambda/PacketRefinementExamples.lean"),
    ("OmegaLambda.W2AxiomAudit", "OmegaLambda/W2AxiomAudit.lean"),
    ("OmegaLambdaW2", "OmegaLambdaW2.lean"),
)

REQUIRED_W2_THEOREMS: Tuple[str, ...] = (
    "OmegaLambda.w2b_ascii_id_forward_roundtrip",
    "OmegaLambda.w2b_ascii_id_backward_roundtrip",
    "OmegaLambda.w2b_ascii_id_byte_lex_iff_string_lex",
    "OmegaLambda.w2b_encodeSnapshotSection_domain_iff",
    "OmegaLambda.w2b_noncanonical_snapshot_encode_none",
    "OmegaLambda.w2b_snapshot_forward_roundtrip",
    "OmegaLambda.w2b_snapshot_backward_roundtrip",
    "OmegaLambda.w2b_snapshot_ir_ids_nodup",
    "OmegaLambda.w2a_cnb1_contiguous_partition_exact",
    "OmegaLambda.w2a_cnb1_encode_domain_iff",
    "OmegaLambda.w2a_cnb1_forward_roundtrip",
    "OmegaLambda.w2a_cnb1_backward_roundtrip",
    "OmegaLambda.w2a_cnp2_packet_encode_domain_iff",
    "OmegaLambda.w2a_cnp2_packet_forward_roundtrip",
    "OmegaLambda.w2a_cnp2_packet_backward_roundtrip",
    "OmegaLambda.w2c_b1_b2_implies_r1_anchor_and_graph",
    "OmegaLambda.f93_02_b1_to_b6_implies_checkVerifiedBase",
    "OmegaLambda.f93_03_synthesizeVerifiedBase_sound",
    "OmegaLambda.f93_03_packet0x03_requires_original_wire_b1_b5",
    "OmegaLambda.f93_01_arbitrary_reg_does_not_imply_trusted_a1",
    "OmegaLambda.w2d_packet_sound_relative_to_registry",
    "OmegaLambda.w2d_packet_sound_pinned_a1",
    "OmegaLambda.w2d_pinned_a1_snapshot_unique",
)

FORBIDDEN_REGEXES = (
    re.compile(r"\bsorry\b"),
    re.compile(r"\badmit\b"),
    re.compile(r"(?m)^\s*axiom\s+"),
    re.compile(r"(?m)^\s*opaque\s+"),
    re.compile(r"(?m)^\s*constant\s+"),
    re.compile(r"\bnative_decide\b"),
    re.compile(r"\bofReduceBool\b"),
    re.compile(r"\btrustCompiler\b"),
    re.compile(r"\bimplemented_by\b"),
    re.compile(r"@\[[^\]]*\bextern\b"),
    re.compile(r"\bunsafe\b"),
    re.compile(r"(?m)^\s*partial\s+def\b"),
)

DECL_HEAD_RE = re.compile(r"^(theorem|def)\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
NS_OPEN_RE = re.compile(r"^namespace\s+([A-Za-z_][A-Za-z0-9_'?.]*)")
NS_END_RE = re.compile(r"^end\s+([A-Za-z_][A-Za-z0-9_'?.]*)")


def _canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def _seal_payload_standalone(payload: Dict[str, Any]) -> Dict[str, Any]:
    body = {k: v for k, v in payload.items() if k != "seal"}
    out = dict(body)
    out["seal"] = {
        "algorithm": "SHA-256",
        "canonicalization": "CAMPUS_CANONICAL_JSON_UTF8_SORTED_KEYS_V1",
        "payload_sha256": hashlib.sha256(_canonical_json_bytes(body)).hexdigest(),
    }
    return out


def _verify_seal_standalone(obj: Dict[str, Any]) -> bool:
    seal = obj.get("seal")
    if not isinstance(seal, dict):
        return False
    body = {k: v for k, v in obj.items() if k != "seal"}
    return seal.get("payload_sha256") == hashlib.sha256(_canonical_json_bytes(body)).hexdigest()


def _strip_comments_and_strings(text: str) -> str:
    out: List[str] = []
    i, n, depth, in_str = 0, len(text), 0, False
    while i < n:
        if depth == 0 and not in_str:
            if text.startswith("/-", i):
                depth = 1
                i += 2
                continue
            if text.startswith("--", i):
                while i < n and text[i] != "\n":
                    i += 1
                continue
            if text[i] == '"':
                in_str = True
                out.append('""')
                i += 1
                continue
            out.append(text[i])
            i += 1
        elif in_str:
            if text[i] == "\\" and i + 1 < n:
                i += 2
                continue
            if text[i] == '"':
                in_str = False
            i += 1
        else:
            if text.startswith("/-", i):
                depth += 1
                i += 2
                continue
            if text.startswith("-/", i):
                depth -= 1
                i += 2
                continue
            if text[i] == "\n":
                out.append("\n")
            i += 1
    return "".join(out)


def _audit_decls_standalone(
    lean_dir: Path,
    modules: Tuple[Tuple[str, str], ...],
) -> Dict[str, Any]:
    decls: List[Tuple[str, str]] = []
    for _, rel_p in modules:
        raw = (lean_dir / rel_p).read_bytes()
        if b"\r" in raw:
            raise ValueError(f"CR byte in {rel_p}")
        cleaned = _strip_comments_and_strings(raw.decode("utf-8"))
        for rx in FORBIDDEN_REGEXES:
            if rx.search(cleaned):
                raise ValueError(f"Forbidden pattern {rx.pattern} in {rel_p}")
        ns_stack: List[str] = []
        for line in cleaned.splitlines():
            sline = line.strip()
            m_open = NS_OPEN_RE.match(sline)
            if m_open:
                ns_stack.append(m_open.group(1))
                continue
            m_end = NS_END_RE.match(sline)
            if m_end and ns_stack:
                ns_stack.pop()
                continue
            if line and not line[0].isspace():
                m_decl = DECL_HEAD_RE.match(line)
                if m_decl:
                    kind, short = m_decl.group(1), m_decl.group(2)
                    prefix = ".".join(ns_stack)
                    fqn = f"{prefix}.{short}" if prefix else short
                    decls.append((kind, fqn))
    thm_c = sum(1 for k, _ in decls if k == "theorem")
    def_c = sum(1 for k, _ in decls if k == "def")
    canon = "\n".join(sorted(f"{k}:{nm}" for k, nm in decls)) + "\n"
    return {
        "theorem": thm_c,
        "def": def_c,
        "total": len(decls),
        "decl_map": {nm: k for k, nm in decls},
        "decl_table_sha256": hashlib.sha256(canon.encode("utf-8")).hexdigest(),
    }


def _find_lean_standalone() -> Optional[Path]:
    env_b = os.environ.get("LEAN_BIN")
    if env_b is not None:
        return Path(env_b) if (env_b.strip() and Path(env_b).is_file()) else None
    wp = shutil.which("lean")
    if wp:
        return Path(wp)
    cand = Path.home() / ".elan" / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    return cand if cand.is_file() else None


STANDALONE_W2_INSPECTOR = r"""import OmegaLambdaW2
import Lean

open Lean

def cinfoVariant : ConstantInfo → String
  | .axiomInfo _ => "axiomInfo"
  | .defnInfo _ => "defnInfo"
  | .thmInfo _ => "thmInfo"
  | .opaqueInfo _ => "opaqueInfo"
  | .quotInfo _ => "quotInfo"
  | .inductInfo _ => "inductInfo"
  | .ctorInfo _ => "ctorInfo"
  | .recInfo _ => "recInfo"

def isProjectPrefix : Name → Bool
  | .anonymous => false
  | .str .anonymous s =>
      s == "OmegaLambda" || s == "OmegaLambdaR1" || s == "OmegaLambdaR2" || s == "OmegaLambdaW1" || s == "OmegaLambdaW2"
  | .str p _ => isProjectPrefix p
  | .num p _ => isProjectPrefix p

def targetMods : Array Name := #[
  `OmegaLambda.PointedLTS, `OmegaLambda.GraphBase, `OmegaLambda.CarrierLocalGlobal,
  `OmegaLambda.CarrierGeodesic, `OmegaLambda.CheckerSoundness, `OmegaLambda.KernelEvalExamples,
  `OmegaLambda.AxiomAudit, `OmegaLambda,
  `OmegaLambda.SourceIRRefinement, `OmegaLambda.SourceIRRefinementExamples,
  `OmegaLambda.R1AxiomAudit, `OmegaLambdaR1,
  `OmegaLambda.CertRefinement, `OmegaLambda.CertRefinementExamples,
  `OmegaLambda.R2AxiomAudit, `OmegaLambdaR2,
  `OmegaLambda.WireRefinement, `OmegaLambda.WireRefinementExamples,
  `OmegaLambda.W1AxiomAudit, `OmegaLambdaW1,
  `OmegaLambda.PacketRefinement, `OmegaLambda.PacketRefinementExamples,
  `OmegaLambda.W2AxiomAudit, `OmegaLambdaW2
]

#eval show MetaM Unit from do
  let env ← getEnv
  let mut idxPairs : Array (Nat × String) := #[]
  for m in targetMods do
    match env.getModuleIdx? m with
    | some idx => idxPairs := idxPairs.push (idx.toNat, m.toString)
    | none => throwError s!"FATAL: Missing module {m}"
  let allowed : List Name := [`propext, `Quot.sound, `Classical.choice]
  for (name, cinfo) in env.constants.map₁.toList ++ env.constants.map₂.toList do
    let inProj := isProjectPrefix name
    match env.getModuleIdxFor? name with
    | some midx =>
      match idxPairs.find? (fun (i, _) => i == midx.toNat) with
      | some (_, modStr) =>
        let kindStr := cinfoVariant cinfo
        if kindStr == "axiomInfo" || kindStr == "opaqueInfo" then
          throwError s!"FATAL: Forbidden {kindStr} constant {name} in {modStr}"
        let axs ← collectAxioms name
        for ax in axs do
          let s := ax.toString
          if !(allowed.contains ax) || (s.splitOn "sorry").length > 1 || (s.splitOn "._native.").length > 1 then
            throwError s!"FATAL: Disallowed axiom {ax} in {name}"
        let axCsv := String.intercalate "," (axs.toList.map Name.toString)
        IO.println s!"CONST_ROW|{modStr}|{kindStr}|{name}|{axCsv}"
      | none =>
        if inProj then
          throwError s!"FATAL: Orphan project constant outside target modules: {name}"
    | none =>
      if inProj then
        throwError s!"FATAL: Unattributed local constant in project namespace: {name}"
"""


def _standalone_w2_packet_sanity_check() -> int:
    """Zero-shared-code sanity check of `#40` `SNAP-PHI-EPLUS-SELFLOOP-A1` Snapshot & `CNP-v2` framing."""
    snap_hex = (
        "001a534e41502d5048492d45504c55532d53454c464c4f4f502d4131000200024c3000024c31"
        "0000000000000000000302000949522d4445542d303100000000010001000102000949522d44"
        "45542d303200010000010000000102000a49522d4c4f4f502d3031000000000100000001"
    )
    snap_b = bytes.fromhex(snap_hex)
    if len(snap_b) != 112:
        raise ValueError("SNAP-PHI-EPLUS-SELFLOOP-A1 wire byte length mismatch")
    snap_pre = b"CAMPUS_NOESIS_CNB1_SNAPSHOT_V1\x00" + struct.pack(">IH", 1, 0xFF33) + snap_b
    h_sig = hashlib.sha256(snap_pre).digest()
    if h_sig.hex() != "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f":
        raise ValueError("Pinned #40 SNAP-PHI-EPLUS-SELFLOOP-A1 SHA-256 root mismatch")
    hdr50 = struct.pack(">4sHBBBBIHBB32s", b"CNB1", 1, 2, 1, 1, 0, 1, 0xFF33, 0, 0, h_sig)
    if len(hdr50) != 50:
        raise ValueError("CNB-v1 50B header framing mismatch")
    env12 = struct.pack(">4sHBBI", b"CNP2", 2, 5, 0, 128)
    if len(env12) != 12:
        raise ValueError("CNP-v2 12B envelope framing mismatch")
    return 4


def verify_extracted_directory(root: Path, run_live_lean_if_present: bool = False) -> Dict[str, Any]:
    manifest_path = root / "MANIFEST.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not _verify_seal_standalone(manifest):
            raise ValueError("MANIFEST.json seal invalid")
        for fentry in manifest["files"]:
            fp = root / fentry["path"]
            raw = fp.read_bytes()
            if b"\r" in raw:
                raise ValueError(f"CR byte detected in {fentry['path']}")
            if len(raw) != fentry["size_bytes"]:
                raise ValueError(f"Size mismatch on {fentry['path']}")
            if hashlib.sha256(raw).hexdigest() != fentry["sha256"]:
                raise ValueError(f"SHA-256 mismatch on {fentry['path']}")

    for rpath in sorted((root / "receipts").glob("*.json")):
        robj = json.loads(rpath.read_text(encoding="utf-8"))
        if not _verify_seal_standalone(robj):
            raise ValueError(f"Invalid receipt seal: {rpath.name}")

    contract = json.loads((root / "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_CONTRACT.json").read_text("utf-8"))
    if contract["authorized_scope"]["w2d_composition_scope"] != W2D_MANDATORY_SCOPE:
        raise ValueError("Missing mandatory W2D scope tag in contract")
    base = contract["frozen_ancestor_baseline"]
    if (
        base["frozen_omega_kappa_40_entry_count"],
        base["frozen_omega_kappa_40_crc32_xor_hex"],
        base["frozen_w1_45_crc32_xor_hex"],
    ) != (21, "2e2a1817", "b7afe44a"):
        raise ValueError("Physical ancestor baseline mismatch in contract")

    for rel_p, exp_sha in PINNED_FROZEN_20_LEAN_SHA256.items():
        act_sha = hashlib.sha256((root / rel_p).read_bytes()).hexdigest()
        if act_sha != exp_sha:
            raise ValueError(f"Frozen ancestor .lean modified: {rel_p}")

    full_static = _audit_decls_standalone(root / "lean", ORDERED_24_MODULES)
    w1_comb_static = _audit_decls_standalone(root / "lean", ORDERED_24_MODULES[:20])
    w2_static = _audit_decls_standalone(root / "lean", ORDERED_24_MODULES[20:])
    if (
        w1_comb_static["theorem"],
        w1_comb_static["def"],
        w1_comb_static["decl_table_sha256"],
    ) != (359, 334, "0a1c2e05b489ef14687bb135bccefc7eec5f2335b933c55fe87db2f9da8d5047"):
        raise ValueError("Inherited #41+#43+#44+#45 declaration count/digest drift")
    for req_thm in REQUIRED_W2_THEOREMS:
        if w2_static["decl_map"].get(req_thm) != "theorem":
            raise ValueError(f"Missing required W2 theorem: {req_thm}")

    env_rec = json.loads(
        (root / "receipts" / "OMEGA_LAMBDA_W2_ENV_COVERAGE_RECEIPT.json").read_text("utf-8")
    )
    kinds = (
        "thmInfo",
        "defnInfo",
        "inductInfo",
        "ctorInfo",
        "recInfo",
        "quotInfo",
        "axiomInfo",
        "opaqueInfo",
    )
    sum_all = 0
    for mod_name, row in env_rec["per_module_constant_info_breakdown"].items():
        if row["axiomInfo"] != 0 or row["opaqueInfo"] != 0:
            raise ValueError(f"Forbidden axiom/opaque in {mod_name}")
        ks = sum(row[k] for k in kinds)
        if ks != row["total"]:
            raise ValueError(f"ConstantInfo sum mismatch in {mod_name}")
        sum_all += ks
    if (
        env_rec["m1_kernel_constants_count"] != 1316
        or env_rec["r1_new_kernel_constants_count"] != 457
        or env_rec["r2_new_kernel_constants_count"] != 441
        or env_rec["w1_new_kernel_constants_count"] != 589
        or sum_all != env_rec["combined_kernel_constants_count"]
    ):
        raise ValueError("Kernel constant count invariant mismatch")

    wire_checks = _standalone_w2_packet_sanity_check()

    live_reexecuted = False
    if run_live_lean_if_present:
        lean_bin = _find_lean_standalone()
        if lean_bin is not None:
            ver = subprocess.run(
                [str(lean_bin), "--version"], capture_output=True, text=True, check=True
            ).stdout.strip()
            if PINNED_LEAN_VERSION_SUBSTR not in ver or PINNED_LEAN_COMMIT not in ver:
                raise ValueError(f"Lean version/commit mismatch: {ver}")
            with tempfile.TemporaryDirectory() as td:
                tdp = Path(td)
                shutil.copytree(root / "lean", tdp / "lean")
                ol_root = tdp / "_olean"
                (ol_root / "OmegaLambda").mkdir(parents=True, exist_ok=True)
                env = dict(os.environ)
                env["LEAN_PATH"] = str(ol_root)
                for mod_n, rel_p in ORDERED_24_MODULES:
                    ol_out = ol_root / Path(rel_p).with_suffix(".olean")
                    pr = subprocess.run(
                        [str(lean_bin), "-DwarningAsError=true", "-o", str(ol_out), f"lean/{rel_p}"],
                        cwd=str(tdp),
                        env=env,
                        capture_output=True,
                        text=True,
                    )
                    if pr.returncode != 0 or pr.stderr.strip():
                        raise ValueError(f"Lean compile failed on {mod_n}: {pr.stdout}\n{pr.stderr}")
                insp_f = tdp / "_StandaloneW2Insp.lean"
                insp_f.write_text(STANDALONE_W2_INSPECTOR, encoding="utf-8", newline="\n")
                ipr = subprocess.run(
                    [str(lean_bin), "_StandaloneW2Insp.lean"],
                    cwd=str(tdp),
                    env=env,
                    capture_output=True,
                    text=True,
                )
                if ipr.returncode != 0 or ipr.stderr.strip():
                    raise ValueError(f"Inspector failed: {ipr.stdout}\n{ipr.stderr}")
                rows = []
                for ln in ipr.stdout.splitlines():
                    s = ln.strip()
                    if not s:
                        continue
                    _, mn, kd, cn, axc = s.split("|", 4)
                    axs = sorted(a for a in axc.split(",") if a)
                    if not set(axs).issubset(ALLOWED_AXIOMS):
                        raise ValueError(f"Disallowed axioms on {cn}: {axs}")
                    rows.append(f"{mn}|{kd}|{cn}|{','.join(axs)}")
                ledger_sha = hashlib.sha256(("\n".join(sorted(rows)) + "\n").encode("utf-8")).hexdigest()
                if len(rows) != sum_all or ledger_sha != env_rec["combined_kernel_ledger_sha256"]:
                    raise ValueError("Live Lean ledger mismatch against receipt")
                live_reexecuted = True

    return {
        "verdict": "PASS",
        "zero_shared_code_verifier": True,
        "w2d_composition_scope": W2D_MANDATORY_SCOPE,
        "frozen_20_lean_files_byte_identical": True,
        "w2_new_decl_counts": {
            "theorem": w2_static["theorem"],
            "def": w2_static["def"],
            "total": w2_static["total"],
            "decl_table_sha256": w2_static["decl_table_sha256"],
        },
        "combined_decl_counts": {
            "theorem": full_static["theorem"],
            "def": full_static["def"],
            "total": full_static["total"],
            "decl_table_sha256": full_static["decl_table_sha256"],
        },
        "combined_kernel_constants_verified_in_receipt": sum_all,
        "standalone_packet_checks": wire_checks,
        "live_lean_reexecuted": live_reexecuted,
    }


def run_detached_package_verification(
    package_root: Path,
    zip_path: Optional[Path] = None,
) -> Dict[str, Any]:
    if zip_path is not None and zip_path.exists():
        with tempfile.TemporaryDirectory() as td:
            tdp = Path(td)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(tdp)
            res = verify_extracted_directory(tdp, run_live_lean_if_present=False)
    else:
        res = verify_extracted_directory(package_root, run_live_lean_if_present=False)

    return _seal_payload_standalone({
        "schema_version": "CAMPUS_NOESIS_OMEGA_LAMBDA_W2_INDEPENDENT_VERIFICATION_RECEIPT_V1",
        "stage_id": "OMEGA-LAMBDA-W2-OUTER-PACKET-AND-SNAPSHOT-REFINEMENT-PROOF-TRACK",
        "zero_shared_code_verifier": True,
        "w2d_composition_scope": W2D_MANDATORY_SCOPE,
        "detached_offline_verification_verdict": res["verdict"],
        "frozen_20_lean_files_byte_identical": res["frozen_20_lean_files_byte_identical"],
        "w2_new_decl_counts": res["w2_new_decl_counts"],
        "combined_decl_counts": res["combined_decl_counts"],
        "combined_kernel_constants_verified_in_receipt": res[
            "combined_kernel_constants_verified_in_receipt"
        ],
    })


if __name__ == "__main__":
    pkg_dir = Path(__file__).resolve().parent.parent
    out = verify_extracted_directory(
        pkg_dir, run_live_lean_if_present=("--allow-offline" not in sys.argv)
    )
    print(json.dumps(out, indent=2, sort_keys=True))

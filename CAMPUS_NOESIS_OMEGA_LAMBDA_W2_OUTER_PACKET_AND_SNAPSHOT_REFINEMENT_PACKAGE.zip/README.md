# CAMPUS-NOESIS `Ωλ-W2` (`#46`)
## Outer `CNB-v1` / `CNP-v2` Packet & Raw `Snapshot` Refinement Lean 4 Proof Track

- **Mandatory Scope**: `SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1`
- **Inherited Frozen `.lean` Files (`20`, Byte-Identical)**: `#41` (`8`) + `#43` (`4`) + `#44` (`4`) + `#45` (`4`)
- **New `Ωλ-W2` `.lean` Files (`4`)**:
  - `lean/OmegaLambda/PacketRefinement.lean`
  - `lean/OmegaLambda/PacketRefinementExamples.lean`
  - `lean/OmegaLambda/W2AxiomAudit.lean`
  - `lean/OmegaLambdaW2.lean`

## Offline & Live Verification Commands

```bash
# 1. Offline + Conditional Live Lean Unittest Suite
python -m unittest discover -s tests -v

# 2. Zero-Shared-Code Standalone Verifier (0 imports from src/ harness)
python src/independent_verify_omega_lambda_w2.py
```

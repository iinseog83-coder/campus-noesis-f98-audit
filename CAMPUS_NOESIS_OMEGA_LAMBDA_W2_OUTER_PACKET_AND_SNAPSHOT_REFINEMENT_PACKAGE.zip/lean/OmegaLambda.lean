/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Root Umbrella Module: `OmegaLambda`
-/

import OmegaLambda.PointedLTS
import OmegaLambda.GraphBase
import OmegaLambda.CarrierLocalGlobal
import OmegaLambda.CarrierGeodesic
import OmegaLambda.CheckerSoundness
import OmegaLambda.KernelEvalExamples
import OmegaLambda.AxiomAudit

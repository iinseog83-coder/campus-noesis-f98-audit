/-
  CAMPUS-NOESIS Omega-Lambda W2: Root Aggregator Module (`#46`)
  Imports all 20 frozen `#41` + `#43` + `#44` + `#45` modules (via `OmegaLambdaW1`) plus
  `OmegaLambda.PacketRefinement`, `OmegaLambda.PacketRefinementExamples`, and
  `OmegaLambda.W2AxiomAudit`.
-/

import OmegaLambdaW1
import OmegaLambda.PacketRefinement
import OmegaLambda.PacketRefinementExamples
import OmegaLambda.W2AxiomAudit

/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 6: `OmegaLambda.AxiomAudit`

  Transitive Kernel Axiom Audit (`F81-02` & 82nd Ruling):
  Queries the Lean 4 logical kernel for every transitive axiom dependency of
  all flagship theorems and concrete kernel-evaluation theorems.
-/

import OmegaLambda.KernelEvalExamples

#print axioms OmegaLambda.lts_unb
#print axioms OmegaLambda.checkUnbreakableWalk_sound
#print axioms OmegaLambda.lts_lower
#print axioms OmegaLambda.checkLowerPacking_sound
#print axioms OmegaLambda.lts_cut_iff
#print axioms OmegaLambda.checkClosedCut_sound
#print axioms OmegaLambda.checkVerifiedBase_sound
#print axioms OmegaLambda.b5_rank_lower_bound
#print axioms OmegaLambda.b5_rank_achievable
#print axioms OmegaLambda.b5_rank_iff_true_shortest
#print axioms OmegaLambda.b6_maxHops_iff
#print axioms OmegaLambda.levelB_implies_levelA
#print axioms OmegaLambda.ref_loc_reflexive_levelA
#print axioms OmegaLambda.f82_01_local_reflexive_not_path_bijection
#print axioms OmegaLambda.no_cross_path_splicing
#print axioms OmegaLambda.ref_loc_positive_levelB
#print axioms OmegaLambda.ref_loc_positive_levelA
#print axioms OmegaLambda.ref_glob_star_levelB
#print axioms OmegaLambda.ref_glob_star_levelA
#print axioms OmegaLambda.glob_plus_walk_pos_length
#print axioms OmegaLambda.ref_glob_plus_levelB
#print axioms OmegaLambda.ref_glob_plus_levelA
#print axioms OmegaLambda.geo_grading
#print axioms OmegaLambda.geo_walk_exact_length
#print axioms OmegaLambda.ref_geo_levelB
#print axioms OmegaLambda.ref_geo_levelA
#print axioms OmegaLambda.geo_excludes_longer_detour
#print axioms OmegaLambda.geodesic_vs_global_plus_distinction
#print axioms OmegaLambda.checkLTSCert_sound
#print axioms OmegaLambda.omegaLambda_resilience_sound
#print axioms OmegaLambda.omegaLambda_exact_resilience_sound
#print axioms OmegaLambda.Examples.ex1_f82_01_semantic_unbreakable
#print axioms OmegaLambda.Examples.ex2_local_positive_exact_2
#print axioms OmegaLambda.Examples.ex4_eplus_self_cycle_exact_1

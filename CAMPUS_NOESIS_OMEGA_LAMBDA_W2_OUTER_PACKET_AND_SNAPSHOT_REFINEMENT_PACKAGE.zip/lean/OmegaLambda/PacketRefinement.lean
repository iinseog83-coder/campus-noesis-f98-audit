/-
  CAMPUS-NOESIS Omega-Lambda W2: Outer Packet & Raw Snapshot Refinement Proof Track (`#46`)
  Module: `OmegaLambda.PacketRefinement`

  93rd Independent Static Tribunal Authorization & Mandatory Guards:
    - Scope Tag (`W2-D`):
        `SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1`
    - `W2-A`: Outer 12-byte `CNP-v2` envelope (`>4sHBBI`), 50-byte `CNB-v1` preamble/header
      (`>4sH` + `>BBBBIHBB32s`), contiguous non-overlapping 3-section `u32be` framing
      (`B_Σ`, `B_cand`, `B_prf`), and asymmetric `0x03` (`C1+C3`, deriving `Global` carrier
      from `B_cnb1.candidateEdges`) vs `0x05` (`C2`, inline `GeodesicHopBundle`) bidirectional
      canonical byte roundtrips (`F91-03` guarded encoder/decoder discipline).
    - `W2-B`: Restricted 66-byte ASCII identifier codec & byte-vs-string lexicographic order
      isomorphism, 4-sort bucketed vertex universe, `RawWireIRRecord` (`recTag` preserved in
      raw bytes and root preimage), and bidirectional `Snapshot` section roundtrips.
    - `W2-C`: Elimination of `TRUSTED_SNAPSHOT_INPUT` (`F92-01`) via deterministic projection
      `projectRawToSourceSnapshot`, plus STRICTLY INDEPENDENT base-refinement branches:
        * Branch `0x05` (`F93-02`): Machine-checked bridge from `#40` `B1..B6` (`claimShortest = 1`
          + `posWitnesses` + `closedCuts` + `hopEntries`) to untouched `#41` `checkVerifiedBase`.
        * Branch `0x03` (`F93-03`): 4-Gate non-laundering architecture enforcing original wire
          `B1..B5` (`Gate 1`) alongside pure Bellman-Ford / shortest-step synthesis
          `synthesizeVerifiedBase` (`Gate 2`), independent `checkVerifiedBase` (`Gate 3`), and
          `Local` + `Global` slice composition (`Gate 4`).
    - `W2-D` & `F93-01`: Explicit `A1` registry authority binding separating Level 1 relative
      soundness (`SourceSoundnessRelativeTo`) from Level 2 pinned `A1` soundness
      (`PinnedA1SourceSoundness` under `TrustedA1Registry`), plus external `hash256` boundary
      (`F91-02`) and local `NoCollisionOn` uniqueness.

  Discipline:
    - `sorryAx = 0`, user `axiom = 0`, `opaque = 0`
    - `Lean.ofReduceBool = 0`, `Lean.trustCompiler = 0` (`native_decide` prohibited)
-/

import OmegaLambda.WireRefinement

namespace OmegaLambda

/-! ## Wire Budget Constants & Magic Bytes (`#40` `omega_kappa_decoder.py` L42–60) -/

def cnb1WireVersion : Nat := 1
def cnp2WireVersion : Nat := 2
def cnp2EnvelopeSizeBytes : Nat := 12
def cnb1FixedHeaderSizeBytes : Nat := 50
def cnb1MinBundleSizeBytes : Nat := 62
def maxPacketBytes : Nat := 2097152
def maxAsciiIdLen : Nat := 128
def maxRefsPerRecord : Nat := 512
def maxGenerationOrRank : Nat := 999999999

def cnb1MagicBytes : List UInt8 := [0x43, 0x4E, 0x42, 0x31]  -- `"CNB1"`
def cnp2MagicBytes : List UInt8 := [0x43, 0x4E, 0x50, 0x32]  -- `"CNP2"`

/-! ## `W2-A` Part I: Fixed Magic & `u32be`-Length-Prefixed Section Combinators -/

def parseExactMagic (expected : List UInt8) (bs : List UInt8) : Option (Unit × List UInt8) :=
  match splitAtExact expected.length bs with
  | none => none
  | some (pre, suf) => if decide (pre = expected) then some ((), suf) else none

theorem parseExactMagic_append (expected rest : List UInt8) :
    parseExactMagic expected (expected ++ rest) = some ((), rest) := by
  unfold parseExactMagic
  rw [splitAtExact_append rfl rest]
  simp

theorem parseExactMagic_eq_some {expected bs rest : List UInt8}
    (h : parseExactMagic expected bs = some ((), rest)) :
    bs = expected ++ rest := by
  unfold parseExactMagic at h
  cases hs : splitAtExact expected.length bs with
  | none => rw [hs] at h; cases h
  | some pair =>
    rw [hs] at h
    rcases pair with ⟨pre, suf⟩
    dsimp only at h
    split at h
    · next heqB =>
      have heq : pre = expected := of_decide_eq_true heqB
      injection h with hp
      rcases Prod.mk.inj hp with ⟨_, hsuf⟩
      subst heq; subst hsuf
      exact (splitAtExact_eq_some hs).2
    · cases h

def encodeLenSliceList (sec : List UInt8) : List UInt8 :=
  packU32BE sec.length ++ sec

def parseLenSlice (bs : List UInt8) : Option (List UInt8 × List UInt8) :=
  match parseU32BE bs with
  | none => none
  | some (secLen, bs1) => splitAtExact secLen bs1

theorem parseLenSlice_encode_append {sec : List UInt8}
    (hlt : sec.length < 4294967296) (rest : List UInt8) :
    parseLenSlice (encodeLenSliceList sec ++ rest) = some (sec, rest) := by
  unfold encodeLenSliceList parseLenSlice
  rw [List.append_assoc, parseU32BE_packU32BE_append hlt]
  dsimp only
  exact splitAtExact_append rfl rest

theorem parseLenSlice_eq_some {bs rest sec : List UInt8}
    (h : parseLenSlice bs = some (sec, rest)) :
    sec.length < 4294967296 ∧ bs = encodeLenSliceList sec ++ rest := by
  unfold parseLenSlice at h
  cases h1 : parseU32BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h
    rcases p1 with ⟨secLen, bs1⟩
    dsimp only at h
    rcases parseU32BE_eq_some h1 with ⟨hlenLt, e1⟩
    rcases splitAtExact_eq_some h with ⟨hsecLen, e2⟩
    subst hsecLen
    refine ⟨hlenLt, ?_⟩
    rw [e1, e2]
    simp [encodeLenSliceList, List.append_assoc]

/-! ## `W2-B`: Restricted 66-Byte ASCII Identifier Grammar & `RawSnapshotWireTerm` Bijection -/

/-- Exact 66-character `#40` `_ALLOWED_ASCII_BYTES` (`A-Za-z0-9_.:-`, `omega_kappa_decoder.py` L74–76). -/
def isAllowedAsciiCode (n : Nat) : Bool :=
  decide ((65 ≤ n ∧ n ≤ 90) ∨ (97 ≤ n ∧ n ≤ 122) ∨ (48 ≤ n ∧ n ≤ 57) ∨
          n = 95 ∨ n = 46 ∨ n = 58 ∨ n = 45)

theorem allowedAsciiCode_lt_256 {n : Nat} (h : isAllowedAsciiCode n = true) : n < 256 := by
  unfold isAllowedAsciiCode at h
  have hp := of_decide_eq_true h
  omega

def asciiCodeToChar : Nat → Char
  | 45 => '-' | 46 => '.'
  | 48 => '0' | 49 => '1' | 50 => '2' | 51 => '3' | 52 => '4'
  | 53 => '5' | 54 => '6' | 55 => '7' | 56 => '8' | 57 => '9'
  | 58 => ':'
  | 65 => 'A' | 66 => 'B' | 67 => 'C' | 68 => 'D' | 69 => 'E' | 70 => 'F' | 71 => 'G'
  | 72 => 'H' | 73 => 'I' | 74 => 'J' | 75 => 'K' | 76 => 'L' | 77 => 'M' | 78 => 'N'
  | 79 => 'O' | 80 => 'P' | 81 => 'Q' | 82 => 'R' | 83 => 'S' | 84 => 'T' | 85 => 'U'
  | 86 => 'V' | 87 => 'W' | 88 => 'X' | 89 => 'Y' | 90 => 'Z'
  | 95 => '_'
  | 97 => 'a' | 98 => 'b' | 99 => 'c' | 100 => 'd' | 101 => 'e' | 102 => 'f' | 103 => 'g'
  | 104 => 'h' | 105 => 'i' | 106 => 'j' | 107 => 'k' | 108 => 'l' | 109 => 'm' | 110 => 'n'
  | 111 => 'o' | 112 => 'p' | 113 => 'q' | 114 => 'r' | 115 => 's' | 116 => 't' | 117 => 'u'
  | 118 => 'v' | 119 => 'w' | 120 => 'x' | 121 => 'y' | 122 => 'z'
  | _ => '!'

private def checkAsciiToNatFin (fn : Fin 128) : Bool :=
  !(isAllowedAsciiCode fn.val) || decide ((asciiCodeToChar fn.val).toNat = fn.val)

private theorem checkAsciiToNatFin_all : ∀ fn : Fin 128, checkAsciiToNatFin fn = true := by
  decide

theorem asciiCodeToChar_toNat {n : Nat} (h : isAllowedAsciiCode n = true) :
    (asciiCodeToChar n).toNat = n := by
  have hlt128 : n < 128 := by
    unfold isAllowedAsciiCode at h
    have hp := of_decide_eq_true h
    omega
  have hf := checkAsciiToNatFin_all ⟨n, hlt128⟩
  unfold checkAsciiToNatFin at hf
  dsimp only at hf
  rw [h] at hf
  simp only [Bool.not_true, Bool.false_or, decide_eq_true_eq] at hf
  exact hf

theorem char_eq_of_toNat_eq {c1 c2 : Char} (h : c1.toNat = c2.toNat) : c1 = c2 := by
  cases c1 with
  | mk v1 _ =>
    cases c2 with
    | mk v2 _ =>
      cases v1 with
      | ofBitVec bv1 =>
        cases v2 with
        | ofBitVec bv2 =>
          have hbv : bv1 = bv2 := BitVec.eq_of_toNat_eq h
          subst hbv
          rfl

theorem asciiCodeToChar_id_of_allowed {c : Char}
    (h : isAllowedAsciiCode c.toNat = true) :
    asciiCodeToChar c.toNat = c :=
  char_eq_of_toNat_eq (asciiCodeToChar_toNat h)

def charToByteRaw (c : Char) : UInt8 :=
  UInt8.ofNat c.toNat

def wfAsciiIdBool (s : AsciiId) : Bool :=
  let cs := s.toList
  decide (1 ≤ cs.length) &&
  decide (cs.length ≤ maxAsciiIdLen) &&
  listAllBool (fun c => isAllowedAsciiCode c.toNat) cs

def encodeAsciiIdList (s : AsciiId) : List UInt8 :=
  let cs := s.toList
  packU16BE cs.length ++ cs.map charToByteRaw

def parseAsciiId (bs : List UInt8) : Option (AsciiId × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (sLen, bs1) =>
      if decide (1 ≤ sLen ∧ sLen ≤ maxAsciiIdLen) then
        match splitAtExact sLen bs1 with
        | none => none
        | some (rawBytes, bs2) =>
            if listAllBool (fun b => isAllowedAsciiCode b.toNat) rawBytes then
              some (String.ofList (rawBytes.map (fun b => asciiCodeToChar b.toNat)), bs2)
            else none
      else none

theorem map_char_uint8_roundtrip :
    ∀ {cs : List Char},
      listAllBool (fun c => isAllowedAsciiCode c.toNat) cs = true →
      listAllBool (fun b => isAllowedAsciiCode b.toNat) (cs.map charToByteRaw) = true ∧
      (cs.map charToByteRaw).map (fun b => asciiCodeToChar b.toNat) = cs
  | [], _ => ⟨rfl, rfl⟩
  | c :: tl, hall => by
      simp only [listAllBool, Bool.and_eq_true] at hall
      rcases hall with ⟨hc, htl⟩
      rcases map_char_uint8_roundtrip htl with ⟨hbtl, hmaptl⟩
      have hu : (charToByteRaw c).toNat = c.toNat :=
        uint8_ofNat_toNat_lt (allowedAsciiCode_lt_256 hc)
      refine ⟨?_, ?_⟩
      · simp only [List.map_cons, listAllBool, hu, hc, hbtl, Bool.and_self]
      · simp only [List.map_cons, hu, asciiCodeToChar_id_of_allowed hc, hmaptl]

theorem map_uint8_char_roundtrip :
    ∀ {rawBytes : List UInt8},
      listAllBool (fun b => isAllowedAsciiCode b.toNat) rawBytes = true →
      listAllBool (fun c => isAllowedAsciiCode c.toNat) (rawBytes.map (fun b => asciiCodeToChar b.toNat)) = true ∧
      (rawBytes.map (fun b => asciiCodeToChar b.toNat)).map charToByteRaw = rawBytes
  | [], _ => ⟨rfl, rfl⟩
  | b :: tl, hall => by
      simp only [listAllBool, Bool.and_eq_true] at hall
      rcases hall with ⟨hb, htl⟩
      rcases map_uint8_char_roundtrip htl with ⟨hctl, hmaptl⟩
      have hc : (asciiCodeToChar b.toNat).toNat = b.toNat := asciiCodeToChar_toNat hb
      refine ⟨?_, ?_⟩
      · simp only [List.map_cons, listAllBool, hc, hb, hctl, Bool.and_self]
      · simp only [List.map_cons, charToByteRaw, hc, uint8_ofNat_toNat_id b, hmaptl]

theorem parseAsciiId_encode_append {s : AsciiId}
    (hwf : wfAsciiIdBool s = true) (rest : List UInt8) :
    parseAsciiId (encodeAsciiIdList s ++ rest) = some (s, rest) := by
  unfold wfAsciiIdBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨hge1, hle128⟩, hallC⟩
  have hlt64k : s.toList.length < 65536 := by unfold maxAsciiIdLen at hle128; omega
  rcases map_char_uint8_roundtrip hallC with ⟨hallB, hmapId⟩
  unfold encodeAsciiIdList parseAsciiId
  rw [List.append_assoc, parseU16BE_packU16BE_append hlt64k]
  dsimp only
  rw [if_pos (decide_eq_true ⟨hge1, hle128⟩)]
  have hlenMap : (s.toList.map charToByteRaw).length = s.toList.length := List.length_map _
  rw [splitAtExact_append hlenMap rest]
  dsimp only
  rw [if_pos hallB, hmapId, String.ofList_toList]

theorem parseAsciiId_eq_some {bs rest : List UInt8} {s : AsciiId}
    (h : parseAsciiId bs = some (s, rest)) :
    wfAsciiIdBool s = true ∧ bs = encodeAsciiIdList s ++ rest := by
  unfold parseAsciiId at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨sLen, bs1⟩; dsimp only at h
    split at h
    · next hlenB =>
      rcases of_decide_eq_true hlenB with ⟨hge1, hle128⟩
      cases h2 : splitAtExact sLen bs1 with
      | none => rw [h2] at h; cases h
      | some p2 =>
        rw [h2] at h; rcases p2 with ⟨rawBytes, bs2⟩; dsimp only at h
        split at h
        · next hallB =>
          simp only [Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨hsEq, hrest⟩
          subst hsEq; subst hrest
          rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
          rcases splitAtExact_eq_some h2 with ⟨hrawLen, e2⟩
          rcases map_uint8_char_roundtrip hallB with ⟨hallC, hmapEq⟩
          refine ⟨?_, ?_⟩
          · unfold wfAsciiIdBool
            rw [String.toList_ofList]
            simp [List.length_map, hrawLen, hge1, hle128, hallC]
          · unfold encodeAsciiIdList
            dsimp only
            rw [String.toList_ofList, List.length_map, hrawLen, hmapEq, e1, e2]
            simp [List.append_assoc]
        · cases h
    · cases h

def encodeAsciiIdSlice (s : AsciiId) : Option ByteArray :=
  encodeGuardedSlice wfAsciiIdBool encodeAsciiIdList s

def decodeAsciiIdSlice (raw : ByteArray) : Option AsciiId :=
  decodeExactSlice parseAsciiId raw

theorem w2b_ascii_id_forward_roundtrip {s : AsciiId} (hwf : wfAsciiIdBool s = true) :
    ∃ B, encodeAsciiIdSlice s = some B ∧ decodeAsciiIdSlice B = some s :=
  guardedSlice_forward_roundtrip wfAsciiIdBool encodeAsciiIdList parseAsciiId
    (fun _ r hw => parseAsciiId_encode_append hw r) hwf

theorem w2b_ascii_id_backward_roundtrip {B : ByteArray} {s : AsciiId}
    (hdec : decodeAsciiIdSlice B = some s) :
    wfAsciiIdBool s = true ∧ encodeAsciiIdSlice s = some B :=
  guardedSlice_backward_roundtrip wfAsciiIdBool encodeAsciiIdList parseAsciiId
    (fun _ _ _ hp => parseAsciiId_eq_some hp) hdec

/-- Code-point lexicographic order on `AsciiId`, proved order-isomorphic to `#40` byte order (`m_r <= prev_raw`). -/
def asciiLtBool (s1 s2 : AsciiId) : Bool :=
  lexLtNatListBool (s1.toList.map Char.toNat) (s2.toList.map Char.toNat)

theorem asciiLtBool_irrefl (s : AsciiId) : asciiLtBool s s = false :=
  lexLtNatList_irrefl (s.toList.map Char.toNat)

theorem asciiLtBool_trans {s1 s2 s3 : AsciiId}
    (h12 : asciiLtBool s1 s2 = true) (h23 : asciiLtBool s2 s3 = true) :
    asciiLtBool s1 s3 = true :=
  lexLtNatList_trans h12 h23

theorem strictLexAsciiIds_nodup {xs : List AsciiId}
    (h : strictSortedByBool asciiLtBool xs = true) :
    NodupList xs :=
  strictSortedBy_nodup asciiLtBool_irrefl (fun _ _ _ h1 h2 => asciiLtBool_trans h1 h2) h

theorem map_charToByteRaw_toNat :
    ∀ {cs : List Char},
      listAllBool (fun c => isAllowedAsciiCode c.toNat) cs = true →
      (cs.map charToByteRaw).map UInt8.toNat = cs.map Char.toNat
  | [], _ => rfl
  | c :: tl, hall => by
      simp only [listAllBool, Bool.and_eq_true] at hall
      have hu : (charToByteRaw c).toNat = c.toNat :=
        uint8_ofNat_toNat_lt (allowedAsciiCode_lt_256 hall.1)
      simp only [List.map_cons, hu, map_charToByteRaw_toNat hall.2]

/-- **`W2-B` Order-Isomorphism Theorem**:
    Raw ASCII wire byte order (`m_r1 < m_r2` in `#40` L202 & L231) is strictly equivalent
    to `asciiLtBool s1 s2`. -/
theorem w2b_ascii_id_byte_lex_iff_string_lex {s1 s2 : AsciiId}
    (hwf1 : wfAsciiIdBool s1 = true) (hwf2 : wfAsciiIdBool s2 = true) :
    lexLtNatListBool
      ((s1.toList.map charToByteRaw).map UInt8.toNat)
      ((s2.toList.map charToByteRaw).map UInt8.toNat) =
    asciiLtBool s1 s2 := by
  unfold wfAsciiIdBool at hwf1 hwf2
  simp only [Bool.and_eq_true] at hwf1 hwf2
  rw [map_charToByteRaw_toNat hwf1.2, map_charToByteRaw_toNat hwf2.2]
  rfl

/-! ## `W2-B` `RawWireRef`, `RawWireIRRecord`, & `RawSnapshotWireTerm` (`#40` L176–291) -/

structure RawWireRef where
  targetVid : VertexId
  targetSortCode : Nat
  relTag : Nat
  deriving DecidableEq, Repr

def wfRawWireRefBool (vTotal : Nat) (r : RawWireRef) : Bool :=
  wfVertexWireBool vTotal r.targetVid &&
  decide (r.targetSortCode ≤ 3) &&
  decide (1 ≤ r.relTag ∧ r.relTag ≤ 13)

def rawWireRefLtBool (r1 r2 : RawWireRef) : Bool :=
  if r1.targetVid < r2.targetVid then true
  else if r2.targetVid < r1.targetVid then false
  else if r1.targetSortCode < r2.targetSortCode then true
  else if r2.targetSortCode < r1.targetSortCode then false
  else decide (r1.relTag < r2.relTag)

def encodeRawWireRefList (r : RawWireRef) : List UInt8 :=
  packU16BE r.targetVid ++ packU8 r.targetSortCode ++ packU8 r.relTag

def parseRawWireRef (vTotal : Nat) (bs : List UInt8) : Option (RawWireRef × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (tv, bs1) =>
    match parseU8 bs1 with
    | none => none
    | some (ts, bs2) =>
      match parseU8 bs2 with
      | none => none
      | some (rt, bs3) =>
          let r : RawWireRef := { targetVid := tv, targetSortCode := ts, relTag := rt }
          if wfRawWireRefBool vTotal r then some (r, bs3) else none

theorem parseRawWireRef_encode_append (vTotal : Nat) {r : RawWireRef}
    (hwf : wfRawWireRefBool vTotal r = true) (rest : List UInt8) :
    parseRawWireRef vTotal (encodeRawWireRefList r ++ rest) = some (r, rest) := by
  have hwfCopy := hwf
  unfold wfRawWireRefBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨_, _⟩, htv64⟩, hts3⟩, hrt⟩
  have hts256 : r.targetSortCode < 256 := by omega
  have hrt256 : r.relTag < 256 := by omega
  unfold encodeRawWireRefList parseRawWireRef
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append htv64]
  dsimp only
  rw [parseU8_packU8_append hts256]
  dsimp only
  rw [parseU8_packU8_append hrt256]
  dsimp only
  cases r
  simp [hwfCopy]

theorem parseRawWireRef_eq_some (vTotal : Nat) {bs rest : List UInt8} {r : RawWireRef}
    (h : parseRawWireRef vTotal bs = some (r, rest)) :
    wfRawWireRefBool vTotal r = true ∧ bs = encodeRawWireRefList r ++ rest := by
  unfold parseRawWireRef at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨tv, bs1⟩; dsimp only at h
    cases h2 : parseU8 bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨ts, bs2⟩; dsimp only at h
      cases h3 : parseU8 bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨rt, bs3⟩; dsimp only at h
        split at h
        · next hwf =>
          simp only [Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨hr, hrest⟩
          subst hr; subst hrest
          rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
          rcases parseU8_eq_some h2 with ⟨_, e2⟩
          rcases parseU8_eq_some h3 with ⟨_, e3⟩
          refine ⟨hwf, ?_⟩
          rw [e1, e2, e3]
          simp [encodeRawWireRefList, List.append_assoc]
        · cases h

structure RawWireIRRecord where
  recTag : Nat
  recordId : AsciiId
  sourceVid : VertexId
  sourceSortCode : Nat
  refs : List RawWireRef
  deriving DecidableEq, Repr

def wfRawWireIRRecordBool (vTotal : Nat) (rc : RawWireIRRecord) : Bool :=
  decide (1 ≤ rc.recTag ∧ rc.recTag ≤ 12) &&
  wfAsciiIdBool rc.recordId &&
  wfVertexWireBool vTotal rc.sourceVid &&
  decide (rc.sourceSortCode ≤ 3) &&
  decide (rc.refs.length ≤ maxRefsPerRecord) &&
  listAllBool (wfRawWireRefBool vTotal) rc.refs &&
  strictSortedByBool rawWireRefLtBool rc.refs

def encodeRawWireIRRecordList (rc : RawWireIRRecord) : List UInt8 :=
  packU8 rc.recTag ++
  encodeAsciiIdList rc.recordId ++
  packU16BE rc.sourceVid ++
  packU8 rc.sourceSortCode ++
  packU16BE rc.refs.length ++
  encodeRepeat encodeRawWireRefList rc.refs

def parseRawWireIRRecord (vTotal : Nat) (bs : List UInt8) : Option (RawWireIRRecord × List UInt8) :=
  match parseU8 bs with
  | none => none
  | some (rtag, bs1) =>
      if decide (1 ≤ rtag ∧ rtag ≤ 12) then
        match parseAsciiId bs1 with
        | none => none
        | some (rid, bs2) =>
          match parseU16BE bs2 with
          | none => none
          | some (svid, bs3) =>
            match parseU8 bs3 with
            | none => none
            | some (ssort, bs4) =>
              match parseU16BE bs4 with
              | none => none
              | some (rcnt, bs5) =>
                  if decide (rcnt ≤ maxRefsPerRecord) then
                    match parseRepeat (parseRawWireRef vTotal) rcnt bs5 with
                    | none => none
                    | some (rfs, bs6) =>
                        let rc : RawWireIRRecord :=
                          { recTag := rtag
                            recordId := rid
                            sourceVid := svid
                            sourceSortCode := ssort
                            refs := rfs }
                        if wfRawWireIRRecordBool vTotal rc then some (rc, bs6) else none
                  else none
      else none

theorem parseRawWireIRRecord_encode_append (vTotal : Nat) {rc : RawWireIRRecord}
    (hwf : wfRawWireIRRecordBool vTotal rc = true) (rest : List UInt8) :
    parseRawWireIRRecord vTotal (encodeRawWireIRRecordList rc ++ rest) = some (rc, rest) := by
  have hwfCopy := hwf
  unfold wfRawWireIRRecordBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨⟨hrtag, hrid⟩, ⟨_, hsv64⟩⟩, hss3⟩, hrcnt512⟩, hallRefs⟩, _⟩
  have hrtag256 : rc.recTag < 256 := by omega
  have hss256 : rc.sourceSortCode < 256 := by omega
  have hrcnt64 : rc.refs.length < 65536 := by unfold maxRefsPerRecord at hrcnt512; omega
  unfold encodeRawWireIRRecordList parseRawWireIRRecord
  simp only [List.append_assoc]
  rw [parseU8_packU8_append hrtag256]
  dsimp only
  rw [if_pos (decide_eq_true hrtag)]
  rw [parseAsciiId_encode_append hrid]
  dsimp only
  rw [parseU16BE_packU16BE_append hsv64]
  dsimp only
  rw [parseU8_packU8_append hss256]
  dsimp only
  rw [parseU16BE_packU16BE_append hrcnt64]
  dsimp only
  rw [if_pos (decide_eq_true hrcnt512)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseRawWireRef_encode_append vTotal hw r) hallRefs rest]
  dsimp only
  cases rc
  simp [hwfCopy]

theorem parseRawWireIRRecord_eq_some (vTotal : Nat) {bs rest : List UInt8} {rc : RawWireIRRecord}
    (h : parseRawWireIRRecord vTotal bs = some (rc, rest)) :
    wfRawWireIRRecordBool vTotal rc = true ∧ bs = encodeRawWireIRRecordList rc ++ rest := by
  unfold parseRawWireIRRecord at h
  cases h1 : parseU8 bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨rtag, bs1⟩; dsimp only at h
    split at h
    · cases h2 : parseAsciiId bs1 with
      | none => rw [h2] at h; cases h
      | some p2 =>
        rw [h2] at h; rcases p2 with ⟨rid, bs2⟩; dsimp only at h
        cases h3 : parseU16BE bs2 with
        | none => rw [h3] at h; cases h
        | some p3 =>
          rw [h3] at h; rcases p3 with ⟨svid, bs3⟩; dsimp only at h
          cases h4 : parseU8 bs3 with
          | none => rw [h4] at h; cases h
          | some p4 =>
            rw [h4] at h; rcases p4 with ⟨ssort, bs4⟩; dsimp only at h
            cases h5 : parseU16BE bs4 with
            | none => rw [h5] at h; cases h
            | some p5 =>
              rw [h5] at h; rcases p5 with ⟨rcnt, bs5⟩; dsimp only at h
              split at h
              · cases h6 : parseRepeat (parseRawWireRef vTotal) rcnt bs5 with
                | none => rw [h6] at h; cases h
                | some p6 =>
                  rw [h6] at h; rcases p6 with ⟨rfs, bs6⟩; dsimp only at h
                  split at h
                  · next hwf =>
                    simp only [Option.some.injEq, Prod.mk.injEq] at h
                    rcases h with ⟨hrc, hrest⟩
                    subst hrc; subst hrest
                    rcases parseU8_eq_some h1 with ⟨_, e1⟩
                    rcases parseAsciiId_eq_some h2 with ⟨_, e2⟩
                    rcases parseU16BE_eq_some h3 with ⟨_, e3⟩
                    rcases parseU8_eq_some h4 with ⟨_, e4⟩
                    rcases parseU16BE_eq_some h5 with ⟨_, e5⟩
                    rcases parseRepeat_eq_some (fun _ _ _ hp => parseRawWireRef_eq_some vTotal hp) h6 with
                      ⟨hlenR, _, e6⟩
                    refine ⟨hwf, ?_⟩
                    rw [e1, e2, e3, e4, e5, e6]
                    simp [encodeRawWireIRRecordList, hlenR, List.append_assoc]
                  · cases h
              · cases h
    · cases h

def wfSortBucketBool (b : List AsciiId) : Bool :=
  decide (b.length ≤ maxWireVertices) &&
  listAllBool wfAsciiIdBool b &&
  strictSortedByBool asciiLtBool b

def encodeSortBucketList (b : List AsciiId) : List UInt8 :=
  packU16BE b.length ++ encodeRepeat encodeAsciiIdList b

def parseSortBucket (bs : List UInt8) : Option (List AsciiId × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (cnt, bs1) =>
      if decide (cnt ≤ maxWireVertices) then
        match parseRepeat parseAsciiId cnt bs1 with
        | none => none
        | some (ids, bs2) =>
            if strictSortedByBool asciiLtBool ids then some (ids, bs2) else none
      else none

theorem parseSortBucket_encode_append {b : List AsciiId}
    (hwf : wfSortBucketBool b = true) (rest : List UInt8) :
    parseSortBucket (encodeSortBucketList b ++ rest) = some (b, rest) := by
  unfold wfSortBucketBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨hle512, hallA⟩, hlex⟩
  have hlt64 : b.length < 65536 := by unfold maxWireVertices at hle512; omega
  unfold encodeSortBucketList parseSortBucket
  rw [List.append_assoc, parseU16BE_packU16BE_append hlt64]
  dsimp only
  rw [if_pos (decide_eq_true hle512)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseAsciiId_encode_append hw r) hallA rest]
  dsimp only
  rw [if_pos hlex]

theorem parseSortBucket_eq_some {bs rest : List UInt8} {b : List AsciiId}
    (h : parseSortBucket bs = some (b, rest)) :
    wfSortBucketBool b = true ∧ bs = encodeSortBucketList b ++ rest := by
  unfold parseSortBucket at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨cnt, bs1⟩; dsimp only at h
    split at h
    · next hleB =>
      have hle512 : cnt ≤ maxWireVertices := of_decide_eq_true hleB
      cases h2 : parseRepeat parseAsciiId cnt bs1 with
      | none => rw [h2] at h; cases h
      | some p2 =>
        rw [h2] at h; rcases p2 with ⟨ids, bs2⟩; dsimp only at h
        split at h
        · next hlex =>
          simp only [Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨hb, hrest⟩
          subst hb; subst hrest
          rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
          rcases parseRepeat_eq_some (fun _ _ _ hp => parseAsciiId_eq_some hp) h2 with
            ⟨hlenI, hallA, e2⟩
          refine ⟨?_, ?_⟩
          · unfold wfSortBucketBool
            rw [hlenI]
            simp [hle512, hallA, hlex]
          · rw [e1, e2]
            simp [encodeSortBucketList, hlenI, List.append_assoc]
        · cases h
    · cases h

structure RawSnapshotWireTerm where
  snapshotId : AsciiId
  bucket0 : List AsciiId
  bucket1 : List AsciiId
  bucket2 : List AsciiId
  bucket3 : List AsciiId
  irRecords : List RawWireIRRecord
  deriving DecidableEq, Repr

def RawSnapshotWireTerm.vTotal (s : RawSnapshotWireTerm) : Nat :=
  s.bucket0.length + s.bucket1.length + s.bucket2.length + s.bucket3.length

def rawRecordIdLtBool (r1 r2 : RawWireIRRecord) : Bool :=
  asciiLtBool r1.recordId r2.recordId

def wfRawSnapshotWireBool (s : RawSnapshotWireTerm) : Bool :=
  wfAsciiIdBool s.snapshotId &&
  wfSortBucketBool s.bucket0 &&
  wfSortBucketBool s.bucket1 &&
  wfSortBucketBool s.bucket2 &&
  wfSortBucketBool s.bucket3 &&
  decide (1 ≤ s.vTotal ∧ s.vTotal ≤ maxWireVertices) &&
  decide (s.irRecords.length ≤ maxWireIrRecords) &&
  listAllBool (wfRawWireIRRecordBool s.vTotal) s.irRecords &&
  strictSortedByBool rawRecordIdLtBool s.irRecords

def WF_RawSnapshotWire (s : RawSnapshotWireTerm) : Prop :=
  wfRawSnapshotWireBool s = true

def encodeSnapshotSectionList (s : RawSnapshotWireTerm) : List UInt8 :=
  encodeAsciiIdList s.snapshotId ++
  encodeSortBucketList s.bucket0 ++
  encodeSortBucketList s.bucket1 ++
  encodeSortBucketList s.bucket2 ++
  encodeSortBucketList s.bucket3 ++
  packU32BE s.irRecords.length ++
  encodeRepeat encodeRawWireIRRecordList s.irRecords

def parseSnapshotSection (bs : List UInt8) : Option (RawSnapshotWireTerm × List UInt8) :=
  match parseAsciiId bs with
  | none => none
  | some (sid, bs1) =>
    match parseSortBucket bs1 with
    | none => none
    | some (b0, bs2) =>
      match parseSortBucket bs2 with
      | none => none
      | some (b1, bs3) =>
        match parseSortBucket bs3 with
        | none => none
        | some (b2, bs4) =>
          match parseSortBucket bs4 with
          | none => none
          | some (b3, bs5) =>
              let vTot := b0.length + b1.length + b2.length + b3.length
              if decide (1 ≤ vTot ∧ vTot ≤ maxWireVertices) then
                match parseU32BE bs5 with
                | none => none
                | some (irCnt, bs6) =>
                    if decide (irCnt ≤ maxWireIrRecords) then
                      match parseRepeat (parseRawWireIRRecord vTot) irCnt bs6 with
                      | none => none
                      | some (recs, bs7) =>
                          let s : RawSnapshotWireTerm :=
                            { snapshotId := sid
                              bucket0 := b0
                              bucket1 := b1
                              bucket2 := b2
                              bucket3 := b3
                              irRecords := recs }
                          if wfRawSnapshotWireBool s then some (s, bs7) else none
                    else none
              else none

def encodeSnapshotSection (s : RawSnapshotWireTerm) : Option ByteArray :=
  encodeGuardedSlice wfRawSnapshotWireBool encodeSnapshotSectionList s

def decodeSnapshotSection (raw : ByteArray) : Option RawSnapshotWireTerm :=
  decodeExactSlice parseSnapshotSection raw

theorem parseSnapshotSection_encode_append {s : RawSnapshotWireTerm}
    (hwf : wfRawSnapshotWireBool s = true) (rest : List UInt8) :
    parseSnapshotSection (encodeSnapshotSectionList s ++ rest) = some (s, rest) := by
  have hwfCopy := hwf
  unfold wfRawSnapshotWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨⟨⟨⟨hsid, hb0⟩, hb1⟩, hb2⟩, hb3⟩, hvTot⟩, hirMax⟩, hallIr⟩, _⟩
  have hir32 : s.irRecords.length < 4294967296 := by unfold maxWireIrRecords at hirMax; omega
  unfold encodeSnapshotSectionList parseSnapshotSection
  simp only [List.append_assoc]
  rw [parseAsciiId_encode_append hsid]
  dsimp only
  rw [parseSortBucket_encode_append hb0]
  dsimp only
  rw [parseSortBucket_encode_append hb1]
  dsimp only
  rw [parseSortBucket_encode_append hb2]
  dsimp only
  rw [parseSortBucket_encode_append hb3]
  dsimp only
  have hvEq : s.bucket0.length + s.bucket1.length + s.bucket2.length + s.bucket3.length = s.vTotal := rfl
  rw [hvEq, if_pos (decide_eq_true hvTot)]
  rw [parseU32BE_packU32BE_append hir32]
  dsimp only
  rw [if_pos (decide_eq_true hirMax)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseRawWireIRRecord_encode_append s.vTotal hw r) hallIr rest]
  dsimp only
  cases s
  simp [hwfCopy]

theorem parseSnapshotSection_eq_some {bs rest : List UInt8} {s : RawSnapshotWireTerm}
    (h : parseSnapshotSection bs = some (s, rest)) :
    wfRawSnapshotWireBool s = true ∧ bs = encodeSnapshotSectionList s ++ rest := by
  unfold parseSnapshotSection at h
  cases h1 : parseAsciiId bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨sid, bs1⟩; dsimp only at h
    cases h2 : parseSortBucket bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨b0, bs2⟩; dsimp only at h
      cases h3 : parseSortBucket bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨b1, bs3⟩; dsimp only at h
        cases h4 : parseSortBucket bs3 with
        | none => rw [h4] at h; cases h
        | some p4 =>
          rw [h4] at h; rcases p4 with ⟨b2, bs4⟩; dsimp only at h
          cases h5 : parseSortBucket bs4 with
          | none => rw [h5] at h; cases h
          | some p5 =>
            rw [h5] at h; rcases p5 with ⟨b3, bs5⟩; dsimp only at h
            split at h
            · cases h6 : parseU32BE bs5 with
              | none => rw [h6] at h; cases h
              | some p6 =>
                rw [h6] at h; rcases p6 with ⟨irCnt, bs6⟩; dsimp only at h
                split at h
                · cases h7 : parseRepeat (parseRawWireIRRecord (b0.length + b1.length + b2.length + b3.length)) irCnt bs6 with
                  | none => rw [h7] at h; cases h
                  | some p7 =>
                    rw [h7] at h; rcases p7 with ⟨recs, bs7⟩; dsimp only at h
                    split at h
                    · next hwf =>
                      simp only [Option.some.injEq, Prod.mk.injEq] at h
                      rcases h with ⟨hsEq, hrest⟩
                      subst hsEq; subst hrest
                      rcases parseAsciiId_eq_some h1 with ⟨_, e1⟩
                      rcases parseSortBucket_eq_some h2 with ⟨_, e2⟩
                      rcases parseSortBucket_eq_some h3 with ⟨_, e3⟩
                      rcases parseSortBucket_eq_some h4 with ⟨_, e4⟩
                      rcases parseSortBucket_eq_some h5 with ⟨_, e5⟩
                      rcases parseU32BE_eq_some h6 with ⟨_, e6⟩
                      rcases parseRepeat_eq_some
                        (fun _ _ _ hp => parseRawWireIRRecord_eq_some (b0.length + b1.length + b2.length + b3.length) hp) h7 with
                        ⟨hlenR, _, e7⟩
                      refine ⟨hwf, ?_⟩
                      rw [e1, e2, e3, e4, e5, e6, e7]
                      simp [encodeSnapshotSectionList, hlenR, List.append_assoc]
                    · cases h
                · cases h
            · cases h

/-- **`W2-B` Theorem 1 (Encoder Domain Characterization, `F91-03` Discipline)**. -/
theorem w2b_encodeSnapshotSection_domain_iff (s : RawSnapshotWireTerm) :
    (∃ B, encodeSnapshotSection s = some B) ↔ WF_RawSnapshotWire s :=
  encodeGuardedSlice_isSome_iff wfRawSnapshotWireBool encodeSnapshotSectionList s

theorem w2b_noncanonical_snapshot_encode_none {s : RawSnapshotWireTerm}
    (hnot : ¬ WF_RawSnapshotWire s) :
    encodeSnapshotSection s = none :=
  encodeGuardedSlice_eq_none_of_not_wf wfRawSnapshotWireBool encodeSnapshotSectionList s hnot

/-- **`W2-B` Theorem 2 (Forward Canonical Snapshot Roundtrip)**. -/
theorem w2b_snapshot_forward_roundtrip {s : RawSnapshotWireTerm}
    (hwf : WF_RawSnapshotWire s) :
    ∃ B, encodeSnapshotSection s = some B ∧ decodeSnapshotSection B = some s :=
  guardedSlice_forward_roundtrip wfRawSnapshotWireBool encodeSnapshotSectionList parseSnapshotSection
    (fun _ r hw => parseSnapshotSection_encode_append hw r) hwf

/-- **`W2-B` Theorem 3 (Backward Canonical Snapshot Roundtrip & Zero Silent Normalization)**. -/
theorem w2b_snapshot_backward_roundtrip {B : ByteArray} {s : RawSnapshotWireTerm}
    (hdec : decodeSnapshotSection B = some s) :
    WF_RawSnapshotWire s ∧ encodeSnapshotSection s = some B :=
  guardedSlice_backward_roundtrip wfRawSnapshotWireBool encodeSnapshotSectionList parseSnapshotSection
    (fun _ _ _ hp => parseSnapshotSection_eq_some hp) hdec

theorem w2b_snapshot_bijection_iff (B : ByteArray) (s : RawSnapshotWireTerm) :
    decodeSnapshotSection B = some s ↔ encodeSnapshotSection s = some B :=
  guardedSlice_bijection_iff wfRawSnapshotWireBool encodeSnapshotSectionList parseSnapshotSection
    (fun _ r hw => parseSnapshotSection_encode_append hw r)
    (fun _ _ _ hp => parseSnapshotSection_eq_some hp) B s

theorem strictSorted_map_asciiLtBool :
    ∀ {recs : List RawWireIRRecord},
      strictSortedByBool rawRecordIdLtBool recs = true →
      strictSortedByBool asciiLtBool (recs.map RawWireIRRecord.recordId) = true
  | [], _ => rfl
  | [_], _ => rfl
  | r1 :: r2 :: tl, h => by
      have htail : strictSortedByBool rawRecordIdLtBool (r2 :: tl) = true := by
        simp only [strictSortedByBool, strictChainBool, Bool.and_eq_true] at h
        exact h.2
      have ih := strictSorted_map_asciiLtBool htail
      simp only [List.map_cons, strictSortedByBool, strictChainBool, Bool.and_eq_true] at h ⊢
      exact ⟨h.1, ih⟩

/-- **`W2-B` Theorem 4**: Every wire-valid `RawSnapshotWireTerm` has duplicate-free `recordId`s
    (whereas cross-sort `vertexIds` uniqueness is intentionally deferred to `B2` per 93rd Ruling §2). -/
theorem w2b_snapshot_ir_ids_nodup {s : RawSnapshotWireTerm}
    (hwf : WF_RawSnapshotWire s) :
    NodupList (s.irRecords.map RawWireIRRecord.recordId) := by
  unfold WF_RawSnapshotWire wfRawSnapshotWireBool at hwf
  simp only [Bool.and_eq_true] at hwf
  exact strictLexAsciiIds_nodup (strictSorted_map_asciiLtBool hwf.2)

/-! ## `W2-A` Part II: `CNB-v1` Embedded Base Bundle & Outer `CNP-v2` (`0x03` / `0x05`) Framing -/

structure RawCNB1Header50 where
  closureTag : Nat
  claimShortest : Nat
  authTierTag : Nat
  reservedZero : Nat
  generationV : Nat
  policyMask : Nat
  transitionTag : Nat
  padZero : Nat
  claimedRoot32 : ByteArray

/-- Representation legality ONLY (`93rd Ruling §1 & §2`): byte widths + `generationV` wire budget. -/
def wfRawCNB1Header50Bool (h : RawCNB1Header50) : Bool :=
  decide (h.closureTag < 256) &&
  decide (h.claimShortest < 256) &&
  decide (h.authTierTag < 256) &&
  decide (h.reservedZero < 256) &&
  decide (h.generationV ≤ maxGenerationOrRank) &&
  decide (h.policyMask < 65536) &&
  decide (h.transitionTag < 256) &&
  decide (h.padZero < 256) &&
  decide (h.claimedRoot32.size = 32)

def encodeCNB1Header50List (h : RawCNB1Header50) : List UInt8 :=
  cnb1MagicBytes ++
  packU16BE cnb1WireVersion ++
  packU8 h.closureTag ++
  packU8 h.claimShortest ++
  packU8 h.authTierTag ++
  packU8 h.reservedZero ++
  packU32BE h.generationV ++
  packU16BE h.policyMask ++
  packU8 h.transitionTag ++
  packU8 h.padZero ++
  listOfBytes h.claimedRoot32

def parseCNB1Header50 (bs : List UInt8) : Option (RawCNB1Header50 × List UInt8) :=
  match parseExactMagic cnb1MagicBytes bs with
  | none => none
  | some ((), bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (wver, bs2) =>
        if decide (wver = cnb1WireVersion) then
          match parseU8 bs2 with
          | none => none
          | some (clo, bs3) =>
            match parseU8 bs3 with
            | none => none
            | some (csh, bs4) =>
              match parseU8 bs4 with
              | none => none
              | some (auth, bs5) =>
                match parseU8 bs5 with
                | none => none
                | some (rz, bs6) =>
                  match parseU32BE bs6 with
                  | none => none
                  | some (genv, bs7) =>
                      if decide (genv ≤ maxGenerationOrRank) then
                        match parseU16BE bs7 with
                        | none => none
                        | some (pmask, bs8) =>
                          match parseU8 bs8 with
                          | none => none
                          | some (ttag, bs9) =>
                            match parseU8 bs9 with
                            | none => none
                            | some (pzero, bs10) =>
                              match parseFixedByteArray 32 bs10 with
                              | none => none
                              | some (root32, bs11) =>
                                  some ({ closureTag := clo
                                          claimShortest := csh
                                          authTierTag := auth
                                          reservedZero := rz
                                          generationV := genv
                                          policyMask := pmask
                                          transitionTag := ttag
                                          padZero := pzero
                                          claimedRoot32 := root32 }, bs11)
                      else none
        else none

theorem encodeCNB1Header50List_length {h : RawCNB1Header50}
    (hwf : wfRawCNB1Header50Bool h = true) :
    (encodeCNB1Header50List h).length = 50 := by
  unfold wfRawCNB1Header50Bool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  have hr : (listOfBytes h.claimedRoot32).length = 32 := by
    rw [← byteArray_size_eq_length]; exact hwf.2
  unfold encodeCNB1Header50List cnb1MagicBytes
  simp [packU16BE, packU8, packU32BE, hr]

theorem parseCNB1Header50_encode_append {h : RawCNB1Header50}
    (hwf : wfRawCNB1Header50Bool h = true) (rest : List UInt8) :
    parseCNB1Header50 (encodeCNB1Header50List h ++ rest) = some (h, rest) := by
  unfold wfRawCNB1Header50Bool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨⟨⟨⟨hclo, hcsh⟩, hauth⟩, hrz⟩, hgen⟩, hpm⟩, htt⟩, hpz⟩, hrootSz⟩
  have hgen32 : h.generationV < 4294967296 := by unfold maxGenerationOrRank at hgen; omega
  unfold encodeCNB1Header50List parseCNB1Header50
  simp only [List.append_assoc]
  rw [parseExactMagic_append cnb1MagicBytes]
  dsimp only
  rw [parseU16BE_packU16BE_append (by decide : cnb1WireVersion < 65536)]
  dsimp only
  rw [if_pos (decide_eq_true rfl)]
  rw [parseU8_packU8_append hclo]
  dsimp only
  rw [parseU8_packU8_append hcsh]
  dsimp only
  rw [parseU8_packU8_append hauth]
  dsimp only
  rw [parseU8_packU8_append hrz]
  dsimp only
  rw [parseU32BE_packU32BE_append hgen32]
  dsimp only
  rw [if_pos (decide_eq_true hgen)]
  rw [parseU16BE_packU16BE_append hpm]
  dsimp only
  rw [parseU8_packU8_append htt]
  dsimp only
  rw [parseU8_packU8_append hpz]
  dsimp only
  rw [parseFixedByteArray_append hrootSz]

theorem parseCNB1Header50_eq_some {bs rest : List UInt8} {h : RawCNB1Header50}
    (hp : parseCNB1Header50 bs = some (h, rest)) :
    wfRawCNB1Header50Bool h = true ∧ bs = encodeCNB1Header50List h ++ rest := by
  unfold parseCNB1Header50 at hp
  cases h0 : parseExactMagic cnb1MagicBytes bs with
  | none => rw [h0] at hp; cases hp
  | some p0 =>
    rw [h0] at hp; rcases p0 with ⟨⟨⟩, bs1⟩; dsimp only at hp
    cases h1 : parseU16BE bs1 with
    | none => rw [h1] at hp; cases hp
    | some p1 =>
      rw [h1] at hp; rcases p1 with ⟨wver, bs2⟩; dsimp only at hp
      split at hp
      · next hwvB =>
        have hwv : wver = cnb1WireVersion := of_decide_eq_true hwvB
        subst hwv
        cases h2 : parseU8 bs2 with
        | none => rw [h2] at hp; cases hp
        | some p2 =>
          rw [h2] at hp; rcases p2 with ⟨clo, bs3⟩; dsimp only at hp
          cases h3 : parseU8 bs3 with
          | none => rw [h3] at hp; cases hp
          | some p3 =>
            rw [h3] at hp; rcases p3 with ⟨csh, bs4⟩; dsimp only at hp
            cases h4 : parseU8 bs4 with
            | none => rw [h4] at hp; cases hp
            | some p4 =>
              rw [h4] at hp; rcases p4 with ⟨auth, bs5⟩; dsimp only at hp
              cases h5 : parseU8 bs5 with
              | none => rw [h5] at hp; cases hp
              | some p5 =>
                rw [h5] at hp; rcases p5 with ⟨rz, bs6⟩; dsimp only at hp
                cases h6 : parseU32BE bs6 with
                | none => rw [h6] at hp; cases hp
                | some p6 =>
                  rw [h6] at hp; rcases p6 with ⟨genv, bs7⟩; dsimp only at hp
                  split at hp
                  · next hgenB =>
                    have hgen : genv ≤ maxGenerationOrRank := of_decide_eq_true hgenB
                    cases h7 : parseU16BE bs7 with
                    | none => rw [h7] at hp; cases hp
                    | some p7 =>
                      rw [h7] at hp; rcases p7 with ⟨pmask, bs8⟩; dsimp only at hp
                      cases h8 : parseU8 bs8 with
                      | none => rw [h8] at hp; cases hp
                      | some p8 =>
                        rw [h8] at hp; rcases p8 with ⟨ttag, bs9⟩; dsimp only at hp
                        cases h9 : parseU8 bs9 with
                        | none => rw [h9] at hp; cases hp
                        | some p9 =>
                          rw [h9] at hp; rcases p9 with ⟨pzero, bs10⟩; dsimp only at hp
                          cases h10 : parseFixedByteArray 32 bs10 with
                          | none => rw [h10] at hp; cases hp
                          | some p10 =>
                            rw [h10] at hp; rcases p10 with ⟨root32, bs11⟩
                            simp only [Option.some.injEq, Prod.mk.injEq] at hp
                            rcases hp with ⟨hh, hrest⟩
                            subst hh; subst hrest
                            have e0 := parseExactMagic_eq_some h0
                            rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
                            rcases parseU8_eq_some h2 with ⟨l2, e2⟩
                            rcases parseU8_eq_some h3 with ⟨l3, e3⟩
                            rcases parseU8_eq_some h4 with ⟨l4, e4⟩
                            rcases parseU8_eq_some h5 with ⟨l5, e5⟩
                            rcases parseU32BE_eq_some h6 with ⟨_, e6⟩
                            rcases parseU16BE_eq_some h7 with ⟨l7, e7⟩
                            rcases parseU8_eq_some h8 with ⟨l8, e8⟩
                            rcases parseU8_eq_some h9 with ⟨l9, e9⟩
                            rcases parseFixedByteArray_eq_some h10 with ⟨l10, e10⟩
                            refine ⟨?_, ?_⟩
                            · unfold wfRawCNB1Header50Bool
                              simp [l2, l3, l4, l5, hgen, l7, l8, l9, l10]
                            · rw [e0, e1, e2, e3, e4, e5, e6, e7, e8, e9, e10]
                              simp [encodeCNB1Header50List, List.append_assoc]
                  · cases hp
      · cases hp

structure RawPosWitness where
  sVid : VertexId
  tVid : VertexId
  rank : Nat
  nextHop : Nat
  deriving DecidableEq, Repr

def wfRawPosWitnessBool (vTotal : Nat) (w : RawPosWitness) : Bool :=
  wfVertexWireBool vTotal w.sVid &&
  wfVertexWireBool vTotal w.tVid &&
  decide (w.rank ≤ maxGenerationOrRank) &&
  decide (w.nextHop = noneVidSentinel ∨ w.nextHop < vTotal) &&
  decide (w.nextHop < 65536)

def encodeRawPosWitnessList (w : RawPosWitness) : List UInt8 :=
  packU16BE w.sVid ++ packU16BE w.tVid ++ packU32BE w.rank ++ packU16BE w.nextHop

def parseRawPosWitness (vTotal : Nat) (bs : List UInt8) : Option (RawPosWitness × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (sv, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (tv, bs2) =>
      match parseU32BE bs2 with
      | none => none
      | some (rk, bs3) =>
        match parseU16BE bs3 with
        | none => none
        | some (nh, bs4) =>
            let w : RawPosWitness := { sVid := sv, tVid := tv, rank := rk, nextHop := nh }
            if wfRawPosWitnessBool vTotal w then some (w, bs4) else none

theorem parseRawPosWitness_encode_append (vTotal : Nat) {w : RawPosWitness}
    (hwf : wfRawPosWitnessBool vTotal w = true) (rest : List UInt8) :
    parseRawPosWitness vTotal (encodeRawPosWitnessList w ++ rest) = some (w, rest) := by
  have hwfCopy := hwf
  unfold wfRawPosWitnessBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨_, hsv64⟩, ⟨_, htv64⟩⟩, hrkMax⟩, _⟩, hnh64⟩
  have hrk32 : w.rank < 4294967296 := by unfold maxGenerationOrRank at hrkMax; omega
  unfold encodeRawPosWitnessList parseRawPosWitness
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append hsv64]
  dsimp only
  rw [parseU16BE_packU16BE_append htv64]
  dsimp only
  rw [parseU32BE_packU32BE_append hrk32]
  dsimp only
  rw [parseU16BE_packU16BE_append hnh64]
  dsimp only
  cases w
  simp [hwfCopy]

theorem parseRawPosWitness_eq_some (vTotal : Nat) {bs rest : List UInt8} {w : RawPosWitness}
    (h : parseRawPosWitness vTotal bs = some (w, rest)) :
    wfRawPosWitnessBool vTotal w = true ∧ bs = encodeRawPosWitnessList w ++ rest := by
  unfold parseRawPosWitness at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨sv, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨tv, bs2⟩; dsimp only at h
      cases h3 : parseU32BE bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨rk, bs3⟩; dsimp only at h
        cases h4 : parseU16BE bs3 with
        | none => rw [h4] at h; cases h
        | some p4 =>
          rw [h4] at h; rcases p4 with ⟨nh, bs4⟩; dsimp only at h
          split at h
          · next hwf =>
            simp only [Option.some.injEq, Prod.mk.injEq] at h
            rcases h with ⟨hw, hrest⟩
            subst hw; subst hrest
            rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
            rcases parseU16BE_eq_some h2 with ⟨_, e2⟩
            rcases parseU32BE_eq_some h3 with ⟨_, e3⟩
            rcases parseU16BE_eq_some h4 with ⟨_, e4⟩
            refine ⟨hwf, ?_⟩
            rw [e1, e2, e3, e4]
            simp [encodeRawPosWitnessList, List.append_assoc]
          · cases h

structure RawClosedCut where
  srcVid : VertexId
  targets : List VertexId
  deriving DecidableEq, Repr

def wfRawClosedCutBool (vTotal : Nat) (c : RawClosedCut) : Bool :=
  wfVertexWireBool vTotal c.srcVid &&
  decide (c.targets.length ≤ vTotal) &&
  decide (c.targets.length < 65536) &&
  listAllBool (wfVertexWireBool vTotal) c.targets &&
  strictIncNatBool c.targets

def encodeRawClosedCutList (c : RawClosedCut) : List UInt8 :=
  packU16BE c.srcVid ++ packU16BE c.targets.length ++ encodeRepeat packU16BE c.targets

def parseRawClosedCut (vTotal : Nat) (bs : List UInt8) : Option (RawClosedCut × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (cs, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (clen, bs2) =>
        if decide (clen ≤ vTotal) then
          match parseRepeat parseU16BE clen bs2 with
          | none => none
          | some (targs, bs3) =>
              let c : RawClosedCut := { srcVid := cs, targets := targs }
              if wfRawClosedCutBool vTotal c then some (c, bs3) else none
        else none

theorem parseRawClosedCut_encode_append (vTotal : Nat) {c : RawClosedCut}
    (hwf : wfRawClosedCutBool vTotal c = true) (rest : List UInt8) :
    parseRawClosedCut vTotal (encodeRawClosedCutList c ++ rest) = some (c, rest) := by
  have hwfCopy := hwf
  unfold wfRawClosedCutBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨_, hcs64⟩, hlenV⟩, hlen64⟩, hallT⟩, _⟩
  have hall64 : listAllBool (fun t => decide (t < 65536)) c.targets = true := by
    rw [listAllBool_iff] at hallT ⊢
    intro t ht
    have ht' := hallT t ht
    unfold wfVertexWireBool at ht'
    simp only [Bool.and_eq_true] at ht'
    exact ht'.2
  unfold encodeRawClosedCutList parseRawClosedCut
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append hcs64]
  dsimp only
  rw [parseU16BE_packU16BE_append hlen64]
  dsimp only
  rw [if_pos (decide_eq_true hlenV)]
  rw [parseRepeat_encodeRepeat_append
        (wfItem := fun t => decide (t < 65536))
        (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r)
        hall64 rest]
  dsimp only
  cases c
  simp [hwfCopy]

theorem parseRawClosedCut_eq_some (vTotal : Nat) {bs rest : List UInt8} {c : RawClosedCut}
    (h : parseRawClosedCut vTotal bs = some (c, rest)) :
    wfRawClosedCutBool vTotal c = true ∧ bs = encodeRawClosedCutList c ++ rest := by
  unfold parseRawClosedCut at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨cs, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨clen, bs2⟩; dsimp only at h
      split at h
      · cases h3 : parseRepeat parseU16BE clen bs2 with
        | none => rw [h3] at h; cases h
        | some p3 =>
          rw [h3] at h; rcases p3 with ⟨targs, bs3⟩; dsimp only at h
          split at h
          · next hwf =>
            simp only [Option.some.injEq, Prod.mk.injEq] at h
            rcases h with ⟨hc, hrest⟩
            subst hc; subst hrest
            rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
            rcases parseU16BE_eq_some h2 with ⟨_, e2⟩
            rcases parseRepeat_eq_some
                (wfItem := fun t => decide (t < 65536))
                (fun _ _ _ hp =>
                  let ⟨hl, he⟩ := parseU16BE_eq_some hp
                  ⟨decide_eq_true hl, he⟩) h3 with ⟨hlenT, _, e3⟩
            refine ⟨hwf, ?_⟩
            rw [e1, e2, e3]
            simp [encodeRawClosedCutList, hlenT, List.append_assoc]
          · cases h
      · cases h

/-- Zero-backtracking monadic parser combinators (`O(1)` `optBind_eq_of_eq` / `optBind_eq_some`
    avoiding `kabstract` traversal over nested parser branches). -/
theorem optBind_eq_of_eq {α β : Type} {m : Option α} {v : α} {f : α → Option β}
    (hm : m = some v) : Option.bind m f = f v := by
  cases hm; rfl

theorem optBind_eq_some {α β : Type} {m : Option α} {f : α → Option β} {y : β}
    (h : Option.bind m f = some y) : ∃ a, m = some a ∧ f a = some y := by
  cases m with
  | none => cases h
  | some a => exact ⟨a, rfl, h⟩

def expectEmptyRest {α : Type} (res : Option (α × List UInt8)) : Option α :=
  Option.bind res (fun p =>
    match p.2 with
    | [] => some p.1
    | _ :: _ => none)

theorem expectEmptyRest_some {α : Type} {res : Option (α × List UInt8)} {v : α}
    (h : res = some (v, [])) : expectEmptyRest res = some v :=
  optBind_eq_of_eq h

theorem expectEmptyRest_eq_some {α : Type} {res : Option (α × List UInt8)} {v : α}
    (h : expectEmptyRest res = some v) : res = some (v, []) := by
  rcases optBind_eq_some h with ⟨⟨v', rem⟩, hres, hm⟩
  cases rem with
  | nil =>
    dsimp only at hm
    injection hm with hv
    subst hv
    exact hres
  | cons _ _ =>
    dsimp only at hm
    cases hm

def parseLocalPathsStep (vTotal : Nat) (bs : List UInt8) :
    Option (List (List VertexId) × List UInt8) :=
  Option.bind (parseCarrierPayloadByTag 1 vTotal bs) (fun p =>
    match p.1 with
    | .localPaths pkt => some (pkt, p.2)
    | _ => none)

theorem parseLocalPathsStep_encode_append (vTotal : Nat) {pkt : List (List VertexId)}
    (hwf : wfCarrierPayloadBool vTotal (.localPaths pkt) = true) (rest : List UInt8) :
    parseLocalPathsStep vTotal (encodeCarrierPayloadList (.localPaths pkt) ++ rest) =
      some (pkt, rest) :=
  optBind_eq_of_eq (parseCarrierPayload_encode_append vTotal (p := .localPaths pkt) hwf rest)

theorem parseLocalPathsStep_eq_some {vTotal : Nat} {bs rest : List UInt8}
    {pkt : List (List VertexId)}
    (h : parseLocalPathsStep vTotal bs = some (pkt, rest)) :
    wfCarrierPayloadBool vTotal (.localPaths pkt) = true ∧
    bs = encodeCarrierPayloadList (.localPaths pkt) ++ rest := by
  rcases optBind_eq_some h with ⟨⟨c, r⟩, hp, hm⟩
  cases c with
  | geodesicHops _ => dsimp only at hm; cases hm
  | globalEdges _ => dsimp only at hm; cases hm
  | localPaths pkt' =>
    dsimp only at hm
    simp only [Option.some.injEq, Prod.mk.injEq] at hm
    rcases hm with ⟨rfl, rfl⟩
    rcases parseCarrierPayload_eq_some hp with ⟨_, hwf, eqBs⟩
    exact ⟨hwf, eqBs⟩

def parseGeodesicHopsStep (vTotal : Nat) (bs : List UInt8) :
    Option (List RawHopWireEntry × List UInt8) :=
  Option.bind (parseCarrierPayloadByTag 2 vTotal bs) (fun p =>
    match p.1 with
    | .geodesicHops hs => some (hs, p.2)
    | _ => none)

theorem parseGeodesicHopsStep_encode_append (vTotal : Nat) {hs : List RawHopWireEntry}
    (hwf : wfCarrierPayloadBool vTotal (.geodesicHops hs) = true) (rest : List UInt8) :
    parseGeodesicHopsStep vTotal (encodeCarrierPayloadList (.geodesicHops hs) ++ rest) =
      some (hs, rest) :=
  optBind_eq_of_eq (parseCarrierPayload_encode_append vTotal (p := .geodesicHops hs) hwf rest)

theorem parseGeodesicHopsStep_eq_some {vTotal : Nat} {bs rest : List UInt8}
    {hs : List RawHopWireEntry}
    (h : parseGeodesicHopsStep vTotal bs = some (hs, rest)) :
    wfCarrierPayloadBool vTotal (.geodesicHops hs) = true ∧
    bs = encodeCarrierPayloadList (.geodesicHops hs) ++ rest := by
  rcases optBind_eq_some h with ⟨⟨c, r⟩, hp, hm⟩
  cases c with
  | localPaths _ => dsimp only at hm; cases hm
  | globalEdges _ => dsimp only at hm; cases hm
  | geodesicHops hs' =>
    dsimp only at hm
    simp only [Option.some.injEq, Prod.mk.injEq] at hm
    rcases hm with ⟨rfl, rfl⟩
    rcases parseCarrierPayload_eq_some hp with ⟨_, hwf, eqBs⟩
    exact ⟨hwf, eqBs⟩

def parseGlobalEdgesStep (vTotal : Nat) (bs : List UInt8) :
    Option (List (VertexId × VertexId) × List UInt8) :=
  Option.bind (parseCarrierPayloadByTag 3 vTotal bs) (fun p =>
    match p.1 with
    | .globalEdges es => some (es, p.2)
    | _ => none)

theorem parseGlobalEdgesStep_encode_append (vTotal : Nat) {es : List (VertexId × VertexId)}
    (hwf : wfCarrierPayloadBool vTotal (.globalEdges es) = true) (rest : List UInt8) :
    parseGlobalEdgesStep vTotal (encodeCarrierPayloadList (.globalEdges es) ++ rest) =
      some (es, rest) :=
  optBind_eq_of_eq (parseCarrierPayload_encode_append vTotal (p := .globalEdges es) hwf rest)

theorem parseGlobalEdgesStep_eq_some {vTotal : Nat} {bs rest : List UInt8}
    {es : List (VertexId × VertexId)}
    (h : parseGlobalEdgesStep vTotal bs = some (es, rest)) :
    wfCarrierPayloadBool vTotal (.globalEdges es) = true ∧
    bs = encodeCarrierPayloadList (.globalEdges es) ++ rest := by
  rcases optBind_eq_some h with ⟨⟨c, r⟩, hp, hm⟩
  cases c with
  | localPaths _ => dsimp only at hm; cases hm
  | geodesicHops _ => dsimp only at hm; cases hm
  | globalEdges es' =>
    dsimp only at hm
    simp only [Option.some.injEq, Prod.mk.injEq] at hm
    rcases hm with ⟨rfl, rfl⟩
    rcases parseCarrierPayload_eq_some hp with ⟨_, hwf, eqBs⟩
    exact ⟨hwf, eqBs⟩

/-- Candidate edges + candidate relations section (`cand_slice` in `#40` L333–373). -/
def wfCandSectionBool (vTotal : Nat)
    (cand : List (VertexId × VertexId) × List (VertexId × VertexId)) : Bool :=
  let edges := cand.1
  let rels := cand.2
  wfCarrierPayloadBool vTotal (.globalEdges edges) &&
  wfCarrierPayloadBool vTotal (.globalEdges rels)

def encodeCandSectionList
    (cand : List (VertexId × VertexId) × List (VertexId × VertexId)) : List UInt8 :=
  encodeCarrierPayloadList (.globalEdges cand.1) ++
  encodeCarrierPayloadList (.globalEdges cand.2)

def parseCandSection (vTotal : Nat) (bs : List UInt8) :
    Option ((List (VertexId × VertexId) × List (VertexId × VertexId)) × List UInt8) :=
  Option.bind (parseGlobalEdgesStep vTotal bs) (fun p1 =>
    Option.bind (parseGlobalEdgesStep vTotal p1.2) (fun p2 =>
      some ((p1.1, p2.1), p2.2)))

theorem parseCandSection_encode_append (vTotal : Nat)
    {cand : List (VertexId × VertexId) × List (VertexId × VertexId)}
    (hwf : wfCandSectionBool vTotal cand = true) (rest : List UInt8) :
    parseCandSection vTotal (encodeCandSectionList cand ++ rest) = some (cand, rest) := by
  rcases cand with ⟨edges, rels⟩
  unfold wfCandSectionBool at hwf
  rcases (Bool.and_eq_true _ _).mp hwf with ⟨hwf1, hwf2⟩
  exact (congrArg (parseCandSection vTotal) (List.append_assoc _ _ _)).trans
    ((optBind_eq_of_eq (parseGlobalEdgesStep_encode_append vTotal hwf1 _)).trans
      (optBind_eq_of_eq (parseGlobalEdgesStep_encode_append vTotal hwf2 rest)))

theorem parseCandSection_eq_some (vTotal : Nat) {bs rest : List UInt8}
    {cand : List (VertexId × VertexId) × List (VertexId × VertexId)}
    (h : parseCandSection vTotal bs = some (cand, rest)) :
    wfCandSectionBool vTotal cand = true ∧ bs = encodeCandSectionList cand ++ rest := by
  rcases optBind_eq_some h with ⟨⟨edges, bs1⟩, h1, h⟩
  dsimp only at h
  rcases optBind_eq_some h with ⟨⟨rels, bs2⟩, h2, h⟩
  dsimp only at h
  simp only [Option.some.injEq, Prod.mk.injEq] at h
  rcases h with ⟨rfl, rfl⟩
  rcases parseGlobalEdgesStep_eq_some h1 with ⟨hwf1, e1⟩
  rcases parseGlobalEdgesStep_eq_some h2 with ⟨hwf2, e2⟩
  refine ⟨by unfold wfCandSectionBool; simp [hwf1, hwf2], ?_⟩
  rw [e1, e2]
  exact (List.append_assoc _ _ _).symm

/-- Proof section (`prf_slice`: `posWitnesses` + `closedCuts`, `#40` L380–437). -/
def wfPrfSectionBool (vTotal : Nat)
    (prf : List RawPosWitness × List RawClosedCut) : Bool :=
  let posW := prf.1
  let cuts := prf.2
  decide (posW.length ≤ vTotal * vTotal) &&
  decide (posW.length < 4294967296) &&
  listAllBool (wfRawPosWitnessBool vTotal) posW &&
  strictLexPairsBool (posW.map (fun w => (w.sVid, w.tVid))) &&
  decide (cuts.length ≤ vTotal) &&
  decide (cuts.length < 65536) &&
  listAllBool (wfRawClosedCutBool vTotal) cuts &&
  strictIncNatBool (cuts.map RawClosedCut.srcVid)

def encodePrfSectionList (prf : List RawPosWitness × List RawClosedCut) : List UInt8 :=
  packU32BE prf.1.length ++
  encodeRepeat encodeRawPosWitnessList prf.1 ++
  packU16BE prf.2.length ++
  encodeRepeat encodeRawClosedCutList prf.2

def parsePrfSection (vTotal : Nat) (bs : List UInt8) :
    Option ((List RawPosWitness × List RawClosedCut) × List UInt8) :=
  match parseU32BE bs with
  | none => none
  | some (posCnt, bs1) =>
      if decide (posCnt ≤ vTotal * vTotal) then
        match parseRepeat (parseRawPosWitness vTotal) posCnt bs1 with
        | none => none
        | some (posW, bs2) =>
          match parseU16BE bs2 with
          | none => none
          | some (cutCnt, bs3) =>
              if decide (cutCnt ≤ vTotal) then
                match parseRepeat (parseRawClosedCut vTotal) cutCnt bs3 with
                | none => none
                | some (cuts, bs4) =>
                    if wfPrfSectionBool vTotal (posW, cuts) then
                      some ((posW, cuts), bs4)
                    else none
              else none
      else none

theorem parsePrfSection_encode_append (vTotal : Nat)
    {prf : List RawPosWitness × List RawClosedCut}
    (hwf : wfPrfSectionBool vTotal prf = true) (rest : List UInt8) :
    parsePrfSection vTotal (encodePrfSectionList prf ++ rest) = some (prf, rest) := by
  have hwfCopy := hwf
  rcases prf with ⟨posW, cuts⟩
  unfold wfPrfSectionBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨⟨⟨hpVV, hp32⟩, hallP⟩, _⟩, hcV⟩, hc64⟩, hallC⟩, _⟩
  unfold encodePrfSectionList parsePrfSection
  simp only [List.append_assoc]
  rw [parseU32BE_packU32BE_append hp32]
  dsimp only
  rw [if_pos (decide_eq_true hpVV)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseRawPosWitness_encode_append vTotal hw r) hallP]
  dsimp only
  rw [parseU16BE_packU16BE_append hc64]
  dsimp only
  rw [if_pos (decide_eq_true hcV)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseRawClosedCut_encode_append vTotal hw r) hallC rest]
  dsimp only
  rw [if_pos hwfCopy]

theorem parsePrfSection_eq_some (vTotal : Nat) {bs rest : List UInt8}
    {prf : List RawPosWitness × List RawClosedCut}
    (h : parsePrfSection vTotal bs = some (prf, rest)) :
    wfPrfSectionBool vTotal prf = true ∧ bs = encodePrfSectionList prf ++ rest := by
  unfold parsePrfSection at h
  cases h1 : parseU32BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨posCnt, bs1⟩; dsimp only at h
    split at h
    · cases h2 : parseRepeat (parseRawPosWitness vTotal) posCnt bs1 with
      | none => rw [h2] at h; cases h
      | some p2 =>
        rw [h2] at h; rcases p2 with ⟨posW, bs2⟩; dsimp only at h
        cases h3 : parseU16BE bs2 with
        | none => rw [h3] at h; cases h
        | some p3 =>
          rw [h3] at h; rcases p3 with ⟨cutCnt, bs3⟩; dsimp only at h
          split at h
          · cases h4 : parseRepeat (parseRawClosedCut vTotal) cutCnt bs3 with
            | none => rw [h4] at h; cases h
            | some p4 =>
              rw [h4] at h; rcases p4 with ⟨cuts, bs4⟩; dsimp only at h
              split at h
              · next hwf =>
                simp only [Option.some.injEq, Prod.mk.injEq] at h
                rcases h with ⟨hprf, hrest⟩
                subst hprf; subst hrest
                rcases parseU32BE_eq_some h1 with ⟨_, e1⟩
                rcases parseRepeat_eq_some (fun _ _ _ hp => parseRawPosWitness_eq_some vTotal hp) h2 with
                  ⟨hlenP, _, e2⟩
                rcases parseU16BE_eq_some h3 with ⟨_, e3⟩
                rcases parseRepeat_eq_some (fun _ _ _ hp => parseRawClosedCut_eq_some vTotal hp) h4 with
                  ⟨hlenC, _, e4⟩
                refine ⟨hwf, ?_⟩
                rw [e1, e2, e3, e4]
                simp [encodePrfSectionList, hlenP, hlenC, List.append_assoc]
              · cases h
          · cases h
    · cases h

/-- Complete `CNB-v1` embedded base bundle (`#40` `_decode_cnb1_bundle`, L293–462). -/
structure RawCNB1Bundle where
  hdr : RawCNB1Header50
  rawSnap : RawSnapshotWireTerm
  candidateEdges : List (VertexId × VertexId)
  candidateRelations : List (VertexId × VertexId)
  posWitnesses : List RawPosWitness
  closedCuts : List RawClosedCut

def encodeCNB1BundleList (b : RawCNB1Bundle) : List UInt8 :=
  encodeCNB1Header50List b.hdr ++
  encodeLenSliceList (encodeSnapshotSectionList b.rawSnap) ++
  encodeLenSliceList (encodeCandSectionList (b.candidateEdges, b.candidateRelations)) ++
  encodeLenSliceList (encodePrfSectionList (b.posWitnesses, b.closedCuts))

def wfRawCNB1BundleBool (b : RawCNB1Bundle) : Bool :=
  let vTot := b.rawSnap.vTotal
  let totalBytes := (encodeCNB1BundleList b).length
  wfRawCNB1Header50Bool b.hdr &&
  wfRawSnapshotWireBool b.rawSnap &&
  wfCandSectionBool vTot (b.candidateEdges, b.candidateRelations) &&
  wfPrfSectionBool vTot (b.posWitnesses, b.closedCuts) &&
  decide (cnb1MinBundleSizeBytes ≤ totalBytes ∧ totalBytes ≤ maxPacketBytes)

def WF_RawCNB1Bundle (b : RawCNB1Bundle) : Prop :=
  wfRawCNB1BundleBool b = true

def parseCNB1Core (bs : List UInt8) : Option RawCNB1Bundle :=
  Option.bind (parseCNB1Header50 bs) (fun p1 =>
    Option.bind (parseLenSlice p1.2) (fun p2 =>
      Option.bind (expectEmptyRest (parseSnapshotSection p2.1)) (fun rawSnap =>
        let vTot := rawSnap.vTotal
        Option.bind (parseLenSlice p2.2) (fun p4 =>
          Option.bind (expectEmptyRest (parseCandSection vTot p4.1)) (fun cand =>
            Option.bind (expectEmptyRest (parseLenSlice p4.2)) (fun prfBs =>
              Option.bind (expectEmptyRest (parsePrfSection vTot prfBs)) (fun prf =>
                let b : RawCNB1Bundle :=
                  { hdr := p1.1
                    rawSnap := rawSnap
                    candidateEdges := cand.1
                    candidateRelations := cand.2
                    posWitnesses := prf.1
                    closedCuts := prf.2 }
                if wfRawCNB1BundleBool b then some b else none)))))))

def parseCNB1BundleExact (bs : List UInt8) : Option RawCNB1Bundle :=
  if decide (cnb1MinBundleSizeBytes ≤ bs.length ∧ bs.length ≤ maxPacketBytes) then
    parseCNB1Core bs
  else none

def encodeCNB1Bundle (b : RawCNB1Bundle) : Option ByteArray :=
  encodeGuardedSlice wfRawCNB1BundleBool encodeCNB1BundleList b

def decodeCNB1Bundle (raw : ByteArray) : Option RawCNB1Bundle :=
  parseCNB1BundleExact (listOfBytes raw)

/-- **`W2-A` Contiguous Section Partition Theorem**:
    Every encoded `CNB-v1` bundle partitions contiguously with zero overlap, zero gap,
    and zero trailing bytes into its 50-byte header plus three `u32be`-framed sections. -/
theorem w2a_cnb1_contiguous_partition_exact {b : RawCNB1Bundle}
    (hwf : WF_RawCNB1Bundle b) :
    let snapLen := (encodeSnapshotSectionList b.rawSnap).length
    let candLen := (encodeCandSectionList (b.candidateEdges, b.candidateRelations)).length
    let prfLen := (encodePrfSectionList (b.posWitnesses, b.closedCuts)).length
    (encodeCNB1BundleList b).length = 50 + (4 + snapLen) + (4 + candLen) + (4 + prfLen) ∧
    62 ≤ (encodeCNB1BundleList b).length := by
  unfold WF_RawCNB1Bundle wfRawCNB1BundleBool cnb1MinBundleSizeBytes at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  have h50 : (encodeCNB1Header50List b.hdr).length = 50 :=
    encodeCNB1Header50List_length hwf.1.1.1.1
  dsimp only
  refine ⟨?_, hwf.2.1⟩
  unfold encodeCNB1BundleList encodeLenSliceList
  simp only [List.length_append, h50, packU32BE, List.length_cons, List.length_nil]

theorem parseCNB1BundleExact_encode {b : RawCNB1Bundle}
    (hwf : WF_RawCNB1Bundle b) :
    parseCNB1BundleExact (encodeCNB1BundleList b) = some b := by
  have hwfCopy := hwf
  unfold WF_RawCNB1Bundle wfRawCNB1BundleBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨hhdr, hsnap⟩, hcand⟩, hprf⟩, hbounds⟩
  have hpart := (w2a_cnb1_contiguous_partition_exact hwfCopy).1
  have hmax : (encodeCNB1BundleList b).length ≤ 2097152 := hbounds.2
  have hs32 : (encodeSnapshotSectionList b.rawSnap).length < 4294967296 := by omega
  have hc32 : (encodeCandSectionList (b.candidateEdges, b.candidateRelations)).length < 4294967296 := by omega
  have hp32 : (encodePrfSectionList (b.posWitnesses, b.closedCuts)).length < 4294967296 := by omega
  have heqB : encodeCNB1BundleList b =
      encodeCNB1Header50List b.hdr ++
      (encodeLenSliceList (encodeSnapshotSectionList b.rawSnap) ++
       (encodeLenSliceList (encodeCandSectionList (b.candidateEdges, b.candidateRelations)) ++
        encodeLenSliceList (encodePrfSectionList (b.posWitnesses, b.closedCuts)))) := by
    simp [encodeCNB1BundleList, List.append_assoc]
  have hps := parseSnapshotSection_encode_append hsnap []
  rw [List.append_nil] at hps
  have hpc := parseCandSection_encode_append b.rawSnap.vTotal hcand []
  rw [List.append_nil] at hpc
  have hpLenPrf := parseLenSlice_encode_append hp32 []
  rw [List.append_nil] at hpLenPrf
  have hpp := parsePrfSection_encode_append b.rawSnap.vTotal hprf []
  rw [List.append_nil] at hpp
  unfold parseCNB1BundleExact
  rw [if_pos (decide_eq_true hbounds)]
  refine (congrArg parseCNB1Core heqB).trans ?_
  unfold parseCNB1Core
  refine (optBind_eq_of_eq (parseCNB1Header50_encode_append hhdr _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (parseLenSlice_encode_append hs32 _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (expectEmptyRest_some hps)).trans ?_
  refine (optBind_eq_of_eq (parseLenSlice_encode_append hc32 _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (expectEmptyRest_some hpc)).trans ?_
  refine (optBind_eq_of_eq (expectEmptyRest_some hpLenPrf)).trans ?_
  refine (optBind_eq_of_eq (expectEmptyRest_some hpp)).trans ?_
  dsimp only
  cases b
  exact if_pos hwfCopy

theorem parseCNB1BundleExact_eq_some {bs : List UInt8} {b : RawCNB1Bundle}
    (h : parseCNB1BundleExact bs = some b) :
    WF_RawCNB1Bundle b ∧ bs = encodeCNB1BundleList b := by
  unfold parseCNB1BundleExact at h
  split at h
  · unfold parseCNB1Core at h
    rcases optBind_eq_some h with ⟨⟨hdr, bs1⟩, h1, h⟩
    dsimp only at h
    rcases optBind_eq_some h with ⟨⟨snapBs, bs2⟩, h2, h⟩
    dsimp only at h
    rcases optBind_eq_some h with ⟨rawSnap, h3e, h⟩
    have h3 := expectEmptyRest_eq_some h3e
    rcases optBind_eq_some h with ⟨⟨candBs, bs3⟩, h4, h⟩
    dsimp only at h
    rcases optBind_eq_some h with ⟨⟨edges, rels⟩, h5e, h⟩
    have h5 := expectEmptyRest_eq_some h5e
    dsimp only at h
    rcases optBind_eq_some h with ⟨prfBs, h6e, h⟩
    have h6 := expectEmptyRest_eq_some h6e
    rcases optBind_eq_some h with ⟨⟨posW, cuts⟩, h7e, h⟩
    have h7 := expectEmptyRest_eq_some h7e
    dsimp only at h
    split at h
    · next hwf =>
      injection h with hb
      subst hb
      rcases parseCNB1Header50_eq_some h1 with ⟨_, e1⟩
      rcases parseLenSlice_eq_some h2 with ⟨_, e2⟩
      rcases parseSnapshotSection_eq_some h3 with ⟨_, e3⟩
      rcases parseLenSlice_eq_some h4 with ⟨_, e4⟩
      rcases parseCandSection_eq_some rawSnap.vTotal h5 with ⟨_, e5⟩
      rcases parseLenSlice_eq_some h6 with ⟨_, e6⟩
      rcases parsePrfSection_eq_some rawSnap.vTotal h7 with ⟨_, e7⟩
      rw [List.append_nil] at e3 e5 e6 e7
      refine ⟨hwf, ?_⟩
      rw [e1, e2, e3, e4, e5, e6, e7]
      simp [encodeCNB1BundleList, List.append_assoc]
    · cases h
  · cases h

theorem w2a_cnb1_encode_domain_iff (b : RawCNB1Bundle) :
    (∃ B, encodeCNB1Bundle b = some B) ↔ WF_RawCNB1Bundle b :=
  encodeGuardedSlice_isSome_iff wfRawCNB1BundleBool encodeCNB1BundleList b

theorem w2a_cnb1_forward_roundtrip {b : RawCNB1Bundle} (hwf : WF_RawCNB1Bundle b) :
    ∃ B, encodeCNB1Bundle b = some B ∧ decodeCNB1Bundle B = some b := by
  refine ⟨bytesOfList (encodeCNB1BundleList b), ?_, ?_⟩
  · unfold encodeCNB1Bundle encodeGuardedSlice
    have hwfB : wfRawCNB1BundleBool b = true := hwf
    simp [hwfB]
  · unfold decodeCNB1Bundle
    rw [listOfBytes_bytesOfList]
    exact parseCNB1BundleExact_encode hwf

theorem w2a_cnb1_backward_roundtrip {B : ByteArray} {b : RawCNB1Bundle}
    (hdec : decodeCNB1Bundle B = some b) :
    WF_RawCNB1Bundle b ∧ encodeCNB1Bundle b = some B := by
  unfold decodeCNB1Bundle at hdec
  rcases parseCNB1BundleExact_eq_some hdec with ⟨hwf, hbsEq⟩
  refine ⟨hwf, ?_⟩
  unfold encodeCNB1Bundle encodeGuardedSlice
  have hwfB : wfRawCNB1BundleBool b = true := hwf
  rw [if_pos hwfB, ← hbsEq, bytesOfList_listOfBytes]

/-! ## `W2-A` Outer `CNP-v2` Asymmetric Packet Framing (`0x03` vs `0x05`) -/

inductive RawCnp2ResiliencePacket0x00 where
  | kind0x03
      (base : RawCNB1Bundle)
      (queryS queryT : VertexId)
      (constIrIndices : List Nat)
      (localPaths : List (List VertexId))
      (localBind : RawCarrierBindHeader)
      (localCert : SourceCertTerm)
      (globalBind : RawCarrierBindHeader)
      (globalCert : SourceCertTerm)
  | kind0x05
      (base : RawCNB1Bundle)
      (hopEntries : List RawHopWireEntry)
      (queryS queryT : VertexId)
      (constIrIndices : List Nat)
      (geoBind : RawCarrierBindHeader)
      (geoCert : SourceCertTerm)

def RawCnp2ResiliencePacket0x00.packetKind : RawCnp2ResiliencePacket0x00 → Nat
  | .kind0x03 .. => 3
  | .kind0x05 .. => 5

def encodeQueryAndConstList (qS qT : VertexId) (constIdxs : List Nat) : List UInt8 :=
  packU16BE qS ++ packU16BE qT ++ packU16BE constIdxs.length ++ encodeRepeat packU16BE constIdxs

def wfQueryAndConstBool (vTotal irTotal : Nat) (qS qT : VertexId) (constIdxs : List Nat) : Bool :=
  wfVertexWireBool vTotal qS &&
  wfVertexWireBool vTotal qT &&
  decide (constIdxs.length ≤ irTotal) &&
  decide (constIdxs.length < 65536) &&
  listAllBool (fun ci => decide (ci < 65536)) constIdxs

def parseQueryAndConst (vTotal irTotal : Nat) (bs : List UInt8) :
    Option ((VertexId × VertexId × List Nat) × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (qS, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (qT, bs2) =>
      match parseU16BE bs2 with
      | none => none
      | some (cCnt, bs3) =>
          if decide (cCnt ≤ irTotal) then
            match parseRepeat parseU16BE cCnt bs3 with
            | none => none
            | some (cIdxs, bs4) =>
                if wfQueryAndConstBool vTotal irTotal qS qT cIdxs then
                  some ((qS, qT, cIdxs), bs4)
                else none
          else none

theorem parseQueryAndConst_encode_append (vTotal irTotal : Nat)
    {qS qT : VertexId} {cIdxs : List Nat}
    (hwf : wfQueryAndConstBool vTotal irTotal qS qT cIdxs = true) (rest : List UInt8) :
    parseQueryAndConst vTotal irTotal (encodeQueryAndConstList qS qT cIdxs ++ rest) =
      some ((qS, qT, cIdxs), rest) := by
  have hwfCopy := hwf
  unfold wfQueryAndConstBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨_, hqs64⟩, ⟨_, hqt64⟩⟩, hleIr⟩, hlen64⟩, hall64⟩
  unfold encodeQueryAndConstList parseQueryAndConst
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append hqs64]
  dsimp only
  rw [parseU16BE_packU16BE_append hqt64]
  dsimp only
  rw [parseU16BE_packU16BE_append hlen64]
  dsimp only
  rw [if_pos (decide_eq_true hleIr)]
  rw [parseRepeat_encodeRepeat_append
        (wfItem := fun ci => decide (ci < 65536))
        (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r)
        hall64 rest]
  dsimp only
  rw [if_pos hwfCopy]

theorem parseQueryAndConst_eq_some (vTotal irTotal : Nat) {bs rest : List UInt8}
    {qS qT : VertexId} {cIdxs : List Nat}
    (h : parseQueryAndConst vTotal irTotal bs = some ((qS, qT, cIdxs), rest)) :
    wfQueryAndConstBool vTotal irTotal qS qT cIdxs = true ∧
    bs = encodeQueryAndConstList qS qT cIdxs ++ rest := by
  unfold parseQueryAndConst at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨qs, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨qt, bs2⟩; dsimp only at h
      cases h3 : parseU16BE bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨ccnt, bs3⟩; dsimp only at h
        split at h
        · cases h4 : parseRepeat parseU16BE ccnt bs3 with
          | none => rw [h4] at h; cases h
          | some p4 =>
            rw [h4] at h; rcases p4 with ⟨cis, bs4⟩; dsimp only at h
            split at h
            · next hwf =>
              simp only [Option.some.injEq, Prod.mk.injEq] at h
              rcases h with ⟨⟨rfl, rfl, rfl⟩, rfl⟩
              rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
              rcases parseU16BE_eq_some h2 with ⟨_, e2⟩
              rcases parseU16BE_eq_some h3 with ⟨_, e3⟩
              rcases parseRepeat_eq_some
                  (wfItem := fun ci => decide (ci < 65536))
                  (fun _ _ _ hp =>
                    let ⟨hl, he⟩ := parseU16BE_eq_some hp
                    ⟨decide_eq_true hl, he⟩) h4 with ⟨hlenC, _, e4⟩
              refine ⟨hwf, ?_⟩
              rw [e1, e2, e3, e4]
              simp [encodeQueryAndConstList, hlenC, List.append_assoc]
            · cases h
        · cases h

def encodeCnp2BodyList : RawCnp2ResiliencePacket0x00 → List UInt8
  | .kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert =>
      encodeLenSliceList (encodeCNB1BundleList base) ++
      encodeQueryAndConstList qS qT cIdxs ++
      encodeCarrierPayloadList (.localPaths locPaths) ++
      encodeClaimPair0x00List (locBh, locCert) ++
      encodeClaimPair0x00List (globBh, globCert)
  | .kind0x05 base hopEntries qS qT cIdxs geoBh geoCert =>
      encodeLenSliceList (encodeCNB1BundleList base) ++
      encodeCarrierPayloadList (.geodesicHops hopEntries) ++
      encodeQueryAndConstList qS qT cIdxs ++
      encodeClaimPair0x00List (geoBh, geoCert)

def encodeCnp2PacketList (pkt : RawCnp2ResiliencePacket0x00) : List UInt8 :=
  let body := encodeCnp2BodyList pkt
  cnp2MagicBytes ++
  packU16BE cnp2WireVersion ++
  packU8 pkt.packetKind ++
  packU8 0 ++
  packU32BE body.length ++
  body

def wfCnp2ResiliencePacket0x00Bool (pkt : RawCnp2ResiliencePacket0x00) : Bool :=
  let totalLen := (encodeCnp2PacketList pkt).length
  decide (cnp2EnvelopeSizeBytes ≤ totalLen ∧ totalLen ≤ maxPacketBytes) &&
  match pkt with
  | .kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert =>
      let vTot := base.rawSnap.vTotal
      let irTot := base.rawSnap.irRecords.length
      wfRawCNB1BundleBool base &&
      wfQueryAndConstBool vTot irTot qS qT cIdxs &&
      wfCarrierPayloadBool vTot (.localPaths locPaths) &&
      decide (locBh.carrierTag = 1) &&
      checkCanonicalClaimPairBool vTot irTot (locBh, locCert) &&
      decide (globBh.carrierTag = 3) &&
      checkCanonicalClaimPairBool vTot irTot (globBh, globCert)
  | .kind0x05 base hopEntries qS qT cIdxs geoBh geoCert =>
      let vTot := base.rawSnap.vTotal
      let irTot := base.rawSnap.irRecords.length
      wfRawCNB1BundleBool base &&
      wfCarrierPayloadBool vTot (.geodesicHops hopEntries) &&
      wfQueryAndConstBool vTot irTot qS qT cIdxs &&
      decide (geoBh.carrierTag = 2) &&
      checkCanonicalClaimPairBool vTot irTot (geoBh, geoCert)

def WF_Cnp2ResiliencePacket0x00 (pkt : RawCnp2ResiliencePacket0x00) : Prop :=
  wfCnp2ResiliencePacket0x00Bool pkt = true

def parseCnp2Body0x03 (body : List UInt8) : Option RawCnp2ResiliencePacket0x00 :=
  Option.bind (parseLenSlice body) (fun pb1 =>
    Option.bind (parseCNB1BundleExact pb1.1) (fun base =>
      let vTot := base.rawSnap.vTotal
      let irTot := base.rawSnap.irRecords.length
      Option.bind (parseQueryAndConst vTot irTot pb1.2) (fun pb3 =>
        Option.bind (parseLocalPathsStep vTot pb3.2) (fun pb4 =>
          Option.bind (parseClaimPair0x00 vTot irTot pb4.2) (fun pb5 =>
            Option.bind (expectEmptyRest (parseClaimPair0x00 vTot irTot pb5.2)) (fun globPair =>
              let pkt := RawCnp2ResiliencePacket0x00.kind0x03
                base pb3.1.1 pb3.1.2.1 pb3.1.2.2 pb4.1 pb5.1.1 pb5.1.2 globPair.1 globPair.2
              if wfCnp2ResiliencePacket0x00Bool pkt then some pkt else none))))))

def parseCnp2Body0x05 (body : List UInt8) : Option RawCnp2ResiliencePacket0x00 :=
  Option.bind (parseLenSlice body) (fun pb1 =>
    Option.bind (parseCNB1BundleExact pb1.1) (fun base =>
      let vTot := base.rawSnap.vTotal
      let irTot := base.rawSnap.irRecords.length
      Option.bind (parseGeodesicHopsStep vTot pb1.2) (fun pb3 =>
        Option.bind (parseQueryAndConst vTot irTot pb3.2) (fun pb4 =>
          Option.bind (expectEmptyRest (parseClaimPair0x00 vTot irTot pb4.2)) (fun geoPair =>
            let pkt := RawCnp2ResiliencePacket0x00.kind0x05
              base pb3.1 pb4.1.1 pb4.1.2.1 pb4.1.2.2 geoPair.1 geoPair.2
            if wfCnp2ResiliencePacket0x00Bool pkt then some pkt else none)))))

def dispatchCnp2BodyByKind (pkind : Nat) (body : List UInt8) : Option RawCnp2ResiliencePacket0x00 :=
  match pkind with
  | 3 => parseCnp2Body0x03 body
  | 5 => parseCnp2Body0x05 body
  | _ => none

def parseCnp2Core (bs : List UInt8) : Option RawCnp2ResiliencePacket0x00 :=
  Option.bind (parseExactMagic cnp2MagicBytes bs) (fun p0 =>
    Option.bind (parseU16BE p0.2) (fun p1 =>
      if decide (p1.1 = cnp2WireVersion) then
        Option.bind (parseU8 p1.2) (fun p2 =>
          Option.bind (parseU8 p2.2) (fun p3 =>
            if decide (p3.1 = 0) then
              Option.bind (expectEmptyRest (parseLenSlice p3.2))
                (dispatchCnp2BodyByKind p2.1)
            else none))
      else none))

def parseCnp2PacketExact (bs : List UInt8) : Option RawCnp2ResiliencePacket0x00 :=
  if decide (cnp2EnvelopeSizeBytes ≤ bs.length ∧ bs.length ≤ maxPacketBytes) then
    parseCnp2Core bs
  else none

def encodeCnp2ResiliencePacket0x00 (pkt : RawCnp2ResiliencePacket0x00) : Option ByteArray :=
  encodeGuardedSlice wfCnp2ResiliencePacket0x00Bool encodeCnp2PacketList pkt

def decodeCnp2ResiliencePacket0x00 (raw : ByteArray) : Option RawCnp2ResiliencePacket0x00 :=
  parseCnp2PacketExact (listOfBytes raw)

theorem parseCnp2PacketExact_encode {pkt : RawCnp2ResiliencePacket0x00}
    (hwf : WF_Cnp2ResiliencePacket0x00 pkt) :
    parseCnp2PacketExact (encodeCnp2PacketList pkt) = some pkt := by
  have hwfCopy := hwf
  unfold WF_Cnp2ResiliencePacket0x00 wfCnp2ResiliencePacket0x00Bool at hwf
  rcases (Bool.and_eq_true _ _).mp hwf with ⟨hboundsB, hbodyWf⟩
  have hbounds := of_decide_eq_true hboundsB
  have hbody32 : (encodeCnp2BodyList pkt).length < 4294967296 := by
    have hmax := hbounds.2
    unfold encodeCnp2PacketList cnp2MagicBytes maxPacketBytes at hmax
    simp only [List.length_append, packU16BE, packU8, packU32BE, List.length_cons, List.length_nil] at hmax
    omega
  have heqEnv : encodeCnp2PacketList pkt =
      cnp2MagicBytes ++
      (packU16BE cnp2WireVersion ++
       (packU8 pkt.packetKind ++
        (packU8 0 ++ encodeLenSliceList (encodeCnp2BodyList pkt)))) := by
    simp [encodeCnp2PacketList, encodeLenSliceList, List.append_assoc]
  have hpkind256 : pkt.packetKind < 256 := by
    cases pkt <;> (dsimp only [RawCnp2ResiliencePacket0x00.packetKind]; omega)
  have hbodySlice := parseLenSlice_encode_append hbody32 []
  rw [List.append_nil] at hbodySlice
  unfold parseCnp2PacketExact
  rw [if_pos hboundsB]
  refine (congrArg parseCnp2Core heqEnv).trans ?_
  unfold parseCnp2Core
  refine (optBind_eq_of_eq (parseExactMagic_append cnp2MagicBytes _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (parseU16BE_packU16BE_append (by decide : cnp2WireVersion < 65536) _)).trans ?_
  dsimp only
  rw [if_pos (decide_eq_true rfl)]
  refine (optBind_eq_of_eq (parseU8_packU8_append hpkind256 _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (parseU8_packU8_append (by decide : 0 < 256) _)).trans ?_
  dsimp only
  rw [if_pos (decide_eq_true rfl)]
  refine (optBind_eq_of_eq (expectEmptyRest_some hbodySlice)).trans ?_
  cases pkt with
  | kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert =>
    dsimp only [RawCnp2ResiliencePacket0x00.packetKind, dispatchCnp2BodyByKind, wfCnp2ResiliencePacket0x00Bool] at hbodyWf ⊢
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hbodyWf
    rcases hbodyWf with ⟨⟨⟨⟨⟨⟨hbase, hqc⟩, hlocCar⟩, _⟩, hlocClm⟩, _⟩, hglobClm⟩
    have hcnb32 : (encodeCNB1BundleList base).length < 4294967296 := by
      unfold wfRawCNB1BundleBool maxPacketBytes at hbase
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hbase
      omega
    have heqBody : encodeCnp2BodyList (.kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert) =
        encodeLenSliceList (encodeCNB1BundleList base) ++
        (encodeQueryAndConstList qS qT cIdxs ++
         (encodeCarrierPayloadList (.localPaths locPaths) ++
          (encodeClaimPair0x00List (locBh, locCert) ++
           encodeClaimPair0x00List (globBh, globCert)))) := by
      simp [encodeCnp2BodyList, List.append_assoc]
    have hpGlob := parseClaimPair0x00_encode_append base.rawSnap.vTotal base.rawSnap.irRecords.length hglobClm []
    rw [List.append_nil] at hpGlob
    refine (congrArg parseCnp2Body0x03 heqBody).trans ?_
    unfold parseCnp2Body0x03
    refine (optBind_eq_of_eq (parseLenSlice_encode_append hcnb32 _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (parseCNB1BundleExact_encode hbase)).trans ?_
    refine (optBind_eq_of_eq (parseQueryAndConst_encode_append base.rawSnap.vTotal base.rawSnap.irRecords.length hqc _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (parseLocalPathsStep_encode_append base.rawSnap.vTotal hlocCar _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (parseClaimPair0x00_encode_append base.rawSnap.vTotal base.rawSnap.irRecords.length hlocClm _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (expectEmptyRest_some hpGlob)).trans ?_
    dsimp only
    exact if_pos hwfCopy
  | kind0x05 base hopEntries qS qT cIdxs geoBh geoCert =>
    dsimp only [RawCnp2ResiliencePacket0x00.packetKind, dispatchCnp2BodyByKind, wfCnp2ResiliencePacket0x00Bool] at hbodyWf ⊢
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hbodyWf
    rcases hbodyWf with ⟨⟨⟨⟨hbase, hgeoCar⟩, hqc⟩, _⟩, hgeoClm⟩
    have hcnb32 : (encodeCNB1BundleList base).length < 4294967296 := by
      unfold wfRawCNB1BundleBool maxPacketBytes at hbase
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hbase
      omega
    have heqBody : encodeCnp2BodyList (.kind0x05 base hopEntries qS qT cIdxs geoBh geoCert) =
        encodeLenSliceList (encodeCNB1BundleList base) ++
        (encodeCarrierPayloadList (.geodesicHops hopEntries) ++
         (encodeQueryAndConstList qS qT cIdxs ++
          encodeClaimPair0x00List (geoBh, geoCert))) := by
      simp [encodeCnp2BodyList, List.append_assoc]
    have hpClm := parseClaimPair0x00_encode_append base.rawSnap.vTotal base.rawSnap.irRecords.length hgeoClm []
    rw [List.append_nil] at hpClm
    refine (congrArg parseCnp2Body0x05 heqBody).trans ?_
    unfold parseCnp2Body0x05
    refine (optBind_eq_of_eq (parseLenSlice_encode_append hcnb32 _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (parseCNB1BundleExact_encode hbase)).trans ?_
    refine (optBind_eq_of_eq (parseGeodesicHopsStep_encode_append base.rawSnap.vTotal hgeoCar _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (parseQueryAndConst_encode_append base.rawSnap.vTotal base.rawSnap.irRecords.length hqc _)).trans ?_
    dsimp only
    refine (optBind_eq_of_eq (expectEmptyRest_some hpClm)).trans ?_
    dsimp only
    exact if_pos hwfCopy

theorem parseCnp2PacketExact_eq_some {bs : List UInt8} {pkt : RawCnp2ResiliencePacket0x00}
    (h : parseCnp2PacketExact bs = some pkt) :
    WF_Cnp2ResiliencePacket0x00 pkt ∧ bs = encodeCnp2PacketList pkt := by
  unfold parseCnp2PacketExact at h
  split at h
  · unfold parseCnp2Core at h
    rcases optBind_eq_some h with ⟨⟨⟨⟩, bs1⟩, h0, h⟩
    dsimp only at h
    rcases optBind_eq_some h with ⟨⟨wver, bs2⟩, h1, h⟩
    dsimp only at h
    split at h
    · next hwvB =>
      have hwv : wver = cnp2WireVersion := of_decide_eq_true hwvB
      subst hwv
      rcases optBind_eq_some h with ⟨⟨pkind, bs3⟩, h2, h⟩
      dsimp only at h
      rcases optBind_eq_some h with ⟨⟨rzero, bs4⟩, h3, h⟩
      dsimp only at h
      split at h
      · next hrzB =>
        have hrz : rzero = 0 := of_decide_eq_true hrzB
        subst hrz
        rcases optBind_eq_some h with ⟨body, h4e, h⟩
        have h4 := expectEmptyRest_eq_some h4e
        have e0 := parseExactMagic_eq_some h0
        rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
        rcases parseU8_eq_some h2 with ⟨_, e2⟩
        rcases parseU8_eq_some h3 with ⟨_, e3⟩
        rcases parseLenSlice_eq_some h4 with ⟨_, e4⟩
        rw [List.append_nil] at e4
        unfold dispatchCnp2BodyByKind at h
        split at h
        · unfold parseCnp2Body0x03 at h
          rcases optBind_eq_some h with ⟨⟨cnbBs, b1⟩, hb1, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨base, hb2, h⟩
          rcases optBind_eq_some h with ⟨⟨⟨qS, qT, cIdxs⟩, b2⟩, hb3, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨⟨locPaths, b3⟩, hb4, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨⟨⟨locBh, locCert⟩, b4⟩, hb5, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨⟨globBh, globCert⟩, hb6e, h⟩
          have hb6 := expectEmptyRest_eq_some hb6e
          dsimp only at h
          split at h
          · next hwf =>
            injection h with hpkt
            subst hpkt
            rcases parseLenSlice_eq_some hb1 with ⟨_, eb1⟩
            rcases parseCNB1BundleExact_eq_some hb2 with ⟨_, eb2⟩
            rcases parseQueryAndConst_eq_some _ _ hb3 with ⟨_, eb3⟩
            rcases parseLocalPathsStep_eq_some hb4 with ⟨_, eb4⟩
            rcases parseClaimPair0x00_eq_some _ _ hb5 with ⟨_, eb5⟩
            rcases parseClaimPair0x00_eq_some _ _ hb6 with ⟨_, eb6⟩
            rw [List.append_nil] at eb6
            have eBody : body = encodeCnp2BodyList
                (.kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert) := by
              rw [eb1, eb2, eb3, eb4, eb5, eb6]
              simp [encodeCnp2BodyList, List.append_assoc]
            refine ⟨hwf, ?_⟩
            rw [e0, e1, e2, e3, e4, eBody]
            simp [encodeCnp2PacketList, encodeLenSliceList, RawCnp2ResiliencePacket0x00.packetKind, List.append_assoc]
          · cases h
        · unfold parseCnp2Body0x05 at h
          rcases optBind_eq_some h with ⟨⟨cnbBs, b1⟩, hb1, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨base, hb2, h⟩
          rcases optBind_eq_some h with ⟨⟨hopEntries, b2⟩, hb3, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨⟨⟨qS, qT, cIdxs⟩, b3⟩, hb4, h⟩
          dsimp only at h
          rcases optBind_eq_some h with ⟨⟨geoBh, geoCert⟩, hb5e, h⟩
          have hb5 := expectEmptyRest_eq_some hb5e
          dsimp only at h
          split at h
          · next hwf =>
            injection h with hpkt
            subst hpkt
            rcases parseLenSlice_eq_some hb1 with ⟨_, eb1⟩
            rcases parseCNB1BundleExact_eq_some hb2 with ⟨_, eb2⟩
            rcases parseGeodesicHopsStep_eq_some hb3 with ⟨_, eb3⟩
            rcases parseQueryAndConst_eq_some _ _ hb4 with ⟨_, eb4⟩
            rcases parseClaimPair0x00_eq_some _ _ hb5 with ⟨_, eb5⟩
            rw [List.append_nil] at eb5
            have eBody : body = encodeCnp2BodyList
                (.kind0x05 base hopEntries qS qT cIdxs geoBh geoCert) := by
              rw [eb1, eb2, eb3, eb4, eb5]
              simp [encodeCnp2BodyList, List.append_assoc]
            refine ⟨hwf, ?_⟩
            rw [e0, e1, e2, e3, e4, eBody]
            simp [encodeCnp2PacketList, encodeLenSliceList, RawCnp2ResiliencePacket0x00.packetKind, List.append_assoc]
          · cases h
        · cases h
      · cases h
    · cases h
  · cases h

/-- **`W2-A` Outer `CNP-v2` Packet Bijection Theorems (`0x03` & `0x05`, `F91-03` Discipline)**. -/
theorem w2a_cnp2_packet_encode_domain_iff (pkt : RawCnp2ResiliencePacket0x00) :
    (∃ B, encodeCnp2ResiliencePacket0x00 pkt = some B) ↔ WF_Cnp2ResiliencePacket0x00 pkt :=
  encodeGuardedSlice_isSome_iff wfCnp2ResiliencePacket0x00Bool encodeCnp2PacketList pkt

theorem w2a_cnp2_packet_forward_roundtrip {pkt : RawCnp2ResiliencePacket0x00}
    (hwf : WF_Cnp2ResiliencePacket0x00 pkt) :
    ∃ B, encodeCnp2ResiliencePacket0x00 pkt = some B ∧ decodeCnp2ResiliencePacket0x00 B = some pkt := by
  refine ⟨bytesOfList (encodeCnp2PacketList pkt), ?_, ?_⟩
  · unfold encodeCnp2ResiliencePacket0x00 encodeGuardedSlice
    have hwfB : wfCnp2ResiliencePacket0x00Bool pkt = true := hwf
    simp [hwfB]
  · unfold decodeCnp2ResiliencePacket0x00
    rw [listOfBytes_bytesOfList]
    exact parseCnp2PacketExact_encode hwf

theorem w2a_cnp2_packet_backward_roundtrip {B : ByteArray} {pkt : RawCnp2ResiliencePacket0x00}
    (hdec : decodeCnp2ResiliencePacket0x00 B = some pkt) :
    WF_Cnp2ResiliencePacket0x00 pkt ∧ encodeCnp2ResiliencePacket0x00 pkt = some B := by
  unfold decodeCnp2ResiliencePacket0x00 at hdec
  rcases parseCnp2PacketExact_eq_some hdec with ⟨hwf, hbsEq⟩
  refine ⟨hwf, ?_⟩
  unfold encodeCnp2ResiliencePacket0x00 encodeGuardedSlice
  have hwfB : wfCnp2ResiliencePacket0x00Bool pkt = true := hwf
  rw [if_pos hwfB, ← hbsEq, bytesOfList_listOfBytes]

theorem w2a_cnp2_packet_bijection_iff (B : ByteArray) (pkt : RawCnp2ResiliencePacket0x00) :
    decodeCnp2ResiliencePacket0x00 B = some pkt ↔ encodeCnp2ResiliencePacket0x00 pkt = some B := by
  constructor
  · exact fun h => (w2a_cnp2_packet_backward_roundtrip h).2
  · intro henc
    unfold encodeCnp2ResiliencePacket0x00 encodeGuardedSlice at henc
    cases hwf : wfCnp2ResiliencePacket0x00Bool pkt with
    | false => rw [hwf] at henc; cases henc
    | true =>
      rw [if_pos hwf] at henc
      injection henc with hBeq
      subst hBeq
      unfold decodeCnp2ResiliencePacket0x00
      rw [listOfBytes_bytesOfList]
      exact parseCnp2PacketExact_encode hwf

/-! ## `W2-C.1` (`F92-01`): Deterministic Raw-to-Source `Snapshot` Projection & `B1 + B2` Bridge -/

def sortOfCode : Nat → EpistemicSort
  | 0 => .event
  | 1 => .dataset
  | 2 => .proposition
  | _ => .derivation

theorem sortCode_sortOfCode {c : Nat} (h : c ≤ 3) : sortCode (sortOfCode c) = c := by
  match c with
  | 0 => rfl
  | 1 => rfl
  | 2 => rfl
  | 3 => rfl
  | n + 4 => omega

/-- Exact `#40` `_EXPECTED_SORT_PAIR_BY_REL_TAG` (`omega_kappa_pure_checker.py` L51–64; `13 => none`). -/
def expectedSortPairByRelTag : Nat → Option (EpistemicSort × EpistemicSort)
  | 1 => some (.event, .event)
  | 2 => some (.event, .dataset)
  | 3 => some (.dataset, .event)
  | 4 => some (.dataset, .dataset)
  | 5 => some (.proposition, .event)
  | 6 => some (.proposition, .dataset)
  | 7 => some (.proposition, .proposition)
  | 8 => some (.proposition, .derivation)
  | 9 => some (.derivation, .event)
  | 10 => some (.derivation, .dataset)
  | 11 => some (.derivation, .proposition)
  | 12 => some (.derivation, .derivation)
  | _ => none

def projectRawWireRef (r : RawWireRef) : SourceRef :=
  let (rs, rd) :=
    match expectedSortPairByRelTag r.relTag with
    | some p => p
    | none => (.event, .event)
  { targetVid := r.targetVid
    targetSort := sortOfCode r.targetSortCode
    relSrcSort := rs
    relDstSort := rd }

def projectRawWireIRRecord (rc : RawWireIRRecord) : SourceIRRecord :=
  { recordId := rc.recordId
    sourceVid := rc.sourceVid
    sourceSort := sortOfCode rc.sourceSortCode
    refs := rc.refs.map projectRawWireRef }

def rawSnapshotVertexIds (s : RawSnapshotWireTerm) : List AsciiId :=
  s.bucket0 ++ s.bucket1 ++ s.bucket2 ++ s.bucket3

def rawSnapshotVertexSorts (s : RawSnapshotWireTerm) : List EpistemicSort :=
  List.replicate s.bucket0.length .event ++
  List.replicate s.bucket1.length .dataset ++
  List.replicate s.bucket2.length .proposition ++
  List.replicate s.bucket3.length .derivation

theorem rawSnapshotVertexIds_length (s : RawSnapshotWireTerm) :
    (rawSnapshotVertexIds s).length = s.vTotal := by
  unfold rawSnapshotVertexIds RawSnapshotWireTerm.vTotal
  simp [List.length_append, Nat.add_assoc]

theorem rawSnapshotVertexSorts_length (s : RawSnapshotWireTerm) :
    (rawSnapshotVertexSorts s).length = s.vTotal := by
  unfold rawSnapshotVertexSorts RawSnapshotWireTerm.vTotal
  simp [List.length_append, List.length_replicate, Nat.add_assoc]

/-- **`F92-01` Deterministic Raw-to-Source `Snapshot` Projection**:
    Constructs untouched `#43` `SourceSnapshot` directly from `CNB-v1` wire header + `RawSnapshotWireTerm`
    with ZERO caller-supplied `SourceSnapshot` input (`recTag` preserved in canonical snapshot bytes
    `encodeSnapshotSectionList rawSnap` for root preimage computation). -/
def projectRawToSourceSnapshot (hash256 : ByteArray → ByteArray)
    (hdr : RawCNB1Header50) (rawSnap : RawSnapshotWireTerm) : SourceSnapshot :=
  let bSnap := bytesOfList (encodeSnapshotSectionList rawSnap)
  let compRoot32 := hash256 (mkSnapshotPreimageBytes hdr.generationV hdr.policyMask bSnap)
  { snapshotId := rawSnap.snapshotId
    generation := hdr.generationV
    authTierTag := hdr.authTierTag
    policyMask := hdr.policyMask
    claimedRootHex := bytes32ToLowerHex hdr.claimedRoot32
    computedRootHex := bytes32ToLowerHex compRoot32
    vertexIds := rawSnapshotVertexIds rawSnap
    vertexSorts := rawSnapshotVertexSorts rawSnap
    irRecords := rawSnap.irRecords.map projectRawWireIRRecord }

def closureOfTag (tag : Nat) : ClosureKind :=
  if tag = 1 then .eStar else .ePlus

/-- `#40` `B1`: Trusted `A1` Snapshot Anchor, Header Discipline, & `C*` Partition Exactness (`L394–432`). -/
def checkCNB1B1Bool (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (b : RawCNB1Bundle) (constIrIndices : List Nat) : Bool :=
  let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
  let bSnap := bytesOfList (encodeSnapshotSectionList b.rawSnap)
  let compRoot32 := hash256 (mkSnapshotPreimageBytes b.hdr.generationV b.hdr.policyMask bSnap)
  decide (b.hdr.closureTag = 1 ∨ b.hdr.closureTag = 2) &&
  decide (b.hdr.claimShortest = 0 ∨ b.hdr.claimShortest = 1) &&
  decide (b.hdr.authTierTag = 1) &&
  decide (b.hdr.reservedZero = 0 ∧ b.hdr.transitionTag = 0 ∧ b.hdr.padZero = 0) &&
  decide (b.hdr.policyMask = constitutionalMask0xFF33) &&
  decide (compRoot32 = b.hdr.claimedRoot32) &&
  match lookupPinnedA1 b.rawSnap.snapshotId reg with
  | none => false
  | some ent =>
      decide (b.hdr.generationV = ent.pinnedGen) &&
      decide (bytes32ToLowerHex b.hdr.claimedRoot32 = ent.pinnedRootHex) &&
      strictIncNatBool constIrIndices &&
      listAllBool (fun ci => decide (ci < b.rawSnap.irRecords.length)) constIrIndices &&
      decide (constIrIndices.map (ridOfIdx snap) = ent.pinnedConstIds) &&
      decide (constIrIndices = (projectIssuerPartition snap ent.pinnedConstIds).constIssuers)

/-- `#40` `B2`: Cross-Sort Vertex Collision Check, `0xFF33` + `relTag` Licensing, & Sealed IR Edge Reconstruction (`L435–462`). -/
def checkCNB1B2Bool (hash256 : ByteArray → ByteArray) (b : RawCNB1Bundle) : Bool :=
  let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
  nodupBool snap.vertexIds &&
  listAllBool (fun rawRc =>
    let srcSort := sortOfCode rawRc.sourceSortCode
    decide (nthOpt snap.vertexSorts rawRc.sourceVid = some srcSort) &&
    listAllBool (fun r =>
      let tgtSort := sortOfCode r.targetSortCode
      decide (nthOpt snap.vertexSorts r.targetVid = some tgtSort) &&
      licensedSortBit srcSort tgtSort &&
      decide (expectedSortPairByRelTag r.relTag = some (srcSort, tgtSort))) rawRc.refs)
    b.rawSnap.irRecords &&
  decide (b.candidateEdges = ((projectIRGraph snap).edges).map (fun e => (e.src, e.dst)))

theorem map_recordId_projectRawWireIRRecord (recs : List RawWireIRRecord) :
    (recs.map projectRawWireIRRecord).map SourceIRRecord.recordId =
      recs.map RawWireIRRecord.recordId := by
  induction recs with
  | nil => rfl
  | cons rc tl ih =>
    simp only [List.map_cons, projectRawWireIRRecord, ih]

/-- **`W2-C.1` Bridge Theorem (`w2c_b1_b2_implies_r1_anchor_and_graph`)**:
    Acceptance by wire-level `WF_RawCNB1Bundle + B1 + B2` guarantees untouched `#43` (`Ωλ-R1`)
    `checkSourceAnchorAndSortLaw reg snap = true`, exact `projectIssuerPartition` alignment,
    and exact `projectIRGraph` edge-list reconstruction. -/
theorem w2c_b1_b2_implies_r1_anchor_and_graph
    (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (b : RawCNB1Bundle) (constIrIndices : List Nat)
    (hwf : WF_RawCNB1Bundle b)
    (hb1 : checkCNB1B1Bool hash256 reg b constIrIndices = true)
    (hb2 : checkCNB1B2Bool hash256 b = true) :
    let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
    ∃ ent : PinnedA1Entry,
      lookupPinnedA1 snap.snapshotId reg = some ent ∧
      checkSourceAnchorAndSortLaw reg snap = true ∧
      constIrIndices = (projectIssuerPartition snap ent.pinnedConstIds).constIssuers ∧
      b.candidateEdges = ((projectIRGraph snap).edges).map (fun e => (e.src, e.dst)) := by
  dsimp only
  let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
  have hsnapDef : snap = projectRawToSourceSnapshot hash256 b.hdr b.rawSnap := rfl
  have hwfSnap : WF_RawSnapshotWire b.rawSnap := by
    unfold WF_RawCNB1Bundle wfRawCNB1BundleBool at hwf
    simp only [Bool.and_eq_true] at hwf
    exact hwf.1.1.1.2
  have hndRecIds : NodupList (snap.irRecords.map SourceIRRecord.recordId) := by
    rw [hsnapDef]
    dsimp only [projectRawToSourceSnapshot]
    rw [map_recordId_projectRawWireIRRecord]
    exact w2b_snapshot_ir_ids_nodup hwfSnap
  have hvTotBounds : 1 ≤ b.rawSnap.vTotal ∧
      listAllBool (wfRawWireIRRecordBool b.rawSnap.vTotal) b.rawSnap.irRecords = true := by
    unfold WF_RawSnapshotWire wfRawSnapshotWireBool at hwfSnap
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hwfSnap
    exact ⟨hwfSnap.1.1.1.2.1, hwfSnap.1.2⟩
  unfold checkCNB1B1Bool at hb1
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hb1
  rcases hb1 with ⟨⟨⟨⟨⟨⟨_, _⟩, htier⟩, _⟩, hmask⟩, hcompEq⟩, hregMatch⟩
  cases hlk : lookupPinnedA1 b.rawSnap.snapshotId reg with
  | none => rw [hlk] at hregMatch; cases hregMatch
  | some ent =>
    rw [hlk] at hregMatch
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hregMatch
    rcases hregMatch with ⟨⟨⟨⟨⟨hgenEq, hrootHexEq⟩, _⟩, _⟩, _⟩, hconstEq⟩
    unfold checkCNB1B2Bool at hb2
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hb2
    rcases hb2 with ⟨⟨hndVerts, hallSortRaw⟩, hedgesEq⟩
    have hsnapSid : snap.snapshotId = b.rawSnap.snapshotId := rfl
    refine ⟨ent, by rw [hsnapSid]; exact hlk, ?_, hconstEq, hedgesEq⟩
    unfold checkSourceAnchorAndSortLaw
    have hcompHexEq : snap.computedRootHex = snap.claimedRootHex := by
      rw [hsnapDef]
      dsimp only [projectRawToSourceSnapshot]
      rw [hcompEq]
    have hvLen1 : 1 ≤ snap.vertexIds.length := by
      rw [hsnapDef]
      dsimp only [projectRawToSourceSnapshot]
      rw [rawSnapshotVertexIds_length]
      exact hvTotBounds.1
    have hvLenSorts : snap.vertexIds.length = snap.vertexSorts.length := by
      rw [hsnapDef]
      dsimp only [projectRawToSourceSnapshot]
      rw [rawSnapshotVertexIds_length, rawSnapshotVertexSorts_length]
    have hndRecBool : nodupBool (snap.irRecords.map SourceIRRecord.recordId) = true :=
      (nodupBool_iff _).mpr hndRecIds
    have hallProjRecs : listAllBool (fun rc =>
        decide (rc.sourceVid < snap.vertexIds.length) &&
        decide (nthOpt snap.vertexSorts rc.sourceVid = some rc.sourceSort) &&
        listAllBool (fun ref =>
          decide (ref.targetVid < snap.vertexIds.length) &&
          decide (nthOpt snap.vertexSorts ref.targetVid = some ref.targetSort) &&
          licensedSortBit rc.sourceSort ref.targetSort &&
          decide (ref.relSrcSort = rc.sourceSort) &&
          decide (ref.relDstSort = ref.targetSort)) rc.refs) snap.irRecords = true := by
      rw [listAllBool_iff]
      intro rc hrcMem
      have hrcInMap : rc ∈ b.rawSnap.irRecords.map projectRawWireIRRecord := hrcMem
      rcases List.mem_map.mp hrcInMap with ⟨rawRc, hrawMem, rfl⟩
      have hwfRc := (listAllBool_iff _ _).mp hvTotBounds.2 rawRc hrawMem
      unfold wfRawWireIRRecordBool wfVertexWireBool at hwfRc
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hwfRc
      have hsrcLt : rawRc.sourceVid < snap.vertexIds.length := by
        rw [hsnapDef]; dsimp only [projectRawToSourceSnapshot]
        rw [rawSnapshotVertexIds_length]
        exact hwfRc.1.1.1.1.2.1.1
      have hallRefsWf := hwfRc.1.2
      have hsortRc := (listAllBool_iff _ _).mp hallSortRaw rawRc hrawMem
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hsortRc
      rcases hsortRc with ⟨hsrcSortEq, hrefsSort⟩
      dsimp only [projectRawWireIRRecord]
      rw [Bool.and_eq_true, Bool.and_eq_true]
      refine ⟨⟨decide_eq_true hsrcLt, decide_eq_true hsrcSortEq⟩, ?_⟩
      rw [listAllBool_iff]
      intro ref hrefMem
      rcases List.mem_map.mp hrefMem with ⟨rawRef, hrawRefMem, rfl⟩
      have hwfRef := (listAllBool_iff _ _).mp hallRefsWf rawRef hrawRefMem
      unfold wfRawWireRefBool wfVertexWireBool at hwfRef
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hwfRef
      have htgtLt : rawRef.targetVid < snap.vertexIds.length := by
        rw [hsnapDef]; dsimp only [projectRawToSourceSnapshot]
        rw [rawSnapshotVertexIds_length]
        exact hwfRef.1.1.1.1
      have hsRef := (listAllBool_iff _ _).mp hrefsSort rawRef hrawRefMem
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hsRef
      rcases hsRef with ⟨⟨htgtSortEq, hlic⟩, hexpRel⟩
      dsimp only [projectRawWireRef]
      rw [Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true]
      refine ⟨⟨⟨⟨decide_eq_true htgtLt, decide_eq_true htgtSortEq⟩, hlic⟩, ?_⟩, ?_⟩
      · apply decide_eq_true; rw [hexpRel]
      · apply decide_eq_true; rw [hexpRel]
    simp only [Bool.and_eq_true, decide_eq_true_eq]
    refine ⟨⟨⟨⟨⟨⟨⟨⟨htier, hmask⟩, hcompHexEq⟩, hvLen1⟩, hvLenSorts⟩, hndVerts⟩, hndRecBool⟩, ?_⟩, hallProjRecs⟩
    rw [hsnapSid, hlk]
    simp [projectRawToSourceSnapshot, hgenEq, hrootHexEq]

/-! ## `W2-C.2` (`F93-02`): Independent `0x05` Branch (`B1..B6` → `#41` `checkVerifiedBase`) -/

theorem pairLtBool_irrefl (p : VertexId × VertexId) : pairLtBool p p = false := by
  unfold pairLtBool
  have hnot1 : ¬ (p.1 < p.1) := Nat.lt_irrefl p.1
  have hnot2 : ¬ (p.2 < p.2) := Nat.lt_irrefl p.2
  simp [hnot1, hnot2]

theorem pairLtBool_trans {p1 p2 p3 : VertexId × VertexId}
    (h12 : pairLtBool p1 p2 = true) (h23 : pairLtBool p2 p3 = true) :
    pairLtBool p1 p3 = true := by
  rcases p1 with ⟨x1, y1⟩
  rcases p2 with ⟨x2, y2⟩
  rcases p3 with ⟨x3, y3⟩
  unfold VertexId at x1 y1 x2 y2 x3 y3
  unfold pairLtBool at h12 h23 ⊢
  dsimp only at h12 h23 ⊢
  by_cases ha : x1 < x2
  · rw [if_pos ha] at h12
    by_cases hb : x2 < x3
    · rw [if_pos (Nat.lt_trans ha hb)]
    · rw [if_neg hb] at h23
      by_cases hc : x3 < x2
      · rw [if_pos hc] at h23; cases h23
      · have heq : x2 = x3 := by omega
        rw [← heq, if_pos ha]
  · rw [if_neg ha] at h12
    by_cases ha2 : x2 < x1
    · rw [if_pos ha2] at h12; cases h12
    · rw [if_neg ha2] at h12
      have heq1 : x1 = x2 := by omega
      rw [heq1]
      by_cases hb : x2 < x3
      · rw [if_pos hb]
      · rw [if_neg hb] at h23 ⊢
        by_cases hc : x3 < x2
        · rw [if_pos hc] at h23; cases h23
        · rw [if_neg hc] at h23 ⊢
          simp only [decide_eq_true_eq] at h12 h23 ⊢
          exact Nat.lt_trans h12 h23

theorem strictLexPairs_nodup {pairs : List (VertexId × VertexId)}
    (h : strictLexPairsBool pairs = true) :
    NodupList pairs :=
  strictSortedBy_nodup pairLtBool_irrefl (fun _ _ _ h1 h2 => pairLtBool_trans h1 h2) h

def rankTableOfWitnesses (posW : List RawPosWitness) : List (VertexId × VertexId × Nat) :=
  posW.map (fun w => (w.sVid, w.tVid, w.rank))

def hopTableOfEntries (hops : List RawHopWireEntry) :
    List (VertexId × VertexId × List VertexId) :=
  hops.map (fun e => (e.sVid, e.tVid, e.hops))

def projectWireBase0x05 (snap : SourceSnapshot) (b : RawCNB1Bundle)
    (hopEntries : List RawHopWireEntry) : BaseData :=
  { G := projectIRGraph snap
    kappa := closureOfTag b.hdr.closureTag
    rankEntries := rankTableOfWitnesses b.posWitnesses
    maxHopEntries := hopTableOfEntries hopEntries }

theorem lookupPairNat_witness_iff {posW : List RawPosWitness}
    (hnd : NodupList (posW.map (fun w => (w.sVid, w.tVid))))
    (u v : VertexId) (r : Nat) :
    lookupPairNat u v (rankTableOfWitnesses posW) = some r ↔
    ∃ w ∈ posW, w.sVid = u ∧ w.tVid = v ∧ w.rank = r := by
  induction posW with
  | nil => simp [rankTableOfWitnesses, lookupPairNat]
  | cons hd tl ih =>
    simp only [List.map_cons] at hnd
    cases hnd with
    | cons hnotMem hndTl =>
      simp only [rankTableOfWitnesses, List.map_cons, lookupPairNat]
      split
      · next heq =>
        rcases heq with ⟨hu, hv⟩
        constructor
        · intro hs
          injection hs with hr
          exact ⟨hd, List.Mem.head tl, hu, hv, hr⟩
        · intro ⟨w, hwMem, hws, hwt, hwr⟩
          cases hwMem with
          | head => rw [hwr]
          | tail _ hm =>
            exfalso
            apply hnotMem
            rw [hu, hv, ← hws, ← hwt]
            exact List.mem_map_of_mem (f := fun x : RawPosWitness => (x.sVid, x.tVid)) hm
      · next hne =>
        change lookupPairNat u v (rankTableOfWitnesses tl) = some r ↔ _
        rw [ih hndTl]
        constructor
        · intro ⟨w, hm, h1, h2, h3⟩
          exact ⟨w, List.Mem.tail hd hm, h1, h2, h3⟩
        · intro ⟨w, hwMem, h1, h2, h3⟩
          cases hwMem with
          | head => exfalso; exact hne ⟨h1, h2⟩
          | tail _ hm => exact ⟨w, hm, h1, h2, h3⟩

theorem lookupPairNat_witness_none_iff {posW : List RawPosWitness}
    (u v : VertexId) :
    lookupPairNat u v (rankTableOfWitnesses posW) = none ↔
    (u, v) ∉ posW.map (fun w => (w.sVid, w.tVid)) := by
  induction posW with
  | nil => simp [rankTableOfWitnesses, lookupPairNat]
  | cons hd tl ih =>
    simp only [rankTableOfWitnesses, List.map_cons, lookupPairNat, List.mem_cons]
    split
    · next heq =>
      rcases heq with ⟨hu, hv⟩
      simp [hu, hv]
    · next hne =>
      change lookupPairNat u v (rankTableOfWitnesses tl) = none ↔ _
      rw [ih]
      constructor
      · intro hnot hmem
        rcases hmem with hp | hm
        · injection hp with hu hv; exact hne ⟨hu.symm, hv.symm⟩
        · exact hnot hm
      · intro hnot hm
        exact hnot (Or.inr hm)

theorem lookupPairList_hops_of_mem {hops : List RawHopWireEntry}
    (hnd : NodupList (hops.map (fun e => (e.sVid, e.tVid))))
    {ent : RawHopWireEntry} (hmem : ent ∈ hops) :
    lookupPairList ent.sVid ent.tVid (hopTableOfEntries hops) = ent.hops := by
  induction hops with
  | nil => cases hmem
  | cons hd tl ih =>
    simp only [List.map_cons] at hnd
    cases hnd with
    | cons hnotMem hndTl =>
      simp only [hopTableOfEntries, List.map_cons, lookupPairList]
      cases hmem with
      | head => simp
      | tail _ hm =>
        split
        · next heq =>
          exfalso
          apply hnotMem
          rw [heq.1, heq.2]
          exact List.mem_map_of_mem (f := fun x : RawHopWireEntry => (x.sVid, x.tVid)) hm
        · exact ih hndTl hm

theorem lookupPairList_hops_of_not_mem {hops : List RawHopWireEntry}
    {u t : VertexId} (hnot : (u, t) ∉ hops.map (fun e => (e.sVid, e.tVid))) :
    lookupPairList u t (hopTableOfEntries hops) = [] := by
  induction hops with
  | nil => rfl
  | cons hd tl ih =>
    simp only [List.map_cons, List.mem_cons, not_or] at hnot
    simp only [hopTableOfEntries, List.map_cons, lookupPairList]
    split
    · next heq =>
      exfalso
      exact hnot.1 (Prod.ext heq.1.symm heq.2.symm)
    · exact ih hnot.2

/-- `#40` `B3`: Positive Rank Soundness (`omega_kappa_pure_checker.py` L465–515). -/
def checkCNB1B3Bool (b : RawCNB1Bundle) : Bool :=
  let vTot := b.rawSnap.vTotal
  let rkTbl := rankTableOfWitnesses b.posWitnesses
  decide (b.posWitnesses.map (fun w => (w.sVid, w.tVid)) = b.candidateRelations) &&
  if b.hdr.closureTag = 1 then
    listAllBool (fun w =>
      if w.rank = 0 then
        decide (w.sVid = w.tVid ∧ w.nextHop = noneVidSentinel)
      else
        decide (w.sVid ≠ w.tVid ∧ w.rank ≤ vTot ∧ w.nextHop < vTot) &&
        listMemBool (w.sVid, w.nextHop) b.candidateEdges &&
        match lookupPairNat w.nextHop w.tVid rkTbl with
        | none => false
        | some nhRk => decide (nhRk < w.rank)) b.posWitnesses
  else
    listAllBool (fun w =>
      decide (1 ≤ w.rank ∧ w.rank ≤ vTot ∧ w.nextHop < vTot) &&
      if w.rank = 1 then
        listMemBool (w.sVid, w.tVid) b.candidateEdges && decide (w.nextHop = w.tVid)
      else
        listMemBool (w.sVid, w.nextHop) b.candidateEdges &&
        match lookupPairNat w.nextHop w.tVid rkTbl with
        | none => false
        | some nhRk => decide (1 ≤ nhRk ∧ nhRk < w.rank)) b.posWitnesses

/-- `#40` `B4`: Closed Cut Completeness (`omega_kappa_pure_checker.py` L517–540). -/
def checkCNB1B4Bool (b : RawCNB1Bundle) : Bool :=
  let vTot := b.rawSnap.vTotal
  decide (b.closedCuts.map RawClosedCut.srcVid = rangeBelow vTot) &&
  (if b.hdr.closureTag = 2 then
     listAllBool (fun edge => listMemBool edge b.candidateRelations) b.candidateEdges
   else true) &&
  listAllBool (fun cut =>
    let sFromR := (b.candidateRelations.filter (fun p => decide (p.1 = cut.srcVid))).map Prod.snd
    listAllBool (fun t => listMemBool t sFromR) cut.targets &&
    listAllBool (fun t => listMemBool t cut.targets) sFromR &&
    (if b.hdr.closureTag = 1 then listMemBool cut.srcVid cut.targets else true) &&
    listAllBool (fun edge =>
      if listMemBool edge.1 cut.targets then listMemBool edge.2 cut.targets else true)
      b.candidateEdges) b.closedCuts

/-- `#40` `B5`: Bellman Geodesic Exactness (`omega_kappa_pure_checker.py` L542–571). -/
def checkCNB1B5Bool (b : RawCNB1Bundle) : Bool :=
  if b.hdr.claimShortest = 0 then true
  else
    let vTot := b.rawSnap.vTotal
    let rkTbl := rankTableOfWitnesses b.posWitnesses
    listAllBool (fun w =>
      if (b.hdr.closureTag = 1 ∧ 0 < w.rank) ∨ (b.hdr.closureTag = 2 ∧ 1 < w.rank) then
        decide (lookupPairNat w.nextHop w.tVid rkTbl = some (w.rank - 1))
      else true) b.posWitnesses &&
    listAllBool (fun edge =>
      (if b.hdr.closureTag = 2 then
         match lookupPairNat edge.1 edge.2 rkTbl with
         | none => true
         | some rk => decide (rk = 1)
       else true) &&
      listAllBool (fun tV =>
        match lookupPairNat edge.2 tV rkTbl, lookupPairNat edge.1 tV rkTbl with
        | some wtRk, some utRk => decide (utRk ≤ wtRk + 1)
        | _, _ => true) (rangeBelow vTot)) b.candidateEdges

/-- `#40` `B6`: Maximal Geodesic First-Hop Bundle Exactness (`omega_kappa_pure_checker.py` L573–626). -/
def checkCNB1B6Bool (b : RawCNB1Bundle) (hopEntries : List RawHopWireEntry) : Bool :=
  let vTot := b.rawSnap.vTotal
  let rkTbl := rankTableOfWitnesses b.posWitnesses
  decide (b.hdr.claimShortest = 1) &&
  decide (hopEntries.map (fun e => (e.sVid, e.tVid)) = b.candidateRelations) &&
  strictLexPairsBool (hopEntries.map (fun e => (e.sVid, e.tVid))) &&
  listAllBool (fun ent =>
    decide (lookupPairNat ent.sVid ent.tVid rkTbl = some ent.rank) &&
    strictIncNatBool ent.hops &&
    listAllBool (fun h => decide (h < vTot)) ent.hops &&
    let isExpHop (z : VertexId) : Bool :=
      if b.hdr.closureTag = 1 ∧ ent.sVid = ent.tVid then false
      else if b.hdr.closureTag = 2 ∧ ent.rank = 1 then
        listMemBool (ent.sVid, ent.tVid) b.candidateEdges && decide (z = ent.tVid)
      else
        listMemBool (ent.sVid, z) b.candidateEdges &&
        decide (lookupPairNat z ent.tVid rkTbl = some (ent.rank - 1))
    listAllBool (fun z => decide (listMemBool z ent.hops = isExpHop z)) (rangeBelow vTot))
    hopEntries

theorem mem_sFromR_iff {rels : List (VertexId × VertexId)} {u v : VertexId} :
    v ∈ (rels.filter (fun p => decide (p.1 = u))).map Prod.snd ↔ (u, v) ∈ rels := by
  simp only [List.mem_map, List.mem_filter, decide_eq_true_eq]
  constructor
  · intro ⟨⟨x, y⟩, ⟨hmem, hx⟩, hy⟩
    dsimp only at hx hy
    subst hx; subst hy; exact hmem
  · intro hmem; exact ⟨(u, v), ⟨hmem, rfl⟩, rfl⟩

theorem b4_cut_props {b : RawCNB1Bundle} (hb4 : checkCNB1B4Bool b = true)
    {u : VertexId} (hu : u < b.rawSnap.vTotal) :
    ((b.hdr.closureTag = 1 → (u, u) ∈ b.candidateRelations) ∧
     (∀ x y, (x, y) ∈ b.candidateEdges → (u, x) ∈ b.candidateRelations → (u, y) ∈ b.candidateRelations)) ∧
    (b.hdr.closureTag = 2 → ∀ e ∈ b.candidateEdges, e ∈ b.candidateRelations) := by
  unfold checkCNB1B4Bool at hb4
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hb4
  rcases hb4 with ⟨⟨hdom, hplusBase⟩, hcuts⟩
  have huInMap : u ∈ b.closedCuts.map RawClosedCut.srcVid := by
    rw [hdom, mem_rangeBelow_iff]; exact hu
  rcases List.mem_map.mp huInMap with ⟨cut, hcutMem, hcutSrc⟩
  have hc := (listAllBool_iff _ _).mp hcuts cut hcutMem
  simp only [Bool.and_eq_true] at hc
  rcases hc with ⟨⟨⟨hcSub, hrSub⟩, hrefl⟩, hclosed⟩
  have hiff : ∀ z, z ∈ cut.targets ↔ (u, z) ∈ b.candidateRelations := by
    intro z
    subst hcutSrc
    constructor
    · intro hz
      have h1 := (listAllBool_iff _ _).mp hcSub z hz
      exact mem_sFromR_iff.mp ((listMemBool_iff _ _).mp h1)
    · intro hrel
      have h1 := (listAllBool_iff _ _).mp hrSub z (mem_sFromR_iff.mpr hrel)
      exact (listMemBool_iff _ _).mp h1
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · intro hkl1
    rw [if_pos hkl1] at hrefl
    have hm := (listMemBool_iff _ _).mp hrefl
    rw [hcutSrc] at hm
    exact (hiff u).mp hm
  · intro x y hxy hux
    have hxT : listMemBool x cut.targets = true := (listMemBool_iff _ _).mpr ((hiff x).mpr hux)
    have he := (listAllBool_iff _ _).mp hclosed (x, y) hxy
    dsimp only at he
    rw [if_pos hxT] at he
    exact (hiff y).mp ((listMemBool_iff _ _).mp he)
  · intro hkl2 e he
    rw [if_pos hkl2] at hplusBase
    exact (listMemBool_iff _ _).mp ((listAllBool_iff _ _).mp hplusBase e he)

theorem b3_b4_trans_step {b : RawCNB1Bundle}
    (hwf : WF_RawCNB1Bundle b)
    (hclo : b.hdr.closureTag = 1 ∨ b.hdr.closureTag = 2)
    (hb3 : checkCNB1B3Bool b = true)
    (hb4 : checkCNB1B4Bool b = true) :
    ∀ (k : Nat) {u w v rk : Nat},
      u < b.rawSnap.vTotal →
      (u, w) ∈ b.candidateRelations →
      lookupPairNat w v (rankTableOfWitnesses b.posWitnesses) = some rk →
      rk ≤ k →
      (u, v) ∈ b.candidateRelations := by
  have hndW : NodupList (b.posWitnesses.map (fun x => (x.sVid, x.tVid))) := by
    unfold WF_RawCNB1Bundle wfRawCNB1BundleBool wfPrfSectionBool at hwf
    simp only [Bool.and_eq_true] at hwf
    exact strictLexPairs_nodup hwf.1.2.1.1.1.1.2
  unfold checkCNB1B3Bool at hb3
  rcases (Bool.and_eq_true _ _).mp hb3 with ⟨_, hb3Body⟩
  intro k
  induction k with
  | zero =>
    intro u w v rk hu huw hlk hrk0
    have hrkEq0 : rk = 0 := by omega
    subst hrkEq0
    rcases (lookupPairNat_witness_iff hndW w v 0).mp hlk with ⟨pw, hpwMem, rfl, rfl, hpwRk⟩
    rcases hclo with hkl1 | hkl2
    · rw [if_pos hkl1] at hb3Body
      have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
      rw [if_pos hpwRk] at hpwOk
      have hst : pw.sVid = pw.tVid := (of_decide_eq_true hpwOk).1
      rw [← hst]; exact huw
    · have hne1 : b.hdr.closureTag ≠ 1 := by omega
      rw [if_neg hne1] at hb3Body
      have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
      omega
  | succ k' ih =>
    intro u w v rk hu huw hlk hrkLe
    by_cases hle' : rk ≤ k'
    · exact ih hu huw hlk hle'
    · have hrkSucc : rk = k' + 1 := by omega
      subst hrkSucc
      have hcutU := (b4_cut_props hb4 hu).1.2
      rcases (lookupPairNat_witness_iff hndW w v (k' + 1)).mp hlk with ⟨pw, hpwMem, rfl, rfl, hpwRk⟩
      rcases hclo with hkl1 | hkl2
      · rw [if_pos hkl1] at hb3Body
        have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
        rw [if_neg (by omega : pw.rank ≠ 0)] at hpwOk
        simp only [Bool.and_eq_true, listMemBool_iff] at hpwOk
        rcases hpwOk with ⟨⟨_, hEdge⟩, hNhMatch⟩
        cases hnhLk : lookupPairNat pw.nextHop pw.tVid (rankTableOfWitnesses b.posWitnesses) with
        | none => rw [hnhLk] at hNhMatch; cases hNhMatch
        | some nhRk =>
          rw [hnhLk] at hNhMatch
          have hltRk : nhRk < pw.rank := of_decide_eq_true hNhMatch
          have hunh : (u, pw.nextHop) ∈ b.candidateRelations := hcutU pw.sVid pw.nextHop hEdge huw
          exact ih hu hunh hnhLk (by omega)
      · have hne1 : b.hdr.closureTag ≠ 1 := by omega
        rw [if_neg hne1] at hb3Body
        have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
        rcases (Bool.and_eq_true _ _).mp hpwOk with ⟨_, hpwStep⟩
        by_cases hrk1 : pw.rank = 1
        · rw [if_pos hrk1] at hpwStep
          simp only [Bool.and_eq_true, listMemBool_iff] at hpwStep
          exact hcutU pw.sVid pw.tVid hpwStep.1 huw
        · rw [if_neg hrk1] at hpwStep
          simp only [Bool.and_eq_true, listMemBool_iff] at hpwStep
          rcases hpwStep with ⟨hEdge, hNhMatch⟩
          cases hnhLk : lookupPairNat pw.nextHop pw.tVid (rankTableOfWitnesses b.posWitnesses) with
          | none => rw [hnhLk] at hNhMatch; cases hNhMatch
          | some nhRk =>
            rw [hnhLk] at hNhMatch
            have hltRk : (1 ≤ nhRk ∧ nhRk < pw.rank) := of_decide_eq_true hNhMatch
            have hunh : (u, pw.nextHop) ∈ b.candidateRelations := hcutU pw.sVid pw.nextHop hEdge huw
            exact ih hu hunh hnhLk (by omega)

theorem hopEntries_rank_align :
    ∀ {hops : List RawHopWireEntry} {posW : List RawPosWitness}
      {fullPosW : List RawPosWitness},
      NodupList (fullPosW.map (fun w => (w.sVid, w.tVid))) →
      (∀ w ∈ posW, w ∈ fullPosW) →
      hops.map (fun e => (e.sVid, e.tVid)) = posW.map (fun w => (w.sVid, w.tVid)) →
      (∀ e ∈ hops, lookupPairNat e.sVid e.tVid (rankTableOfWitnesses fullPosW) = some e.rank) →
      hops.map (fun e => (e.sVid, e.tVid, e.rank)) = posW.map (fun w => (w.sVid, w.tVid, w.rank))
  | [], [], _, _, _, _, _ => rfl
  | [], _ :: _, _, _, _, hdom, _ => by cases hdom
  | _ :: _, [], _, _, _, hdom, _ => by cases hdom
  | he :: htl, pw :: pwtl, fullPosW, hndFull, hsub, hdom, hrkOk => by
      simp only [List.map_cons, List.cons.injEq, Prod.mk.injEq] at hdom
      rcases hdom with ⟨⟨hsEq, htEq⟩, htlDom⟩
      have hlk := hrkOk he (List.Mem.head htl)
      rcases (lookupPairNat_witness_iff hndFull he.sVid he.tVid he.rank).mp hlk with
        ⟨pw', hpw'Mem, hs', ht', hrk'⟩
      have hpwInFull : pw ∈ fullPosW := hsub pw (List.Mem.head pwtl)
      have hlkPw : lookupPairNat pw.sVid pw.tVid (rankTableOfWitnesses fullPosW) = some pw.rank :=
        (lookupPairNat_witness_iff hndFull pw.sVid pw.tVid pw.rank).mpr ⟨pw, hpwInFull, rfl, rfl, rfl⟩
      rw [hsEq, htEq] at hlk
      rw [hlk] at hlkPw
      injection hlkPw with hrkEq
      have hrec := hopEntries_rank_align hndFull
        (fun x hx => hsub x (List.Mem.tail pw hx))
        htlDom
        (fun x hx => hrkOk x (List.Mem.tail he hx))
      simp only [List.map_cons, hsEq, htEq, hrkEq, hrec]

/-- **`F93-02` Theorem (`f93_02_b1_to_b6_implies_checkVerifiedBase`)**:
    Independent `0x05` Base-Refinement Bridge (`93rd Ruling §2.2`):
    Wire-level acceptance by `#40`'s `B1..B6` (`claimShortest = 1` + `posWitnesses` +
    `closedCuts` + `hopEntries`) directly implies untouched `#41` `checkVerifiedBase = true`
    AND exact `projectRawCarrierToSpec = some .geodesicBundle` (with ZERO reliance on `0x03` synthesis). -/
theorem f93_02_b1_to_b6_implies_checkVerifiedBase
    (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (b : RawCNB1Bundle)
    (constIrIndices : List Nat) (hopEntries : List RawHopWireEntry)
    (hwf : WF_RawCNB1Bundle b)
    (hb1 : checkCNB1B1Bool hash256 reg b constIrIndices = true)
    (hb2 : checkCNB1B2Bool hash256 b = true)
    (hb3 : checkCNB1B3Bool b = true)
    (hb4 : checkCNB1B4Bool b = true)
    (hb5 : checkCNB1B5Bool b = true)
    (hb6 : checkCNB1B6Bool b hopEntries = true) :
    let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
    ∃ ent : PinnedA1Entry,
      let ip := projectIssuerPartition snap ent.pinnedConstIds
      let base05 := projectWireBase0x05 snap b hopEntries
      lookupPinnedA1 snap.snapshotId reg = some ent ∧
      checkSourceAnchorAndSortLaw reg snap = true ∧
      constIrIndices = ip.constIssuers ∧
      checkVerifiedBase ip base05 = true ∧
      projectRawCarrierToSpec base05 (.geodesicHops hopEntries) = some .geodesicBundle := by
  dsimp only
  rcases w2c_b1_b2_implies_r1_anchor_and_graph hash256 reg b constIrIndices hwf hb1 hb2 with
    ⟨ent, hlk, hAnchor, hconstEq, hedgesEq⟩
  let snap := projectRawToSourceSnapshot hash256 b.hdr b.rawSnap
  let ip := projectIssuerPartition snap ent.pinnedConstIds
  let base05 := projectWireBase0x05 snap b hopEntries
  have hGwf : GraphWF ip base05.G := projectIRGraph_wf snap ent.pinnedConstIds
  have hCheckGwf : checkGraphWF ip base05.G = true := by
    unfold checkGraphWF
    rw [Bool.and_eq_true, nodupBool_iff, listAllBool_iff]
    refine ⟨hGwf.1, fun e he => ?_⟩
    rcases hGwf.2 e he with ⟨h1, h2, h3, h4⟩
    simp only [Bool.and_eq_true, decide_eq_true_eq, listAllBool_iff, Bool.or_eq_true, listMemBool_iff]
    exact ⟨⟨⟨h1, h2⟩, h3⟩, h4⟩
  have hCheckPart : checkIssuerPartition ip = true :=
    checkIssuerPartition_projectIssuerPartition snap ent.pinnedConstIds
  have hnEq : base05.G.numVertices = b.rawSnap.vTotal := by
    change snap.vertexIds.length = b.rawSnap.vTotal
    exact rawSnapshotVertexIds_length b.rawSnap
  have hclo : b.hdr.closureTag = 1 ∨ b.hdr.closureTag = 2 := by
    unfold checkCNB1B1Bool at hb1
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hb1
    exact hb1.1.1.1.1.1.1
  have hndW : NodupList (b.posWitnesses.map (fun x => (x.sVid, x.tVid))) := by
    unfold WF_RawCNB1Bundle wfRawCNB1BundleBool wfPrfSectionBool at hwf
    simp only [Bool.and_eq_true] at hwf
    exact strictLexPairs_nodup hwf.1.2.1.1.1.1.2
  have hb3Copy := hb3
  unfold checkCNB1B3Bool at hb3
  rcases (Bool.and_eq_true _ _).mp hb3 with ⟨hdomWB, hb3Body⟩
  have hdomW : b.posWitnesses.map (fun w => (w.sVid, w.tVid)) = b.candidateRelations :=
    of_decide_eq_true hdomWB
  unfold checkCNB1B6Bool at hb6
  simp only [Bool.and_eq_true] at hb6
  rcases hb6 with ⟨⟨⟨hcsh1B, hdomHB⟩, hlexH⟩, hallHops⟩
  have hcsh1 : b.hdr.claimShortest = 1 := of_decide_eq_true hcsh1B
  have hdomH : hopEntries.map (fun e => (e.sVid, e.tVid)) = b.candidateRelations :=
    of_decide_eq_true hdomHB
  have hndH : NodupList (hopEntries.map (fun e => (e.sVid, e.tVid))) :=
    strictLexPairs_nodup hlexH
  unfold checkCNB1B5Bool at hb5
  rw [if_neg (by omega : b.hdr.claimShortest ≠ 0)] at hb5
  rcases (Bool.and_eq_true _ _).mp hb5 with ⟨hb5Pred, hb5Bellman⟩
  have hedgeMemIff : ∀ x y, listMemBool (x, y) b.candidateEdges = (edgeSupport? base05.G x y).isSome := by
    intro x y
    cases hr : (edgeSupport? base05.G x y).isSome
    · apply (listMemBool_false_iff _ _).mpr
      rw [hedgesEq]
      intro hm
      rcases List.mem_map.mp hm with ⟨e, he, hp⟩
      injection hp with hx hy
      subst hx; subst hy
      have hs := edge_mem_gives_edgeSupport? hGwf he
      change edgeSupport? base05.G e.src e.dst = some e.support at hs
      rw [hs] at hr; cases hr
    · apply (listMemBool_iff _ _).mpr
      rw [hedgesEq]
      cases hs : edgeSupport? base05.G x y with
      | none => rw [hs] at hr; cases hr
      | some supp =>
        have he := (edgeSupport?_eq_some_iff hGwf x y supp).mp hs
        exact List.mem_map_of_mem (f := fun e : GraphEdge => (e.src, e.dst)) he
  have hedgeGivesRel : ∀ u w, u < b.rawSnap.vTotal → (u, w) ∈ b.candidateEdges → (u, w) ∈ b.candidateRelations := by
    intro u w hu he
    rcases b4_cut_props hb4 hu with ⟨⟨hrefl1, hcl⟩, hbase2⟩
    rcases hclo with hkl1 | hkl2
    · exact hcl u w he (hrefl1 hkl1)
    · exact hbase2 hkl2 (u, w) he
  have hselfStarRank0 : ∀ v < b.rawSnap.vTotal, b.hdr.closureTag = 1 →
      lookupPairNat v v (rankTableOfWitnesses b.posWitnesses) = some 0 := by
    intro v hv hkl1
    have hvvRel : (v, v) ∈ b.candidateRelations := (b4_cut_props hb4 hv).1.1 hkl1
    rw [← hdomW] at hvvRel
    rcases List.mem_map.mp hvvRel with ⟨pw, hpwMem, hp⟩
    injection hp with hsEq htEq
    have hpwOk := (listAllBool_iff _ _).mp (by rw [if_pos hkl1] at hb3Body; exact hb3Body) pw hpwMem
    by_cases hr0 : pw.rank = 0
    · exact (lookupPairNat_witness_iff hndW v v 0).mpr ⟨pw, hpwMem, hsEq, htEq, hr0⟩
    · rw [if_neg hr0] at hpwOk
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
      exfalso; exact hpwOk.1.1.1 (hsEq.trans htEq.symm)
  refine ⟨ent, hlk, hAnchor, hconstEq, ?_, ?_⟩
  · change checkVerifiedBase ip base05 = true
    unfold checkVerifiedBase
    dsimp only
    rw [Bool.and_eq_true, Bool.and_eq_true]
    refine ⟨⟨hCheckPart, hCheckGwf⟩, ?_⟩
    rw [listAllBool_iff]
    intro u huR
    rw [listAllBool_iff]
    intro v hvR
    have hu : u < b.rawSnap.vTotal := by rw [← hnEq]; exact (mem_rangeBelow_iff _ _).mp huR
    have hv : v < b.rawSnap.vTotal := by rw [← hnEq]; exact (mem_rangeBelow_iff _ _).mp hvR
    rw [Bool.and_eq_true]
    refine ⟨?_, ?_⟩
    · -- `checkRankPair base05 u v = true`
      unfold checkRankPair
      dsimp only
      cases hrk : rankOf base05 u v with
      | none =>
        have hnotRel : (u, v) ∉ b.candidateRelations := by
          rw [← hdomW]
          exact (lookupPairNat_witness_none_iff u v).mp hrk
        have hnotRefl : decide (base05.kappa = .eStar ∧ u = v) = false := by
          apply decide_eq_false
          intro ⟨hkap, huv⟩
          subst huv
          have hkl1 : b.hdr.closureTag = 1 := by
            change closureOfTag b.hdr.closureTag = .eStar at hkap
            unfold closureOfTag at hkap
            split at hkap
            · assumption
            · cases hkap
          exact hnotRel ((b4_cut_props hb4 hu).1.1 hkl1)
        have hnotDir : (edgeSupport? base05.G u v).isSome = false := by
          rw [← hedgeMemIff u v]
          exact (listMemBool_false_iff _ _).mpr (fun he => hnotRel (hedgeGivesRel u v hu he))
        simp only [hnotRefl, hnotDir, Bool.not_false, Bool.true_and, listAllBool_iff]
        intro e heMem
        split
        · next hsrcEq =>
          subst hsrcEq
          apply decide_eq_true
          cases hdstRk : rankOf base05 e.dst v with
          | none => rfl
          | some rw =>
            exfalso
            have heCand : (e.src, e.dst) ∈ b.candidateEdges := by
              apply (listMemBool_iff _ _).mp
              rw [hedgeMemIff e.src e.dst, edge_mem_gives_edgeSupport? hGwf heMem]; rfl
            have huDstRel : (e.src, e.dst) ∈ b.candidateRelations := hedgeGivesRel e.src e.dst hu heCand
            have huvRel := b3_b4_trans_step hwf hclo hb3Copy hb4 rw hu huDstRel hdstRk (Nat.le_refl rw)
            exact hnotRel huvRel
        · rfl
      | some rkVal =>
        rcases (lookupPairNat_witness_iff hndW u v rkVal).mp hrk with ⟨pw, hpwMem, hsEq, htEq, hrkEq⟩
        cases rkVal with
        | zero =>
          rcases hclo with hkl1 | hkl2
          · rw [if_pos hkl1] at hb3Body
            have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
            rw [if_pos hrkEq] at hpwOk
            have hst := (of_decide_eq_true hpwOk).1
            apply decide_eq_true
            refine ⟨?_, hsEq.symm.trans (hst.trans htEq)⟩
            change closureOfTag b.hdr.closureTag = .eStar
            simp [closureOfTag, hkl1]
          · have hne1 : b.hdr.closureTag ≠ 1 := by omega
            rw [if_neg hne1] at hb3Body
            have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
            simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
            omega
        | succ r1 =>
          cases r1 with
          | zero =>
            -- `rkVal = 1`
            rcases hclo with hkl1 | hkl2
            · rw [if_pos hkl1] at hb3Body
              have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
              rw [if_neg (by omega : pw.rank ≠ 0)] at hpwOk
              simp only [Bool.and_eq_true, decide_eq_true_eq, listMemBool_iff] at hpwOk
              rcases hpwOk with ⟨⟨⟨hneST, _⟩, hEdge⟩, _⟩
              have hpred := (listAllBool_iff _ _).mp hb5Pred pw hpwMem
              rw [if_pos (Or.inl ⟨hkl1, by omega⟩)] at hpred
              have hnhRk0 : lookupPairNat pw.nextHop pw.tVid (rankTableOfWitnesses b.posWitnesses) = some 0 := by
                have h1 := of_decide_eq_true hpred
                rw [hrkEq] at h1; exact h1
              rcases (lookupPairNat_witness_iff hndW pw.nextHop pw.tVid 0).mp hnhRk0 with
                ⟨pw0, hpw0Mem, hs0, ht0, hr0⟩
              have hpw0Ok := (listAllBool_iff _ _).mp hb3Body pw0 hpw0Mem
              rw [if_pos hr0] at hpw0Ok
              have hnhEqT : pw.nextHop = v := hs0.symm.trans ((of_decide_eq_true hpw0Ok).1.trans (ht0.trans htEq))
              rw [hsEq, hnhEqT] at hEdge
              have hhas : (edgeSupport? base05.G u v).isSome = true := by
                rw [← hedgeMemIff u v]; exact (listMemBool_iff _ _).mpr hEdge
              have hnotRefl : decide (base05.kappa = .eStar ∧ u = v) = false := by
                apply decide_eq_false
                intro ⟨_, huv⟩; exact hneST (hsEq.trans (huv.trans htEq.symm))
              simp [hnotRefl, hhas]
            · have hne1 : b.hdr.closureTag ≠ 1 := by omega
              rw [if_neg hne1] at hb3Body
              have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
              rcases (Bool.and_eq_true _ _).mp hpwOk with ⟨_, hpw1⟩
              rw [if_pos hrkEq] at hpw1
              simp only [Bool.and_eq_true, listMemBool_iff] at hpw1
              have hEdge := hpw1.1
              rw [hsEq, htEq] at hEdge
              have hhas : (edgeSupport? base05.G u v).isSome = true := by
                rw [← hedgeMemIff u v]; exact (listMemBool_iff _ _).mpr hEdge
              have hnotRefl : decide (base05.kappa = .eStar ∧ u = v) = false := by
                apply decide_eq_false
                intro ⟨hkap, _⟩
                change closureOfTag b.hdr.closureTag = .eStar at hkap
                simp [closureOfTag, hne1] at hkap
              simp [hnotRefl, hhas]
          | succ r' =>
            -- `rkVal = r' + 2`
            have hnotRefl : decide (base05.kappa = .eStar ∧ u = v) = false := by
              apply decide_eq_false
              intro ⟨hkap, huv⟩
              change closureOfTag b.hdr.closureTag = .eStar at hkap
              unfold closureOfTag at hkap
              split at hkap
              · next hkl1 =>
                have h0 := hselfStarRank0 u hu hkl1
                rw [← huv] at hrk
                change lookupPairNat u u (rankTableOfWitnesses b.posWitnesses) = some (r' + 2) at hrk
                rw [h0] at hrk; cases hrk
              · cases hkap
            have hnotDir : (edgeSupport? base05.G u v).isSome = false := by
              rw [← hedgeMemIff u v]
              apply (listMemBool_false_iff _ _).mpr
              intro hEdgeUV
              have hb5E := (listAllBool_iff _ _).mp hb5Bellman (u, v) hEdgeUV
              rcases (Bool.and_eq_true _ _).mp hb5E with ⟨hb5Plus1, hb5Tri⟩
              rcases hclo with hkl1 | hkl2
              · have hvv0 := hselfStarRank0 v hv hkl1
                have htriV := (listAllBool_iff _ _).mp hb5Tri v ((mem_rangeBelow_iff _ _).mpr hv)
                dsimp only at htriV
                change lookupPairNat u v (rankTableOfWitnesses b.posWitnesses) = some (r' + 2) at hrk
                rw [hvv0, hrk] at htriV
                have hle := of_decide_eq_true htriV
                omega
              · rw [if_pos hkl2] at hb5Plus1
                dsimp only at hb5Plus1
                change lookupPairNat u v (rankTableOfWitnesses b.posWitnesses) = some (r' + 2) at hrk
                rw [hrk] at hb5Plus1
                have heq1 := of_decide_eq_true hb5Plus1
                omega
            have hexPred : listAnyBool (fun e =>
                decide (e.src = u) && decide (rankOf base05 e.dst v = some (r' + 1))) base05.G.edges = true := by
              have hEdgeNh : (u, pw.nextHop) ∈ b.candidateEdges := by
                rcases hclo with hkl1 | hkl2
                · rw [if_pos hkl1] at hb3Body
                  have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
                  rw [if_neg (by omega : pw.rank ≠ 0)] at hpwOk
                  simp only [Bool.and_eq_true, listMemBool_iff] at hpwOk
                  rw [← hsEq]; exact hpwOk.1.2
                · have hne1 : b.hdr.closureTag ≠ 1 := by omega
                  rw [if_neg hne1] at hb3Body
                  have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
                  rcases (Bool.and_eq_true _ _).mp hpwOk with ⟨_, hpwS⟩
                  rw [if_neg (by omega : pw.rank ≠ 1)] at hpwS
                  simp only [Bool.and_eq_true, listMemBool_iff] at hpwS
                  rw [← hsEq]; exact hpwS.1
              have hpred := (listAllBool_iff _ _).mp hb5Pred pw hpwMem
              have hcond : (b.hdr.closureTag = 1 ∧ 0 < pw.rank) ∨ (b.hdr.closureTag = 2 ∧ 1 < pw.rank) := by
                rcases hclo with hkl1 | hkl2
                · exact Or.inl ⟨hkl1, by omega⟩
                · exact Or.inr ⟨hkl2, by omega⟩
              rw [if_pos hcond] at hpred
              have hnhRk : rankOf base05 pw.nextHop v = some (r' + 1) := by
                have h1 := of_decide_eq_true hpred
                rw [htEq, hrkEq] at h1
                exact h1
              rw [hedgesEq] at hEdgeNh
              rcases List.mem_map.mp hEdgeNh with ⟨e, heMem, hpE⟩
              injection hpE with heSrc heDst
              rw [listAnyBool_iff]
              refine ⟨e, heMem, ?_⟩
              rw [heSrc, heDst]
              simp [hnhRk]
            have hallTri : listAllBool (fun e =>
                if e.src = u then
                  match rankOf base05 e.dst v with
                  | some rw => decide (r' + 2 ≤ rw + 1)
                  | none => true
                else true) base05.G.edges = true := by
              rw [listAllBool_iff]
              intro e heMem
              split
              · next heSrc =>
                subst heSrc
                cases hdstRk : rankOf base05 e.dst v with
                | none => rfl
                | some rw =>
                  have heCand : (e.src, e.dst) ∈ b.candidateEdges := by
                    rw [hedgesEq]
                    exact List.mem_map_of_mem (f := fun x : GraphEdge => (x.src, x.dst)) heMem
                  have hb5E := (listAllBool_iff _ _).mp hb5Bellman (e.src, e.dst) heCand
                  rcases (Bool.and_eq_true _ _).mp hb5E with ⟨_, hb5Tri⟩
                  have htriV := (listAllBool_iff _ _).mp hb5Tri v ((mem_rangeBelow_iff _ _).mpr hv)
                  dsimp only at htriV
                  change lookupPairNat e.dst v (rankTableOfWitnesses b.posWitnesses) = some rw at hdstRk
                  change lookupPairNat e.src v (rankTableOfWitnesses b.posWitnesses) = some (r' + 2) at hrk
                  rw [hdstRk, hrk] at htriV
                  exact htriV
              · rfl
            simp only [hnotRefl, hnotDir, hexPred, Bool.not_false, Bool.true_and]
            exact hallTri
    · -- `checkMaxHopsPair base05 u v = true`
      unfold checkMaxHopsPair
      dsimp only
      cases hrk : rankOf base05 u v with
      | none =>
        have hnotInH : (u, v) ∉ hopEntries.map (fun e => (e.sVid, e.tVid)) := by
          rw [hdomH, ← hdomW]
          exact (lookupPairNat_witness_none_iff u v).mp hrk
        have hmEmpty : maxHopsOf base05 u v = [] :=
          lookupPairList_hops_of_not_mem hnotInH
        rw [hmEmpty]
        simp only [nodupBool, listAllBool, Bool.true_and]
        rw [listAllBool_iff]
        intro w _
        unfold checkShortestFirstHopBool
        rw [hrk]
        simp [listMemBool]
      | some rkVal =>
        have hinH : (u, v) ∈ hopEntries.map (fun e => (e.sVid, e.tVid)) := by
          rw [hdomH, ← hdomW]
          rcases (lookupPairNat_witness_iff hndW u v rkVal).mp hrk with ⟨pw, hpwMem, hs, ht, _⟩
          rw [← hs, ← ht]
          exact List.mem_map_of_mem (f := fun x : RawPosWitness => (x.sVid, x.tVid)) hpwMem
        rcases List.mem_map.mp hinH with ⟨hent, hhentMem, hpH⟩
        injection hpH with hhs hht
        have hmEq : maxHopsOf base05 u v = hent.hops := by
          rw [← hhs, ← hht]
          exact lookupPairList_hops_of_mem hndH hhentMem
        have hhOk := (listAllBool_iff _ _).mp hallHops hent hhentMem
        simp only [Bool.and_eq_true] at hhOk
        rcases hhOk with ⟨⟨⟨hrkEntB, hincH⟩, hltH⟩, hexpMatch⟩
        have hrkEnt : hent.rank = rkVal := by
          have h1 := of_decide_eq_true hrkEntB
          rw [hhs, hht] at h1
          change rankOf base05 u v = some hent.rank at h1
          rw [hrk] at h1
          injection h1 with heq; exact heq.symm
        have hndHops : nodupBool hent.hops = true :=
          (nodupBool_iff _).mpr (w1d_strict_inc_implies_nodup hincH)
        have hltH' : listAllBool (fun w => decide (w < base05.G.numVertices)) hent.hops = true := by
          rw [hnEq]; exact hltH
        rw [hmEq, Bool.and_eq_true, Bool.and_eq_true]
        refine ⟨⟨hndHops, hltH'⟩, ?_⟩
        rw [listAllBool_iff]
        intro w hwR
        have hw : w < b.rawSnap.vTotal := by rw [← hnEq]; exact (mem_rangeBelow_iff _ _).mp hwR
        have hwExp := of_decide_eq_true ((listAllBool_iff _ _).mp hexpMatch w ((mem_rangeBelow_iff _ _).mpr hw))
        apply decide_eq_true
        rw [hwExp, hhs, hht, hrkEnt]
        unfold checkShortestFirstHopBool
        rw [hrk]
        cases rkVal with
        | zero =>
          rcases (lookupPairNat_witness_iff hndW u v 0).mp hrk with ⟨pw, hpwMem, hsEq, htEq, hr0⟩
          rcases hclo with hkl1 | hkl2
          · rw [if_pos hkl1] at hb3Body
            have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
            rw [if_pos hr0] at hpwOk
            have huv : u = v := hsEq.symm.trans ((of_decide_eq_true hpwOk).1.trans htEq)
            simp [hkl1, huv]
          · have hne1 : b.hdr.closureTag ≠ 1 := by omega
            rw [if_neg hne1] at hb3Body
            have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
            simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
            omega
        | succ r1 =>
          cases r1 with
          | zero =>
            -- `rkVal = 1`
            rcases hclo with hkl1 | hkl2
            · rcases (lookupPairNat_witness_iff hndW u v 1).mp hrk with ⟨pw, hpwMem, hsEq, htEq, hr1⟩
              rw [if_pos hkl1] at hb3Body
              have hpwOk := (listAllBool_iff _ _).mp hb3Body pw hpwMem
              rw [if_neg (by omega : pw.rank ≠ 0)] at hpwOk
              simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
              have hneUV : u ≠ v := fun huv => hpwOk.1.1.1 (hsEq.trans (huv.trans htEq.symm))
              rw [if_neg (by intro h; exact hneUV h.2), if_neg (by omega : ¬ (b.hdr.closureTag = 2 ∧ 1 = 1))]
              simp only [Nat.sub_self, hedgeMemIff u w]
              congr 1
              by_cases hwt : w = v
              · subst hwt
                simp [hselfStarRank0 w hw hkl1]
              · have hne0 : lookupPairNat w v (rankTableOfWitnesses b.posWitnesses) ≠ some 0 := by
                  intro h0
                  rcases (lookupPairNat_witness_iff hndW w v 0).mp h0 with ⟨pw0, hpw0Mem, hs0, ht0, hr0⟩
                  have hpw0Ok := (listAllBool_iff _ _).mp hb3Body pw0 hpw0Mem
                  rw [if_pos hr0] at hpw0Ok
                  exact hwt (hs0.symm.trans ((of_decide_eq_true hpw0Ok).1.trans ht0))
                simp [hne0, hwt]
            · rw [if_neg (by omega : ¬ (b.hdr.closureTag = 1 ∧ u = v)), if_pos ⟨hkl2, rfl⟩]
              rw [hedgeMemIff u v]
              dsimp only
              by_cases hwt : w = v
              · subst hwt; simp
              · simp [hwt]
          | succ r' =>
            have hnot1 : ¬ (b.hdr.closureTag = 1 ∧ u = v) := by
              intro ⟨hkl1, huv⟩
              have h0 := hselfStarRank0 u hu hkl1
              rw [← huv] at hrk
              change lookupPairNat u u (rankTableOfWitnesses b.posWitnesses) = some (r' + 2) at hrk
              rw [h0] at hrk; cases hrk
            rw [if_neg hnot1, if_neg (by omega : ¬ (b.hdr.closureTag = 2 ∧ r' + 2 = 1))]
            rw [hedgeMemIff u w]
            rfl
  · -- `projectRawCarrierToSpec base05 (.geodesicHops hopEntries) = some .geodesicBundle`
    change projectRawCarrierToSpec base05 (.geodesicHops hopEntries) = some .geodesicBundle
    unfold projectRawCarrierToSpec
    have hrkAlign : hopEntries.map (fun e => (e.sVid, e.tVid, e.rank)) = base05.rankEntries := by
      apply hopEntries_rank_align hndW (fun _ hx => hx) (hdomH.trans hdomW.symm)
      intro e heMem
      have hhOk := (listAllBool_iff _ _).mp hallHops e heMem
      simp only [Bool.and_eq_true] at hhOk
      exact of_decide_eq_true hhOk.1.1.1
    have hhopAlign : hopEntries.map (fun e => (e.sVid, e.tVid, e.hops)) = base05.maxHopEntries := rfl
    simp [hrkAlign, hhopAlign]

/-! ## `W2-C.3` (`F93-03`): Independent `0x03` Branch (4-Gate Non-Laundering Canonical Synthesis) -/

def hasExactStepChain (G : LabeledGraph) : Nat → VertexId → VertexId → Bool
  | 0, u, v => decide (u = v)
  | k + 1, u, v =>
      listAnyBool (fun e => decide (e.src = u) && hasExactStepChain G k e.dst v) G.edges

theorem hasExactStepChain_iff (G : LabeledGraph) :
    ∀ (k : Nat) (u v : VertexId),
      hasExactStepChain G k u v = true ↔
      ∃ tail, IsEdgeChain G u v tail ∧ tail.length = k
  | 0, u, v => by
      simp only [hasExactStepChain, decide_eq_true_eq]
      constructor
      · intro h; subst h; exact ⟨[], IsEdgeChain.nil u, rfl⟩
      · intro ⟨tail, hc, hlen⟩
        cases tail with
        | cons _ _ => cases hlen
        | nil => cases hc; rfl
  | k + 1, u, v => by
      simp only [hasExactStepChain, listAnyBool_iff, Bool.and_eq_true, decide_eq_true_eq]
      constructor
      · intro ⟨e, he, hsrc, hsub⟩
        rcases (hasExactStepChain_iff G k e.dst v).mp hsub with ⟨tl, hctl, hlen⟩
        exact ⟨e.dst :: tl, IsEdgeChain.cons e tl he hsrc rfl hctl, by simp [hlen]⟩
      · intro ⟨tail, hc, hlen⟩
        cases hc with
        | nil _ => cases hlen
        | cons e rest he hsrc hdst hcrest =>
          subst hdst
          simp only [List.length_cons, Nat.succ.injEq] at hlen
          exact ⟨e, he, hsrc, (hasExactStepChain_iff G k e.dst v).mpr ⟨rest, hcrest, hlen⟩⟩

def eraseFirstNat (a : Nat) : List Nat → List Nat
  | [] => []
  | x :: xs => if x = a then xs else x :: eraseFirstNat a xs

theorem mem_eraseFirstNat_of_ne {a z : Nat} {ys : List Nat}
    (hne : z ≠ a) (hz : z ∈ ys) : z ∈ eraseFirstNat a ys := by
  induction ys with
  | nil => cases hz
  | cons y tl ih =>
    simp only [eraseFirstNat]
    split
    · next hya =>
      subst hya
      cases hz with
      | head => exact absurd rfl hne
      | tail _ hm => exact hm
    · cases hz with
      | head => exact List.Mem.head _
      | tail _ hm => exact List.Mem.tail _ (ih hm)

theorem length_eraseFirstNat_lt {a : Nat} {ys : List Nat} (ha : a ∈ ys) :
    (eraseFirstNat a ys).length < ys.length := by
  induction ys with
  | nil => cases ha
  | cons y tl ih =>
    simp only [eraseFirstNat]
    split
    · simp
    · next hne =>
      cases ha with
      | head => exact absurd rfl hne
      | tail _ hm =>
        simp only [List.length_cons]
        exact Nat.succ_lt_succ (ih hm)

theorem nodup_length_le_of_subset {xs ys : List Nat}
    (hnd : NodupList xs) (hsub : ∀ x ∈ xs, x ∈ ys) :
    xs.length ≤ ys.length := by
  induction hnd generalizing ys with
  | nil => exact Nat.zero_le _
  | @cons x rest hxNot _ ih =>
    have hxY : x ∈ ys := hsub x (List.Mem.head rest)
    have hlt := length_eraseFirstNat_lt hxY
    have hle := ih (ys := eraseFirstNat x ys) (fun z hz =>
      mem_eraseFirstNat_of_ne (fun hzx => hxNot (hzx ▸ hz)) (hsub z (List.Mem.tail x hz)))
    simp only [List.length_cons]
    omega

theorem length_rangeBelow (n : Nat) : (rangeBelow n).length = n := by
  induction n with
  | zero => rfl
  | succ m ih => simp [rangeBelow, ih]

theorem edgeChain_mem_lt {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {u v : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u v tail) :
    ∀ z ∈ tail, z < G.numVertices := by
  induction hc with
  | nil _ => intro _ hm; cases hm
  | cons e rest he _ hdst _ ih =>
    intro z hz
    cases hz with
    | head => rw [← hdst]; exact (hwf.2 e he).2.1
    | tail _ hm => exact ih z hm

theorem chain_suffix_from_mem {G : LabeledGraph} {y v : VertexId} {rest : List VertexId}
    (hc : IsEdgeChain G y v rest) {w : VertexId} (hw : w ∈ rest) :
    ∃ suf, suf.length < rest.length ∧ IsEdgeChain G w v suf := by
  induction hc with
  | nil _ => cases hw
  | @cons _ z _ e2 rest2 _ _ hdst2 hc2 ih =>
    cases hw with
    | head =>
      exact ⟨rest2, Nat.lt_succ_self _, hc2⟩
    | tail _ hm2 =>
      rcases ih hm2 with ⟨suf, hlt, hcsuf⟩
      exact ⟨suf, Nat.lt_trans hlt (Nat.lt_succ_self _), hcsuf⟩

theorem chain_shorten_of_not_nodup {G : LabeledGraph} {u v : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u v tail) (hnotNd : ¬ NodupList tail) :
    ∃ tail', 1 ≤ tail'.length ∧ tail'.length < tail.length ∧ IsEdgeChain G u v tail' := by
  induction hc with
  | nil _ => exact absurd NodupList.nil hnotNd
  | @cons u0 w0 _ e rest he hsrc hdst hcRest ih =>
    by_cases hwMem : w0 ∈ rest
    · rcases chain_suffix_from_mem hcRest hwMem with ⟨suf, hlt, hcsuf⟩
      exact ⟨w0 :: suf, by simp, Nat.succ_lt_succ hlt, IsEdgeChain.cons e suf he hsrc hdst hcsuf⟩
    · have hnotNdRest : ¬ NodupList rest :=
        fun hndR => hnotNd (NodupList.cons hwMem hndR)
      rcases ih hnotNdRest with ⟨rest', hge1, hlt, hcrest'⟩
      exact ⟨w0 :: rest', by simp, Nat.succ_lt_succ hlt, IsEdgeChain.cons e rest' he hsrc hdst hcrest'⟩

theorem hasExactStepChain_bounded_witness {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) :
    ∀ (B : Nat) {k : Nat} {u v : VertexId},
      k ≤ B →
      hasExactStepChain G k u v = true →
      ∃ k0, k0 ≤ k ∧ k0 ≤ G.numVertices ∧ (1 ≤ k → 1 ≤ k0) ∧ hasExactStepChain G k0 u v = true := by
  intro B
  induction B with
  | zero =>
    intro k u v hk0 hch
    have hkEq0 : k = 0 := by omega
    subst hkEq0
    exact ⟨0, Nat.le_refl 0, Nat.zero_le _, fun h => by omega, hch⟩
  | succ B' ih =>
    intro k u v hkLe hch
    by_cases hkLeB' : k ≤ B'
    · exact ih hkLeB' hch
    · have hkEq : k = B' + 1 := by omega
      by_cases hkLeN : k ≤ G.numVertices
      · exact ⟨k, Nat.le_refl k, hkLeN, fun h => h, hch⟩
      · rcases (hasExactStepChain_iff G k u v).mp hch with ⟨tail, hc, hlen⟩
        have hnotNd : ¬ NodupList tail := by
          intro hnd
          have hsub : ∀ z ∈ tail, z ∈ rangeBelow G.numVertices := fun z hz =>
            (mem_rangeBelow_iff z G.numVertices).mpr (edgeChain_mem_lt hwf hc z hz)
          have hle := nodup_length_le_of_subset hnd hsub
          rw [hlen, length_rangeBelow] at hle
          omega
        rcases chain_shorten_of_not_nodup hc hnotNd with ⟨tail', hge1, hlt, hc'⟩
        have hch' : hasExactStepChain G tail'.length u v = true :=
          (hasExactStepChain_iff G tail'.length u v).mpr ⟨tail', hc', rfl⟩
        have hltB : tail'.length ≤ B' := by omega
        rcases ih hltB hch' with ⟨k0, hk0Le, hk0N, hk0Pos, hk0Ch⟩
        exact ⟨k0, by omega, hk0N, fun _ => hk0Pos hge1, hk0Ch⟩

def findMinFrom (p : Nat → Bool) (cur : Nat) : Nat → Option Nat
  | 0 => if p cur then some cur else none
  | rem + 1 => if p cur then some cur else findMinFrom p (cur + 1) rem

theorem findMinFrom_eq_some {p : Nat → Bool} :
    ∀ {cur rem r : Nat},
      findMinFrom p cur rem = some r →
      cur ≤ r ∧ r ≤ cur + rem ∧ p r = true ∧ (∀ k, cur ≤ k → k < r → p k = false)
  | cur, 0, r, h => by
      unfold findMinFrom at h
      split at h
      · next hp =>
        injection h with hcr
        subst hcr
        exact ⟨Nat.le_refl _, by omega, hp, fun k h1 h2 => by omega⟩
      · cases h
  | cur, rem + 1, r, h => by
      unfold findMinFrom at h
      split at h
      · next hp =>
        injection h with hcr
        subst hcr
        exact ⟨Nat.le_refl _, by omega, hp, fun k h1 h2 => by omega⟩
      · next hnp =>
        have hfalse : p cur = false := Bool.eq_false_iff.mpr hnp
        rcases findMinFrom_eq_some h with ⟨hge, hle, hpr, hmin⟩
        refine ⟨by omega, by omega, hpr, ?_⟩
        intro k hkGe hkLt
        by_cases hkc : k = cur
        · subst hkc; exact hfalse
        · exact hmin k (by omega) hkLt

theorem findMinFrom_eq_none {p : Nat → Bool} :
    ∀ {cur rem : Nat},
      findMinFrom p cur rem = none →
      ∀ k, cur ≤ k → k ≤ cur + rem → p k = false
  | cur, 0, h => by
      unfold findMinFrom at h
      split at h
      · cases h
      · next hnp =>
        intro k h1 h2
        have hkc : k = cur := by omega
        subst hkc
        exact Bool.eq_false_iff.mpr hnp
  | cur, rem + 1, h => by
      unfold findMinFrom at h
      split at h
      · cases h
      · next hnp =>
        have ih := findMinFrom_eq_none h
        intro k h1 h2
        by_cases hkc : k = cur
        · subst hkc; exact Bool.eq_false_iff.mpr hnp
        · exact ih k (by omega) (by omega)

def synthRankOpt (G : LabeledGraph) (κ : ClosureKind) (u v : VertexId) : Option Nat :=
  match κ with
  | .eStar => findMinFrom (fun k => hasExactStepChain G k u v) 0 G.numVertices
  | .ePlus =>
      if G.numVertices = 0 then none
      else findMinFrom (fun k => hasExactStepChain G k u v) 1 (G.numVertices - 1)

theorem synthRankOpt_some_spec {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {κ : ClosureKind} {u v : VertexId} {r : Nat}
    (hu : u < G.numVertices)
    (hs : synthRankOpt G κ u v = some r) :
    (κ = .ePlus → 1 ≤ r) ∧
    hasExactStepChain G r u v = true ∧
    (∀ k, (κ = .ePlus → 1 ≤ k) → hasExactStepChain G k u v = true → r ≤ k) := by
  have hnPos : G.numVertices ≠ 0 := Nat.ne_of_gt (Nat.lt_of_le_of_lt (Nat.zero_le u) hu)
  cases κ with
  | eStar =>
    unfold synthRankOpt at hs
    rcases findMinFrom_eq_some hs with ⟨_, hrLeN, hpr, hmin⟩
    refine ⟨fun h => ClosureKind.noConfusion h, hpr, ?_⟩
    intro k _ hkCh
    rcases hasExactStepChain_bounded_witness hwf k (Nat.le_refl k) hkCh with
      ⟨k0, hk0LeK, _, _, hk0Ch⟩
    by_cases hlt : k0 < r
    · rw [hmin k0 (Nat.zero_le k0) hlt] at hk0Ch; cases hk0Ch
    · omega
  | ePlus =>
    unfold synthRankOpt at hs
    rw [if_neg hnPos] at hs
    rcases findMinFrom_eq_some hs with ⟨hrGe1, _, hpr, hmin⟩
    refine ⟨fun _ => hrGe1, hpr, ?_⟩
    intro k hkPos hkCh
    have hk1 : 1 ≤ k := hkPos rfl
    rcases hasExactStepChain_bounded_witness hwf k (Nat.le_refl k) hkCh with
      ⟨k0, hk0LeK, _, hk0Pos, hk0Ch⟩
    have hk0Ge1 : 1 ≤ k0 := hk0Pos hk1
    by_cases hlt : k0 < r
    · rw [hmin k0 hk0Ge1 hlt] at hk0Ch; cases hk0Ch
    · omega

theorem synthRankOpt_none_spec {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {κ : ClosureKind} {u v : VertexId}
    (hu : u < G.numVertices)
    (hn : synthRankOpt G κ u v = none) :
    ∀ k, (κ = .ePlus → 1 ≤ k) → hasExactStepChain G k u v = false := by
  have hnPos : G.numVertices ≠ 0 := Nat.ne_of_gt (Nat.lt_of_le_of_lt (Nat.zero_le u) hu)
  intro k hkPos
  cases hch : hasExactStepChain G k u v with
  | false => rfl
  | true =>
    exfalso
    rcases hasExactStepChain_bounded_witness hwf k (Nat.le_refl k) hch with
      ⟨k0, _, hk0LeN, hk0Pos, hk0Ch⟩
    cases κ with
    | eStar =>
      unfold synthRankOpt at hn
      have hf := findMinFrom_eq_none hn k0 (Nat.zero_le k0) (by omega)
      rw [hf] at hk0Ch; cases hk0Ch
    | ePlus =>
      unfold synthRankOpt at hn
      rw [if_neg hnPos] at hn
      have hk0Ge1 : 1 ≤ k0 := hk0Pos (hkPos rfl)
      have hf := findMinFrom_eq_none hn k0 hk0Ge1 (by omega)
      rw [hf] at hk0Ch; cases hk0Ch

def synthesizeRankEntries (G : LabeledGraph) (κ : ClosureKind) :
    List (VertexId × VertexId × Nat) :=
  let vs := rangeBelow G.numVertices
  vs.flatMap (fun u =>
    vs.flatMap (fun v =>
      match synthRankOpt G κ u v with
      | none => []
      | some r => [(u, v, r)]))

def synthMaxHopsList (G : LabeledGraph) (κ : ClosureKind) (u t : VertexId) : List VertexId :=
  (rangeBelow G.numVertices).filter (fun w =>
    match synthRankOpt G κ u t with
    | none => false
    | some 0 => false
    | some 1 => (edgeSupport? G u w).isSome && decide (w = t)
    | some (r' + 2) =>
        (edgeSupport? G u w).isSome && decide (synthRankOpt G κ w t = some (r' + 1)))

def synthesizeMaxHopEntries (G : LabeledGraph) (κ : ClosureKind) :
    List (VertexId × VertexId × List VertexId) :=
  let vs := rangeBelow G.numVertices
  vs.flatMap (fun u => vs.map (fun t => (u, t, synthMaxHopsList G κ u t)))

/-- **`F93-03` Gate 2 Pure Shortest-Step Base Synthesis (`synthesizeVerifiedBase`)**. -/
def synthesizeVerifiedBase (G : LabeledGraph) (κ : ClosureKind) : BaseData :=
  { G := G
    kappa := κ
    rankEntries := synthesizeRankEntries G κ
    maxHopEntries := synthesizeMaxHopEntries G κ }

theorem lookupPairNat_append (u v : VertexId) (xs ys : List (VertexId × VertexId × Nat)) :
    lookupPairNat u v (xs ++ ys) =
      match lookupPairNat u v xs with
      | some r => some r
      | none => lookupPairNat u v ys := by
  induction xs with
  | nil => rfl
  | cons hd tl ih =>
    rcases hd with ⟨x, y, r⟩
    simp only [List.cons_append, lookupPairNat]
    split
    · rfl
    · exact ih

theorem lookupPairNat_flatMap_none {α : Type} (u v : VertexId)
    (xs : List α) (f : α → List (VertexId × VertexId × Nat))
    (hall : ∀ a ∈ xs, lookupPairNat u v (f a) = none) :
    lookupPairNat u v (xs.flatMap f) = none := by
  induction xs with
  | nil => rfl
  | cons a tl ih =>
    simp only [List.flatMap_cons, lookupPairNat_append, hall a (List.Mem.head tl)]
    exact ih (fun x hx => hall x (List.Mem.tail a hx))

theorem lookupPairNat_flatMap_unique {α : Type} (u v : VertexId)
    {xs : List α} (hnd : NodupList xs) (f : α → List (VertexId × VertexId × Nat))
    {a0 : α} (ha0 : a0 ∈ xs)
    (hother : ∀ a ∈ xs, a ≠ a0 → lookupPairNat u v (f a) = none) :
    lookupPairNat u v (xs.flatMap f) = lookupPairNat u v (f a0) := by
  induction hnd with
  | nil => cases ha0
  | @cons hd tl hhdNot _ ih =>
    simp only [List.flatMap_cons, lookupPairNat_append]
    cases ha0 with
    | head =>
      have htlNone : lookupPairNat u v (tl.flatMap f) = none :=
        lookupPairNat_flatMap_none u v tl f
          (fun a ha => hother a (List.Mem.tail a0 ha) (fun heq => hhdNot (heq ▸ ha)))
      rw [htlNone]
      cases lookupPairNat u v (f a0) <;> rfl
    | tail _ hm =>
      have hhdNone : lookupPairNat u v (f hd) = none :=
        hother hd (List.Mem.head tl) (fun heq => hhdNot (heq ▸ hm))
      rw [hhdNone]
      exact ih hm (fun a ha hne => hother a (List.Mem.tail hd ha) hne)

theorem rankOf_synthesizeVerifiedBase (G : LabeledGraph) (κ : ClosureKind)
    {u v : VertexId} (hu : u < G.numVertices) (hv : v < G.numVertices) :
    rankOf (synthesizeVerifiedBase G κ) u v = synthRankOpt G κ u v := by
  unfold rankOf synthesizeVerifiedBase synthesizeRankEntries
  dsimp only
  have hnd := nodup_rangeBelow G.numVertices
  have huMem := (mem_rangeBelow_iff u G.numVertices).mpr hu
  have hvMem := (mem_rangeBelow_iff v G.numVertices).mpr hv
  rw [lookupPairNat_flatMap_unique u v hnd _ huMem (fun u' _ hneU => by
    apply lookupPairNat_flatMap_none
    intro v' _
    cases synthRankOpt G κ u' v' with
    | none => rfl
    | some r => simp [lookupPairNat, hneU])]
  rw [lookupPairNat_flatMap_unique u v hnd _ hvMem (fun v' _ hneV => by
    cases synthRankOpt G κ u v' with
    | none => rfl
    | some r => simp [lookupPairNat, hneV])]
  cases synthRankOpt G κ u v with
  | none => rfl
  | some r => simp [lookupPairNat]

theorem lookupPairList_append_of_first_disjoint (u t : VertexId)
    {xs ys : List (VertexId × VertexId × List VertexId)}
    (hdisj : ∀ p ∈ xs, ¬ (p.1 = u ∧ p.2.1 = t)) :
    lookupPairList u t (xs ++ ys) = lookupPairList u t ys := by
  induction xs with
  | nil => rfl
  | cons hd tl ih =>
    rcases hd with ⟨x, y, ws⟩
    simp only [List.cons_append, lookupPairList]
    have hnot : ¬ (x = u ∧ y = t) := hdisj (x, y, ws) (List.Mem.head tl)
    rw [if_neg hnot]
    exact ih (fun p hp => hdisj p (List.Mem.tail _ hp))

theorem lookupPairList_map_unique (u t : VertexId) {vs : List VertexId}
    (hnd : NodupList vs) (htMem : t ∈ vs) (g : VertexId → List VertexId) :
    lookupPairList u t (vs.map (fun v => (u, v, g v))) = g t := by
  induction hnd with
  | nil => cases htMem
  | @cons v tl hvNot _ ih =>
    dsimp only [List.map, lookupPairList]
    cases htMem with
    | head => simp
    | tail _ hm =>
      have hne : ¬ (u = u ∧ v = t) := fun ⟨_, hvt⟩ => hvNot (hvt ▸ hm)
      rw [if_neg hne]
      exact ih hm

theorem maxHopsOf_synthesizeVerifiedBase (G : LabeledGraph) (κ : ClosureKind)
    {u t : VertexId} (hu : u < G.numVertices) (ht : t < G.numVertices) :
    maxHopsOf (synthesizeVerifiedBase G κ) u t = synthMaxHopsList G κ u t := by
  unfold maxHopsOf synthesizeVerifiedBase synthesizeMaxHopEntries
  dsimp only
  have hnd := nodup_rangeBelow G.numVertices
  have huMem := (mem_rangeBelow_iff u G.numVertices).mpr hu
  have htMem := (mem_rangeBelow_iff t G.numVertices).mpr ht
  suffices ∀ (us : List VertexId), NodupList us → u ∈ us →
      lookupPairList u t (us.flatMap (fun x =>
        (rangeBelow G.numVertices).map (fun y => (x, y, synthMaxHopsList G κ x y)))) =
      synthMaxHopsList G κ u t from
    this (rangeBelow G.numVertices) hnd huMem
  intro us hndU huIn
  induction hndU with
  | nil => cases huIn
  | @cons x tl hxNot _ ih =>
    simp only [List.flatMap_cons]
    cases huIn with
    | head =>
      suffices ∀ (ys rest : List (VertexId × VertexId × List VertexId)),
          (∃ ws, (u, t, ws) ∈ ys ∧ lookupPairList u t ys = ws) →
          lookupPairList u t (ys ++ rest) = lookupPairList u t ys by
        rw [this _ _]
        · exact lookupPairList_map_unique u t hnd htMem (synthMaxHopsList G κ u)
        · refine ⟨synthMaxHopsList G κ u t, ?_,
                  lookupPairList_map_unique u t hnd htMem (synthMaxHopsList G κ u)⟩
          exact List.mem_map_of_mem (f := fun y => (u, y, synthMaxHopsList G κ u y)) htMem
      intro ys rest ⟨ws, hmem, hlk⟩
      induction ys with
      | nil => cases hmem
      | cons hd ytl ihy =>
        rcases hd with ⟨a, b, hs⟩
        dsimp only [List.cons_append, lookupPairList] at hlk ⊢
        by_cases hab : a = u ∧ b = t
        · rw [if_pos hab, if_pos hab]
        · rw [if_neg hab, if_neg hab]
          rw [if_neg hab] at hlk
          cases hmem with
          | head => exact False.elim (hab ⟨rfl, rfl⟩)
          | tail _ hm => exact ihy hm hlk
    | tail _ hm =>
      have hdisj : ∀ p ∈ (rangeBelow G.numVertices).map (fun y => (x, y, synthMaxHopsList G κ x y)),
          ¬ (p.1 = u ∧ p.2.1 = t) := by
        intro p hp ⟨hpu, _⟩
        rcases List.mem_map.mp hp with ⟨_, _, rfl⟩
        dsimp only at hpu
        subst hpu
        exact hxNot hm
      rw [lookupPairList_append_of_first_disjoint u t hdisj]
      exact ih hm

/-- **`F93-03` Theorem 1 (`f93_03_synthesizeVerifiedBase_sound`)**:
    Gate 2 + Gate 3 Soundness (`93rd Ruling §2.3`):
    For ANY well-formed issuer partition `ip` and well-formed `LabeledGraph` `G`,
    `synthesizeVerifiedBase G κ` is guaranteed to pass `#41`'s `checkVerifiedBase ip`! -/
theorem f93_03_synthesizeVerifiedBase_sound
    {ip : IssuerPartition} {G : LabeledGraph} (κ : ClosureKind)
    (hwfP : WFPartition ip) (hwfG : GraphWF ip G) :
    checkVerifiedBase ip (synthesizeVerifiedBase G κ) = true := by
  let b := synthesizeVerifiedBase G κ
  have hCheckP : checkIssuerPartition ip = true := by
    simp only [checkIssuerPartition, disjointListsBool_iff]; exact hwfP
  have hCheckG : checkGraphWF ip G = true := by
    unfold checkGraphWF
    rw [Bool.and_eq_true, nodupBool_iff, listAllBool_iff]
    refine ⟨hwfG.1, fun e he => ?_⟩
    rcases hwfG.2 e he with ⟨h1, h2, h3, h4⟩
    simp only [Bool.and_eq_true, decide_eq_true_eq, listAllBool_iff, Bool.or_eq_true, listMemBool_iff]
    exact ⟨⟨⟨h1, h2⟩, h3⟩, h4⟩
  have hDirIff : ∀ x y, (edgeSupport? G x y).isSome = hasExactStepChain G 1 x y := by
    intro x y
    cases hs : edgeSupport? G x y with
    | none =>
      symm
      cases h1 : hasExactStepChain G 1 x y with
      | false => rfl
      | true =>
        exfalso
        rcases (hasExactStepChain_iff G 1 x y).mp h1 with ⟨tl, hc, hlen⟩
        cases hc with
        | nil _ => cases hlen
        | cons e rest he hsrc hdst hcr =>
          cases rest with
          | cons _ _ => cases hlen
          | nil =>
            cases hcr
            exact (edgeSupport?_none_iff_no_edge hwfG x y).mp hs e he ⟨hsrc, hdst⟩
    | some supp =>
      symm
      have he := (edgeSupport?_eq_some_iff hwfG x y supp).mp hs
      exact (hasExactStepChain_iff G 1 x y).mpr
        ⟨[y], IsEdgeChain.cons { src := x, dst := y, support := supp } [] he rfl rfl (IsEdgeChain.nil y), rfl⟩
  change checkVerifiedBase ip b = true
  unfold checkVerifiedBase
  dsimp only
  rw [Bool.and_eq_true, Bool.and_eq_true]
  refine ⟨⟨hCheckP, hCheckG⟩, ?_⟩
  rw [listAllBool_iff]
  intro u huR
  rw [listAllBool_iff]
  intro v hvR
  have hu : u < G.numVertices := (mem_rangeBelow_iff _ _).mp huR
  have hv : v < G.numVertices := (mem_rangeBelow_iff _ _).mp hvR
  rw [Bool.and_eq_true]
  refine ⟨?_, ?_⟩
  · -- `checkRankPair b u v = true`
    unfold checkRankPair
    rw [rankOf_synthesizeVerifiedBase G κ hu hv]
    dsimp only [b, synthesizeVerifiedBase]
    cases hr : synthRankOpt G κ u v with
    | none =>
      have hnone := synthRankOpt_none_spec hwfG hu hr
      have hnotRefl : ¬ (κ = .eStar ∧ u = v) := by
        intro ⟨hkap, huv⟩
        have h0 := hnone 0 (fun hp => by rw [hkap] at hp; cases hp)
        simp [hasExactStepChain, huv] at h0
      have hnotDir : (edgeSupport? G u v).isSome = false := by
        rw [hDirIff u v]; exact hnone 1 (fun _ => Nat.le_refl 1)
      rw [Bool.and_eq_true, Bool.and_eq_true]
      refine ⟨⟨?_, ?_⟩, ?_⟩
      · rw [Bool.not_eq_true']
        exact decide_eq_false hnotRefl
      · rw [Bool.not_eq_true']
        exact hnotDir
      · rw [listAllBool_iff]
        intro e heMem
        have hdstLt : e.dst < G.numVertices := (hwfG.2 e heMem).2.1
        split
        · next hsrc =>
          apply decide_eq_true
          change rankOf (synthesizeVerifiedBase G κ) e.dst v = none
          rw [rankOf_synthesizeVerifiedBase G κ hdstLt hv]
          cases hdstRk : synthRankOpt G κ e.dst v with
          | none => rfl
          | some rkW =>
            exfalso
            rcases synthRankOpt_some_spec hwfG hdstLt hdstRk with ⟨_, hrwCh, _⟩
            have hstep : hasExactStepChain G (rkW + 1) u v = true := by
              rw [hasExactStepChain, listAnyBool_iff]
              exact ⟨e, heMem, by simp [hsrc, hrwCh]⟩
            have hf := hnone (rkW + 1) (fun _ => by omega)
            rw [hf] at hstep; cases hstep
        · rfl
    | some r =>
      rcases synthRankOpt_some_spec hwfG hu hr with ⟨hrPlus, hrCh, hrMin⟩
      cases r with
      | zero =>
        have hkap : κ = .eStar := by
          cases κ with
          | eStar => rfl
          | ePlus => have h1 := hrPlus rfl; omega
        have huv : u = v := of_decide_eq_true hrCh
        exact decide_eq_true ⟨hkap, huv⟩
      | succ r1 =>
        cases r1 with
        | zero =>
          have hnotRefl : ¬ (κ = .eStar ∧ u = v) := by
            intro ⟨hkap, huv⟩
            have hle := hrMin 0 (fun hp => by rw [hkap] at hp; cases hp) (by simp [hasExactStepChain, huv])
            omega
          have hhas : (edgeSupport? G u v).isSome = true := by
            rw [hDirIff u v]; exact hrCh
          rw [Bool.and_eq_true]
          refine ⟨?_, hhas⟩
          rw [Bool.not_eq_true']
          exact decide_eq_false hnotRefl
        | succ r' =>
          have hnotRefl : ¬ (κ = .eStar ∧ u = v) := by
            intro ⟨hkap, huv⟩
            have hle := hrMin 0 (fun hp => by rw [hkap] at hp; cases hp) (by simp [hasExactStepChain, huv])
            omega
          have hnotDir : (edgeSupport? G u v).isSome = false := by
            rw [hDirIff u v]
            cases h1 : hasExactStepChain G 1 u v with
            | false => rfl
            | true =>
              exfalso
              have hle := hrMin 1 (fun _ => Nat.le_refl 1) h1
              omega
          have hexPred : listAnyBool (fun e =>
              decide (e.src = u) &&
              decide (rankOf { G := G, kappa := κ, rankEntries := synthesizeRankEntries G κ, maxHopEntries := synthesizeMaxHopEntries G κ } e.dst v = some (r' + 1))) G.edges = true := by
            rw [hasExactStepChain] at hrCh
            rcases (listAnyBool_iff _ _).mp hrCh with ⟨e, heMem, hboth⟩
            rcases (Bool.and_eq_true _ _).mp hboth with ⟨hsrcDec, hsubCh⟩
            have hsrc : e.src = u := of_decide_eq_true hsrcDec
            have hdstLt : e.dst < G.numVertices := (hwfG.2 e heMem).2.1
            have hplusR1 : κ = .ePlus → 1 ≤ r' + 1 := fun _ => by omega
            have hdstNotNone : ∀ hN : synthRankOpt G κ e.dst v = none, False := by
              intro hN
              have hf := synthRankOpt_none_spec hwfG hdstLt hN (r' + 1) hplusR1
              rw [hf] at hsubCh; cases hsubCh
            cases hdstRk : synthRankOpt G κ e.dst v with
            | none => exact False.elim (hdstNotNone hdstRk)
            | some rkW =>
              rcases synthRankOpt_some_spec hwfG hdstLt hdstRk with ⟨_, hrwCh, hrwMin⟩
              have hrwLe : rkW ≤ r' + 1 := hrwMin (r' + 1) hplusR1 hsubCh
              have hstepRw : hasExactStepChain G (rkW + 1) u v = true := by
                rw [hasExactStepChain, listAnyBool_iff]
                exact ⟨e, heMem, by simp [hsrc, hrwCh]⟩
              have hrwGe : r' + 2 ≤ rkW + 1 := hrMin (rkW + 1) (fun _ => by omega) hstepRw
              have hrwEq : rkW = r' + 1 := by omega
              subst hrwEq
              rw [listAnyBool_iff]
              refine ⟨e, heMem, ?_⟩
              rw [Bool.and_eq_true]
              refine ⟨decide_eq_true hsrc, ?_⟩
              apply decide_eq_true
              change rankOf (synthesizeVerifiedBase G κ) e.dst v = some (r' + 1)
              rw [rankOf_synthesizeVerifiedBase G κ hdstLt hv]
              exact hdstRk
          have hallTri : listAllBool (fun e =>
              if e.src = u then
                match rankOf { G := G, kappa := κ, rankEntries := synthesizeRankEntries G κ, maxHopEntries := synthesizeMaxHopEntries G κ } e.dst v with
                | some rkW => decide (r' + 2 ≤ rkW + 1)
                | none => true
              else true) G.edges = true := by
            rw [listAllBool_iff]
            intro e heMem
            have hdstLt : e.dst < G.numVertices := (hwfG.2 e heMem).2.1
            split
            · next hsrc =>
              change (match rankOf (synthesizeVerifiedBase G κ) e.dst v with
                | some rkW => decide (r' + 2 ≤ rkW + 1)
                | none => true) = true
              rw [rankOf_synthesizeVerifiedBase G κ hdstLt hv]
              cases hdstRk : synthRankOpt G κ e.dst v with
              | none => rfl
              | some rkW =>
                rcases synthRankOpt_some_spec hwfG hdstLt hdstRk with ⟨_, hrwCh, _⟩
                have hstepRw : hasExactStepChain G (rkW + 1) u v = true := by
                  rw [hasExactStepChain, listAnyBool_iff]
                  exact ⟨e, heMem, by simp [hsrc, hrwCh]⟩
                exact decide_eq_true (hrMin (rkW + 1) (fun _ => by omega) hstepRw)
            · rfl
          rw [Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true]
          refine ⟨⟨⟨?_, ?_⟩, hexPred⟩, hallTri⟩
          · rw [Bool.not_eq_true']
            exact decide_eq_false hnotRefl
          · rw [Bool.not_eq_true']
            exact hnotDir
  · -- `checkMaxHopsPair b u v = true`
    unfold checkMaxHopsPair
    dsimp only
    rw [maxHopsOf_synthesizeVerifiedBase G κ hu hv]
    have hndHs : nodupBool (synthMaxHopsList G κ u v) = true :=
      (nodupBool_iff _).mpr (nodup_filter _ (nodup_rangeBelow G.numVertices))
    have hltHs : listAllBool (fun w => decide (w < G.numVertices)) (synthMaxHopsList G κ u v) = true := by
      rw [listAllBool_iff]
      intro w hwMem
      unfold synthMaxHopsList at hwMem
      exact decide_eq_true ((mem_rangeBelow_iff _ _).mp (List.mem_filter.mp hwMem).1)
    rw [Bool.and_eq_true, Bool.and_eq_true]
    refine ⟨⟨hndHs, hltHs⟩, ?_⟩
    rw [listAllBool_iff]
    intro w hwR
    have hw : w < G.numVertices := (mem_rangeBelow_iff _ _).mp hwR
    apply decide_eq_true
    have hpredEq :
        (match synthRankOpt G κ u v with
         | none => false
         | some 0 => false
         | some 1 => (edgeSupport? G u w).isSome && decide (w = v)
         | some (r' + 2) =>
             (edgeSupport? G u w).isSome && decide (synthRankOpt G κ w v = some (r' + 1))) =
        checkShortestFirstHopBool b u v w := by
      unfold checkShortestFirstHopBool
      rw [rankOf_synthesizeVerifiedBase G κ hu hv]
      dsimp only [b, synthesizeVerifiedBase]
      cases synthRankOpt G κ u v with
      | none => rfl
      | some r =>
        cases r with
        | zero => rfl
        | succ r1 =>
          cases r1 with
          | zero => rfl
          | succ r' =>
            change ((edgeSupport? G u w).isSome && decide (synthRankOpt G κ w v = some (r' + 1))) =
              ((edgeSupport? G u w).isSome && decide (rankOf (synthesizeVerifiedBase G κ) w v = some (r' + 1)))
            rw [rankOf_synthesizeVerifiedBase G κ hw hv]
    cases hchk : checkShortestFirstHopBool b u v w with
    | false =>
      apply (listMemBool_false_iff _ _).mpr
      unfold synthMaxHopsList
      intro hm
      have hp := (List.mem_filter.mp hm).2
      rw [hpredEq, hchk] at hp; cases hp
    | true =>
      apply (listMemBool_iff _ _).mpr
      unfold synthMaxHopsList
      exact List.mem_filter.mpr ⟨hwR, by rw [hpredEq, hchk]⟩

/-- **`F93-03` Gate 1**: Original wire `CNB-v1` `B1..B5` + `(qS, qT) ∈ candidateRelations` check for `0x03`. -/
def checkGate1Wire0x03Bool (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (base : RawCNB1Bundle)
    (qS qT : VertexId) (constIrIndices : List Nat) : Bool :=
  checkCNB1B1Bool hash256 reg base constIrIndices &&
  checkCNB1B2Bool hash256 base &&
  checkCNB1B3Bool base &&
  checkCNB1B4Bool base &&
  checkCNB1B5Bool base &&
  listMemBool (qS, qT) base.candidateRelations

/-! ## `W2-D` & `F93-01`: Explicit Two-Level `A1` Registry Authority Binding & End-to-End Composition
    Mandatory Scope Tag (`93rd Ruling §5`):
      `SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1` -/

def w2dMandatoryCompositionScope : String :=
  "SCOPED_CNP2_OUTER_RESILIENCE_PACKETS_0X03_0X05_WITH_CANONICAL_SNAPSHOT_DECODE_EVASION_0X00_A1"

/-- Exact 15-entry `_PINNED_A1_SNAPSHOT_REGISTRY` from frozen `#40` `omega_kappa_pure_checker.py` L66–82 (`F93-01`). -/
def pinnedOmegaKappaA1Registry15 : List PinnedA1Entry :=
  [ { snapshotId := "SNAP-KAPPA-F78-NONPRES-V1-A1"
      pinnedGen := 1
      pinnedRootHex := "eabf4d6fdc3108a23b75b82016cdd7b888a07f849cd440f622c518e035aa09fc"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-KAPPA-F78-NONPRES-V2-A1"
      pinnedGen := 2
      pinnedRootHex := "5c725ca262b23e67a74e716bc6bf4ba796713c2e13bfaf4ff7c3239c15eab18f"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-KAPPA-F78-SIGMA1-A1"
      pinnedGen := 1
      pinnedRootHex := "d98c8af02b46cf8d3e1f953308320b7b95341e95337f26b5cbd80e2c513c5eda"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-KAPPA-F78-SIGMA2-PROMOTE-A1"
      pinnedGen := 2
      pinnedRootHex := "6304003f79db330ee67841d22cde03346049db826618a0e0f5e876fb29fcab40"
      pinnedConstIds := ["IR-00-CONST-K"] },
    { snapshotId := "SNAP-PHI-ABC-V1-A1"
      pinnedGen := 1
      pinnedRootHex := "dace9001d106fbe91d011fe24eefd80ba5a2d413223c0c31d2ecfec2279e74df"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-ABC-V2-A1"
      pinnedGen := 2
      pinnedRootHex := "831a99beff076fde0739591566c52716f702d23a3cabc3039973f76e453c6d53"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-BUDGET-14-A1"
      pinnedGen := 1
      pinnedRootHex := "556b6c3427f058b9b99988b69b496ede00a38a5c6a0be99c46421ff6171f1b5f"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-EPLUS-SELFLOOP-A1"
      pinnedGen := 1
      pinnedRootHex := "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-K3-EXACT3-SERIES-A1"
      pinnedGen := 1
      pinnedRootHex := "fcfc41e39d7e424241f21ce3bf7198e76842c0abe6efd31e7b28e47d1edb968e"
      pinnedConstIds := ["IR-CONST-S"] },
    { snapshotId := "SNAP-PHI-K3-PARALLEL-MIXED-A1"
      pinnedGen := 1
      pinnedRootHex := "9fb25ac0777f10a8d1cd0dc0bdd7a4fc70ecfa549d8550c92c872ea0d4d6d85b"
      pinnedConstIds := ["IR-CONST-K1", "IR-CONST-K2", "IR-CONST-K3", "IR-CONST-M1", "IR-CONST-M2"] },
    { snapshotId := "SNAP-PHI-K3-SERIES-A1"
      pinnedGen := 1
      pinnedRootHex := "a1e355aae21f67e9f9ab43b0d608c4f43cb591f57b297d1c1fe9a513bb920fe0"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-PRIMARY-V2-A1"
      pinnedGen := 2
      pinnedRootHex := "88c2360342bcaa4542e1e2eb7fecab9b17953aea81a76d79f1ed21898442fa7b"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-PHI-RESILIENCE-DIAMOND-A1"
      pinnedGen := 1
      pinnedRootHex := "1dfda8adb25f331a29d8105c6c9fb54637c6831a33937c1b10c6b4fedc25f1a7"
      pinnedConstIds := ["IR-CONST-00"] },
    { snapshotId := "SNAP-R2-CYCLIC-A1"
      pinnedGen := 1
      pinnedRootHex := "589dc2d810175c6550a944c8ce28f8e6dc2e98bc998d8e8736f4edf7fbc75891"
      pinnedConstIds := [] },
    { snapshotId := "SNAP-R2-PRIMARY-DAG-A1"
      pinnedGen := 1
      pinnedRootHex := "345bc1f820bcd1ed50ab18d41eacd243bb2864a4e2862e7ad5361400fdd1554f"
      pinnedConstIds := [] } ]

/-- **`F93-01` Explicit `A1` Registry Authority Hypothesis (`93rd Ruling §2.1`)**. -/
def TrustedA1Registry (reg : List PinnedA1Entry) : Prop :=
  reg = pinnedOmegaKappaA1Registry15

def checkSingleDecodedClaimAgainstBase (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry) (snap : SourceSnapshot)
    (ip : IssuerPartition) (b : BaseData)
    (qS qT : VertexId) (bSnap : ByteArray)
    (cRaw : RawCarrierPayload) (bh : RawCarrierBindHeader) (cert : SourceCertTerm) : Bool :=
  let vTot := snap.vertexIds.length
  match encodeCarrierPayload vTot cRaw with
  | none => false
  | some bCar =>
      match projectRawCarrierToSpec b cRaw with
      | none => false
      | some cSpec =>
          decide (bh.queryS = qS ∧ bh.queryT = qT) &&
          checkDigestVerifiedBool hash256 ent snap.generation bSnap bCar bh cRaw cert vTot &&
          checkSourceCert0x00 ip b qS qT cSpec cert

/-- **`F92-01` & `W2-D` Top-Level Executable Single-Packet Gate (`0` Caller `SourceSnapshot`)**:
    Accepts a raw `CNP-v2` packet (`0x03` or `0x05`, `evasion_mode = 0x00`) relative to
    `hash256` and `reg : List PinnedA1Entry`, keeping the `0x03` (`F93-03` 4-gate) and `0x05`
    (`F93-02` `B1..B6`) base-refinement pipelines strictly independent! -/
def checkCnp2ResiliencePacket0x00 (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (rawPacket : ByteArray) : Bool :=
  match decodeCnp2ResiliencePacket0x00 rawPacket with
  | none => false
  | some (.kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert) =>
      -- `F93-03` Gate 1: Original wire `B1..B5` + `(qS, qT) ∈ candidateRelations`
      checkGate1Wire0x03Bool hash256 reg base qS qT cIdxs &&
      let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
      let bSnap := bytesOfList (encodeSnapshotSectionList base.rawSnap)
      match lookupPinnedA1 base.rawSnap.snapshotId reg with
      | none => false
      | some ent =>
          let ip := projectIssuerPartition snap ent.pinnedConstIds
          -- `F93-03` Gate 2: Pure shortest-step canonical base synthesis
          let bCanon := synthesizeVerifiedBase (projectIRGraph snap) (closureOfTag base.hdr.closureTag)
          -- `F93-03` Gate 3: Independent `#41` `checkVerifiedBase` verification
          checkVerifiedBase ip bCanon &&
          -- `F93-03` Gate 4: Both `Local` and `Global` slice digests & `0x00` certificates
          checkSingleDecodedClaimAgainstBase hash256 ent snap ip bCanon qS qT bSnap
            (.localPaths locPaths) locBh locCert &&
          checkSingleDecodedClaimAgainstBase hash256 ent snap ip bCanon qS qT bSnap
            (.globalEdges base.candidateEdges) globBh globCert
  | some (.kind0x05 base hopEntries qS qT cIdxs geoBh geoCert) =>
      -- `F93-02` Independent `0x05` Branch: Wire `B1..B6` + `(qS, qT) ∈ candidateRelations`
      checkCNB1B1Bool hash256 reg base cIdxs &&
      checkCNB1B2Bool hash256 base &&
      checkCNB1B3Bool base &&
      checkCNB1B4Bool base &&
      checkCNB1B5Bool base &&
      checkCNB1B6Bool base hopEntries &&
      listMemBool (qS, qT) base.candidateRelations &&
      let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
      let bSnap := bytesOfList (encodeSnapshotSectionList base.rawSnap)
      match lookupPinnedA1 base.rawSnap.snapshotId reg with
      | none => false
      | some ent =>
          let ip := projectIssuerPartition snap ent.pinnedConstIds
          let base05 := projectWireBase0x05 snap base hopEntries
          checkSingleDecodedClaimAgainstBase hash256 ent snap ip base05 qS qT bSnap
            (.geodesicHops hopEntries) geoBh geoCert

/-- **`F93-01` Level 2 Pinned `A1` Gate**: Fixes `reg = pinnedOmegaKappaA1Registry15`. -/
def checkCnp2ResiliencePacketPinnedA1_0x00 (hash256 : ByteArray → ByteArray)
    (rawPacket : ByteArray) : Bool :=
  checkCnp2ResiliencePacket0x00 hash256 pinnedOmegaKappaA1Registry15 rawPacket

/-- **`F93-03` Theorem 2 (`f93_03_packet0x03_requires_original_wire_b1_b5`)**:
    Non-Laundering Theorem (`93rd Ruling §2.3`):
    Even though Gate 2 (`synthesizeVerifiedBase`) produces a valid `BaseData` passing
    `checkVerifiedBase`, ANY `0x03` packet accepted by `checkCnp2ResiliencePacket0x00`
    MUST also satisfy original wire `CNB-v1` `B1..B5` (`posWitnesses` + `closedCuts`)
    and `(qS, qT) ∈ base.candidateRelations`! -/
theorem f93_03_packet0x03_requires_original_wire_b1_b5
    (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (rawPacket : ByteArray)
    (base : RawCNB1Bundle) (qS qT : VertexId) (cIdxs : List Nat)
    (locPaths : List (List VertexId))
    (locBh : RawCarrierBindHeader) (locCert : SourceCertTerm)
    (globBh : RawCarrierBindHeader) (globCert : SourceCertTerm)
    (hdec : decodeCnp2ResiliencePacket0x00 rawPacket =
      some (.kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert))
    (hOk : checkCnp2ResiliencePacket0x00 hash256 reg rawPacket = true) :
    checkCNB1B1Bool hash256 reg base cIdxs = true ∧
    checkCNB1B2Bool hash256 base = true ∧
    checkCNB1B3Bool base = true ∧
    checkCNB1B4Bool base = true ∧
    checkCNB1B5Bool base = true ∧
    (qS, qT) ∈ base.candidateRelations := by
  unfold checkCnp2ResiliencePacket0x00 at hOk
  rw [hdec] at hOk
  dsimp only at hOk
  rcases (Bool.and_eq_true _ _).mp hOk with ⟨hGate1, _⟩
  unfold checkGate1Wire0x03Bool at hGate1
  simp only [Bool.and_eq_true, listMemBool_iff] at hGate1
  rcases hGate1 with ⟨⟨⟨⟨⟨hb1, hb2⟩, hb3⟩, hb4⟩, hb5⟩, hrel⟩
  exact ⟨hb1, hb2, hb3, hb4, hb5, hrel⟩

def ClaimCertSourceSoundRelativeTo (reg : List PinnedA1Entry) (snap : SourceSnapshot)
    (κ : ClosureKind) (qS qT : VertexId) (cSpec : CarrierSpec) (T : SourceCertTerm) : Prop :=
  T.evasionModeTag = 0 ∧
  ((T.modeTag = 1 ∧ T.claimedL = 0 ∧ T.claimedU = 0 ∧
    SourceStringSemanticResilience reg snap κ qS qT cSpec .unbreakable) ∨
   (T.modeTag = 2 ∧ 1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU ∧
    SourceStringSemanticResilience reg snap κ qS qT cSpec (.finiteBounds T.claimedL T.claimedU)))

/-- **Level 1 (`F93-01` Relative Soundness)**:
    End-to-end byte-to-source soundness of a raw `CNP-v2` packet relative to a caller-provided
    registry `reg : List PinnedA1Entry` and external `hash256 : ByteArray → ByteArray`. -/
def SourceSoundnessRelativeTo (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (rawPacket : ByteArray) : Prop :=
  ∃ pkt : RawCnp2ResiliencePacket0x00,
    decodeCnp2ResiliencePacket0x00 rawPacket = some pkt ∧
    encodeCnp2ResiliencePacket0x00 pkt = some rawPacket ∧
    match pkt with
    | .kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert =>
        let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
        let κ := closureOfTag base.hdr.closureTag
        ∃ (ent : PinnedA1Entry) (bSnap bCarLoc bCarGlob : ByteArray),
          lookupPinnedA1 snap.snapshotId reg = some ent ∧
          encodeSnapshotSection base.rawSnap = some bSnap ∧
          decodeSnapshotSection bSnap = some base.rawSnap ∧
          checkGate1Wire0x03Bool hash256 reg base qS qT cIdxs = true ∧
          DigestVerified hash256 ent snap.generation bSnap bCarLoc locBh
            (.localPaths locPaths) locCert snap.vertexIds.length ∧
          DigestVerified hash256 ent snap.generation bSnap bCarGlob globBh
            (.globalEdges base.candidateEdges) globCert snap.vertexIds.length ∧
          ClaimCertSourceSoundRelativeTo reg snap κ qS qT (.localPacket locPaths) locCert ∧
          ClaimCertSourceSoundRelativeTo reg snap κ qS qT .globalGraph globCert
    | .kind0x05 base hopEntries qS qT _cIdxs geoBh geoCert =>
        let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
        let κ := closureOfTag base.hdr.closureTag
        ∃ (ent : PinnedA1Entry) (bSnap bCarGeo : ByteArray),
          lookupPinnedA1 snap.snapshotId reg = some ent ∧
          encodeSnapshotSection base.rawSnap = some bSnap ∧
          decodeSnapshotSection bSnap = some base.rawSnap ∧
          checkCNB1B6Bool base hopEntries = true ∧
          DigestVerified hash256 ent snap.generation bSnap bCarGeo geoBh
            (.geodesicHops hopEntries) geoCert snap.vertexIds.length ∧
          ClaimCertSourceSoundRelativeTo reg snap κ qS qT .geodesicBundle geoCert

/-- **Level 2 (`F93-01` Pinned `A1` Soundness)**:
    Binds `reg` to `pinnedOmegaKappaA1Registry15` via `TrustedA1Registry`. -/
def PinnedA1SourceSoundness (hash256 : ByteArray → ByteArray) (rawPacket : ByteArray) : Prop :=
  ∃ reg : List PinnedA1Entry,
    TrustedA1Registry reg ∧ SourceSoundnessRelativeTo hash256 reg rawPacket

theorem singleDecodedClaim_sound (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (ent : PinnedA1Entry) (snap : SourceSnapshot)
    (ip : IssuerPartition) (b : BaseData) (qS qT : VertexId) (bSnap : ByteArray)
    (cRaw : RawCarrierPayload) (bh : RawCarrierBindHeader) (cert : SourceCertTerm)
    (hAnchor : checkSourceAnchorAndSortLaw reg snap = true)
    (hLookup : lookupPinnedA1 snap.snapshotId reg = some ent)
    (hPart : ip = projectIssuerPartition snap ent.pinnedConstIds)
    (hGraph : b.G = projectIRGraph snap)
    (hBase : checkVerifiedBase ip b = true)
    (hClm : checkSingleDecodedClaimAgainstBase hash256 ent snap ip b qS qT bSnap cRaw bh cert = true) :
    ∃ (bCar : ByteArray) (cSpec : CarrierSpec),
      encodeCarrierPayload snap.vertexIds.length cRaw = some bCar ∧
      projectRawCarrierToSpec b cRaw = some cSpec ∧
      DigestVerified hash256 ent snap.generation bSnap bCar bh cRaw cert snap.vertexIds.length ∧
      ClaimCertSourceSoundRelativeTo reg snap b.kappa qS qT cSpec cert := by
  unfold checkSingleDecodedClaimAgainstBase at hClm
  dsimp only at hClm
  cases hencCar : encodeCarrierPayload snap.vertexIds.length cRaw with
  | none => rw [hencCar] at hClm; cases hClm
  | some bCar =>
    rw [hencCar] at hClm; dsimp only at hClm
    cases hproj : projectRawCarrierToSpec b cRaw with
    | none => rw [hproj] at hClm; cases hClm
    | some cSpec =>
      rw [hproj] at hClm; dsimp only at hClm
      simp only [Bool.and_eq_true] at hClm
      rcases hClm with ⟨⟨_, hDig⟩, hSrcCert⟩
      rcases cert4_with_r1_source_string_sound reg snap ent ip b qS qT cSpec cert
          hAnchor hLookup hPart hGraph hBase hSrcCert with
        ⟨hev0, _, hsemOr⟩
      exact ⟨bCar, cSpec, rfl, rfl, hDig, ⟨hev0, hsemOr⟩⟩

theorem projectRawCarrierToSpec_globalEdges_eq_some {b : BaseData}
    {es : List (VertexId × VertexId)} {c : CarrierSpec}
    (h : projectRawCarrierToSpec b (.globalEdges es) = some c) :
    c = .globalGraph := by
  dsimp only [projectRawCarrierToSpec] at h
  split at h
  · injection h with heq; exact heq.symm
  · cases h

theorem projectRawCarrierToSpec_geodesicHops_eq_some {b : BaseData}
    {hops : List RawHopWireEntry} {c : CarrierSpec}
    (h : projectRawCarrierToSpec b (.geodesicHops hops) = some c) :
    c = .geodesicBundle := by
  dsimp only [projectRawCarrierToSpec] at h
  split at h
  · injection h with heq; exact heq.symm
  · cases h

/-- **`W2-D` Theorem 1 (`w2d_packet_sound_relative_to_registry`, `F93-01` Level 1)**:
    End-to-end single-packet soundness relative to `reg` and `hash256` (`0` caller `SourceSnapshot`). -/
theorem w2d_packet_sound_relative_to_registry
    (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (rawPacket : ByteArray)
    (hOk : checkCnp2ResiliencePacket0x00 hash256 reg rawPacket = true) :
    SourceSoundnessRelativeTo hash256 reg rawPacket := by
  unfold checkCnp2ResiliencePacket0x00 at hOk
  cases hdec : decodeCnp2ResiliencePacket0x00 rawPacket with
  | none => rw [hdec] at hOk; cases hOk
  | some pkt =>
    rw [hdec] at hOk
    rcases w2a_cnp2_packet_backward_roundtrip hdec with ⟨hwfPkt, hencPkt⟩
    refine ⟨pkt, hdec, hencPkt, ?_⟩
    cases pkt with
    | kind0x03 base qS qT cIdxs locPaths locBh locCert globBh globCert =>
      dsimp only at hOk ⊢
      have hwfBase : WF_RawCNB1Bundle base := by
        unfold WF_Cnp2ResiliencePacket0x00 wfCnp2ResiliencePacket0x00Bool at hwfPkt
        simp only [Bool.and_eq_true] at hwfPkt
        exact hwfPkt.2.1.1.1.1.1.1
      have hwfSnap : WF_RawSnapshotWire base.rawSnap := by
        unfold WF_RawCNB1Bundle wfRawCNB1BundleBool at hwfBase
        simp only [Bool.and_eq_true] at hwfBase
        exact hwfBase.1.1.1.2
      rcases (Bool.and_eq_true _ _).mp hOk with ⟨hGate1, hRest⟩
      have hGate1Copy := hGate1
      unfold checkGate1Wire0x03Bool at hGate1
      simp only [Bool.and_eq_true] at hGate1
      rcases hGate1 with ⟨⟨⟨⟨⟨hb1, hb2⟩, _⟩, _⟩, _⟩, _⟩
      rcases w2c_b1_b2_implies_r1_anchor_and_graph hash256 reg base cIdxs hwfBase hb1 hb2 with
        ⟨ent, hlk, hAnchor, _, _⟩
      have hlkRaw : lookupPinnedA1 base.rawSnap.snapshotId reg = some ent := hlk
      rw [hlkRaw] at hRest
      dsimp only at hRest
      simp only [Bool.and_eq_true] at hRest
      rcases hRest with ⟨⟨hBaseCanon, hLocOk⟩, hGlobOk⟩
      let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
      let bSnap := bytesOfList (encodeSnapshotSectionList base.rawSnap)
      have hencSnap : encodeSnapshotSection base.rawSnap = some bSnap := by
        unfold encodeSnapshotSection encodeGuardedSlice
        have hwfS : wfRawSnapshotWireBool base.rawSnap = true := hwfSnap
        rw [if_pos hwfS]
      have hdecSnap : decodeSnapshotSection bSnap = some base.rawSnap := by
        unfold decodeSnapshotSection decodeExactSlice
        rw [listOfBytes_bytesOfList]
        have hp := parseSnapshotSection_encode_append hwfSnap []
        rw [List.append_nil] at hp
        rw [hp]
      let ip := projectIssuerPartition snap ent.pinnedConstIds
      let bCanon := synthesizeVerifiedBase (projectIRGraph snap) (closureOfTag base.hdr.closureTag)
      rcases singleDecodedClaim_sound hash256 reg ent snap ip bCanon qS qT bSnap
          (.localPaths locPaths) locBh locCert hAnchor hlk rfl rfl hBaseCanon hLocOk with
        ⟨bCarLoc, cLoc, _, hprojLoc, hDigLoc, hSoundLoc⟩
      unfold projectRawCarrierToSpec at hprojLoc
      injection hprojLoc with hcLocEq
      subst hcLocEq
      rcases singleDecodedClaim_sound hash256 reg ent snap ip bCanon qS qT bSnap
          (.globalEdges base.candidateEdges) globBh globCert hAnchor hlk rfl rfl hBaseCanon hGlobOk with
        ⟨bCarGlob, cGlob, _, hprojGlob, hDigGlob, hSoundGlob⟩
      have hcGlobEq : cGlob = .globalGraph :=
        projectRawCarrierToSpec_globalEdges_eq_some hprojGlob
      subst hcGlobEq
      exact ⟨ent, bSnap, bCarLoc, bCarGlob, hlk, hencSnap, hdecSnap, hGate1Copy,
             hDigLoc, hDigGlob, hSoundLoc, hSoundGlob⟩
    | kind0x05 base hopEntries qS qT cIdxs geoBh geoCert =>
      dsimp only at hOk ⊢
      have hwfBase : WF_RawCNB1Bundle base := by
        unfold WF_Cnp2ResiliencePacket0x00 wfCnp2ResiliencePacket0x00Bool at hwfPkt
        simp only [Bool.and_eq_true] at hwfPkt
        exact hwfPkt.2.1.1.1.1
      have hwfSnap : WF_RawSnapshotWire base.rawSnap := by
        unfold WF_RawCNB1Bundle wfRawCNB1BundleBool at hwfBase
        simp only [Bool.and_eq_true] at hwfBase
        exact hwfBase.1.1.1.2
      rcases (Bool.and_eq_true _ _).mp hOk with ⟨hB16, hGeoRest⟩
      simp only [Bool.and_eq_true] at hB16
      rcases hB16 with ⟨⟨⟨⟨⟨⟨hb1, hb2⟩, hb3⟩, hb4⟩, hb5⟩, hb6⟩, _⟩
      rcases f93_02_b1_to_b6_implies_checkVerifiedBase hash256 reg base cIdxs hopEntries
          hwfBase hb1 hb2 hb3 hb4 hb5 hb6 with
        ⟨ent, hlk, hAnchor, _, hBase05, _⟩
      have hlkRaw : lookupPinnedA1 base.rawSnap.snapshotId reg = some ent := hlk
      rw [hlkRaw] at hGeoRest
      dsimp only at hGeoRest
      let snap := projectRawToSourceSnapshot hash256 base.hdr base.rawSnap
      let bSnap := bytesOfList (encodeSnapshotSectionList base.rawSnap)
      have hencSnap : encodeSnapshotSection base.rawSnap = some bSnap := by
        unfold encodeSnapshotSection encodeGuardedSlice
        have hwfS : wfRawSnapshotWireBool base.rawSnap = true := hwfSnap
        rw [if_pos hwfS]
      have hdecSnap : decodeSnapshotSection bSnap = some base.rawSnap := by
        unfold decodeSnapshotSection decodeExactSlice
        rw [listOfBytes_bytesOfList]
        have hp := parseSnapshotSection_encode_append hwfSnap []
        rw [List.append_nil] at hp
        rw [hp]
      let ip := projectIssuerPartition snap ent.pinnedConstIds
      let base05 := projectWireBase0x05 snap base hopEntries
      rcases singleDecodedClaim_sound hash256 reg ent snap ip base05 qS qT bSnap
          (.geodesicHops hopEntries) geoBh geoCert hAnchor hlk rfl rfl hBase05 hGeoRest with
        ⟨bCarGeo, cGeo, _, hprojGeo, hDigGeo, hSoundGeo⟩
      have hcGeoEq : cGeo = .geodesicBundle :=
        projectRawCarrierToSpec_geodesicHops_eq_some hprojGeo
      subst hcGeoEq
      exact ⟨ent, bSnap, bCarGeo, hlk, hencSnap, hdecSnap, hb6, hDigGeo, hSoundGeo⟩

/-- **`W2-D` Theorem 2 (`w2d_packet_sound_pinned_a1`, `F93-01` Level 2)**:
    Acceptance by `checkCnp2ResiliencePacketPinnedA1_0x00` establishes `PinnedA1SourceSoundness`
    under `TrustedA1Registry pinnedOmegaKappaA1Registry15`. -/
theorem w2d_packet_sound_pinned_a1
    (hash256 : ByteArray → ByteArray) (rawPacket : ByteArray)
    (hOk : checkCnp2ResiliencePacketPinnedA1_0x00 hash256 rawPacket = true) :
    PinnedA1SourceSoundness hash256 rawPacket :=
  ⟨pinnedOmegaKappaA1Registry15, rfl,
   w2d_packet_sound_relative_to_registry hash256 pinnedOmegaKappaA1Registry15 rawPacket hOk⟩

/-- **`W2-D` Theorem 3 (`w2d_pinned_a1_snapshot_unique`)**:
    Under scoped local `NoCollisionOn` (`0` global cryptographic axioms!), any two canonical
    `Snapshot` byte slices matching the same `PinnedA1Entry` (`pinnedGen`, `0xFF33`, `pinnedRootHex`)
    are byte-identical (`bSnap1 = bSnap2`) and decode to identical `RawSnapshotWireTerm`s. -/
theorem w2d_pinned_a1_snapshot_unique
    (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry)
    (bSnap1 bSnap2 : ByteArray)
    (rawSnap1 rawSnap2 : RawSnapshotWireTerm)
    (hgenLt : ent.pinnedGen < 4294967296)
    (hdec1 : decodeSnapshotSection bSnap1 = some rawSnap1)
    (hdec2 : decodeSnapshotSection bSnap2 = some rawSnap2)
    (hsz1 : (hash256 (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap1)).size = 32)
    (hhex1 : bytes32ToLowerHex (hash256 (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap1)) =
      ent.pinnedRootHex)
    (hhex2 : bytes32ToLowerHex (hash256 (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap2)) =
      ent.pinnedRootHex)
    (hNoColl : NoCollisionOn hash256
      (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap1)
      (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap2)) :
    bSnap1 = bSnap2 ∧ rawSnap1 = rawSnap2 := by
  have hhashEq :
      hash256 (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap1) =
      hash256 (mkSnapshotPreimageBytes ent.pinnedGen constitutionalMask0xFF33 bSnap2) :=
    (w1c_bytes32ToLowerHex_spec hsz1).2 (hhex1.trans hhex2.symm)
  have hpreEq := hNoColl hhashEq
  have hmaskLt : constitutionalMask0xFF33 < 65536 := by decide
  have hbEq := (w1c_snapshot_preimage_injective hgenLt hgenLt hmaskLt hmaskLt hpreEq).2.2
  subst hbEq
  rw [hdec1] at hdec2
  injection hdec2 with hsEq
  exact ⟨rfl, hsEq⟩

/-- Minimal forged-registry witness (`F93-01` Separation Theorem). -/
def f93ForgedRawSnap : RawSnapshotWireTerm :=
  { snapshotId := "SF99"
    bucket0 := ["V0", "V1"]
    bucket1 := []
    bucket2 := []
    bucket3 := []
    irRecords :=
      [ { recTag := 1
          recordId := "F0"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 1, targetSortCode := 0, relTag := 1 }] } ] }

def f93ForgedZero32 : ByteArray := bytesOfList (List.replicate 32 0)

def f93ForgedRegistry : List PinnedA1Entry :=
  [ { snapshotId := "SF99"
      pinnedGen := 1
      pinnedRootHex := bytes32ToLowerHex f93ForgedZero32
      pinnedConstIds := ["F0"] } ]

def f93ForgedBundle : RawCNB1Bundle :=
  { hdr :=
      { closureTag := 2
        claimShortest := 1
        authTierTag := 1
        reservedZero := 0
        generationV := 1
        policyMask := constitutionalMask0xFF33
        transitionTag := 0
        padZero := 0
        claimedRoot32 := f93ForgedZero32 }
    rawSnap := f93ForgedRawSnap
    candidateEdges := [(0, 1)]
    candidateRelations := [(0, 1)]
    posWitnesses := [{ sVid := 0, tVid := 1, rank := 1, nextHop := 1 }]
    closedCuts := [{ srcVid := 0, targets := [1] }, { srcVid := 1, targets := [] }] }

def f93ForgedHops : List RawHopWireEntry :=
  [{ sVid := 0, tVid := 1, rank := 1, hops := [1] }]

def f93ForgedCert : SourceCertTerm :=
  { evasionModeTag := 0
    closureTag := 2
    carrierTag := 2
    modeTag := 1
    claimedL := 0
    claimedU := 0
    unbreakableRefKind := 2
    unbreakableLocalIdx := 0
    unbreakableWalk := [0, 1]
    primalWitnesses := []
    retractionIrIndices := []
    dualCutVids := [] }

def f93ForgedBindHeader : RawCarrierBindHeader :=
  { hSigma32 := f93ForgedZero32
    hCarrier32 := f93ForgedZero32
    closureTag := 2
    carrierTag := 2
    queryS := 0
    queryT := 1 }

def f93ForgedPktTerm : RawCnp2ResiliencePacket0x00 :=
  .kind0x05 f93ForgedBundle f93ForgedHops 0 1 [0] f93ForgedBindHeader f93ForgedCert

def f93ForgedPacketBytes : ByteArray :=
  bytesOfList (encodeCnp2PacketList f93ForgedPktTerm)

set_option maxRecDepth 4096 in
/-- **`F93-01` Separation Theorem (`f93_01_arbitrary_reg_does_not_imply_trusted_a1`, `93rd Ruling §2.1`)**:
    Relative validation `checkCnp2ResiliencePacket0x00 H regForged rawPkt = true` against a
    caller-supplied registry does NOT imply `TrustedA1Registry regForged`, and the exact same
    forged packet is deterministically rejected (`= false`) by `checkCnp2ResiliencePacketPinnedA1_0x00`! -/
theorem f93_01_arbitrary_reg_does_not_imply_trusted_a1 :
    ∃ (H : ByteArray → ByteArray) (regForged : List PinnedA1Entry) (rawPkt : ByteArray),
      checkCnp2ResiliencePacket0x00 H regForged rawPkt = true ∧
      ¬ TrustedA1Registry regForged ∧
      checkCnp2ResiliencePacketPinnedA1_0x00 H rawPkt = false := by
  have hwfPkt : WF_Cnp2ResiliencePacket0x00 f93ForgedPktTerm := rfl
  have hdec : decodeCnp2ResiliencePacket0x00 f93ForgedPacketBytes = some f93ForgedPktTerm := by
    unfold decodeCnp2ResiliencePacket0x00 f93ForgedPacketBytes
    rw [listOfBytes_bytesOfList]
    exact parseCnp2PacketExact_encode hwfPkt
  have hlk : lookupPinnedA1 f93ForgedBundle.rawSnap.snapshotId f93ForgedRegistry =
      some { snapshotId := "SF99", pinnedGen := 1,
             pinnedRootHex := bytes32ToLowerHex f93ForgedZero32, pinnedConstIds := ["F0"] } := rfl
  have hRelOk : checkCnp2ResiliencePacket0x00 constZeroHash32 f93ForgedRegistry f93ForgedPacketBytes = true := by
    unfold checkCnp2ResiliencePacket0x00
    rw [hdec]
    dsimp only [f93ForgedPktTerm]
    have hb1 : checkCNB1B1Bool constZeroHash32 f93ForgedRegistry f93ForgedBundle [0] = true := by
      unfold checkCNB1B1Bool
      rw [hlk]
      dsimp only
      have hhex :
          decide (bytes32ToLowerHex f93ForgedBundle.hdr.claimedRoot32 =
            bytes32ToLowerHex f93ForgedZero32) = true :=
        decide_eq_true rfl
      rw [hhex]
      rfl
    rw [hb1, hlk]
    dsimp only
    unfold checkSingleDecodedClaimAgainstBase
    dsimp only
    have hencC : encodeCarrierPayload 2 (.geodesicHops f93ForgedHops) =
        some (bytesOfList (encodeCarrierPayloadList (.geodesicHops f93ForgedHops))) := rfl
    have hrawLen : (projectRawToSourceSnapshot constZeroHash32 f93ForgedBundle.hdr f93ForgedBundle.rawSnap).vertexIds.length = 2 := rfl
    rw [hrawLen, hencC]
    dsimp only
    have hprojC : projectRawCarrierToSpec
        (projectWireBase0x05 (projectRawToSourceSnapshot constZeroHash32 f93ForgedBundle.hdr f93ForgedBundle.rawSnap)
          f93ForgedBundle f93ForgedHops)
        (.geodesicHops f93ForgedHops) = some .geodesicBundle := rfl
    rw [hprojC]
    dsimp only
    unfold checkDigestVerifiedBool
    have hdHex : decide (bytes32ToLowerHex f93ForgedBindHeader.hSigma32 = bytes32ToLowerHex f93ForgedZero32) = true :=
      decide_eq_true rfl
    rw [hdHex]
    rfl
  have hPinFail : checkCnp2ResiliencePacketPinnedA1_0x00 constZeroHash32 f93ForgedPacketBytes = false := by
    unfold checkCnp2ResiliencePacketPinnedA1_0x00 checkCnp2ResiliencePacket0x00
    rw [hdec]
    dsimp only [f93ForgedPktTerm]
    have hb1F : checkCNB1B1Bool constZeroHash32 pinnedOmegaKappaA1Registry15 f93ForgedBundle [0] = false := rfl
    rw [hb1F]
    rfl
  refine ⟨constZeroHash32, f93ForgedRegistry, f93ForgedPacketBytes, hRelOk, ?_, hPinFail⟩
  intro htr
  unfold TrustedA1Registry at htr
  have hlen := congrArg List.length htr
  revert hlen
  decide

end OmegaLambda

/-
  CAMPUS-NOESIS Omega-Lambda W1: Scoped Canonical Slice Refinement Proof Track (`#45`)
  Module: `OmegaLambda.WireRefinement`

  91st Independent Static Tribunal Authorization & Mandatory Guards:
    - Scope Tag (`W-1E`): `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT`
      (Full `CNB-v1` / `CNP-v2` outer packet & raw Snapshot parser remain `HELD` for `W2`).
    - `W-1A`: Big-endian primitives (`u8`, `u16be`, `u32be`) and 70-byte `CarrierBindHeader`
      (`>32s32sBBHH`) bidirectional roundtrips, strictly separating byte-representation
      legality (`WF_RawBindHeader`) from semantic tag legality (`BindHeaderSemanticWF`).
    - `W-1B`: Canonical serialization & bidirectional roundtrips (`decode(encode(x)) = some x`
      AND `decode(B) = some x → WF(x) ∧ encode(x) = some B`) across all 3 carrier payloads
      (`0x01` `LocalPathPacket` including 4-byte 0-step `[s]` preserving `F82-01`,
      `0x02` `GeodesicHopBundle`, `0x03` `GlobalGraph`).
    - `W-1C` & `F91-02`: Exact 68-byte-prefix 6-component Carrier SHA-256 preimage and
      37-byte-prefix Snapshot SHA-256 preimage framing injectivity (`0` kernel axioms),
      4-domain prefix disjointness, `bytes32ToLowerHex` injectivity, explicit external
      `hash256 : ByteArray → ByteArray` parameterization, machine-checked pigeonhole proof
      that no 32-byte digest function is globally injective over `ByteArray`
      (`f91_02_no_32byte_hash_globally_injective`), and explicit proof that abstract
      `DigestVerified` does not by itself identify FIPS `SHA-256`
      (`f91_02_abstract_digest_does_not_force_sha256_identity`).
    - `W-1D` & `F91-03`: Asymmetric `0x00` Claim Slice (`Local` vs `Global`/`Geodesic`)
      with guarded canonical `Option ByteArray` encoder domain theorem
      (`f91_03_encodeClaimSlice0x00_domain_iff`), forward canonical roundtrip
      (`f91_03_claim_slice_forward_roundtrip`), and backward decoded-bytes roundtrip
      (`f91_03_claim_slice_backward_roundtrip`).
    - `W-1E`: Scoped composition with untouched `#43` (`Ωλ-R1`) and `#44` (`Ωλ-R2`)
      (`w1e_scoped_canonical_slices_with_trusted_snapshot_sound`) plus detached header
      uniqueness under local `NoCollisionOn` (`w1e_detached_bind_header_carrier_unique`).

  Discipline:
    - `sorryAx = 0`, user `axiom = 0`, `opaque = 0`
    - `Lean.ofReduceBool = 0`, `Lean.trustCompiler = 0` (`native_decide` prohibited)
-/

import OmegaLambda.CertRefinement

namespace OmegaLambda

/-! ## Pure `ByteArray` ↔ `List UInt8` Bridge & Wire Constants (`#40` Fidelity) -/

def noneVidSentinel : Nat := 65535   -- `0xFFFF` (`NONE_VID_SENTINEL`)
def maxWireVertices : Nat := 512     -- `MAX_VERTICES`
def maxWireIrRecords : Nat := 4096   -- `MAX_IR_RECORDS`
def maxLocalPacketPaths : Nat := 64  -- `MAX_LOCAL_PATHS`

def bytesOfList (bs : List UInt8) : ByteArray :=
  { data := { toList := bs } }

def listOfBytes (b : ByteArray) : List UInt8 :=
  b.data.toList

theorem bytesOfList_listOfBytes (b : ByteArray) :
    bytesOfList (listOfBytes b) = b := by
  cases b with
  | mk d =>
    cases d with
    | mk l => rfl

theorem listOfBytes_bytesOfList (bs : List UInt8) :
    listOfBytes (bytesOfList bs) = bs := rfl

theorem byteArray_eq_iff_list (b1 b2 : ByteArray) :
    b1 = b2 ↔ listOfBytes b1 = listOfBytes b2 := by
  cases b1 with
  | mk d1 =>
    cases d1 with
    | mk l1 =>
      cases b2 with
      | mk d2 =>
        cases d2 with
        | mk l2 =>
          simp [listOfBytes]

theorem byteArray_size_eq_length (b : ByteArray) :
    b.size = (listOfBytes b).length := by
  cases b with
  | mk d =>
    cases d with
    | mk l => rfl

def byteConcat (b1 b2 : ByteArray) : ByteArray :=
  bytesOfList (listOfBytes b1 ++ listOfBytes b2)

def byteConcatList (chunks : List ByteArray) : ByteArray :=
  bytesOfList (chunks.flatMap listOfBytes)

/-! ## Universal Guarded Exact-Slice Parser/Encoder Framework -/

def decodeExactSlice (parse : List UInt8 → Option (α × List UInt8)) (raw : ByteArray) : Option α :=
  match parse (listOfBytes raw) with
  | some (x, []) => some x
  | _ => none

def encodeGuardedSlice (wf : α → Bool) (enc : α → List UInt8) (x : α) : Option ByteArray :=
  if wf x then some (bytesOfList (enc x)) else none

theorem encodeGuardedSlice_isSome_iff (wf : α → Bool) (enc : α → List UInt8) (x : α) :
    (∃ B, encodeGuardedSlice wf enc x = some B) ↔ wf x = true := by
  unfold encodeGuardedSlice
  cases h : wf x <;> simp

theorem encodeGuardedSlice_eq_none_of_not_wf (wf : α → Bool) (enc : α → List UInt8) (x : α)
    (hnot : ¬ (wf x = true)) :
    encodeGuardedSlice wf enc x = none := by
  unfold encodeGuardedSlice
  cases h : wf x
  · rfl
  · exact absurd h hnot

theorem guardedSlice_forward_roundtrip
    (wf : α → Bool) (enc : α → List UInt8)
    (parse : List UInt8 → Option (α × List UInt8))
    (hfwd : ∀ x rest, wf x = true → parse (enc x ++ rest) = some (x, rest))
    {x : α} (hwf : wf x = true) :
    ∃ B, encodeGuardedSlice wf enc x = some B ∧ decodeExactSlice parse B = some x := by
  refine ⟨bytesOfList (enc x), ?_, ?_⟩
  · simp [encodeGuardedSlice, hwf]
  · unfold decodeExactSlice
    rw [listOfBytes_bytesOfList]
    have h0 := hfwd x [] hwf
    rw [List.append_nil] at h0
    rw [h0]

theorem guardedSlice_backward_roundtrip
    (wf : α → Bool) (enc : α → List UInt8)
    (parse : List UInt8 → Option (α × List UInt8))
    (hbwd : ∀ bs rest x, parse bs = some (x, rest) → wf x = true ∧ bs = enc x ++ rest)
    {B : ByteArray} {x : α}
    (hdec : decodeExactSlice parse B = some x) :
    wf x = true ∧ encodeGuardedSlice wf enc x = some B := by
  unfold decodeExactSlice at hdec
  cases hp : parse (listOfBytes B) with
  | none => rw [hp] at hdec; cases hdec
  | some pair =>
    rw [hp] at hdec
    rcases pair with ⟨y, rem⟩
    cases rem with
    | nil =>
      injection hdec with hyx
      subst hyx
      rcases hbwd (listOfBytes B) [] y hp with ⟨hwf, hbsEq⟩
      rw [List.append_nil] at hbsEq
      refine ⟨hwf, ?_⟩
      unfold encodeGuardedSlice
      rw [if_pos hwf, ← hbsEq, bytesOfList_listOfBytes]
    | cons _ _ => cases hdec

theorem guardedSlice_bijection_iff
    (wf : α → Bool) (enc : α → List UInt8)
    (parse : List UInt8 → Option (α × List UInt8))
    (hfwd : ∀ x rest, wf x = true → parse (enc x ++ rest) = some (x, rest))
    (hbwd : ∀ bs rest x, parse bs = some (x, rest) → wf x = true ∧ bs = enc x ++ rest)
    (B : ByteArray) (x : α) :
    decodeExactSlice parse B = some x ↔ encodeGuardedSlice wf enc x = some B := by
  constructor
  · intro hdec
    exact (guardedSlice_backward_roundtrip wf enc parse hbwd hdec).2
  · intro henc
    unfold encodeGuardedSlice at henc
    cases hwf : wf x with
    | false => rw [hwf] at henc; cases henc
    | true =>
      rw [if_pos hwf] at henc
      injection henc with hBeq
      subst hBeq
      unfold decodeExactSlice
      rw [listOfBytes_bytesOfList]
      have h0 := hfwd x [] hwf
      rw [List.append_nil] at h0
      rw [h0]

/-! ## `W-1A`: Big-Endian Primitives (`u8`, `u16be`, `u32be`) & Fixed-Slice Combinators -/

theorem uint8_ofNat_toNat_lt {n : Nat} (hlt : n < 256) :
    (UInt8.ofNat n).toNat = n := by
  change n % UInt8.size = n
  have hs : UInt8.size = 256 := rfl
  rw [hs]
  exact Nat.mod_eq_of_lt hlt

theorem uint8_ofNat_toNat_id (b : UInt8) :
    UInt8.ofNat b.toNat = b :=
  UInt8.ofNat_toNat

theorem uint8_toNat_lt_256 (b : UInt8) : b.toNat < 256 :=
  b.toBitVec.isLt

def packU8 (n : Nat) : List UInt8 :=
  [UInt8.ofNat n]

def parseU8 : List UInt8 → Option (Nat × List UInt8)
  | b :: rest => some (b.toNat, rest)
  | [] => none

theorem parseU8_packU8_append {n : Nat} (hlt : n < 256) (rest : List UInt8) :
    parseU8 (packU8 n ++ rest) = some (n, rest) := by
  simp [packU8, parseU8, uint8_ofNat_toNat_lt hlt]

theorem parseU8_eq_some {bs rest : List UInt8} {n : Nat}
    (h : parseU8 bs = some (n, rest)) :
    n < 256 ∧ bs = packU8 n ++ rest := by
  cases bs with
  | nil => cases h
  | cons b tl =>
    simp only [parseU8, Option.some.injEq, Prod.mk.injEq] at h
    rcases h with ⟨hn, htl⟩
    subst hn; subst htl
    exact ⟨uint8_toNat_lt_256 b, by simp [packU8]⟩

def packU16BE (n : Nat) : List UInt8 :=
  [UInt8.ofNat (n / 256), UInt8.ofNat (n % 256)]

def parseU16BE : List UInt8 → Option (Nat × List UInt8)
  | b0 :: b1 :: rest => some (b0.toNat * 256 + b1.toNat, rest)
  | _ => none

theorem parseU16BE_packU16BE_append {n : Nat} (hlt : n < 65536) (rest : List UInt8) :
    parseU16BE (packU16BE n ++ rest) = some (n, rest) := by
  have h0 : n / 256 < 256 := by omega
  have h1 : n % 256 < 256 := by omega
  simp only [packU16BE, List.cons_append, List.nil_append, parseU16BE,
    uint8_ofNat_toNat_lt h0, uint8_ofNat_toNat_lt h1]
  congr 1
  ext <;> simp
  omega

theorem parseU16BE_eq_some {bs rest : List UInt8} {n : Nat}
    (h : parseU16BE bs = some (n, rest)) :
    n < 65536 ∧ bs = packU16BE n ++ rest := by
  cases bs with
  | nil => cases h
  | cons b0 tl0 =>
    cases tl0 with
    | nil => cases h
    | cons b1 tl1 =>
      simp only [parseU16BE, Option.some.injEq, Prod.mk.injEq] at h
      rcases h with ⟨hn, htl⟩
      subst htl
      have hb0 := uint8_toNat_lt_256 b0
      have hb1 := uint8_toNat_lt_256 b1
      have hnLt : n < 65536 := by omega
      have hdiv : n / 256 = b0.toNat := by omega
      have hmod : n % 256 = b1.toNat := by omega
      refine ⟨hnLt, ?_⟩
      simp [packU16BE, hdiv, hmod]

def packU32BE (n : Nat) : List UInt8 :=
  [ UInt8.ofNat (n / 16777216),
    UInt8.ofNat ((n / 65536) % 256),
    UInt8.ofNat ((n / 256) % 256),
    UInt8.ofNat (n % 256) ]

def parseU32BE : List UInt8 → Option (Nat × List UInt8)
  | b0 :: b1 :: b2 :: b3 :: rest =>
      some (b0.toNat * 16777216 + b1.toNat * 65536 + b2.toNat * 256 + b3.toNat, rest)
  | _ => none

theorem parseU32BE_packU32BE_append {n : Nat} (hlt : n < 4294967296) (rest : List UInt8) :
    parseU32BE (packU32BE n ++ rest) = some (n, rest) := by
  have h0 : n / 16777216 < 256 := by omega
  have h1 : (n / 65536) % 256 < 256 := by omega
  have h2 : (n / 256) % 256 < 256 := by omega
  have h3 : n % 256 < 256 := by omega
  simp only [packU32BE, List.cons_append, List.nil_append, parseU32BE,
    uint8_ofNat_toNat_lt h0, uint8_ofNat_toNat_lt h1,
    uint8_ofNat_toNat_lt h2, uint8_ofNat_toNat_lt h3]
  congr 1
  ext <;> simp
  omega

theorem parseU32BE_eq_some {bs rest : List UInt8} {n : Nat}
    (h : parseU32BE bs = some (n, rest)) :
    n < 4294967296 ∧ bs = packU32BE n ++ rest := by
  cases bs with
  | nil => cases h
  | cons b0 t0 =>
    cases t0 with
    | nil => cases h
    | cons b1 t1 =>
      cases t1 with
      | nil => cases h
      | cons b2 t2 =>
        cases t2 with
        | nil => cases h
        | cons b3 tl =>
          simp only [parseU32BE, Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨hn, htl⟩
          subst htl
          have hb0 := uint8_toNat_lt_256 b0
          have hb1 := uint8_toNat_lt_256 b1
          have hb2 := uint8_toNat_lt_256 b2
          have hb3 := uint8_toNat_lt_256 b3
          have hnLt : n < 4294967296 := by omega
          have hd0 : n / 16777216 = b0.toNat := by omega
          have hd1 : (n / 65536) % 256 = b1.toNat := by omega
          have hd2 : (n / 256) % 256 = b2.toNat := by omega
          have hd3 : n % 256 = b3.toNat := by omega
          refine ⟨hnLt, ?_⟩
          simp [packU32BE, hd0, hd1, hd2, hd3]

/-- Standalone `u16be` & `u32be` slice roundtrips (`W-1A`). -/
def encodeU16BESlice (n : Nat) : Option ByteArray :=
  encodeGuardedSlice (fun x => decide (x < 65536)) packU16BE n

def decodeU16BESlice (raw : ByteArray) : Option Nat :=
  decodeExactSlice parseU16BE raw

theorem w1a_u16be_forward_roundtrip {n : Nat} (hlt : n < 65536) :
    ∃ B, encodeU16BESlice n = some B ∧ decodeU16BESlice B = some n :=
  guardedSlice_forward_roundtrip _ packU16BE parseU16BE
    (fun _ rest hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) rest)
    (decide_eq_true hlt)

theorem w1a_u16be_backward_roundtrip {B : ByteArray} {n : Nat}
    (hdec : decodeU16BESlice B = some n) :
    n < 65536 ∧ encodeU16BESlice n = some B := by
  rcases guardedSlice_backward_roundtrip
      (fun x => decide (x < 65536)) packU16BE parseU16BE
      (fun _ _ _ hp =>
        let ⟨h1, h2⟩ := parseU16BE_eq_some hp
        ⟨decide_eq_true h1, h2⟩) hdec with ⟨hw, henc⟩
  exact ⟨of_decide_eq_true hw, henc⟩

def encodeU32BESlice (n : Nat) : Option ByteArray :=
  encodeGuardedSlice (fun x => decide (x < 4294967296)) packU32BE n

def decodeU32BESlice (raw : ByteArray) : Option Nat :=
  decodeExactSlice parseU32BE raw

theorem w1a_u32be_forward_roundtrip {n : Nat} (hlt : n < 4294967296) :
    ∃ B, encodeU32BESlice n = some B ∧ decodeU32BESlice B = some n :=
  guardedSlice_forward_roundtrip _ packU32BE parseU32BE
    (fun _ rest hw => parseU32BE_packU32BE_append (of_decide_eq_true hw) rest)
    (decide_eq_true hlt)

theorem w1a_u32be_backward_roundtrip {B : ByteArray} {n : Nat}
    (hdec : decodeU32BESlice B = some n) :
    n < 4294967296 ∧ encodeU32BESlice n = some B := by
  rcases guardedSlice_backward_roundtrip
      (fun x => decide (x < 4294967296)) packU32BE parseU32BE
      (fun _ _ _ hp =>
        let ⟨h1, h2⟩ := parseU32BE_eq_some hp
        ⟨decide_eq_true h1, h2⟩) hdec with ⟨hw, henc⟩
  exact ⟨of_decide_eq_true hw, henc⟩

def splitAtExact : Nat → List UInt8 → Option (List UInt8 × List UInt8)
  | 0, bs => some ([], bs)
  | _ + 1, [] => none
  | k + 1, b :: rest =>
      match splitAtExact k rest with
      | none => none
      | some (pre, suf) => some (b :: pre, suf)

theorem splitAtExact_append {k : Nat} {pre : List UInt8} (hlen : pre.length = k) (suf : List UInt8) :
    splitAtExact k (pre ++ suf) = some (pre, suf) := by
  induction k generalizing pre with
  | zero =>
    cases pre with
    | nil => rfl
    | cons _ _ => cases hlen
  | succ m ih =>
    cases pre with
    | nil => cases hlen
    | cons b tl =>
      simp only [List.length_cons, Nat.succ.injEq] at hlen
      simp [splitAtExact, ih hlen]

theorem splitAtExact_eq_some {k : Nat} {bs pre suf : List UInt8}
    (h : splitAtExact k bs = some (pre, suf)) :
    pre.length = k ∧ bs = pre ++ suf := by
  induction k generalizing bs pre with
  | zero =>
    simp only [splitAtExact, Option.some.injEq, Prod.mk.injEq] at h
    rcases h with ⟨hpre, hsuf⟩
    subst hpre; subst hsuf
    exact ⟨rfl, rfl⟩
  | succ m ih =>
    cases bs with
    | nil => cases h
    | cons b tl =>
      simp only [splitAtExact] at h
      cases hs : splitAtExact m tl with
      | none => rw [hs] at h; cases h
      | some pair =>
        rw [hs] at h
        rcases pair with ⟨pre', suf'⟩
        simp only [Option.some.injEq, Prod.mk.injEq] at h
        rcases h with ⟨hpre, hsuf⟩
        subst hpre; subst hsuf
        rcases ih hs with ⟨hlen', htlEq⟩
        exact ⟨by simp [hlen'], by simp [htlEq]⟩

def parseFixedByteArray (k : Nat) (bs : List UInt8) : Option (ByteArray × List UInt8) :=
  match splitAtExact k bs with
  | none => none
  | some (pre, suf) => some (bytesOfList pre, suf)

theorem parseFixedByteArray_append {k : Nat} {b : ByteArray}
    (hsize : b.size = k) (rest : List UInt8) :
    parseFixedByteArray k (listOfBytes b ++ rest) = some (b, rest) := by
  rw [byteArray_size_eq_length] at hsize
  unfold parseFixedByteArray
  rw [splitAtExact_append hsize rest]
  dsimp only
  rw [bytesOfList_listOfBytes]

theorem parseFixedByteArray_eq_some {k : Nat} {bs rest : List UInt8} {b : ByteArray}
    (h : parseFixedByteArray k bs = some (b, rest)) :
    b.size = k ∧ bs = listOfBytes b ++ rest := by
  unfold parseFixedByteArray at h
  cases hs : splitAtExact k bs with
  | none => rw [hs] at h; cases h
  | some pair =>
    rw [hs] at h
    rcases pair with ⟨pre, suf⟩
    simp only [Option.some.injEq, Prod.mk.injEq] at h
    rcases h with ⟨hb, hrest⟩
    subst hb; subst hrest
    rcases splitAtExact_eq_some hs with ⟨hlen, hbsEq⟩
    rw [byteArray_size_eq_length, listOfBytes_bytesOfList]
    exact ⟨hlen, hbsEq⟩

/-- Generic fixed-count list repetition parser/encoder (`k` items). -/
def parseRepeat (parseItem : List UInt8 → Option (α × List UInt8)) :
    Nat → List UInt8 → Option (List α × List UInt8)
  | 0, bs => some ([], bs)
  | k + 1, bs =>
      match parseItem bs with
      | none => none
      | some (x, bs1) =>
          match parseRepeat parseItem k bs1 with
          | none => none
          | some (xs, bs2) => some (x :: xs, bs2)

def encodeRepeat (encItem : α → List UInt8) : List α → List UInt8
  | [] => []
  | x :: xs => encItem x ++ encodeRepeat encItem xs

theorem parseRepeat_encodeRepeat_append
    {wfItem : α → Bool} {encItem : α → List UInt8}
    {parseItem : List UInt8 → Option (α × List UInt8)}
    (hfwd : ∀ x rest, wfItem x = true → parseItem (encItem x ++ rest) = some (x, rest))
    {xs : List α} (hall : listAllBool wfItem xs = true) (rest : List UInt8) :
    parseRepeat parseItem xs.length (encodeRepeat encItem xs ++ rest) = some (xs, rest) := by
  induction xs with
  | nil => rfl
  | cons x tl ih =>
    simp only [listAllBool, Bool.and_eq_true] at hall
    simp only [List.length_cons, encodeRepeat, List.append_assoc, parseRepeat]
    rw [hfwd x (encodeRepeat encItem tl ++ rest) hall.1]
    dsimp only
    rw [ih hall.2]

theorem parseRepeat_eq_some
    {wfItem : α → Bool} {encItem : α → List UInt8}
    {parseItem : List UInt8 → Option (α × List UInt8)}
    (hbwd : ∀ bs rest x, parseItem bs = some (x, rest) → wfItem x = true ∧ bs = encItem x ++ rest) :
    ∀ {k : Nat} {bs rest : List UInt8} {xs : List α},
      parseRepeat parseItem k bs = some (xs, rest) →
      xs.length = k ∧ listAllBool wfItem xs = true ∧ bs = encodeRepeat encItem xs ++ rest := by
  intro k
  induction k with
  | zero =>
    intro bs rest xs h
    simp only [parseRepeat, Option.some.injEq, Prod.mk.injEq] at h
    rcases h with ⟨hxs, hrest⟩
    subst hxs; subst hrest
    exact ⟨rfl, rfl, rfl⟩
  | succ m ih =>
    intro bs rest xs h
    simp only [parseRepeat] at h
    cases hp1 : parseItem bs with
    | none => rw [hp1] at h; cases h
    | some p1 =>
      rw [hp1] at h
      rcases p1 with ⟨x, bs1⟩
      dsimp only at h
      cases hp2 : parseRepeat parseItem m bs1 with
      | none => rw [hp2] at h; cases h
      | some p2 =>
        rw [hp2] at h
        rcases p2 with ⟨tl, bs2⟩
        dsimp only at h
        simp only [Option.some.injEq, Prod.mk.injEq] at h
        rcases h with ⟨hxs, hrest⟩
        subst hxs; subst hrest
        rcases hbwd bs bs1 x hp1 with ⟨hwfX, hbsEq⟩
        rcases ih hp2 with ⟨hlenTl, hallTl, hbs1Eq⟩
        refine ⟨by simp [hlenTl], ?_, ?_⟩
        · simp [listAllBool, hwfX, hallTl]
        · rw [hbsEq, hbs1Eq]
          simp [encodeRepeat, List.append_assoc]

/-! ## `W-1A`: 70-Byte `RawCarrierBindHeader` (`>32s32sBBHH`) Bijection vs Semantic Legality -/

/-- Exact 70-byte `CarrierBindHeader` structure (`#40` `_CARRIER_BIND_FMT = ">32s32sBBHH"`). -/
structure RawCarrierBindHeader where
  hSigma32 : ByteArray
  hCarrier32 : ByteArray
  closureTag : Nat
  carrierTag : Nat
  queryS : VertexId
  queryT : VertexId
  deriving DecidableEq

/-- Byte-representation legality ONLY (`91st Ruling §2`):
    Widths fit `32s, 32s, u8, u8, u16be, u16be`, WITHOUT restricting tag semantics. -/
def wfRawBindHeaderBool (bh : RawCarrierBindHeader) : Bool :=
  decide (bh.hSigma32.size = 32) &&
  decide (bh.hCarrier32.size = 32) &&
  decide (bh.closureTag < 256) &&
  decide (bh.carrierTag < 256) &&
  decide (bh.queryS < 65536) &&
  decide (bh.queryT < 65536)

def WF_RawBindHeader (bh : RawCarrierBindHeader) : Prop :=
  wfRawBindHeaderBool bh = true

/-- Higher-level semantic header legality (`closureTag ∈ {1, 2}`, `carrierTag ∈ {1, 2, 3}`,
    `queryS, queryT < vTotal`, and `0xFFFF` sentinel exclusion). -/
def checkBindHeaderSemanticWF (vTotal : Nat) (bh : RawCarrierBindHeader) : Bool :=
  wfRawBindHeaderBool bh &&
  decide (bh.closureTag = 1 ∨ bh.closureTag = 2) &&
  decide (bh.carrierTag = 1 ∨ bh.carrierTag = 2 ∨ bh.carrierTag = 3) &&
  decide (bh.queryS < vTotal) &&
  decide (bh.queryT < vTotal) &&
  decide (bh.queryS ≠ noneVidSentinel) &&
  decide (bh.queryT ≠ noneVidSentinel)

def encodeBindHeaderList (bh : RawCarrierBindHeader) : List UInt8 :=
  listOfBytes bh.hSigma32 ++
  listOfBytes bh.hCarrier32 ++
  packU8 bh.closureTag ++
  packU8 bh.carrierTag ++
  packU16BE bh.queryS ++
  packU16BE bh.queryT

def parseBindHeader : List UInt8 → Option (RawCarrierBindHeader × List UInt8) := fun bs =>
  match parseFixedByteArray 32 bs with
  | none => none
  | some (hSig, bs1) =>
    match parseFixedByteArray 32 bs1 with
    | none => none
    | some (hCar, bs2) =>
      match parseU8 bs2 with
      | none => none
      | some (clo, bs3) =>
        match parseU8 bs3 with
        | none => none
        | some (ctag, bs4) =>
          match parseU16BE bs4 with
          | none => none
          | some (qs, bs5) =>
            match parseU16BE bs5 with
            | none => none
            | some (qt, bs6) =>
                some ({ hSigma32 := hSig
                        hCarrier32 := hCar
                        closureTag := clo
                        carrierTag := ctag
                        queryS := qs
                        queryT := qt }, bs6)

def encodeBindHeader (bh : RawCarrierBindHeader) : Option ByteArray :=
  encodeGuardedSlice wfRawBindHeaderBool encodeBindHeaderList bh

def decodeBindHeader (raw : ByteArray) : Option RawCarrierBindHeader :=
  decodeExactSlice parseBindHeader raw

theorem parseBindHeader_encode_append {bh : RawCarrierBindHeader}
    (hwf : wfRawBindHeaderBool bh = true) (rest : List UInt8) :
    parseBindHeader (encodeBindHeaderList bh ++ rest) = some (bh, rest) := by
  unfold wfRawBindHeaderBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨hSigSz, hCarSz⟩, hClo⟩, hCtag⟩, hQs⟩, hQt⟩
  unfold encodeBindHeaderList parseBindHeader
  simp only [List.append_assoc]
  rw [parseFixedByteArray_append hSigSz]
  dsimp only
  rw [parseFixedByteArray_append hCarSz]
  dsimp only
  rw [parseU8_packU8_append hClo]
  dsimp only
  rw [parseU8_packU8_append hCtag]
  dsimp only
  rw [parseU16BE_packU16BE_append hQs]
  dsimp only
  rw [parseU16BE_packU16BE_append hQt]

theorem parseBindHeader_eq_some {bs rest : List UInt8} {bh : RawCarrierBindHeader}
    (h : parseBindHeader bs = some (bh, rest)) :
    wfRawBindHeaderBool bh = true ∧ bs = encodeBindHeaderList bh ++ rest := by
  unfold parseBindHeader at h
  cases h1 : parseFixedByteArray 32 bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨hSig, bs1⟩; dsimp only at h
    cases h2 : parseFixedByteArray 32 bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨hCar, bs2⟩; dsimp only at h
      cases h3 : parseU8 bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨clo, bs3⟩; dsimp only at h
        cases h4 : parseU8 bs3 with
        | none => rw [h4] at h; cases h
        | some p4 =>
          rw [h4] at h; rcases p4 with ⟨ctag, bs4⟩; dsimp only at h
          cases h5 : parseU16BE bs4 with
          | none => rw [h5] at h; cases h
          | some p5 =>
            rw [h5] at h; rcases p5 with ⟨qs, bs5⟩; dsimp only at h
            cases h6 : parseU16BE bs5 with
            | none => rw [h6] at h; cases h
            | some p6 =>
              rw [h6] at h; rcases p6 with ⟨qt, bs6⟩
              simp only [Option.some.injEq, Prod.mk.injEq] at h
              rcases h with ⟨hbh, hrest⟩
              subst hbh; subst hrest
              rcases parseFixedByteArray_eq_some h1 with ⟨hsigSz, e1⟩
              rcases parseFixedByteArray_eq_some h2 with ⟨hcarSz, e2⟩
              rcases parseU8_eq_some h3 with ⟨hcloLt, e3⟩
              rcases parseU8_eq_some h4 with ⟨hctagLt, e4⟩
              rcases parseU16BE_eq_some h5 with ⟨hqsLt, e5⟩
              rcases parseU16BE_eq_some h6 with ⟨hqtLt, e6⟩
              refine ⟨?_, ?_⟩
              · unfold wfRawBindHeaderBool
                simp [hsigSz, hcarSz, hcloLt, hctagLt, hqsLt, hqtLt]
              · rw [e1, e2, e3, e4, e5, e6]
                simp [encodeBindHeaderList, List.append_assoc]

theorem encodeBindHeaderList_length {bh : RawCarrierBindHeader}
    (hwf : wfRawBindHeaderBool bh = true) :
    (encodeBindHeaderList bh).length = 70 := by
  unfold wfRawBindHeaderBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨hSigSz, hCarSz⟩, _⟩, _⟩, _⟩, _⟩
  rw [byteArray_size_eq_length] at hSigSz hCarSz
  unfold encodeBindHeaderList
  simp [packU8, packU16BE, hSigSz, hCarSz]

theorem w1a_bind_header_forward_roundtrip {bh : RawCarrierBindHeader}
    (hwf : WF_RawBindHeader bh) :
    ∃ B : ByteArray,
      B.size = 70 ∧
      encodeBindHeader bh = some B ∧
      decodeBindHeader B = some bh := by
  have hwfB : wfRawBindHeaderBool bh = true := hwf
  rcases guardedSlice_forward_roundtrip wfRawBindHeaderBool encodeBindHeaderList parseBindHeader
      (fun _ rest hw => parseBindHeader_encode_append hw rest) hwfB with ⟨B, henc, hdec⟩
  refine ⟨B, ?_, henc, hdec⟩
  unfold encodeGuardedSlice at henc
  rw [if_pos hwfB] at henc
  injection henc with hBeq
  subst hBeq
  rw [byteArray_size_eq_length, listOfBytes_bytesOfList]
  exact encodeBindHeaderList_length hwfB

theorem w1a_bind_header_backward_roundtrip {B : ByteArray} {bh : RawCarrierBindHeader}
    (hdec : decodeBindHeader B = some bh) :
    B.size = 70 ∧ WF_RawBindHeader bh ∧ encodeBindHeader bh = some B := by
  rcases guardedSlice_backward_roundtrip wfRawBindHeaderBool encodeBindHeaderList parseBindHeader
      (fun _ _ _ hp => parseBindHeader_eq_some hp) hdec with ⟨hwf, henc⟩
  refine ⟨?_, hwf, henc⟩
  unfold encodeGuardedSlice at henc
  rw [if_pos hwf] at henc
  injection henc with hBeq
  rw [← hBeq, byteArray_size_eq_length, listOfBytes_bytesOfList]
  exact encodeBindHeaderList_length hwf

theorem w1a_bind_header_bijection_iff (B : ByteArray) (bh : RawCarrierBindHeader) :
    decodeBindHeader B = some bh ↔ encodeBindHeader bh = some B :=
  guardedSlice_bijection_iff wfRawBindHeaderBool encodeBindHeaderList parseBindHeader
    (fun _ rest hw => parseBindHeader_encode_append hw rest)
    (fun _ _ _ hp => parseBindHeader_eq_some hp) B bh

/-- **`W-1A` Separation Theorem (`91st Ruling §2`)**:
    Byte-representation legality (`decodeBindHeader` succeeding on 70 bytes) is strictly
    weaker than semantic header legality (`carrierTag = 99` roundtrips cleanly as 70 bytes
    yet is rejected by `checkBindHeaderSemanticWF`). -/
theorem w1a_repr_valid_does_not_imply_semantic_tag_valid :
    ∃ B : ByteArray, ∃ bh : RawCarrierBindHeader,
      B.size = 70 ∧
      decodeBindHeader B = some bh ∧
      encodeBindHeader bh = some B ∧
      checkBindHeaderSemanticWF 4 bh = false := by
  let z32 := bytesOfList (List.replicate 32 0)
  let bhBad : RawCarrierBindHeader :=
    { hSigma32 := z32
      hCarrier32 := z32
      closureTag := 1
      carrierTag := 99
      queryS := 0
      queryT := 1 }
  have hwf : WF_RawBindHeader bhBad := rfl
  rcases w1a_bind_header_forward_roundtrip hwf with ⟨B, hsz, henc, hdec⟩
  exact ⟨B, bhBad, hsz, hdec, henc, rfl⟩

/-! ## Strict Canonical Ordering Predicates & `NodupList` Lemmas (`#40` `P1`/`P3`/`P4` Fidelity) -/

def strictIncNatFrom (prev : Nat) : List Nat → Bool
  | [] => true
  | x :: xs => decide (prev < x) && strictIncNatFrom x xs

def strictIncNatBool : List Nat → Bool
  | [] => true
  | x :: xs => strictIncNatFrom x xs

theorem strictIncNatFrom_gt {prev : Nat} {xs : List Nat}
    (h : strictIncNatFrom prev xs = true) :
    ∀ y ∈ xs, prev < y := by
  induction xs generalizing prev with
  | nil => intro _ hm; cases hm
  | cons x tl ih =>
    simp only [strictIncNatFrom, Bool.and_eq_true, decide_eq_true_eq] at h
    intro y hy
    cases hy with
    | head => exact h.1
    | tail _ hm =>
      have hxt := ih h.2 y hm
      omega

theorem strictIncNatFrom_nodup {prev : Nat} {xs : List Nat}
    (h : strictIncNatFrom prev xs = true) :
    NodupList xs := by
  induction xs generalizing prev with
  | nil => exact NodupList.nil
  | cons x tl ih =>
    simp only [strictIncNatFrom, Bool.and_eq_true, decide_eq_true_eq] at h
    refine NodupList.cons ?_ (ih h.2)
    intro hmem
    have hlt := strictIncNatFrom_gt h.2 x hmem
    omega

theorem w1d_strict_inc_implies_nodup {xs : List Nat}
    (h : strictIncNatBool xs = true) :
    NodupList xs := by
  cases xs with
  | nil => exact NodupList.nil
  | cons x tl =>
    refine NodupList.cons ?_ (strictIncNatFrom_nodup h)
    intro hmem
    have hlt := strictIncNatFrom_gt h x hmem
    omega

def lexLtNatListBool : List Nat → List Nat → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: as, b :: bs =>
      if a < b then true
      else if b < a then false
      else lexLtNatListBool as bs

theorem lexLtNatList_irrefl (xs : List Nat) : lexLtNatListBool xs xs = false := by
  induction xs with
  | nil => rfl
  | cons a tl ih =>
    simp only [lexLtNatListBool]
    have hnot : ¬ (a < a) := Nat.lt_irrefl a
    simp [hnot, ih]

theorem lexLtNatList_trans {xs ys zs : List Nat}
    (hxy : lexLtNatListBool xs ys = true)
    (hyz : lexLtNatListBool ys zs = true) :
    lexLtNatListBool xs zs = true := by
  induction xs generalizing ys zs with
  | nil =>
    cases ys with
    | nil => simp [lexLtNatListBool] at hxy
    | cons _ _ =>
      cases zs with
      | nil => simp [lexLtNatListBool] at hyz
      | cons _ _ => rfl
  | cons a as ih =>
    cases ys with
    | nil => simp [lexLtNatListBool] at hxy
    | cons b bs =>
      cases zs with
      | nil => simp [lexLtNatListBool] at hyz
      | cons c cs =>
        simp only [lexLtNatListBool] at hxy hyz ⊢
        by_cases hab : a < b
        · rw [if_pos hab] at hxy
          by_cases hbc : b < c
          · have hac : a < c := Nat.lt_trans hab hbc
            rw [if_pos hac]
          · rw [if_neg hbc] at hyz
            by_cases hcb : c < b
            · rw [if_pos hcb] at hyz; cases hyz
            · have hbeqc : b = c := by omega
              subst hbeqc
              rw [if_pos hab]
        · rw [if_neg hab] at hxy
          by_cases hba : b < a
          · rw [if_pos hba] at hxy; cases hxy
          · rw [if_neg hba] at hxy
            have habEq : a = b := by omega
            subst habEq
            by_cases hac : a < c
            · rw [if_pos hac]
            · rw [if_neg hac] at hyz ⊢
              by_cases hca : c < a
              · rw [if_pos hca] at hyz; cases hyz
              · rw [if_neg hca] at hyz ⊢
                exact ih hxy hyz

def strictChainBool (lt : α → α → Bool) : α → List α → Bool
  | _, [] => true
  | prev, x :: xs => lt prev x && strictChainBool lt x xs

def strictSortedByBool (lt : α → α → Bool) : List α → Bool
  | [] => true
  | x :: xs => strictChainBool lt x xs

theorem strictChain_all_gt {lt : α → α → Bool}
    (htrans : ∀ a b c, lt a b = true → lt b c = true → lt a c = true)
    {prev : α} {xs : List α}
    (h : strictChainBool lt prev xs = true) :
    ∀ y ∈ xs, lt prev y = true := by
  induction xs generalizing prev with
  | nil => intro _ hm; cases hm
  | cons x tl ih =>
    simp only [strictChainBool, Bool.and_eq_true] at h
    intro y hy
    cases hy with
    | head => exact h.1
    | tail _ hm => exact htrans prev x y h.1 (ih h.2 y hm)

theorem strictSortedBy_nodup {lt : α → α → Bool}
    (hirrefl : ∀ a, lt a a = false)
    (htrans : ∀ a b c, lt a b = true → lt b c = true → lt a c = true)
    {xs : List α} (h : strictSortedByBool lt xs = true) :
    NodupList xs := by
  cases xs with
  | nil => exact NodupList.nil
  | cons x tl =>
    simp only [strictSortedByBool] at h
    suffices ∀ (p : α) (ys : List α), strictChainBool lt p ys = true → p ∉ ys ∧ NodupList ys by
      rcases this x tl h with ⟨hnot, hnd⟩
      exact NodupList.cons hnot hnd
    intro p ys hch
    induction ys generalizing p with
    | nil =>
      refine ⟨?_, NodupList.nil⟩
      intro hm; cases hm
    | cons y rest ih =>
      have hall := strictChain_all_gt htrans hch
      simp only [strictChainBool, Bool.and_eq_true] at hch
      rcases ih y hch.2 with ⟨hyNot, hndRest⟩
      refine ⟨?_, NodupList.cons hyNot hndRest⟩
      intro hpMem
      have hpp := hall p hpMem
      rw [hirrefl p] at hpp
      cases hpp

def strictLexWalksBool (walks : List (List VertexId)) : Bool :=
  strictSortedByBool lexLtNatListBool walks

theorem w1b_strict_lex_walks_gives_nodup {walks : List (List VertexId)}
    (h : strictLexWalksBool walks = true) :
    NodupList walks :=
  strictSortedBy_nodup lexLtNatList_irrefl
    (fun _ _ _ h1 h2 => lexLtNatList_trans h1 h2) h

def pairLtBool (p1 p2 : VertexId × VertexId) : Bool :=
  if p1.1 < p2.1 then true
  else if p2.1 < p1.1 then false
  else decide (p1.2 < p2.2)

def strictLexPairsBool (pairs : List (VertexId × VertexId)) : Bool :=
  strictSortedByBool pairLtBool pairs

/-! ## `W-1B`: Walk & 3-Carrier Canonical Payload Serialization (`0x01`, `0x02`, `0x03`) -/

def wfVertexWireBool (vTotal : Nat) (v : VertexId) : Bool :=
  decide (v < vTotal) && decide (v ≠ noneVidSentinel) && decide (v < 65536)

def wfWalkWireBool (vTotal : Nat) (γ : List VertexId) : Bool :=
  decide (1 ≤ γ.length) &&
  decide (γ.length - 1 ≤ vTotal) &&
  decide (γ.length - 1 < 65536) &&
  listAllBool (wfVertexWireBool vTotal) γ

def encodeWalkList (γ : List VertexId) : List UInt8 :=
  packU16BE (γ.length - 1) ++ encodeRepeat packU16BE γ

def parseWalk (vTotal : Nat) (bs : List UInt8) : Option (List VertexId × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (stepCnt, bs1) =>
      if decide (stepCnt ≤ vTotal) then
        match parseRepeat parseU16BE (stepCnt + 1) bs1 with
        | none => none
        | some (verts, bs2) =>
            if listAllBool (wfVertexWireBool vTotal) verts then
              some (verts, bs2)
            else none
      else none

def encodeWalkSlice (vTotal : Nat) (γ : List VertexId) : Option ByteArray :=
  encodeGuardedSlice (wfWalkWireBool vTotal) encodeWalkList γ

def decodeWalkSlice (vTotal : Nat) (raw : ByteArray) : Option (List VertexId) :=
  decodeExactSlice (parseWalk vTotal) raw

theorem parseWalk_encode_append (vTotal : Nat) {γ : List VertexId}
    (hwf : wfWalkWireBool vTotal γ = true) (rest : List UInt8) :
    parseWalk vTotal (encodeWalkList γ ++ rest) = some (γ, rest) := by
  unfold wfWalkWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨hge1, hleV⟩, hlt64k⟩, hallV⟩
  have hall64k : listAllBool (fun v => decide (v < 65536)) γ = true := by
    rw [listAllBool_iff] at hallV ⊢
    intro v hv
    have hv' := hallV v hv
    unfold wfVertexWireBool at hv'
    simp only [Bool.and_eq_true] at hv'
    exact hv'.2
  unfold encodeWalkList parseWalk
  rw [List.append_assoc, parseU16BE_packU16BE_append hlt64k]
  dsimp only
  rw [if_pos (decide_eq_true hleV)]
  have hlenEq : γ.length - 1 + 1 = γ.length := by omega
  rw [hlenEq]
  rw [parseRepeat_encodeRepeat_append
        (wfItem := fun v => decide (v < 65536))
        (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r)
        hall64k rest]
  dsimp only
  rw [if_pos hallV]

theorem parseWalk_eq_some (vTotal : Nat) {bs rest : List UInt8} {γ : List VertexId}
    (h : parseWalk vTotal bs = some (γ, rest)) :
    wfWalkWireBool vTotal γ = true ∧ bs = encodeWalkList γ ++ rest := by
  unfold parseWalk at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨stepCnt, bs1⟩; dsimp only at h
    split at h
    · next hstepLeB =>
      have hstepLe : stepCnt ≤ vTotal := of_decide_eq_true hstepLeB
      cases h2 : parseRepeat parseU16BE (stepCnt + 1) bs1 with
      | none => rw [h2] at h; cases h
      | some p2 =>
        rw [h2] at h; rcases p2 with ⟨verts, bs2⟩; dsimp only at h
        split at h
        · next hallV =>
          simp only [Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨rfl, rfl⟩
          rcases parseU16BE_eq_some h1 with ⟨hstepLt, e1⟩
          rcases parseRepeat_eq_some
              (wfItem := fun v => decide (v < 65536))
              (fun _ _ _ hp =>
                let ⟨hl, he⟩ := parseU16BE_eq_some hp
                ⟨decide_eq_true hl, he⟩) h2 with ⟨hlenV, _, e2⟩
          have hsub : verts.length - 1 = stepCnt := by omega
          refine ⟨?_, ?_⟩
          · unfold wfWalkWireBool
            rw [hsub]
            have hge1 : 1 ≤ verts.length := by omega
            simp [hge1, hstepLe, hstepLt, hallV]
          · rw [e1, e2]
            simp [encodeWalkList, hsub]
        · cases h
    · cases h

theorem w1b_walk_forward_roundtrip (vTotal : Nat) {γ : List VertexId}
    (hwf : wfWalkWireBool vTotal γ = true) :
    ∃ B, encodeWalkSlice vTotal γ = some B ∧ decodeWalkSlice vTotal B = some γ :=
  guardedSlice_forward_roundtrip _ encodeWalkList (parseWalk vTotal)
    (fun _ rest hw => parseWalk_encode_append vTotal hw rest) hwf

theorem w1b_walk_backward_roundtrip (vTotal : Nat) {B : ByteArray} {γ : List VertexId}
    (hdec : decodeWalkSlice vTotal B = some γ) :
    wfWalkWireBool vTotal γ = true ∧ encodeWalkSlice vTotal γ = some B :=
  guardedSlice_backward_roundtrip _ encodeWalkList (parseWalk vTotal)
    (fun _ _ _ hp => parseWalk_eq_some vTotal hp) hdec

/-- **`W-1B` Reflexive 0-Step Walk 4-Byte Theorem (`F82-01` & `91st Ruling §2`)**:
    A 0-step walk `[s]` encodes on the wire to the exact 4-byte slice
    `[0, 0, s / 256, s % 256]`, while the empty vertex list `[]` has no wire encoding. -/
theorem w1b_reflexive_walk_4bytes {vTotal s : Nat}
    (hsV : s < vTotal) (hsNe : s ≠ noneVidSentinel) (hs64 : s < 65536) :
    encodeWalkSlice vTotal [s] =
      some (bytesOfList [0, 0, UInt8.ofNat (s / 256), UInt8.ofNat (s % 256)]) ∧
    decodeWalkSlice vTotal (bytesOfList [0, 0, UInt8.ofNat (s / 256), UInt8.ofNat (s % 256)]) =
      some [s] ∧
    encodeWalkSlice vTotal [] = none := by
  have hwf : wfWalkWireBool vTotal [s] = true := by
    unfold wfWalkWireBool wfVertexWireBool
    simp [listAllBool, hsV, hsNe, hs64]
  have henc : encodeWalkSlice vTotal [s] =
      some (bytesOfList [0, 0, UInt8.ofNat (s / 256), UInt8.ofNat (s % 256)]) := by
    unfold encodeWalkSlice encodeGuardedSlice
    rw [if_pos hwf]
    simp [encodeWalkList, encodeRepeat, packU16BE]
  rcases w1b_walk_forward_roundtrip vTotal hwf with ⟨B, hencB, hdecB⟩
  rw [henc] at hencB
  injection hencB with hBeq
  subst hBeq
  exact ⟨henc, hdecB, rfl⟩

/-- Wire Hop Table Entry (`#40` `RawHopEntryTerm`: `>HHIH` + `hops` `>H*`). -/
structure RawHopWireEntry where
  sVid : VertexId
  tVid : VertexId
  rank : Nat
  hops : List VertexId
  deriving DecidableEq, Repr

def wfHopEntryWireBool (vTotal : Nat) (e : RawHopWireEntry) : Bool :=
  wfVertexWireBool vTotal e.sVid &&
  wfVertexWireBool vTotal e.tVid &&
  decide (e.rank < 4294967296) &&
  decide (e.hops.length ≤ vTotal) &&
  decide (e.hops.length < 65536) &&
  listAllBool (wfVertexWireBool vTotal) e.hops &&
  strictIncNatBool e.hops

def encodeHopEntryList (e : RawHopWireEntry) : List UInt8 :=
  packU16BE e.sVid ++
  packU16BE e.tVid ++
  packU32BE e.rank ++
  packU16BE e.hops.length ++
  encodeRepeat packU16BE e.hops

def parseHopEntry (vTotal : Nat) (bs : List UInt8) : Option (RawHopWireEntry × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (sv, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (tv, bs2) =>
      match parseU32BE bs2 with
      | none => none
      | some (rk, bs3) =>
        match parseU16BE bs3 with
        | none => none
        | some (hcnt, bs4) =>
            if decide (hcnt ≤ vTotal) then
              match parseRepeat parseU16BE hcnt bs4 with
              | none => none
              | some (hs, bs5) =>
                  let ent : RawHopWireEntry := { sVid := sv, tVid := tv, rank := rk, hops := hs }
                  if wfHopEntryWireBool vTotal ent then some (ent, bs5) else none
            else none

theorem parseHopEntry_encode_append (vTotal : Nat) {e : RawHopWireEntry}
    (hwf : wfHopEntryWireBool vTotal e = true) (rest : List UInt8) :
    parseHopEntry vTotal (encodeHopEntryList e ++ rest) = some (e, rest) := by
  have hwfCopy := hwf
  unfold wfHopEntryWireBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨⟨hsv, htv⟩, hrkLt⟩, hhLe⟩, hhLt⟩, hallH⟩, _⟩
  have hall64 : listAllBool (fun v => decide (v < 65536)) e.hops = true := by
    rw [listAllBool_iff] at hallH ⊢
    intro v hv
    have hv' := hallH v hv
    unfold wfVertexWireBool at hv'
    simp only [Bool.and_eq_true] at hv'
    exact hv'.2
  unfold encodeHopEntryList parseHopEntry
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append hsv.2]
  dsimp only
  rw [parseU16BE_packU16BE_append htv.2]
  dsimp only
  rw [parseU32BE_packU32BE_append hrkLt]
  dsimp only
  rw [parseU16BE_packU16BE_append hhLt]
  dsimp only
  rw [if_pos (decide_eq_true hhLe)]
  rw [parseRepeat_encodeRepeat_append
        (wfItem := fun v => decide (v < 65536))
        (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r)
        hall64 rest]
  dsimp only
  cases e
  simp [hwfCopy]

theorem parseHopEntry_eq_some (vTotal : Nat) {bs rest : List UInt8} {e : RawHopWireEntry}
    (h : parseHopEntry vTotal bs = some (e, rest)) :
    wfHopEntryWireBool vTotal e = true ∧ bs = encodeHopEntryList e ++ rest := by
  unfold parseHopEntry at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨sv, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨tv, bs2⟩; dsimp only at h
      cases h3 : parseU32BE bs2 with
      | none => rw [h3] at h; cases h
      | some p3 =>
        rw [h3] at h; rcases p3 with ⟨rk, bs3⟩; dsimp only at h
        cases h4 : parseU16BE bs3 with
        | none => rw [h4] at h; cases h
        | some p4 =>
          rw [h4] at h; rcases p4 with ⟨hcnt, bs4⟩; dsimp only at h
          split at h
          · cases h5 : parseRepeat parseU16BE hcnt bs4 with
            | none => rw [h5] at h; cases h
            | some p5 =>
              rw [h5] at h; rcases p5 with ⟨hs, bs5⟩; dsimp only at h
              split at h
              · next hwfEnt =>
                simp only [Option.some.injEq, Prod.mk.injEq] at h
                rcases h with ⟨heEq, hrest⟩
                subst heEq; subst hrest
                rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
                rcases parseU16BE_eq_some h2 with ⟨_, e2⟩
                rcases parseU32BE_eq_some h3 with ⟨_, e3⟩
                rcases parseU16BE_eq_some h4 with ⟨_, e4⟩
                rcases parseRepeat_eq_some
                    (wfItem := fun v => decide (v < 65536))
                    (fun _ _ _ hp =>
                      let ⟨hl, he⟩ := parseU16BE_eq_some hp
                      ⟨decide_eq_true hl, he⟩) h5 with ⟨hlenHs, _, e5⟩
                refine ⟨hwfEnt, ?_⟩
                rw [e1, e2, e3, e4, e5]
                simp [encodeHopEntryList, hlenHs, List.append_assoc]
              · cases h
          · cases h

def wfEdgePairWireBool (vTotal : Nat) (uv : VertexId × VertexId) : Bool :=
  wfVertexWireBool vTotal uv.1 && wfVertexWireBool vTotal uv.2

def encodeEdgePairList (uv : VertexId × VertexId) : List UInt8 :=
  packU16BE uv.1 ++ packU16BE uv.2

def parseEdgePair (vTotal : Nat) (bs : List UInt8) : Option ((VertexId × VertexId) × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (u, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (w, bs2) =>
        if wfEdgePairWireBool vTotal (u, w) then some ((u, w), bs2) else none

theorem parseEdgePair_encode_append (vTotal : Nat) {uv : VertexId × VertexId}
    (hwf : wfEdgePairWireBool vTotal uv = true) (rest : List UInt8) :
    parseEdgePair vTotal (encodeEdgePairList uv ++ rest) = some (uv, rest) := by
  have hwfCopy := hwf
  rcases uv with ⟨u, w⟩
  unfold wfEdgePairWireBool wfVertexWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  unfold encodeEdgePairList parseEdgePair
  rw [List.append_assoc, parseU16BE_packU16BE_append hwf.1.2]
  dsimp only
  rw [parseU16BE_packU16BE_append hwf.2.2]
  dsimp only
  rw [if_pos hwfCopy]

theorem parseEdgePair_eq_some (vTotal : Nat) {bs rest : List UInt8} {uv : VertexId × VertexId}
    (h : parseEdgePair vTotal bs = some (uv, rest)) :
    wfEdgePairWireBool vTotal uv = true ∧ bs = encodeEdgePairList uv ++ rest := by
  unfold parseEdgePair at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨u, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨w, bs2⟩; dsimp only at h
      split at h
      · next hwf =>
        simp only [Option.some.injEq, Prod.mk.injEq] at h
        rcases h with ⟨huv, hrest⟩
        subst huv; subst hrest
        rcases parseU16BE_eq_some h1 with ⟨_, e1⟩
        rcases parseU16BE_eq_some h2 with ⟨_, e2⟩
        refine ⟨hwf, ?_⟩
        rw [e1, e2]
        simp [encodeEdgePairList, List.append_assoc]
      · cases h

/-- Sum type of the 3 canonical `CNP-v2` carrier wire payloads (`W-1B`). -/
inductive RawCarrierPayload where
  | localPaths (pkt : List (List VertexId))
  | geodesicHops (entries : List RawHopWireEntry)
  | globalEdges (edges : List (VertexId × VertexId))
  deriving DecidableEq, Repr

def RawCarrierPayload.carrierTag : RawCarrierPayload → Nat
  | .localPaths _ => 1
  | .geodesicHops _ => 2
  | .globalEdges _ => 3

def wfCarrierPayloadBool (vTotal : Nat) : RawCarrierPayload → Bool
  | .localPaths pkt =>
      decide (1 ≤ pkt.length) &&
      decide (pkt.length ≤ maxLocalPacketPaths) &&
      decide (pkt.length < 65536) &&
      listAllBool (wfWalkWireBool vTotal) pkt &&
      strictLexWalksBool pkt
  | .geodesicHops entries =>
      decide (entries.length ≤ vTotal * vTotal) &&
      decide (entries.length < 4294967296) &&
      listAllBool (wfHopEntryWireBool vTotal) entries &&
      strictLexPairsBool (entries.map (fun e => (e.sVid, e.tVid)))
  | .globalEdges edges =>
      decide (edges.length ≤ vTotal * vTotal) &&
      decide (edges.length < 4294967296) &&
      listAllBool (wfEdgePairWireBool vTotal) edges &&
      strictLexPairsBool edges

def encodeCarrierPayloadList : RawCarrierPayload → List UInt8
  | .localPaths pkt =>
      packU16BE pkt.length ++ encodeRepeat encodeWalkList pkt
  | .geodesicHops entries =>
      packU32BE entries.length ++ encodeRepeat encodeHopEntryList entries
  | .globalEdges edges =>
      packU32BE edges.length ++ encodeRepeat encodeEdgePairList edges

def parseCarrierPayloadByTag (cTag vTotal : Nat) (bs : List UInt8) :
    Option (RawCarrierPayload × List UInt8) :=
  match cTag with
  | 1 =>
      match parseU16BE bs with
      | none => none
      | some (cnt, bs1) =>
          if decide (1 ≤ cnt ∧ cnt ≤ maxLocalPacketPaths) then
            match parseRepeat (parseWalk vTotal) cnt bs1 with
            | none => none
            | some (pkt, bs2) =>
                if strictLexWalksBool pkt then some (.localPaths pkt, bs2) else none
          else none
  | 2 =>
      match parseU32BE bs with
      | none => none
      | some (cnt, bs1) =>
          if decide (cnt ≤ vTotal * vTotal) then
            match parseRepeat (parseHopEntry vTotal) cnt bs1 with
            | none => none
            | some (entries, bs2) =>
                if strictLexPairsBool (entries.map (fun e => (e.sVid, e.tVid))) then
                  some (.geodesicHops entries, bs2)
                else none
          else none
  | 3 =>
      match parseU32BE bs with
      | none => none
      | some (cnt, bs1) =>
          if decide (cnt ≤ vTotal * vTotal) then
            match parseRepeat (parseEdgePair vTotal) cnt bs1 with
            | none => none
            | some (edges, bs2) =>
                if strictLexPairsBool edges then some (.globalEdges edges, bs2) else none
          else none
  | _ => none

def encodeCarrierPayload (vTotal : Nat) (p : RawCarrierPayload) : Option ByteArray :=
  encodeGuardedSlice (wfCarrierPayloadBool vTotal) encodeCarrierPayloadList p

def decodeCarrierPayload (cTag vTotal : Nat) (raw : ByteArray) : Option RawCarrierPayload :=
  decodeExactSlice (parseCarrierPayloadByTag cTag vTotal) raw

theorem parseCarrierPayload_encode_append (vTotal : Nat) {p : RawCarrierPayload}
    (hwf : wfCarrierPayloadBool vTotal p = true) (rest : List UInt8) :
    parseCarrierPayloadByTag p.carrierTag vTotal (encodeCarrierPayloadList p ++ rest) =
      some (p, rest) := by
  cases p with
  | localPaths pkt =>
    dsimp only [wfCarrierPayloadBool] at hwf
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
    rcases hwf with ⟨⟨⟨⟨hge1, hle64⟩, hlt64k⟩, hallW⟩, hlex⟩
    simp only [RawCarrierPayload.carrierTag, encodeCarrierPayloadList, parseCarrierPayloadByTag,
      List.append_assoc]
    rw [parseU16BE_packU16BE_append hlt64k]
    dsimp only
    rw [if_pos (decide_eq_true ⟨hge1, hle64⟩)]
    rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseWalk_encode_append vTotal hw r) hallW rest]
    dsimp only
    rw [if_pos hlex]
  | geodesicHops entries =>
    dsimp only [wfCarrierPayloadBool] at hwf
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
    rcases hwf with ⟨⟨⟨hleVV, hlt32⟩, hallE⟩, hlex⟩
    simp only [RawCarrierPayload.carrierTag, encodeCarrierPayloadList, parseCarrierPayloadByTag,
      List.append_assoc]
    rw [parseU32BE_packU32BE_append hlt32]
    dsimp only
    rw [if_pos (decide_eq_true hleVV)]
    rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseHopEntry_encode_append vTotal hw r) hallE rest]
    dsimp only
    rw [if_pos hlex]
  | globalEdges edges =>
    dsimp only [wfCarrierPayloadBool] at hwf
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
    rcases hwf with ⟨⟨⟨hleVV, hlt32⟩, hallE⟩, hlex⟩
    simp only [RawCarrierPayload.carrierTag, encodeCarrierPayloadList, parseCarrierPayloadByTag,
      List.append_assoc]
    rw [parseU32BE_packU32BE_append hlt32]
    dsimp only
    rw [if_pos (decide_eq_true hleVV)]
    rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseEdgePair_encode_append vTotal hw r) hallE rest]
    dsimp only
    rw [if_pos hlex]

theorem parseCarrierPayload_eq_some {cTag vTotal : Nat} {bs rest : List UInt8}
    {p : RawCarrierPayload}
    (h : parseCarrierPayloadByTag cTag vTotal bs = some (p, rest)) :
    p.carrierTag = cTag ∧ wfCarrierPayloadBool vTotal p = true ∧
    bs = encodeCarrierPayloadList p ++ rest := by
  unfold parseCarrierPayloadByTag at h
  split at h
  · cases h1 : parseU16BE bs with
    | none => rw [h1] at h; cases h
    | some p1 =>
      rw [h1] at h; rcases p1 with ⟨cnt, bs1⟩; dsimp only at h
      split at h
      · next hcntB =>
        rcases of_decide_eq_true hcntB with ⟨hge1, hle64⟩
        cases h2 : parseRepeat (parseWalk vTotal) cnt bs1 with
        | none => rw [h2] at h; cases h
        | some p2 =>
          rw [h2] at h; rcases p2 with ⟨pkt, bs2⟩; dsimp only at h
          split at h
          · next hlex =>
            simp only [Option.some.injEq, Prod.mk.injEq] at h
            rcases h with ⟨rfl, rfl⟩
            rcases parseU16BE_eq_some h1 with ⟨hcntLt, e1⟩
            rcases parseRepeat_eq_some (fun _ _ _ hp => parseWalk_eq_some vTotal hp) h2 with
              ⟨hlenP, hallW, e2⟩
            refine ⟨rfl, ?_, ?_⟩
            · dsimp only [wfCarrierPayloadBool]
              rw [hlenP]
              simp [hge1, hle64, hcntLt, hallW, hlex]
            · rw [e1, e2]
              simp [encodeCarrierPayloadList, hlenP, List.append_assoc]
          · cases h
      · cases h
  · cases h1 : parseU32BE bs with
    | none => rw [h1] at h; cases h
    | some p1 =>
      rw [h1] at h; rcases p1 with ⟨cnt, bs1⟩; dsimp only at h
      split at h
      · next hcntB =>
        have hleVV : cnt ≤ vTotal * vTotal := of_decide_eq_true hcntB
        cases h2 : parseRepeat (parseHopEntry vTotal) cnt bs1 with
        | none => rw [h2] at h; cases h
        | some p2 =>
          rw [h2] at h; rcases p2 with ⟨entries, bs2⟩; dsimp only at h
          split at h
          · next hlex =>
            simp only [Option.some.injEq, Prod.mk.injEq] at h
            rcases h with ⟨rfl, rfl⟩
            rcases parseU32BE_eq_some h1 with ⟨hcntLt, e1⟩
            rcases parseRepeat_eq_some (fun _ _ _ hp => parseHopEntry_eq_some vTotal hp) h2 with
              ⟨hlenE, hallE, e2⟩
            refine ⟨rfl, ?_, ?_⟩
            · dsimp only [wfCarrierPayloadBool]
              rw [hlenE]
              simp [hleVV, hcntLt, hallE, hlex]
            · rw [e1, e2]
              simp [encodeCarrierPayloadList, hlenE, List.append_assoc]
          · cases h
      · cases h
  · cases h1 : parseU32BE bs with
    | none => rw [h1] at h; cases h
    | some p1 =>
      rw [h1] at h; rcases p1 with ⟨cnt, bs1⟩; dsimp only at h
      split at h
      · next hcntB =>
        have hleVV : cnt ≤ vTotal * vTotal := of_decide_eq_true hcntB
        cases h2 : parseRepeat (parseEdgePair vTotal) cnt bs1 with
        | none => rw [h2] at h; cases h
        | some p2 =>
          rw [h2] at h; rcases p2 with ⟨edges, bs2⟩; dsimp only at h
          split at h
          · next hlex =>
            simp only [Option.some.injEq, Prod.mk.injEq] at h
            rcases h with ⟨rfl, rfl⟩
            rcases parseU32BE_eq_some h1 with ⟨hcntLt, e1⟩
            rcases parseRepeat_eq_some (fun _ _ _ hp => parseEdgePair_eq_some vTotal hp) h2 with
              ⟨hlenE, hallE, e2⟩
            refine ⟨rfl, ?_, ?_⟩
            · dsimp only [wfCarrierPayloadBool]
              rw [hlenE]
              simp [hleVV, hcntLt, hallE, hlex]
            · rw [e1, e2]
              simp [encodeCarrierPayloadList, hlenE, List.append_assoc]
          · cases h
      · cases h
  · cases h

theorem w1b_carrier_encode_domain_iff (vTotal : Nat) (p : RawCarrierPayload) :
    (∃ B, encodeCarrierPayload vTotal p = some B) ↔ wfCarrierPayloadBool vTotal p = true :=
  encodeGuardedSlice_isSome_iff _ _ p

theorem w1b_carrier_forward_roundtrip (vTotal : Nat) {p : RawCarrierPayload}
    (hwf : wfCarrierPayloadBool vTotal p = true) :
    ∃ B,
      encodeCarrierPayload vTotal p = some B ∧
      decodeCarrierPayload p.carrierTag vTotal B = some p := by
  refine ⟨bytesOfList (encodeCarrierPayloadList p), ?_, ?_⟩
  · simp [encodeCarrierPayload, encodeGuardedSlice, hwf]
  · unfold decodeCarrierPayload decodeExactSlice
    rw [listOfBytes_bytesOfList]
    have h0 := parseCarrierPayload_encode_append vTotal hwf []
    rw [List.append_nil] at h0
    rw [h0]

theorem w1b_carrier_backward_roundtrip {cTag vTotal : Nat} {B : ByteArray}
    {p : RawCarrierPayload}
    (hdec : decodeCarrierPayload cTag vTotal B = some p) :
    p.carrierTag = cTag ∧
    wfCarrierPayloadBool vTotal p = true ∧
    encodeCarrierPayload vTotal p = some B := by
  unfold decodeCarrierPayload decodeExactSlice at hdec
  cases hp : parseCarrierPayloadByTag cTag vTotal (listOfBytes B) with
  | none => rw [hp] at hdec; cases hdec
  | some pair =>
    rw [hp] at hdec
    rcases pair with ⟨q, rem⟩
    cases rem with
    | nil =>
      injection hdec with hqp
      subst hqp
      rcases parseCarrierPayload_eq_some hp with ⟨htag, hwf, hbsEq⟩
      rw [List.append_nil] at hbsEq
      refine ⟨htag, hwf, ?_⟩
      unfold encodeCarrierPayload encodeGuardedSlice
      rw [if_pos hwf, ← hbsEq, bytesOfList_listOfBytes]
    | cons _ _ => cases hdec

/-! ## `W-1C` & `F91-02`: 6-Component Carrier Preimage, Snapshot Preimage, Framing Injectivity,
    `bytes32ToLowerHex`, & Explicit Cryptographic Hash Trust Boundary -/

def asciiNulBytes (s : String) : List UInt8 :=
  (s.toList.map (fun c => UInt8.ofNat c.toNat)) ++ [0]

/-- Exact `#40` NUL-terminated ASCII domain prefixes (`omega_kappa_decoder.py` L69–72). -/
def domainPrefixSnapshot31 : List UInt8 :=
  asciiNulBytes "CAMPUS_NOESIS_CNB1_SNAPSHOT_V1"

def domainPrefixCarrier30 : List UInt8 :=
  asciiNulBytes "CAMPUS_NOESIS_CNP2_CARRIER_V1"

def domainPrefixEdges28 : List UInt8 :=
  asciiNulBytes "CAMPUS_NOESIS_CNP1_EDGES_V1"

def domainPrefixRel26 : List UInt8 :=
  asciiNulBytes "CAMPUS_NOESIS_CNP1_REL_V1"

theorem w1c_domain_prefix_lengths :
    domainPrefixSnapshot31.length = 31 ∧
    domainPrefixCarrier30.length = 30 ∧
    domainPrefixEdges28.length = 28 ∧
    domainPrefixRel26.length = 26 :=
  ⟨rfl, rfl, rfl, rfl⟩

/-- Exact `#40` Snapshot SHA-256 preimage (`31 + 4 + 2 = 37` B prefix + `snapBytes`). -/
def mkSnapshotPreimageBytes (genV : Nat) (policyMask : Nat) (snapBytes : ByteArray) : ByteArray :=
  bytesOfList (
    domainPrefixSnapshot31 ++
    packU32BE genV ++
    packU16BE policyMask ++
    listOfBytes snapBytes)

/-- Exact `#40` 6-Component Carrier SHA-256 preimage (`30 + 1 + 32 + 1 + 2 + 2 = 68` B prefix + `carrierBytes`). -/
def mkCarrierPreimageBytes (carrierTag : Nat) (hSigma32 : ByteArray)
    (closureTag : Nat) (qS qT : VertexId) (carrierBytes : ByteArray) : ByteArray :=
  bytesOfList (
    domainPrefixCarrier30 ++
    packU8 carrierTag ++
    listOfBytes hSigma32 ++
    packU8 closureTag ++
    packU16BE qS ++
    packU16BE qT ++
    listOfBytes carrierBytes)

def mkEdgesPreimageBytes (edgesBytes : ByteArray) : ByteArray :=
  bytesOfList (domainPrefixEdges28 ++ listOfBytes edgesBytes)

def mkRelPreimageBytes (closureTag : Nat) (relBytes : ByteArray) : ByteArray :=
  bytesOfList (domainPrefixRel26 ++ packU8 closureTag ++ listOfBytes relBytes)

theorem w1c_snapshot_preimage_size (genV policyMask : Nat) (snapBytes : ByteArray) :
    (mkSnapshotPreimageBytes genV policyMask snapBytes).size = 37 + snapBytes.size := by
  rw [byteArray_size_eq_length, byteArray_size_eq_length]
  unfold mkSnapshotPreimageBytes
  rw [listOfBytes_bytesOfList]
  have hd : domainPrefixSnapshot31.length = 31 := rfl
  simp [packU32BE, packU16BE, hd]
  omega

theorem w1c_carrier_preimage_size (cTag : Nat) {hSigma32 : ByteArray}
    (hsig : hSigma32.size = 32) (cloTag qS qT : Nat) (carrierBytes : ByteArray) :
    (mkCarrierPreimageBytes cTag hSigma32 cloTag qS qT carrierBytes).size =
      68 + carrierBytes.size := by
  rw [byteArray_size_eq_length] at hsig ⊢
  rw [byteArray_size_eq_length]
  unfold mkCarrierPreimageBytes
  rw [listOfBytes_bytesOfList]
  have hd : domainPrefixCarrier30.length = 30 := rfl
  simp [packU8, packU16BE, hd, hsig]
  omega

theorem list_append_cancel_left_eq_len {xs1 xs2 ys1 ys2 : List α}
    (hlen : xs1.length = xs2.length)
    (heq : xs1 ++ ys1 = xs2 ++ ys2) :
    xs1 = xs2 ∧ ys1 = ys2 := by
  induction xs1 generalizing xs2 with
  | nil =>
    cases xs2 with
    | nil => exact ⟨rfl, heq⟩
    | cons _ _ => cases hlen
  | cons a tl1 ih =>
    cases xs2 with
    | nil => cases hlen
    | cons b tl2 =>
      simp only [List.length_cons, Nat.succ.injEq] at hlen
      simp only [List.cons_append, List.cons.injEq] at heq
      rcases ih hlen heq.2 with ⟨htlEq, hysEq⟩
      exact ⟨by rw [heq.1, htlEq], hysEq⟩

/-- **`W-1C` Theorem 1: 6-Component Carrier Preimage Framing Injectivity (`0` Axioms)**:
    No concatenation ambiguity exists across `(carrierTag, hSigma32, closureTag, qS, qT, B_car)`. -/
theorem w1c_carrier_preimage_injective
    {ct1 ct2 : Nat} {hSig1 hSig2 : ByteArray} {kl1 kl2 s1 s2 t1 t2 : Nat}
    {bCar1 bCar2 : ByteArray}
    (hct1 : ct1 < 256) (hct2 : ct2 < 256)
    (hsig1 : hSig1.size = 32) (hsig2 : hSig2.size = 32)
    (hkl1 : kl1 < 256) (hkl2 : kl2 < 256)
    (hs1 : s1 < 65536) (hs2 : s2 < 65536)
    (ht1 : t1 < 65536) (ht2 : t2 < 65536)
    (heq : mkCarrierPreimageBytes ct1 hSig1 kl1 s1 t1 bCar1 =
           mkCarrierPreimageBytes ct2 hSig2 kl2 s2 t2 bCar2) :
    ct1 = ct2 ∧ hSig1 = hSig2 ∧ kl1 = kl2 ∧ s1 = s2 ∧ t1 = t2 ∧ bCar1 = bCar2 := by
  rw [byteArray_eq_iff_list] at heq
  unfold mkCarrierPreimageBytes at heq
  rw [listOfBytes_bytesOfList, listOfBytes_bytesOfList] at heq
  simp only [List.append_assoc] at heq
  rcases list_append_cancel_left_eq_len rfl heq with ⟨_, r1⟩
  have h1 := congrArg parseU8 r1
  rw [parseU8_packU8_append hct1, parseU8_packU8_append hct2] at h1
  injection h1 with hp1
  rcases Prod.mk.inj hp1 with ⟨hctEq, r2⟩
  have h2 := congrArg (parseFixedByteArray 32) r2
  rw [parseFixedByteArray_append hsig1, parseFixedByteArray_append hsig2] at h2
  injection h2 with hp2
  rcases Prod.mk.inj hp2 with ⟨hsigEq, r3⟩
  have h3 := congrArg parseU8 r3
  rw [parseU8_packU8_append hkl1, parseU8_packU8_append hkl2] at h3
  injection h3 with hp3
  rcases Prod.mk.inj hp3 with ⟨hklEq, r4⟩
  have h4 := congrArg parseU16BE r4
  rw [parseU16BE_packU16BE_append hs1, parseU16BE_packU16BE_append hs2] at h4
  injection h4 with hp4
  rcases Prod.mk.inj hp4 with ⟨hsEq, r5⟩
  have h5 := congrArg parseU16BE r5
  rw [parseU16BE_packU16BE_append ht1, parseU16BE_packU16BE_append ht2] at h5
  injection h5 with hp5
  rcases Prod.mk.inj hp5 with ⟨htEq, r6⟩
  have hbCarEq : bCar1 = bCar2 := (byteArray_eq_iff_list bCar1 bCar2).mpr r6
  exact ⟨hctEq, hsigEq, hklEq, hsEq, htEq, hbCarEq⟩

/-- **`W-1C` Theorem 2: Snapshot Preimage Framing Injectivity (`0` Axioms)**. -/
theorem w1c_snapshot_preimage_injective
    {g1 g2 m1 m2 : Nat} {bSnap1 bSnap2 : ByteArray}
    (hg1 : g1 < 4294967296) (hg2 : g2 < 4294967296)
    (hm1 : m1 < 65536) (hm2 : m2 < 65536)
    (heq : mkSnapshotPreimageBytes g1 m1 bSnap1 = mkSnapshotPreimageBytes g2 m2 bSnap2) :
    g1 = g2 ∧ m1 = m2 ∧ bSnap1 = bSnap2 := by
  rw [byteArray_eq_iff_list] at heq
  unfold mkSnapshotPreimageBytes at heq
  rw [listOfBytes_bytesOfList, listOfBytes_bytesOfList] at heq
  simp only [List.append_assoc] at heq
  rcases list_append_cancel_left_eq_len rfl heq with ⟨_, r1⟩
  have h1 := congrArg parseU32BE r1
  rw [parseU32BE_packU32BE_append hg1, parseU32BE_packU32BE_append hg2] at h1
  injection h1 with hp1
  rcases Prod.mk.inj hp1 with ⟨hgEq, r2⟩
  have h2 := congrArg parseU16BE r2
  rw [parseU16BE_packU16BE_append hm1, parseU16BE_packU16BE_append hm2] at h2
  injection h2 with hp2
  rcases Prod.mk.inj hp2 with ⟨hmEq, r3⟩
  exact ⟨hgEq, hmEq, (byteArray_eq_iff_list bSnap1 bSnap2).mpr r3⟩

theorem take26_append_of_ge26 {p : List UInt8} (hle : 26 ≤ p.length) (rest : List UInt8) :
    List.take 26 (p ++ rest) = List.take 26 p := by
  rw [List.take_append_of_le_length hle]

/-- **`W-1C` Theorem 3: 4-Domain Prefix Non-Collision (`0` Axioms)**:
    No Snapshot preimage, Carrier preimage, Edges preimage, or Relation preimage can ever
    produce identical byte arrays. -/
theorem w1c_domain_prefixes_pairwise_disjoint
    (genV mask ct kl1 kl2 s t : Nat) (hSig bSnap bCar bEdg bRel : ByteArray) :
    mkSnapshotPreimageBytes genV mask bSnap ≠ mkCarrierPreimageBytes ct hSig kl1 s t bCar ∧
    mkSnapshotPreimageBytes genV mask bSnap ≠ mkEdgesPreimageBytes bEdg ∧
    mkSnapshotPreimageBytes genV mask bSnap ≠ mkRelPreimageBytes kl2 bRel ∧
    mkCarrierPreimageBytes ct hSig kl1 s t bCar ≠ mkEdgesPreimageBytes bEdg ∧
    mkCarrierPreimageBytes ct hSig kl1 s t bCar ≠ mkRelPreimageBytes kl2 bRel ∧
    mkEdgesPreimageBytes bEdg ≠ mkRelPreimageBytes kl2 bRel := by
  have hlSnap : 26 ≤ domainPrefixSnapshot31.length := by decide
  have hlCar : 26 ≤ domainPrefixCarrier30.length := by decide
  have hlEdg : 26 ≤ domainPrefixEdges28.length := by decide
  have hlRel : 26 ≤ domainPrefixRel26.length := by decide
  have hneSC : List.take 26 domainPrefixSnapshot31 ≠ List.take 26 domainPrefixCarrier30 := by decide
  have hneSE : List.take 26 domainPrefixSnapshot31 ≠ List.take 26 domainPrefixEdges28 := by decide
  have hneSR : List.take 26 domainPrefixSnapshot31 ≠ List.take 26 domainPrefixRel26 := by decide
  have hneCE : List.take 26 domainPrefixCarrier30 ≠ List.take 26 domainPrefixEdges28 := by decide
  have hneCR : List.take 26 domainPrefixCarrier30 ≠ List.take 26 domainPrefixRel26 := by decide
  have hneER : List.take 26 domainPrefixEdges28 ≠ List.take 26 domainPrefixRel26 := by decide
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkSnapshotPreimageBytes, mkCarrierPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlSnap, take26_append_of_ge26 hlCar] at hl
    exact hneSC hl
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkSnapshotPreimageBytes, mkEdgesPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlSnap, take26_append_of_ge26 hlEdg] at hl
    exact hneSE hl
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkSnapshotPreimageBytes, mkRelPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlSnap, take26_append_of_ge26 hlRel] at hl
    exact hneSR hl
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkCarrierPreimageBytes, mkEdgesPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlCar, take26_append_of_ge26 hlEdg] at hl
    exact hneCE hl
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkCarrierPreimageBytes, mkRelPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlCar, take26_append_of_ge26 hlRel] at hl
    exact hneCR hl
  · intro h
    have hl := congrArg (fun b => List.take 26 (listOfBytes b)) h
    simp only [mkEdgesPreimageBytes, mkRelPreimageBytes, listOfBytes_bytesOfList,
      List.append_assoc, take26_append_of_ge26 hlEdg, take26_append_of_ge26 hlRel] at hl
    exact hneER hl

/-- Pure lowercase hex bridge (`ByteArray` 32B ↔ `#43` `PinnedA1Entry.pinnedRootHex` 64-char `String`). -/
def nibbleToHexChar : Nat → Char
  | 0 => '0' | 1 => '1' | 2 => '2' | 3 => '3'
  | 4 => '4' | 5 => '5' | 6 => '6' | 7 => '7'
  | 8 => '8' | 9 => '9' | 10 => 'a' | 11 => 'b'
  | 12 => 'c' | 13 => 'd' | 14 => 'e' | _ => 'f'

def hexCharVal? : Char → Option Nat
  | '0' => some 0 | '1' => some 1 | '2' => some 2 | '3' => some 3
  | '4' => some 4 | '5' => some 5 | '6' => some 6 | '7' => some 7
  | '8' => some 8 | '9' => some 9 | 'a' => some 10 | 'b' => some 11
  | 'c' => some 12 | 'd' => some 13 | 'e' => some 14 | 'f' => some 15
  | _ => none

theorem hexCharVal?_nibble {n : Nat} (hlt : n < 16) :
    hexCharVal? (nibbleToHexChar n) = some n := by
  have h0 : n = 0 ∨ n = 1 ∨ n = 2 ∨ n = 3 ∨ n = 4 ∨ n = 5 ∨ n = 6 ∨ n = 7 ∨
            n = 8 ∨ n = 9 ∨ n = 10 ∨ n = 11 ∨ n = 12 ∨ n = 13 ∨ n = 14 ∨ n = 15 := by omega
  rcases h0 with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
                 rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

def byteToHexChars (b : UInt8) : List Char :=
  [nibbleToHexChar (b.toNat / 16), nibbleToHexChar (b.toNat % 16)]

def bytesToLowerHexChars : List UInt8 → List Char
  | [] => []
  | b :: rest => byteToHexChars b ++ bytesToLowerHexChars rest

def bytes32ToLowerHex (b : ByteArray) : String :=
  String.ofList (bytesToLowerHexChars (listOfBytes b))

theorem bytesToLowerHexChars_length (bs : List UInt8) :
    (bytesToLowerHexChars bs).length = 2 * bs.length := by
  induction bs with
  | nil => rfl
  | cons b rest ih =>
    simp [bytesToLowerHexChars, byteToHexChars, ih]
    omega

theorem bytesToLowerHexChars_injective {bs1 bs2 : List UInt8}
    (heq : bytesToLowerHexChars bs1 = bytesToLowerHexChars bs2) :
    bs1 = bs2 := by
  induction bs1 generalizing bs2 with
  | nil =>
    cases bs2 with
    | nil => rfl
    | cons _ _ => cases heq
  | cons b1 r1 ih =>
    cases bs2 with
    | nil => cases heq
    | cons b2 r2 =>
      simp only [bytesToLowerHexChars, byteToHexChars, List.cons_append, List.nil_append,
        List.cons.injEq] at heq
      rcases heq with ⟨hcHi, hcLo, hrEq⟩
      have h1Lt := uint8_toNat_lt_256 b1
      have h2Lt := uint8_toNat_lt_256 b2
      have hhi1 : b1.toNat / 16 < 16 := by omega
      have hhi2 : b2.toNat / 16 < 16 := by omega
      have hlo1 : b1.toNat % 16 < 16 := by omega
      have hlo2 : b2.toNat % 16 < 16 := by omega
      have vHi := congrArg hexCharVal? hcHi
      rw [hexCharVal?_nibble hhi1, hexCharVal?_nibble hhi2] at vHi
      injection vHi with eHi
      have vLo := congrArg hexCharVal? hcLo
      rw [hexCharVal?_nibble hlo1, hexCharVal?_nibble hlo2] at vLo
      injection vLo with eLo
      have hnatEq : b1.toNat = b2.toNat := by omega
      have hbEq : b1 = b2 := by
        rw [← uint8_ofNat_toNat_id b1, ← uint8_ofNat_toNat_id b2, hnatEq]
      have hr := ih hrEq
      rw [hbEq, hr]

theorem w1c_bytes32ToLowerHex_spec {b1 b2 : ByteArray} (hs1 : b1.size = 32) :
    (bytes32ToLowerHex b1).length = 64 ∧
    (bytes32ToLowerHex b1 = bytes32ToLowerHex b2 → b1 = b2) := by
  rw [byteArray_size_eq_length] at hs1
  refine ⟨?_, ?_⟩
  · unfold bytes32ToLowerHex
    rw [String.length_ofList, bytesToLowerHexChars_length, hs1]
  · intro hstr
    have hchars : bytesToLowerHexChars (listOfBytes b1) = bytesToLowerHexChars (listOfBytes b2) := by
      have ht := congrArg String.toList hstr
      unfold bytes32ToLowerHex at ht
      rw [String.toList_ofList, String.toList_ofList] at ht
      exact ht
    exact (byteArray_eq_iff_list b1 b2).mpr (bytesToLowerHexChars_injective hchars)

/-! ## `F91-02` Honesty Theorems: Finite-Codomain Non-Injectivity & External `SHA-256` Binding -/

/-- Scoped local non-collision condition on a specific pair `(p1, p2)` (`91st Ruling §3`). -/
def NoCollisionOn (H : ByteArray → ByteArray) (p1 p2 : ByteArray) : Prop :=
  H p1 = H p2 → p1 = p2

def allByteLists : Nat → List (List UInt8)
  | 0 => [[]]
  | k + 1 =>
      (rangeBelow 256).flatMap (fun n =>
        (allByteLists k).map (fun tl => UInt8.ofNat n :: tl))

theorem mem_allByteLists {k : Nat} {bs : List UInt8} (hlen : bs.length = k) :
    bs ∈ allByteLists k := by
  induction k generalizing bs with
  | zero =>
    cases bs with
    | nil => exact List.Mem.head []
    | cons _ _ => cases hlen
  | succ m ih =>
    cases bs with
    | nil => cases hlen
    | cons b tl =>
      simp only [List.length_cons, Nat.succ.injEq] at hlen
      simp only [allByteLists, List.mem_flatMap, mem_rangeBelow_iff, List.mem_map]
      refine ⟨b.toNat, uint8_toNat_lt_256 b, tl, ih hlen, ?_⟩
      rw [uint8_ofNat_toNat_id]

theorem pigeonhole_nat_into_list {α : Type} (univ : List α) :
    ∀ (g : Nat → α), (∀ n, g n ∈ univ) → ∃ i j, i < j ∧ g i = g j := by
  induction univ with
  | nil =>
    intro g hmem
    cases hmem 0
  | cons a rest ih =>
    intro g hmem
    by_cases hex : ∃ i, g i = a
    · rcases hex with ⟨i0, hi0⟩
      by_cases hex2 : ∃ j, i0 < j ∧ g j = a
      · rcases hex2 with ⟨j0, hjLt, hj0⟩
        exact ⟨i0, j0, hjLt, hi0.trans hj0.symm⟩
      · let gShift : Nat → α := fun n => g (i0 + 1 + n)
        have hmemRest : ∀ n, gShift n ∈ rest := by
          intro n
          have hm := hmem (i0 + 1 + n)
          cases hm with
          | head =>
            exfalso
            exact hex2 ⟨i0 + 1 + n, by omega, rfl⟩
          | tail _ hmr => exact hmr
        rcases ih gShift hmemRest with ⟨m1, m2, hmLt, heqShift⟩
        exact ⟨i0 + 1 + m1, i0 + 1 + m2, by omega, heqShift⟩
    · have hmemRest : ∀ n, g n ∈ rest := by
        intro n
        cases hmem n with
        | head => exfalso; exact hex ⟨n, rfl⟩
        | tail _ hmr => exact hmr
      exact ih g hmemRest

theorem f91_02_no_fixed_size_hash_globally_injective
    (k : Nat) (H : ByteArray → ByteArray)
    (hSize : ∀ b, (H b).size = k) :
    ∃ b1 b2 : ByteArray, b1 ≠ b2 ∧ H b1 = H b2 := by
  let seq : Nat → ByteArray := fun n => bytesOfList (List.replicate n 0)
  let g : Nat → List UInt8 := fun n => listOfBytes (H (seq n))
  have hgMem : ∀ n, g n ∈ allByteLists k := by
    intro n
    apply mem_allByteLists
    rw [← byteArray_size_eq_length]
    exact hSize (seq n)
  rcases pigeonhole_nat_into_list (allByteLists k) g hgMem with ⟨i, j, hij, hgEq⟩
  refine ⟨seq i, seq j, ?_, (byteArray_eq_iff_list _ _).mpr hgEq⟩
  intro hseqEq
  have hlenEq := congrArg ByteArray.size hseqEq
  simp only [seq, byteArray_size_eq_length, listOfBytes_bytesOfList, List.length_replicate] at hlenEq
  omega

/-- **`F91-02` Pigeonhole Non-Injectivity Theorem (`91st Ruling §3`)**:
    NO 32-byte digest function `H : ByteArray → ByteArray` can be globally injective across
    all `ByteArray`s, proving inside Lean why `NoCollisionOn H p1 p2` MUST remain a scoped
    local hypothesis rather than an inconsistent global injectivity axiom. -/
theorem f91_02_no_32byte_hash_globally_injective
    (H : ByteArray → ByteArray)
    (hSize : ∀ b, (H b).size = 32) :
    ∃ b1 b2 : ByteArray, b1 ≠ b2 ∧ H b1 = H b2 :=
  f91_02_no_fixed_size_hash_globally_injective 32 H hSize

/-- Executable `DigestVerified` parameterized by external `hash256 : ByteArray → ByteArray`. -/
def checkDigestVerifiedBool (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry) (genV : Nat)
    (bSnap bCar : ByteArray) (bh : RawCarrierBindHeader)
    (cRaw : RawCarrierPayload) (T : SourceCertTerm) (vTotal : Nat) : Bool :=
  wfRawBindHeaderBool bh &&
  decide (bh.hSigma32 = hash256 (mkSnapshotPreimageBytes genV constitutionalMask0xFF33 bSnap)) &&
  decide (bytes32ToLowerHex bh.hSigma32 = ent.pinnedRootHex) &&
  decide (encodeCarrierPayload vTotal cRaw = some bCar) &&
  decide (bh.hCarrier32 = hash256
    (mkCarrierPreimageBytes bh.carrierTag bh.hSigma32 bh.closureTag bh.queryS bh.queryT bCar)) &&
  decide (bh.closureTag = T.closureTag) &&
  decide (bh.carrierTag = T.carrierTag) &&
  decide (bh.carrierTag = cRaw.carrierTag)

def DigestVerified (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry) (genV : Nat)
    (bSnap bCar : ByteArray) (bh : RawCarrierBindHeader)
    (cRaw : RawCarrierPayload) (T : SourceCertTerm) (vTotal : Nat) : Prop :=
  checkDigestVerifiedBool hash256 ent genV bSnap bCar bh cRaw T vTotal = true

/-- **`F91-02` External Hash-Identity Boundary Theorem (`91st Ruling §3.1`)**:
    Abstract `DigestVerified H` is satisfiable even for a trivial constant zero oracle
    `constZeroHash32` on a matching synthetic registry entry, formally demonstrating that
    proving `WireSoundness_H` in Lean does NOT establish `H = SHA256_implemented`; binding
    `H` to FIPS 180-4 `SHA-256` is an explicit external execution obligation. -/
def constZeroHash32 (_ : ByteArray) : ByteArray :=
  bytesOfList (List.replicate 32 0)

theorem f91_02_abstract_digest_does_not_force_sha256_identity :
    ∃ (ent : PinnedA1Entry) (bSnap bCar : ByteArray)
      (bh : RawCarrierBindHeader) (cRaw : RawCarrierPayload) (T : SourceCertTerm),
      (∀ x y, constZeroHash32 x = constZeroHash32 y) ∧
      checkDigestVerifiedBool constZeroHash32 ent 1 bSnap bCar bh cRaw T 2 = true := by
  let z32 := bytesOfList (List.replicate 32 0)
  let ent0 : PinnedA1Entry :=
    { snapshotId := "SYNTH-ZERO"
      pinnedGen := 1
      pinnedRootHex := bytes32ToLowerHex z32
      pinnedConstIds := [] }
  let cRaw0 : RawCarrierPayload := .localPaths [[0]]
  let bCar0 : ByteArray := bytesOfList (encodeCarrierPayloadList cRaw0)
  let bh0 : RawCarrierBindHeader :=
    { hSigma32 := z32
      hCarrier32 := z32
      closureTag := 1
      carrierTag := 1
      queryS := 0
      queryT := 0 }
  let T0 : SourceCertTerm :=
    { closureTag := 1
      carrierTag := 1
      modeTag := 1
      evasionModeTag := 0
      claimedL := 0
      claimedU := 0
      unbreakableRefKind := 1
      unbreakableLocalIdx := 0
      unbreakableWalk := []
      primalWitnesses := []
      retractionIrIndices := []
      dualCutVids := [] }
  refine ⟨ent0, bytesOfList [], bCar0, bh0, cRaw0, T0, fun _ _ => rfl, ?_⟩
  unfold checkDigestVerifiedBool
  have h1 : wfRawBindHeaderBool bh0 = true := rfl
  have h2 : decide (bh0.hSigma32 = constZeroHash32 (mkSnapshotPreimageBytes 1 constitutionalMask0xFF33 (bytesOfList []))) = true := rfl
  have h3 : decide (bytes32ToLowerHex bh0.hSigma32 = ent0.pinnedRootHex) = decide (ent0.pinnedRootHex = ent0.pinnedRootHex) := rfl
  have h4 : decide (encodeCarrierPayload 2 cRaw0 = some bCar0) = true := rfl
  have h5 : decide (bh0.hCarrier32 = constZeroHash32
    (mkCarrierPreimageBytes bh0.carrierTag bh0.hSigma32 bh0.closureTag bh0.queryS bh0.queryT bCar0)) = true := rfl
  rw [h1, h2, h3, decide_eq_true rfl, h4, h5]
  rfl

/-! ## `W-1D` & `F91-03`: Asymmetric `0x00` Claim Slice Bijection (`Local` vs `Global`/`Geodesic`) -/

def wfStepWitnessWireBool (sw : SourceStepWitness) : Bool :=
  decide (sw.stepTag < 256) && decide (sw.irIdx < 65536)

def encodeStepWitnessList (sw : SourceStepWitness) : List UInt8 :=
  packU8 sw.stepTag ++ packU16BE sw.irIdx

def parseStepWitness (bs : List UInt8) : Option (SourceStepWitness × List UInt8) :=
  match parseU8 bs with
  | none => none
  | some (stag, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (iidx, bs2) =>
        some ({ stepTag := stag, irIdx := iidx }, bs2)

theorem parseStepWitness_encode_append {sw : SourceStepWitness}
    (hwf : wfStepWitnessWireBool sw = true) (rest : List UInt8) :
    parseStepWitness (encodeStepWitnessList sw ++ rest) = some (sw, rest) := by
  unfold wfStepWitnessWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  unfold encodeStepWitnessList parseStepWitness
  rw [List.append_assoc, parseU8_packU8_append hwf.1]
  dsimp only
  rw [parseU16BE_packU16BE_append hwf.2]

theorem parseStepWitness_eq_some {bs rest : List UInt8} {sw : SourceStepWitness}
    (h : parseStepWitness bs = some (sw, rest)) :
    wfStepWitnessWireBool sw = true ∧ bs = encodeStepWitnessList sw ++ rest := by
  unfold parseStepWitness at h
  cases h1 : parseU8 bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨stag, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨iidx, bs2⟩
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      rcases h with ⟨hsw, hrest⟩
      subst hsw; subst hrest
      rcases parseU8_eq_some h1 with ⟨hsLt, e1⟩
      rcases parseU16BE_eq_some h2 with ⟨hiLt, e2⟩
      refine ⟨?_, ?_⟩
      · unfold wfStepWitnessWireBool; simp [hsLt, hiLt]
      · rw [e1, e2]; simp [encodeStepWitnessList, List.append_assoc]

/-- Exact `#40` tuple ordering on `step_witnesses` (`omega_kappa_pure_checker.py` L973–978). -/
def lexLtStepListBool : List SourceStepWitness → List SourceStepWitness → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: as, b :: bs =>
      if a.stepTag < b.stepTag then true
      else if b.stepTag < a.stepTag then false
      else if a.irIdx < b.irIdx then true
      else if b.irIdx < a.irIdx then false
      else lexLtStepListBool as bs

def primalWitnessLtBool (pw1 pw2 : SourcePrimalWitness) : Bool :=
  let k1 := if pw1.refKind = 1 then pw1.jIdx else 0
  let k2 := if pw2.refKind = 1 then pw2.jIdx else 0
  if k1 < k2 then true
  else if k2 < k1 then false
  else if lexLtNatListBool pw1.walkVertices pw2.walkVertices then true
  else if lexLtNatListBool pw2.walkVertices pw1.walkVertices then false
  else lexLtStepListBool pw1.stepWitnesses pw2.stepWitnesses

def strictLexPrimalWitnessesBool (pws : List SourcePrimalWitness) : Bool :=
  strictSortedByBool primalWitnessLtBool pws

/-- `Local` primal witness wire entry (`u16be(jIdx) ++ u16be(stepDecl) ++ stepDecl × >BH`). -/
def wfLocalPrimalWireBool (vTotal : Nat) (pw : SourcePrimalWitness) : Bool :=
  decide (pw.refKind = 1) &&
  decide (pw.jIdx < 65536) &&
  decide (pw.walkVertices = []) &&
  decide (pw.stepWitnesses.length ≤ vTotal) &&
  decide (pw.stepWitnesses.length < 65536) &&
  listAllBool wfStepWitnessWireBool pw.stepWitnesses

def encodeLocalPrimalList (pw : SourcePrimalWitness) : List UInt8 :=
  packU16BE pw.jIdx ++
  packU16BE pw.stepWitnesses.length ++
  encodeRepeat encodeStepWitnessList pw.stepWitnesses

def parseLocalPrimal (vTotal : Nat) (bs : List UInt8) : Option (SourcePrimalWitness × List UInt8) :=
  match parseU16BE bs with
  | none => none
  | some (jIdx, bs1) =>
    match parseU16BE bs1 with
    | none => none
    | some (stepDecl, bs2) =>
        if decide (stepDecl ≤ vTotal) then
          match parseRepeat parseStepWitness stepDecl bs2 with
          | none => none
          | some (sws, bs3) =>
              some ({ refKind := 1
                      jIdx := jIdx
                      walkVertices := []
                      stepWitnesses := sws }, bs3)
        else none

theorem parseLocalPrimal_encode_append (vTotal : Nat) {pw : SourcePrimalWitness}
    (hwf : wfLocalPrimalWireBool vTotal pw = true) (rest : List UInt8) :
    parseLocalPrimal vTotal (encodeLocalPrimalList pw ++ rest) = some (pw, rest) := by
  unfold wfLocalPrimalWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨⟨href1, hjLt⟩, hwNil⟩, hsLe⟩, hsLt⟩, hallSw⟩
  unfold encodeLocalPrimalList parseLocalPrimal
  simp only [List.append_assoc]
  rw [parseU16BE_packU16BE_append hjLt]
  dsimp only
  rw [parseU16BE_packU16BE_append hsLt]
  dsimp only
  rw [if_pos (decide_eq_true hsLe)]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseStepWitness_encode_append hw r) hallSw rest]
  cases pw with
  | mk rk j wv sws =>
    dsimp only at href1 hwNil
    subst href1; subst hwNil
    rfl

theorem parseLocalPrimal_eq_some (vTotal : Nat) {bs rest : List UInt8} {pw : SourcePrimalWitness}
    (h : parseLocalPrimal vTotal bs = some (pw, rest)) :
    wfLocalPrimalWireBool vTotal pw = true ∧ bs = encodeLocalPrimalList pw ++ rest := by
  unfold parseLocalPrimal at h
  cases h1 : parseU16BE bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨jIdx, bs1⟩; dsimp only at h
    cases h2 : parseU16BE bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨stepDecl, bs2⟩; dsimp only at h
      split at h
      · next hsLeB =>
        have hsLe : stepDecl ≤ vTotal := of_decide_eq_true hsLeB
        cases h3 : parseRepeat parseStepWitness stepDecl bs2 with
        | none => rw [h3] at h; cases h
        | some p3 =>
          rw [h3] at h; rcases p3 with ⟨sws, bs3⟩
          simp only [Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨hpw, hrest⟩
          subst hpw; subst hrest
          rcases parseU16BE_eq_some h1 with ⟨hjLt, e1⟩
          rcases parseU16BE_eq_some h2 with ⟨hsLt, e2⟩
          rcases parseRepeat_eq_some (fun _ _ _ hp => parseStepWitness_eq_some hp) h3 with
            ⟨hlenSw, hallSw, e3⟩
          refine ⟨?_, ?_⟩
          · unfold wfLocalPrimalWireBool
            rw [hlenSw]
            simp [hjLt, hsLe, hsLt, hallSw]
          · rw [e1, e2, e3]
            simp [encodeLocalPrimalList, hlenSw, List.append_assoc]
      · cases h

/-- Explicit-walk (`Global`/`Geodesic`) primal witness wire entry
    (`encodeWalkList(w_seq) ++ (|w_seq| - 1) × >BH`). -/
def wfExplicitPrimalWireBool (vTotal : Nat) (pw : SourcePrimalWitness) : Bool :=
  decide (pw.refKind = 2) &&
  decide (pw.jIdx = 0) &&
  wfWalkWireBool vTotal pw.walkVertices &&
  decide (pw.stepWitnesses.length = pw.walkVertices.length - 1) &&
  listAllBool wfStepWitnessWireBool pw.stepWitnesses

def encodeExplicitPrimalList (pw : SourcePrimalWitness) : List UInt8 :=
  encodeWalkList pw.walkVertices ++ encodeRepeat encodeStepWitnessList pw.stepWitnesses

def parseExplicitPrimal (vTotal : Nat) (bs : List UInt8) : Option (SourcePrimalWitness × List UInt8) :=
  match parseWalk vTotal bs with
  | none => none
  | some (wSeq, bs1) =>
    match parseRepeat parseStepWitness (wSeq.length - 1) bs1 with
    | none => none
    | some (sws, bs2) =>
        some ({ refKind := 2
                jIdx := 0
                walkVertices := wSeq
                stepWitnesses := sws }, bs2)

theorem parseExplicitPrimal_encode_append (vTotal : Nat) {pw : SourcePrimalWitness}
    (hwf : wfExplicitPrimalWireBool vTotal pw = true) (rest : List UInt8) :
    parseExplicitPrimal vTotal (encodeExplicitPrimalList pw ++ rest) = some (pw, rest) := by
  unfold wfExplicitPrimalWireBool at hwf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwf
  rcases hwf with ⟨⟨⟨⟨href2, hj0⟩, hwfW⟩, hlenSw⟩, hallSw⟩
  unfold encodeExplicitPrimalList parseExplicitPrimal
  rw [List.append_assoc, parseWalk_encode_append vTotal hwfW]
  dsimp only
  rw [← hlenSw]
  rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseStepWitness_encode_append hw r) hallSw rest]
  cases pw with
  | mk rk j wv sws =>
    dsimp only at href2 hj0
    subst href2; subst hj0
    rfl

theorem parseExplicitPrimal_eq_some (vTotal : Nat) {bs rest : List UInt8} {pw : SourcePrimalWitness}
    (h : parseExplicitPrimal vTotal bs = some (pw, rest)) :
    wfExplicitPrimalWireBool vTotal pw = true ∧ bs = encodeExplicitPrimalList pw ++ rest := by
  unfold parseExplicitPrimal at h
  cases h1 : parseWalk vTotal bs with
  | none => rw [h1] at h; cases h
  | some p1 =>
    rw [h1] at h; rcases p1 with ⟨wSeq, bs1⟩; dsimp only at h
    cases h2 : parseRepeat parseStepWitness (wSeq.length - 1) bs1 with
    | none => rw [h2] at h; cases h
    | some p2 =>
      rw [h2] at h; rcases p2 with ⟨sws, bs2⟩
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      rcases h with ⟨hpw, hrest⟩
      subst hpw; subst hrest
      rcases parseWalk_eq_some vTotal h1 with ⟨hwfW, e1⟩
      rcases parseRepeat_eq_some (fun _ _ _ hp => parseStepWitness_eq_some hp) h2 with
        ⟨hlenSw, hallSw, e2⟩
      refine ⟨?_, ?_⟩
      · unfold wfExplicitPrimalWireBool
        simp [hwfW, hlenSw, hallSw]
      · rw [e1, e2]
        simp [encodeExplicitPrimalList, List.append_assoc]

/-- Exact canonical domain predicate `checkCanonicalClaim0x00` (`F91-03`):
    Captures the exact asymmetric `#40` wire normal forms for `Local` (`carrierTag = 1`) vs
    `Geodesic`/`Global` (`carrierTag ∈ {2, 3}`) in the `evasionModeTag = 0x00` track. -/
def checkCanonicalClaimPairBool (vTotal irTotal : Nat) (pair : RawCarrierBindHeader × SourceCertTerm) : Bool :=
  let bh := pair.1
  let T := pair.2
  checkBindHeaderSemanticWF vTotal bh &&
  decide (bh.closureTag = T.closureTag) &&
  decide (bh.carrierTag = T.carrierTag) &&
  decide (T.evasionModeTag = 0) &&
  if T.carrierTag = 1 then
    if T.modeTag = 1 then
      decide (T.unbreakableRefKind = 1) &&
      decide (T.unbreakableLocalIdx < 65536) &&
      decide (T.unbreakableWalk = []) &&
      decide (T.claimedL = 0) &&
      decide (T.claimedU = 0) &&
      decide (T.primalWitnesses = []) &&
      decide (T.retractionIrIndices = []) &&
      decide (T.dualCutVids = [])
    else if T.modeTag = 2 then
      decide (T.unbreakableRefKind = 1) &&
      decide (T.unbreakableLocalIdx = 0) &&
      decide (T.unbreakableWalk = []) &&
      decide (1 ≤ T.claimedL) &&
      decide (T.claimedL ≤ T.claimedU) &&
      decide (T.claimedL ≤ irTotal) &&
      decide (T.claimedU ≤ irTotal) &&
      decide (T.claimedL < 65536) &&
      decide (T.claimedU < 65536) &&
      decide (T.primalWitnesses.length = T.claimedL) &&
      listAllBool (wfLocalPrimalWireBool vTotal) T.primalWitnesses &&
      strictLexPrimalWitnessesBool T.primalWitnesses &&
      decide (T.retractionIrIndices.length = T.claimedU) &&
      listAllBool (fun d => decide (d < 65536)) T.retractionIrIndices &&
      strictIncNatBool T.retractionIrIndices &&
      decide (T.dualCutVids = [])
    else false
  else if T.carrierTag = 2 ∨ T.carrierTag = 3 then
    if T.modeTag = 1 then
      decide (T.unbreakableRefKind = 2) &&
      decide (T.unbreakableLocalIdx = 0) &&
      wfWalkWireBool vTotal T.unbreakableWalk &&
      decide (T.claimedL = 0) &&
      decide (T.claimedU = 0) &&
      decide (T.primalWitnesses = []) &&
      decide (T.retractionIrIndices = []) &&
      decide (T.dualCutVids = [])
    else if T.modeTag = 2 then
      decide (T.unbreakableRefKind = 2) &&
      decide (T.unbreakableLocalIdx = 0) &&
      decide (T.unbreakableWalk = []) &&
      decide (1 ≤ T.claimedL) &&
      decide (T.claimedL ≤ T.claimedU) &&
      decide (T.claimedL ≤ irTotal) &&
      decide (T.claimedU ≤ irTotal) &&
      decide (T.claimedL < 65536) &&
      decide (T.claimedU < 65536) &&
      decide (T.primalWitnesses.length = T.claimedL) &&
      listAllBool (wfExplicitPrimalWireBool vTotal) T.primalWitnesses &&
      strictLexPrimalWitnessesBool T.primalWitnesses &&
      decide (T.retractionIrIndices.length = T.claimedU) &&
      listAllBool (fun d => decide (d < 65536)) T.retractionIrIndices &&
      strictIncNatBool T.retractionIrIndices &&
      decide (T.dualCutVids.length ≤ vTotal) &&
      decide (T.dualCutVids.length < 65536) &&
      listAllBool (wfVertexWireBool vTotal) T.dualCutVids &&
      strictIncNatBool T.dualCutVids
    else false
  else false

def CanonicalClaim0x00 (vTotal irTotal : Nat) (bh : RawCarrierBindHeader) (T : SourceCertTerm) : Prop :=
  checkCanonicalClaimPairBool vTotal irTotal (bh, T) = true

/-- Asymmetric `#40` wire serializer for `(bh, T)` (`Local` emits trailing `0x00` `evasion_mode`
    byte and omits `dualCutVids`; `Global`/`Geodesic` emit `u16be(cut_len) ++ cut` and have NO
    `evasion_mode` byte on the wire). -/
def encodeClaimPair0x00List (pair : RawCarrierBindHeader × SourceCertTerm) : List UInt8 :=
  let bh := pair.1
  let T := pair.2
  if T.carrierTag = 1 then
    if T.modeTag = 1 then
      encodeBindHeaderList bh ++ packU8 1 ++ packU16BE T.unbreakableLocalIdx
    else
      encodeBindHeaderList bh ++
      packU8 2 ++
      packU16BE T.claimedL ++
      packU16BE T.claimedU ++
      encodeRepeat encodeLocalPrimalList T.primalWitnesses ++
      encodeRepeat packU16BE T.retractionIrIndices ++
      packU8 0
  else
    if T.modeTag = 1 then
      encodeBindHeaderList bh ++ packU8 1 ++ encodeWalkList T.unbreakableWalk
    else
      encodeBindHeaderList bh ++
      packU8 2 ++
      packU16BE T.claimedL ++
      packU16BE T.claimedU ++
      encodeRepeat encodeExplicitPrimalList T.primalWitnesses ++
      encodeRepeat packU16BE T.retractionIrIndices ++
      packU16BE T.dualCutVids.length ++
      encodeRepeat packU16BE T.dualCutVids

def parseClaimPair0x00 (vTotal irTotal : Nat) (bs : List UInt8) :
    Option ((RawCarrierBindHeader × SourceCertTerm) × List UInt8) :=
  match parseBindHeader bs with
  | none => none
  | some (bh, bs1) =>
    if checkBindHeaderSemanticWF vTotal bh then
      match parseU8 bs1 with
      | none => none
      | some (mTag, bs2) =>
        if bh.carrierTag = 1 then
          if mTag = 1 then
            match parseU16BE bs2 with
            | none => none
            | some (jUnb, bs3) =>
                let T : SourceCertTerm :=
                  { closureTag := bh.closureTag
                    carrierTag := 1
                    modeTag := 1
                    evasionModeTag := 0
                    claimedL := 0
                    claimedU := 0
                    unbreakableRefKind := 1
                    unbreakableLocalIdx := jUnb
                    unbreakableWalk := []
                    primalWitnesses := []
                    retractionIrIndices := []
                    dualCutVids := [] }
                if checkCanonicalClaimPairBool vTotal irTotal (bh, T) then
                  some ((bh, T), bs3)
                else none
          else if mTag = 2 then
            match parseU16BE bs2 with
            | none => none
            | some (cL, bs3) =>
              match parseU16BE bs3 with
              | none => none
              | some (cU, bs4) =>
                match parseRepeat (parseLocalPrimal vTotal) cL bs4 with
                | none => none
                | some (pws, bs5) =>
                  match parseRepeat parseU16BE cU bs5 with
                  | none => none
                  | some (hits, bs6) =>
                    match parseU8 bs6 with
                    | none => none
                    | some (evMode, bs7) =>
                        if evMode = 0 then
                          let T : SourceCertTerm :=
                            { closureTag := bh.closureTag
                              carrierTag := 1
                              modeTag := 2
                              evasionModeTag := 0
                              claimedL := cL
                              claimedU := cU
                              unbreakableRefKind := 1
                              unbreakableLocalIdx := 0
                              unbreakableWalk := []
                              primalWitnesses := pws
                              retractionIrIndices := hits
                              dualCutVids := [] }
                          if checkCanonicalClaimPairBool vTotal irTotal (bh, T) then
                            some ((bh, T), bs7)
                          else none
                        else none
          else none
        else if bh.carrierTag = 2 ∨ bh.carrierTag = 3 then
          if mTag = 1 then
            match parseWalk vTotal bs2 with
            | none => none
            | some (unbW, bs3) =>
                let T : SourceCertTerm :=
                  { closureTag := bh.closureTag
                    carrierTag := bh.carrierTag
                    modeTag := 1
                    evasionModeTag := 0
                    claimedL := 0
                    claimedU := 0
                    unbreakableRefKind := 2
                    unbreakableLocalIdx := 0
                    unbreakableWalk := unbW
                    primalWitnesses := []
                    retractionIrIndices := []
                    dualCutVids := [] }
                if checkCanonicalClaimPairBool vTotal irTotal (bh, T) then
                  some ((bh, T), bs3)
                else none
          else if mTag = 2 then
            match parseU16BE bs2 with
            | none => none
            | some (cL, bs3) =>
              match parseU16BE bs3 with
              | none => none
              | some (cU, bs4) =>
                match parseRepeat (parseExplicitPrimal vTotal) cL bs4 with
                | none => none
                | some (pws, bs5) =>
                  match parseRepeat parseU16BE cU bs5 with
                  | none => none
                  | some (dStar, bs6) =>
                    match parseU16BE bs6 with
                    | none => none
                    | some (cutLen, bs7) =>
                      match parseRepeat parseU16BE cutLen bs7 with
                      | none => none
                      | some (cutVids, bs8) =>
                          let T : SourceCertTerm :=
                            { closureTag := bh.closureTag
                              carrierTag := bh.carrierTag
                              modeTag := 2
                              evasionModeTag := 0
                              claimedL := cL
                              claimedU := cU
                              unbreakableRefKind := 2
                              unbreakableLocalIdx := 0
                              unbreakableWalk := []
                              primalWitnesses := pws
                              retractionIrIndices := dStar
                              dualCutVids := cutVids }
                          if checkCanonicalClaimPairBool vTotal irTotal (bh, T) then
                            some ((bh, T), bs8)
                          else none
          else none
        else none
    else none

def encodeClaimSlice0x00 (vTotal irTotal : Nat) (bh : RawCarrierBindHeader)
    (T : SourceCertTerm) : Option ByteArray :=
  encodeGuardedSlice (checkCanonicalClaimPairBool vTotal irTotal) encodeClaimPair0x00List (bh, T)

def decodeClaimSlice0x00 (vTotal irTotal : Nat) (raw : ByteArray) :
    Option (RawCarrierBindHeader × SourceCertTerm) :=
  decodeExactSlice (parseClaimPair0x00 vTotal irTotal) raw

theorem parseClaimPair0x00_encode_append (vTotal irTotal : Nat)
    {pair : RawCarrierBindHeader × SourceCertTerm}
    (hcan : checkCanonicalClaimPairBool vTotal irTotal pair = true) (rest : List UInt8) :
    parseClaimPair0x00 vTotal irTotal (encodeClaimPair0x00List pair ++ rest) = some (pair, rest) := by
  rcases pair with ⟨bh, T⟩
  have hcanCopy := hcan
  unfold checkCanonicalClaimPairBool at hcan
  rcases (Bool.and_eq_true _ _).mp hcan with ⟨hHdr4, hBranch⟩
  rcases (Bool.and_eq_true _ _).mp hHdr4 with ⟨hHdr3, hevB⟩
  rcases (Bool.and_eq_true _ _).mp hHdr3 with ⟨hHdr2, hctEqB⟩
  rcases (Bool.and_eq_true _ _).mp hHdr2 with ⟨hsemHdr, hklEqB⟩
  have hklEq : bh.closureTag = T.closureTag := of_decide_eq_true hklEqB
  have hctEq : bh.carrierTag = T.carrierTag := of_decide_eq_true hctEqB
  have hev0 : T.evasionModeTag = 0 := of_decide_eq_true hevB
  have hwfHdr : wfRawBindHeaderBool bh = true := by
    unfold checkBindHeaderSemanticWF at hsemHdr
    simp only [Bool.and_eq_true] at hsemHdr
    exact hsemHdr.1.1.1.1.1.1
  dsimp only at hBranch
  split at hBranch
  · next hct1 =>
    have hbhCt1 : bh.carrierTag = 1 := hctEq.trans hct1
    split at hBranch
    · next hm1 =>
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hBranch
      rcases hBranch with ⟨⟨⟨⟨⟨⟨⟨href1, hjLt⟩, hwNil⟩, hL0⟩, hU0⟩, hpNil⟩, hrNil⟩, hdNil⟩
      unfold encodeClaimPair0x00List parseClaimPair0x00
      simp only [hct1, hm1, ite_true, List.append_assoc]
      rw [parseBindHeader_encode_append hwfHdr]
      dsimp only
      rw [if_pos hsemHdr]
      rw [parseU8_packU8_append (by decide : 1 < 256)]
      dsimp only
      rw [if_pos hbhCt1, if_pos rfl]
      rw [parseU16BE_packU16BE_append hjLt]
      dsimp only
      cases T
      dsimp only at hklEq hct1 hm1 hev0 href1 hjLt hwNil hL0 hU0 hpNil hrNil hdNil
      subst hct1; subst hm1; subst hev0; subst href1; subst hwNil; subst hL0; subst hU0
      subst hpNil; subst hrNil; subst hdNil; subst hklEq
      rw [if_pos hcanCopy]
    · next hneM1 =>
      split at hBranch
      · next hm2 =>
        simp only [Bool.and_eq_true, decide_eq_true_eq] at hBranch
        rcases hBranch with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨href1, hj0⟩, hwNil⟩, _⟩, _⟩, _⟩, _⟩, hL64⟩, hU64⟩,
          hlenP⟩, hallPw⟩, _⟩, hlenR⟩, hallR64⟩, _⟩, hdNil⟩
        unfold encodeClaimPair0x00List parseClaimPair0x00
        simp only [hct1, hneM1, ite_false, ite_true, List.append_assoc]
        rw [parseBindHeader_encode_append hwfHdr]
        dsimp only
        rw [if_pos hsemHdr]
        rw [parseU8_packU8_append (by decide : 2 < 256)]
        dsimp only
        rw [if_pos hbhCt1, if_neg (by decide : (2 : Nat) ≠ 1), if_pos rfl]
        rw [parseU16BE_packU16BE_append hL64]
        dsimp only
        rw [parseU16BE_packU16BE_append hU64]
        dsimp only
        rw [← hlenP]
        rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseLocalPrimal_encode_append vTotal hw r) hallPw]
        dsimp only
        rw [← hlenR]
        rw [parseRepeat_encodeRepeat_append
              (wfItem := fun d => decide (d < 65536))
              (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r) hallR64]
        dsimp only
        rw [parseU8_packU8_append (by decide : 0 < 256)]
        dsimp only
        rw [if_pos rfl]
        cases T
        dsimp only at hklEq hct1 hm2 hev0 href1 hj0 hwNil hlenP hlenR hdNil
        subst hct1; subst hm2; subst hev0; subst href1; subst hj0; subst hwNil; subst hdNil
        subst hlenP; subst hlenR; subst hklEq
        rw [if_pos hcanCopy]
      · cases hBranch
  · next hneCt1 =>
    split at hBranch
    · next hct23 =>
      have hbhNe1 : bh.carrierTag ≠ 1 := by rw [hctEq]; exact hneCt1
      have hbhCt23 : bh.carrierTag = 2 ∨ bh.carrierTag = 3 := by rw [hctEq]; exact hct23
      split at hBranch
      · next hm1 =>
        simp only [Bool.and_eq_true, decide_eq_true_eq] at hBranch
        rcases hBranch with ⟨⟨⟨⟨⟨⟨⟨href2, hj0⟩, hwfW⟩, hL0⟩, hU0⟩, hpNil⟩, hrNil⟩, hdNil⟩
        unfold encodeClaimPair0x00List parseClaimPair0x00
        simp only [hneCt1, hm1, ite_false, ite_true, List.append_assoc]
        rw [parseBindHeader_encode_append hwfHdr]
        dsimp only
        rw [if_pos hsemHdr]
        rw [parseU8_packU8_append (by decide : 1 < 256)]
        dsimp only
        rw [if_neg hbhNe1, if_pos hbhCt23, if_pos rfl]
        rw [parseWalk_encode_append vTotal hwfW]
        dsimp only
        cases T
        dsimp only at hklEq hctEq hm1 hev0 href2 hj0 hL0 hU0 hpNil hrNil hdNil
        subst hm1; subst hev0; subst href2; subst hj0; subst hL0; subst hU0
        subst hpNil; subst hrNil; subst hdNil; subst hklEq; subst hctEq
        rw [if_pos hcanCopy]
      · next hneM1 =>
        split at hBranch
        · next hm2 =>
          simp only [Bool.and_eq_true, decide_eq_true_eq] at hBranch
          rcases hBranch with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨href2, hj0⟩, hwNil⟩, _⟩, _⟩, _⟩, _⟩, hL64⟩, hU64⟩,
            hlenP⟩, hallPw⟩, _⟩, hlenR⟩, hallR64⟩, _⟩, _⟩, hcut64⟩, hallCut⟩, _⟩
          have hallCut64 : listAllBool (fun cv => decide (cv < 65536)) T.dualCutVids = true := by
            rw [listAllBool_iff] at hallCut ⊢
            intro cv hcv
            have hc := hallCut cv hcv
            unfold wfVertexWireBool at hc
            simp only [Bool.and_eq_true] at hc
            exact hc.2
          unfold encodeClaimPair0x00List parseClaimPair0x00
          simp only [hneCt1, hneM1, ite_false, List.append_assoc]
          rw [parseBindHeader_encode_append hwfHdr]
          dsimp only
          rw [if_pos hsemHdr]
          rw [parseU8_packU8_append (by decide : 2 < 256)]
          dsimp only
          rw [if_neg hbhNe1, if_pos hbhCt23, if_neg (by decide : (2 : Nat) ≠ 1), if_pos rfl]
          rw [parseU16BE_packU16BE_append hL64]
          dsimp only
          rw [parseU16BE_packU16BE_append hU64]
          dsimp only
          rw [← hlenP]
          rw [parseRepeat_encodeRepeat_append (fun _ r hw => parseExplicitPrimal_encode_append vTotal hw r) hallPw]
          dsimp only
          rw [← hlenR]
          rw [parseRepeat_encodeRepeat_append
                (wfItem := fun d => decide (d < 65536))
                (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r) hallR64]
          dsimp only
          rw [parseU16BE_packU16BE_append hcut64]
          dsimp only
          rw [parseRepeat_encodeRepeat_append
                (wfItem := fun cv => decide (cv < 65536))
                (fun _ r hw => parseU16BE_packU16BE_append (of_decide_eq_true hw) r) hallCut64]
          dsimp only
          cases T
          dsimp only at hklEq hctEq hm2 hev0 href2 hj0 hwNil hlenP hlenR
          subst hm2; subst hev0; subst href2; subst hj0; subst hwNil
          subst hlenP; subst hlenR; subst hklEq; subst hctEq
          rw [if_pos hcanCopy]
        · cases hBranch
    · cases hBranch

theorem parseClaimPair0x00_eq_some (vTotal irTotal : Nat) {bs rest : List UInt8}
    {pair : RawCarrierBindHeader × SourceCertTerm}
    (h : parseClaimPair0x00 vTotal irTotal bs = some (pair, rest)) :
    checkCanonicalClaimPairBool vTotal irTotal pair = true ∧
    bs = encodeClaimPair0x00List pair ++ rest := by
  unfold parseClaimPair0x00 at h
  cases hbh : parseBindHeader bs with
  | none => rw [hbh] at h; cases h
  | some pBh =>
    rw [hbh] at h; rcases pBh with ⟨bh, bs1⟩; dsimp only at h
    rcases parseBindHeader_eq_some hbh with ⟨_, eBh⟩
    split at h
    · cases hm : parseU8 bs1 with
      | none => rw [hm] at h; cases h
      | some pM =>
        rw [hm] at h; rcases pM with ⟨mTag, bs2⟩; dsimp only at h
        rcases parseU8_eq_some hm with ⟨_, eM⟩
        split at h
        · next hct1 =>
          split at h
          · next hm1 =>
            subst hm1
            cases hj : parseU16BE bs2 with
            | none => rw [hj] at h; cases h
            | some pJ =>
              rw [hj] at h; rcases pJ with ⟨jUnb, bs3⟩; dsimp only at h
              rcases parseU16BE_eq_some hj with ⟨_, eJ⟩
              split at h
              · next hcan =>
                simp only [Option.some.injEq, Prod.mk.injEq] at h
                rcases h with ⟨hpair, hrest⟩
                subst hpair; subst hrest
                refine ⟨hcan, ?_⟩
                rw [eBh, eM, eJ]
                simp [encodeClaimPair0x00List, List.append_assoc]
              · cases h
          · split at h
            · next hm2 =>
              subst hm2
              cases hL : parseU16BE bs2 with
              | none => rw [hL] at h; cases h
              | some pL =>
                rw [hL] at h; rcases pL with ⟨cL, bs3⟩; dsimp only at h
                rcases parseU16BE_eq_some hL with ⟨_, eL⟩
                cases hU : parseU16BE bs3 with
                | none => rw [hU] at h; cases h
                | some pU =>
                  rw [hU] at h; rcases pU with ⟨cU, bs4⟩; dsimp only at h
                  rcases parseU16BE_eq_some hU with ⟨_, eU⟩
                  cases hP : parseRepeat (parseLocalPrimal vTotal) cL bs4 with
                  | none => rw [hP] at h; cases h
                  | some pP =>
                    rw [hP] at h; rcases pP with ⟨pws, bs5⟩; dsimp only at h
                    rcases parseRepeat_eq_some (fun _ _ _ hp => parseLocalPrimal_eq_some vTotal hp) hP with
                      ⟨_, _, eP⟩
                    cases hR : parseRepeat parseU16BE cU bs5 with
                    | none => rw [hR] at h; cases h
                    | some pR =>
                      rw [hR] at h; rcases pR with ⟨hits, bs6⟩; dsimp only at h
                      rcases parseRepeat_eq_some
                          (wfItem := fun d => decide (d < 65536))
                          (fun _ _ _ hp =>
                            let ⟨hl, he⟩ := parseU16BE_eq_some hp
                            ⟨decide_eq_true hl, he⟩) hR with ⟨_, _, eR⟩
                      cases hev : parseU8 bs6 with
                      | none => rw [hev] at h; cases h
                      | some pEv =>
                        rw [hev] at h; rcases pEv with ⟨evMode, bs7⟩; dsimp only at h
                        rcases parseU8_eq_some hev with ⟨_, eEv⟩
                        split at h
                        · next hev0 =>
                          subst hev0
                          split at h
                          · next hcan =>
                            simp only [Option.some.injEq, Prod.mk.injEq] at h
                            rcases h with ⟨hpair, hrest⟩
                            subst hpair; subst hrest
                            refine ⟨hcan, ?_⟩
                            rw [eBh, eM, eL, eU, eP, eR, eEv]
                            simp [encodeClaimPair0x00List, List.append_assoc]
                          · cases h
                        · cases h
            · cases h
        · next hneCt1 =>
          split at h
          · split at h
            · next hm1 =>
              subst hm1
              cases hw : parseWalk vTotal bs2 with
              | none => rw [hw] at h; cases h
              | some pW =>
                rw [hw] at h; rcases pW with ⟨unbW, bs3⟩; dsimp only at h
                rcases parseWalk_eq_some vTotal hw with ⟨_, eW⟩
                split at h
                · next hcan =>
                  simp only [Option.some.injEq, Prod.mk.injEq] at h
                  rcases h with ⟨hpair, hrest⟩
                  subst hpair; subst hrest
                  refine ⟨hcan, ?_⟩
                  rw [eBh, eM, eW]
                  simp [encodeClaimPair0x00List, hneCt1, List.append_assoc]
                · cases h
            · split at h
              · next hm2 =>
                subst hm2
                cases hL : parseU16BE bs2 with
                | none => rw [hL] at h; cases h
                | some pL =>
                  rw [hL] at h; rcases pL with ⟨cL, bs3⟩; dsimp only at h
                  rcases parseU16BE_eq_some hL with ⟨_, eL⟩
                  cases hU : parseU16BE bs3 with
                  | none => rw [hU] at h; cases h
                  | some pU =>
                    rw [hU] at h; rcases pU with ⟨cU, bs4⟩; dsimp only at h
                    rcases parseU16BE_eq_some hU with ⟨_, eU⟩
                    cases hP : parseRepeat (parseExplicitPrimal vTotal) cL bs4 with
                    | none => rw [hP] at h; cases h
                    | some pP =>
                      rw [hP] at h; rcases pP with ⟨pws, bs5⟩; dsimp only at h
                      rcases parseRepeat_eq_some (fun _ _ _ hp => parseExplicitPrimal_eq_some vTotal hp) hP with
                        ⟨_, _, eP⟩
                      cases hR : parseRepeat parseU16BE cU bs5 with
                      | none => rw [hR] at h; cases h
                      | some pR =>
                        rw [hR] at h; rcases pR with ⟨dStar, bs6⟩; dsimp only at h
                        rcases parseRepeat_eq_some
                            (wfItem := fun d => decide (d < 65536))
                            (fun _ _ _ hp =>
                              let ⟨hl, he⟩ := parseU16BE_eq_some hp
                              ⟨decide_eq_true hl, he⟩) hR with ⟨_, _, eR⟩
                        cases hcLen : parseU16BE bs6 with
                        | none => rw [hcLen] at h; cases h
                        | some pCL =>
                          rw [hcLen] at h; rcases pCL with ⟨cutLen, bs7⟩; dsimp only at h
                          rcases parseU16BE_eq_some hcLen with ⟨_, eCL⟩
                          cases hC : parseRepeat parseU16BE cutLen bs7 with
                          | none => rw [hC] at h; cases h
                          | some pC =>
                            rw [hC] at h; rcases pC with ⟨cutVids, bs8⟩; dsimp only at h
                            rcases parseRepeat_eq_some
                                (wfItem := fun cv => decide (cv < 65536))
                                (fun _ _ _ hp =>
                                  let ⟨hl, he⟩ := parseU16BE_eq_some hp
                                  ⟨decide_eq_true hl, he⟩) hC with ⟨hlenC, _, eC⟩
                            split at h
                            · next hcan =>
                              simp only [Option.some.injEq, Prod.mk.injEq] at h
                              rcases h with ⟨hpair, hrest⟩
                              subst hpair; subst hrest
                              refine ⟨hcan, ?_⟩
                              rw [eBh, eM, eL, eU, eP, eR, eCL, eC]
                              simp [encodeClaimPair0x00List, hneCt1, hlenC, List.append_assoc]
                            · cases h
              · cases h
          · cases h
    · cases h

/-- **`F91-03` Theorem 1 (Encoder Domain Characterization)**:
    `encodeClaimSlice0x00` succeeds (`some B`) iff `CanonicalClaim0x00` holds, and rejects
    all non-canonical terms (`= none`). -/
theorem f91_03_encodeClaimSlice0x00_domain_iff (vTotal irTotal : Nat)
    (bh : RawCarrierBindHeader) (T : SourceCertTerm) :
    (∃ B, encodeClaimSlice0x00 vTotal irTotal bh T = some B) ↔
    CanonicalClaim0x00 vTotal irTotal bh T :=
  encodeGuardedSlice_isSome_iff _ _ (bh, T)

theorem f91_03_noncanonical_claim_encode_none (vTotal irTotal : Nat)
    (bh : RawCarrierBindHeader) (T : SourceCertTerm)
    (hnot : ¬ CanonicalClaim0x00 vTotal irTotal bh T) :
    encodeClaimSlice0x00 vTotal irTotal bh T = none :=
  encodeGuardedSlice_eq_none_of_not_wf _ _ (bh, T) hnot

/-- **`F91-03` Theorem 2 (Forward Roundtrip on Canonical Domain)**:
    Every canonical `(bh, T)` encodes to `some B` and decodes back to `some (bh, T)`. -/
theorem f91_03_claim_slice_forward_roundtrip {vTotal irTotal : Nat}
    {bh : RawCarrierBindHeader} {T : SourceCertTerm}
    (hcan : CanonicalClaim0x00 vTotal irTotal bh T) :
    ∃ B,
      encodeClaimSlice0x00 vTotal irTotal bh T = some B ∧
      decodeClaimSlice0x00 vTotal irTotal B = some (bh, T) :=
  guardedSlice_forward_roundtrip
    (checkCanonicalClaimPairBool vTotal irTotal) encodeClaimPair0x00List
    (parseClaimPair0x00 vTotal irTotal)
    (fun _ r hc => parseClaimPair0x00_encode_append vTotal irTotal hc r) hcan

/-- **`F91-03` Theorem 3 (Backward Roundtrip & No Silent Normalization)**:
    Every decoded byte slice `B` yields a canonical `(bh, T)` and re-encodes to `some B`
    byte-for-byte. -/
theorem f91_03_claim_slice_backward_roundtrip {vTotal irTotal : Nat}
    {B : ByteArray} {bh : RawCarrierBindHeader} {T : SourceCertTerm}
    (hdec : decodeClaimSlice0x00 vTotal irTotal B = some (bh, T)) :
    CanonicalClaim0x00 vTotal irTotal bh T ∧
    encodeClaimSlice0x00 vTotal irTotal bh T = some B :=
  guardedSlice_backward_roundtrip
    (checkCanonicalClaimPairBool vTotal irTotal) encodeClaimPair0x00List
    (parseClaimPair0x00 vTotal irTotal)
    (fun _ _ _ hp => parseClaimPair0x00_eq_some vTotal irTotal hp) hdec

/-- **`F91-03` Corollary 4 (Guarded Canonical Bijection Equivalence)**. -/
theorem f91_03_claim_slice_bijection_iff (vTotal irTotal : Nat)
    (B : ByteArray) (bh : RawCarrierBindHeader) (T : SourceCertTerm) :
    decodeClaimSlice0x00 vTotal irTotal B = some (bh, T) ↔
    encodeClaimSlice0x00 vTotal irTotal bh T = some B :=
  guardedSlice_bijection_iff
    (checkCanonicalClaimPairBool vTotal irTotal) encodeClaimPair0x00List
    (parseClaimPair0x00 vTotal irTotal)
    (fun _ r hc => parseClaimPair0x00_encode_append vTotal irTotal hc r)
    (fun _ _ _ hp => parseClaimPair0x00_eq_some vTotal irTotal hp) B (bh, T)

/-! ## `W-1E`: `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT` Composition &
    Detached Header Uniqueness Under Scoped `NoCollisionOn` -/

/-- Exact Carrier-to-Base projection check (`#40` `omega_kappa_pure_checker.py` L789–806 & `B6`). -/
def projectRawCarrierToSpec (b : BaseData) : RawCarrierPayload → Option CarrierSpec
  | .localPaths pkt => some (.localPacket pkt)
  | .geodesicHops entries =>
      if decide (entries.map (fun e => (e.sVid, e.tVid, e.rank)) = b.rankEntries) &&
         decide (entries.map (fun e => (e.sVid, e.tVid, e.hops)) = b.maxHopEntries) then
        some .geodesicBundle
      else none
  | .globalEdges edgePairs =>
      if decide (edgePairs = b.G.edges.map (fun e => (e.src, e.dst))) then
        some .globalGraph
      else none

/-- Scoped Slice-to-Certificate Refinement (`SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT`). -/
def ScopedCanonicalSlicesRefinement (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry) (snap : SourceSnapshot)
    (bSnap bCar bClaim : ByteArray)
    (bh : RawCarrierBindHeader) (cRaw : RawCarrierPayload) (T : SourceCertTerm) : Prop :=
  let vTotal := snap.vertexIds.length
  let irTotal := snap.irRecords.length
  decodeCarrierPayload bh.carrierTag vTotal bCar = some cRaw ∧
  encodeCarrierPayload vTotal cRaw = some bCar ∧
  decodeClaimSlice0x00 vTotal irTotal bClaim = some (bh, T) ∧
  encodeClaimSlice0x00 vTotal irTotal bh T = some bClaim ∧
  CanonicalClaim0x00 vTotal irTotal bh T ∧
  DigestVerified hash256 ent snap.generation bSnap bCar bh cRaw T vTotal

/-- Executable combined slice-level gate for `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT`. -/
def checkScopedCanonicalSlices0x00 (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData)
    (bSnap bCar bClaim : ByteArray) : Bool :=
  let vTotal := snap.vertexIds.length
  let irTotal := snap.irRecords.length
  checkSourceAnchorAndSortLaw reg snap &&
  decide (lookupPinnedA1 snap.snapshotId reg = some ent) &&
  decide (ip = projectIssuerPartition snap ent.pinnedConstIds) &&
  decide (b.G = projectIRGraph snap) &&
  checkVerifiedBase ip b &&
  match decodeClaimSlice0x00 vTotal irTotal bClaim with
  | none => false
  | some (bh, T) =>
    match decodeCarrierPayload bh.carrierTag vTotal bCar with
    | none => false
    | some cRaw =>
      match projectRawCarrierToSpec b cRaw with
      | none => false
      | some c =>
          checkDigestVerifiedBool hash256 ent snap.generation bSnap bCar bh cRaw T vTotal &&
          checkSourceCert0x00 ip b bh.queryS bh.queryT c T

/-- **`W-1E` Master Scoped Slice Composition Theorem (`91st Ruling §5`)**:
    Scope: `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT`
    (Full `CNB-v1` / `CNP-v2` outer bundle & raw Snapshot bytes parser remain `HELD` for `W2`).
    Given a trusted structured `SourceSnapshot` `snap` paired with its canonical snapshot slice
    `bSnap`, plus raw carrier slice `bCar` and raw `0x00` claim slice `bClaim`, acceptance by
    `checkScopedCanonicalSlices0x00` proves BOTH:
      1. Exact canonical wire roundtrips (`encodeCarrierPayload = some bCar` and
         `encodeClaimSlice0x00 = some bClaim`) and preimage `DigestVerified_H`, AND
      2. Pure string-keyed source semantic resilience `SourceStringSemanticResilience`
         via untouched `#43` (`Ωλ-R1`) and `#44` (`Ωλ-R2`)! -/
theorem w1e_scoped_canonical_slices_with_trusted_snapshot_sound
    (hash256 : ByteArray → ByteArray)
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData)
    (bSnap bCar bClaim : ByteArray)
    (hOk : checkScopedCanonicalSlices0x00 hash256 reg snap ent ip b bSnap bCar bClaim = true) :
    ∃ (bh : RawCarrierBindHeader) (cRaw : RawCarrierPayload) (c : CarrierSpec) (T : SourceCertTerm),
      ScopedCanonicalSlicesRefinement hash256 ent snap bSnap bCar bClaim bh cRaw T ∧
      projectRawCarrierToSpec b cRaw = some c ∧
      TagContextMatch T b.kappa c ∧
      ((T.modeTag = 1 ∧ T.claimedL = 0 ∧ T.claimedU = 0 ∧
        SourceStringSemanticResilience reg snap b.kappa bh.queryS bh.queryT c .unbreakable) ∨
       (T.modeTag = 2 ∧ 1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU ∧
        SourceStringSemanticResilience reg snap b.kappa bh.queryS bh.queryT c
          (.finiteBounds T.claimedL T.claimedU))) := by
  unfold checkScopedCanonicalSlices0x00 at hOk
  dsimp only at hOk
  rcases (Bool.and_eq_true _ _).mp hOk with ⟨hTop5, hMatch⟩
  rcases (Bool.and_eq_true _ _).mp hTop5 with ⟨hTop4, hBase⟩
  rcases (Bool.and_eq_true _ _).mp hTop4 with ⟨hTop3, hGraphB⟩
  rcases (Bool.and_eq_true _ _).mp hTop3 with ⟨hTop2, hPartB⟩
  rcases (Bool.and_eq_true _ _).mp hTop2 with ⟨hAnchor, hLookupB⟩
  have hLookup : lookupPinnedA1 snap.snapshotId reg = some ent := of_decide_eq_true hLookupB
  have hPart : ip = projectIssuerPartition snap ent.pinnedConstIds := of_decide_eq_true hPartB
  have hGraph : b.G = projectIRGraph snap := of_decide_eq_true hGraphB
  cases hdecClm : decodeClaimSlice0x00 snap.vertexIds.length snap.irRecords.length bClaim with
  | none => rw [hdecClm] at hMatch; cases hMatch
  | some pair =>
    rw [hdecClm] at hMatch
    rcases pair with ⟨bh, T⟩
    dsimp only at hMatch
    cases hdecCar : decodeCarrierPayload bh.carrierTag snap.vertexIds.length bCar with
    | none => rw [hdecCar] at hMatch; cases hMatch
    | some cRaw =>
      rw [hdecCar] at hMatch
      dsimp only at hMatch
      cases hproj : projectRawCarrierToSpec b cRaw with
      | none => rw [hproj] at hMatch; cases hMatch
      | some c =>
        rw [hproj] at hMatch
        dsimp only at hMatch
        rcases (Bool.and_eq_true _ _).mp hMatch with ⟨hDig, hSrcCert⟩
        rcases f91_03_claim_slice_backward_roundtrip hdecClm with ⟨hCanClm, hencClm⟩
        rcases w1b_carrier_backward_roundtrip hdecCar with ⟨_, _, hencCar⟩
        rcases cert4_with_r1_source_string_sound reg snap ent ip b bh.queryS bh.queryT c T
            hAnchor hLookup hPart hGraph hBase hSrcCert with
          ⟨_, htagCtx, hsemOr⟩
        exact ⟨bh, cRaw, c, T,
               ⟨hdecCar, hencCar, hdecClm, hencClm, hCanClm, hDig⟩,
               hproj, htagCtx, hsemOr⟩

/-- **`W-1E` Detached Header Carrier-Uniqueness Corollary (`91st Ruling §3`)**:
    Under the explicit local hypothesis `NoCollisionOn hash256 pre1 pre2` (ZERO global axioms!),
    any two canonical carrier slices validated against the same 70-byte `RawCarrierBindHeader`
    are byte-identical (`bCar1 = bCar2`) and decode to identical `RawCarrierPayload`s
    (`cRaw1 = cRaw2`). -/
theorem w1e_detached_bind_header_carrier_unique
    (hash256 : ByteArray → ByteArray)
    (ent : PinnedA1Entry) (genV vTotal : Nat)
    (bSnap bCar1 bCar2 : ByteArray)
    (bh : RawCarrierBindHeader)
    (cRaw1 cRaw2 : RawCarrierPayload)
    (T1 T2 : SourceCertTerm)
    (hdec1 : decodeCarrierPayload bh.carrierTag vTotal bCar1 = some cRaw1)
    (hdec2 : decodeCarrierPayload bh.carrierTag vTotal bCar2 = some cRaw2)
    (hdig1 : DigestVerified hash256 ent genV bSnap bCar1 bh cRaw1 T1 vTotal)
    (hdig2 : DigestVerified hash256 ent genV bSnap bCar2 bh cRaw2 T2 vTotal)
    (hNoColl : NoCollisionOn hash256
      (mkCarrierPreimageBytes bh.carrierTag bh.hSigma32 bh.closureTag bh.queryS bh.queryT bCar1)
      (mkCarrierPreimageBytes bh.carrierTag bh.hSigma32 bh.closureTag bh.queryS bh.queryT bCar2)) :
    bCar1 = bCar2 ∧ cRaw1 = cRaw2 := by
  unfold DigestVerified checkDigestVerifiedBool at hdig1 hdig2
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hdig1 hdig2
  rcases hdig1 with ⟨⟨⟨⟨⟨⟨⟨hwfBh, _⟩, _⟩, _⟩, hcarEq1⟩, _⟩, _⟩, _⟩
  rcases hdig2 with ⟨⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hcarEq2⟩, _⟩, _⟩, _⟩
  unfold wfRawBindHeaderBool at hwfBh
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwfBh
  rcases hwfBh with ⟨⟨⟨⟨⟨hsigSz, _⟩, hklLt⟩, hctLt⟩, hqsLt⟩, hqtLt⟩
  have hhashEq :
      hash256 (mkCarrierPreimageBytes bh.carrierTag bh.hSigma32 bh.closureTag bh.queryS bh.queryT bCar1) =
      hash256 (mkCarrierPreimageBytes bh.carrierTag bh.hSigma32 bh.closureTag bh.queryS bh.queryT bCar2) :=
    hcarEq1.symm.trans hcarEq2
  have hpreEq := hNoColl hhashEq
  have hbCarEq := (w1c_carrier_preimage_injective
    hctLt hctLt hsigSz hsigSz hklLt hklLt hqsLt hqsLt hqtLt hqtLt hpreEq).2.2.2.2.2
  subst hbCarEq
  rw [hdec1] at hdec2
  injection hdec2 with hcEq
  exact ⟨rfl, hcEq⟩

end OmegaLambda

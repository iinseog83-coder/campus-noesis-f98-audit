/-
  CAMPUS-NOESIS Omega-Lambda W1: Compile-Time Kernel Axiom Audit
  Module: `OmegaLambda.W1AxiomAudit`

  Emits `#print axioms` at compile time for every flagship `Ωλ-W1` theorem in
  `WireRefinement` and `WireRefinementExamples` (`W-1A`..`W-1E` and mandatory
  guards `F91-02`..`F91-03`), verifying strict adherence to standard Lean 4
  foundation axioms (`propext`, `Quot.sound`, `Classical.choice`; `sorryAx = 0`,
  `ofReduceBool = 0`, `._native. = 0`, user `axiom = 0`).
-/

import OmegaLambda.WireRefinement
import OmegaLambda.WireRefinementExamples

#print axioms OmegaLambda.w1a_u16be_forward_roundtrip
#print axioms OmegaLambda.w1a_u16be_backward_roundtrip
#print axioms OmegaLambda.w1a_u32be_forward_roundtrip
#print axioms OmegaLambda.w1a_u32be_backward_roundtrip
#print axioms OmegaLambda.w1a_bind_header_forward_roundtrip
#print axioms OmegaLambda.w1a_bind_header_backward_roundtrip
#print axioms OmegaLambda.w1a_bind_header_bijection_iff
#print axioms OmegaLambda.w1a_repr_valid_does_not_imply_semantic_tag_valid
#print axioms OmegaLambda.w1b_strict_lex_walks_gives_nodup
#print axioms OmegaLambda.w1b_walk_forward_roundtrip
#print axioms OmegaLambda.w1b_walk_backward_roundtrip
#print axioms OmegaLambda.w1b_reflexive_walk_4bytes
#print axioms OmegaLambda.w1b_carrier_encode_domain_iff
#print axioms OmegaLambda.w1b_carrier_forward_roundtrip
#print axioms OmegaLambda.w1b_carrier_backward_roundtrip
#print axioms OmegaLambda.w1c_domain_prefix_lengths
#print axioms OmegaLambda.w1c_snapshot_preimage_size
#print axioms OmegaLambda.w1c_carrier_preimage_size
#print axioms OmegaLambda.w1c_carrier_preimage_injective
#print axioms OmegaLambda.w1c_snapshot_preimage_injective
#print axioms OmegaLambda.w1c_domain_prefixes_pairwise_disjoint
#print axioms OmegaLambda.w1c_bytes32ToLowerHex_spec
#print axioms OmegaLambda.f91_02_no_32byte_hash_globally_injective
#print axioms OmegaLambda.f91_02_abstract_digest_does_not_force_sha256_identity
#print axioms OmegaLambda.w1d_strict_inc_implies_nodup
#print axioms OmegaLambda.f91_03_encodeClaimSlice0x00_domain_iff
#print axioms OmegaLambda.f91_03_noncanonical_claim_encode_none
#print axioms OmegaLambda.f91_03_claim_slice_forward_roundtrip
#print axioms OmegaLambda.f91_03_claim_slice_backward_roundtrip
#print axioms OmegaLambda.f91_03_claim_slice_bijection_iff
#print axioms OmegaLambda.w1e_scoped_canonical_slices_with_trusted_snapshot_sound
#print axioms OmegaLambda.w1e_detached_bind_header_carrier_unique
#print axioms OmegaLambda.W1Examples.w1_ex1_carrier_roundtrip_exact
#print axioms OmegaLambda.W1Examples.w1_ex1_claim_roundtrip_exact
#print axioms OmegaLambda.W1Examples.w1_ex1_scoped_slices_gate_ok
#print axioms OmegaLambda.W1Examples.w1_ex1_end_to_end_scoped_resilience_sound
#print axioms OmegaLambda.W1Examples.w1_ex2_reflexive_walk_4bytes_and_f82_14bytes
#print axioms OmegaLambda.W1Examples.w1_ex3_local_claim_roundtrip_with_trailing_zero_evasion_byte
#print axioms OmegaLambda.W1Examples.w1_ex3_geodesic_carrier_and_claim_roundtrip
#print axioms OmegaLambda.W1Examples.adv_w1_f91_03_unsorted_retraction_encode_none
#print axioms OmegaLambda.W1Examples.adv_w1_f91_03_local_nonempty_dualcut_encode_none
#print axioms OmegaLambda.W1Examples.adv_w1_trailing_slack_bytes_rejected
#print axioms OmegaLambda.W1Examples.adv_w1_sentinel_0xffff_vertex_rejected
#print axioms OmegaLambda.W1Examples.adv_w1_local_evasion_0x01_wire_rejected
#print axioms OmegaLambda.W1Examples.adv_w1_unsorted_local_packet_bytes_rejected

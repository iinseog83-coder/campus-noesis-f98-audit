/-
  CAMPUS-NOESIS Omega-Lambda R1: Compile-Time Kernel Axiom Audit
  Module: `OmegaLambda.R1AxiomAudit`

  Emits `#print axioms` at compile time for every flagship `Ωλ-R1` theorem in
  `SourceIRRefinement` and `SourceIRRefinementExamples`, verifying that only
  standard Lean 4 foundation axioms (`propext`, `Quot.sound`, `Classical.choice`)
  appear (`sorryAx = 0`, `ofReduceBool = 0`, `._native. = 0`, user `axiom = 0`).
-/

import OmegaLambda.SourceIRRefinement
import OmegaLambda.SourceIRRefinementExamples

#print axioms OmegaLambda.licensedSortBit_iff_not_forbidden
#print axioms OmegaLambda.duplicate_refs_nodup_support
#print axioms OmegaLambda.projectIssuerPartition_wf
#print axioms OmegaLambda.projectIRGraph_wf
#print axioms OmegaLambda.ref_ir_commute
#print axioms OmegaLambda.ref_ir_base_edge_iff
#print axioms OmegaLambda.hyperedge_simultaneous_retraction
#print axioms OmegaLambda.ref_ir_chain_commute
#print axioms OmegaLambda.ref_ir_walk_commute
#print axioms OmegaLambda.ref_ir_valid_walk_iff
#print axioms OmegaLambda.ref_ir_true_shortest_walk_iff
#print axioms OmegaLambda.ref_ir_carrier_survives_idx_iff
#print axioms OmegaLambda.length_ridsOfIdxs
#print axioms OmegaLambda.length_idxsOfRids
#print axioms OmegaLambda.idxsOfRids_ridsOfIdxs
#print axioms OmegaLambda.ridsOfIdxs_idxsOfRids
#print axioms OmegaLambda.nodup_ridsOfIdxs
#print axioms OmegaLambda.nodup_idxsOfRids
#print axioms OmegaLambda.mem_remIssuers_iff_rid_mem_sourceRem
#print axioms OmegaLambda.mem_sourceRem_gives_idx_mem_remIssuers
#print axioms OmegaLambda.residualRecordsByIdx_eq_str
#print axioms OmegaLambda.residualRecordsByStr_eq_idx
#print axioms OmegaLambda.sourceCarrierSurvivesIdx_iff_str
#print axioms OmegaLambda.surviving_source_edge_obeys_0xFF33
#print axioms OmegaLambda.source_ir_to_omegaLambda_resilience_sound
#print axioms OmegaLambda.source_ir_to_omegaLambda_exact_resilience_sound
#print axioms OmegaLambda.R1Examples.r1_ex1_anchor_ok
#print axioms OmegaLambda.R1Examples.r1_ex1_shared_hyperedge_support
#print axioms OmegaLambda.R1Examples.r1_ex1_exact_1_string_resilience
#print axioms OmegaLambda.R1Examples.r1_ex2_duplicate_ref_support_singleton
#print axioms OmegaLambda.R1Examples.r1_ex2_exact_2_string_resilience
#print axioms OmegaLambda.R1Examples.adv_r1_rejects_forbidden_0xFF33_jump
#print axioms OmegaLambda.R1Examples.adv_r1_rejects_a2_and_a3_authority
#print axioms OmegaLambda.R1Examples.adv_r1_rejects_duplicate_record_id
#print axioms OmegaLambda.R1Examples.adv_r1_rejects_duplicate_vertex_id
#print axioms OmegaLambda.R1Examples.adv_r1_rejects_forged_snapshot_root

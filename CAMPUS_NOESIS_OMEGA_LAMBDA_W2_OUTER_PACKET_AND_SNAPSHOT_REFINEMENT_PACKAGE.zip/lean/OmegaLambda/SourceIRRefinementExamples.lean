/-
  CAMPUS-NOESIS Omega-Lambda R1: Concrete Kernel Evaluation & Adversarial Rejection Proofs
  Module: `OmegaLambda.SourceIRRefinementExamples`

  Exercises `OmegaLambda.SourceIRRefinement` via kernel definitional reduction (`rfl`,
  zero `native_decide`):
    1. `r1_ex1`: Multi-ref hyperedge `"rec.hyper.shared"` issuing two disjoint branches
       `0 → 1 → 3` and `0 → 2 → 3` simultaneously — proves exact string-keyed resilience
       `k = 1` (`|D_str| = 1`, NOT `2`!).
    2. `r1_ex2`: Duplicate-reference idempotence (`refs = [ref1, ref1]`) + two independent
       retractable string records `"rec.rem.alpha"` and `"rec.rem.beta"` — proves exact
       string-keyed resilience `k = 2`.
    3. `adv_r1_*`: Five kernel-reduced (`= false := rfl`) rejection proofs:
       - `0xFF33` forbidden epistemic jump (`EVENT → PROPOSITION`),
       - `A2` (`authTierTag = 2`) and `A3` (`authTierTag = 3`) authority escalation,
       - Duplicate string `recordId` (preventing `|D_str| < |D|` cardinality collapse),
       - Duplicate vertex `AsciiId` (cross-sort collision),
       - Unpinned `A1` snapshot root spoofing.
-/

import OmegaLambda.SourceIRRefinement

namespace OmegaLambda.R1Examples

open OmegaLambda

/-! ## Shared Pinned `A1` Registry Fixture -/

def pinnedRegR1 : List PinnedA1Entry :=
  [ { snapshotId := "snap.a1.hyper.v1"
      pinnedGen := 1
      pinnedRootHex := "a1000001deadbeefcafebabe00000001"
      pinnedConstIds := ["rec.const.left", "rec.const.right"] },
    { snapshotId := "snap.a1.parallel.v1"
      pinnedGen := 1
      pinnedRootHex := "a1000002deadbeefcafebabe00000002"
      pinnedConstIds := ["rec.const.tail1", "rec.const.tail2"] } ]

/-! ## Example R1-1: Multi-Ref Hyperedge Simultaneous Retraction (`k = 1`) -/

def snapHyper : SourceSnapshot :=
  { snapshotId := "snap.a1.hyper.v1"
    generation := 1
    authTierTag := 1
    policyMask := 0xFF33
    claimedRootHex := "a1000001deadbeefcafebabe00000001"
    computedRootHex := "a1000001deadbeefcafebabe00000001"
    vertexIds := ["v.deriv.0", "v.prop.1", "v.prop.2", "v.event.3"]
    vertexSorts := [.derivation, .proposition, .proposition, .event]
    irRecords :=
      [ { recordId := "rec.hyper.shared"
          sourceVid := 0
          sourceSort := .derivation
          refs :=
            [ { targetVid := 1, targetSort := .proposition,
                relSrcSort := .derivation, relDstSort := .proposition },
              { targetVid := 2, targetSort := .proposition,
                relSrcSort := .derivation, relDstSort := .proposition } ] },
        { recordId := "rec.const.left"
          sourceVid := 1
          sourceSort := .proposition
          refs :=
            [ { targetVid := 3, targetSort := .event,
                relSrcSort := .proposition, relDstSort := .event } ] },
        { recordId := "rec.const.right"
          sourceVid := 2
          sourceSort := .proposition
          refs :=
            [ { targetVid := 3, targetSort := .event,
                relSrcSort := .proposition, relDstSort := .event } ] } ] }

def entHyper : PinnedA1Entry :=
  { snapshotId := "snap.a1.hyper.v1"
    pinnedGen := 1
    pinnedRootHex := "a1000001deadbeefcafebabe00000001"
    pinnedConstIds := ["rec.const.left", "rec.const.right"] }

def ipHyper : IssuerPartition :=
  projectIssuerPartition snapHyper entHyper.pinnedConstIds

def baseHyper : BaseData :=
  { G := projectIRGraph snapHyper
    kappa := .ePlus
    rankEntries :=
      [ (0, 1, 1), (0, 2, 1), (0, 3, 2),
        (1, 3, 1), (2, 3, 1) ]
    maxHopEntries :=
      [ (0, 1, [1]), (0, 2, [2]), (0, 3, [1, 2]),
        (1, 3, [3]), (2, 3, [3]) ] }

def certHyper : ResilienceCert :=
  .globalPlus
    (.finiteBounds 1 1
      [ { transitions :=
            [ { src := .start, support := [0], dst := .act 1 },
              { src := .act 1, support := [1], dst := .act 3 } ]
          stepWitnesses := [.retractableIssuer 0, .immutableStep] } ]
      [0]
      [.start])

theorem r1_ex1_anchor_ok :
    checkSourceAnchorAndSortLaw pinnedRegR1 snapHyper = true := rfl

theorem r1_ex1_lookup_ok :
    lookupPinnedA1 snapHyper.snapshotId pinnedRegR1 = some entHyper := rfl

theorem r1_ex1_shared_hyperedge_support :
    reconstructSupport snapHyper.irRecords 0 1 = [0] ∧
    reconstructSupport snapHyper.irRecords 0 2 = [0] := ⟨rfl, rfl⟩

theorem r1_ex1_verified_base_ok :
    checkVerifiedBase ipHyper baseHyper = true := rfl

theorem r1_ex1_resilience_cert_ok :
    checkOmegaLambdaResilience ipHyper baseHyper 0 3 .globalGraph certHyper = true := rfl

/-- End-to-End Machine-Checked Proof on `snapHyper`:
    Even though `[0, 1, 3]` and `[0, 2, 3]` are vertex-disjoint walks, the shared
    multi-ref hyperedge `"rec.hyper.shared"` gives exact string-keyed resilience `k = 1`! -/
theorem r1_ex1_exact_1_string_resilience :
    (∀ D_str : List AsciiId,
      NodupList D_str →
      (∀ rid ∈ D_str, rid ∈ sourceRemRecordIds snapHyper entHyper.pinnedConstIds) →
      ¬ SourceCarrierSurvivesStr snapHyper .ePlus 0 3 .globalGraph D_str →
      1 ≤ D_str.length) ∧
    (∃ D_str_star : List AsciiId,
      NodupList D_str_star ∧
      (∀ rid ∈ D_str_star, rid ∈ sourceRemRecordIds snapHyper entHyper.pinnedConstIds) ∧
      D_str_star.length = 1 ∧
      ¬ SourceCarrierSurvivesStr snapHyper .ePlus 0 3 .globalGraph D_str_star) :=
  source_ir_to_omegaLambda_exact_resilience_sound
    pinnedRegR1 snapHyper entHyper ipHyper baseHyper 0 3 .globalGraph certHyper 1
    r1_ex1_anchor_ok r1_ex1_lookup_ok rfl rfl
    r1_ex1_verified_base_ok r1_ex1_resilience_cert_ok rfl

/-! ## Example R1-2: Duplicate-Ref Idempotence + Disjoint String Resilience (`k = 2`) -/

def snapParallel : SourceSnapshot :=
  { snapshotId := "snap.a1.parallel.v1"
    generation := 1
    authTierTag := 1
    policyMask := 0xFF33
    claimedRootHex := "a1000002deadbeefcafebabe00000002"
    computedRootHex := "a1000002deadbeefcafebabe00000002"
    vertexIds := ["v.deriv.0", "v.prop.1", "v.prop.2", "v.dataset.3"]
    vertexSorts := [.derivation, .proposition, .proposition, .dataset]
    irRecords :=
      [ { recordId := "rec.rem.alpha"
          sourceVid := 0
          sourceSort := .derivation
          -- Duplicate reference to `targetVid = 1` within the same record:
          refs :=
            [ { targetVid := 1, targetSort := .proposition,
                relSrcSort := .derivation, relDstSort := .proposition },
              { targetVid := 1, targetSort := .proposition,
                relSrcSort := .derivation, relDstSort := .proposition } ] },
        { recordId := "rec.rem.beta"
          sourceVid := 0
          sourceSort := .derivation
          refs :=
            [ { targetVid := 2, targetSort := .proposition,
                relSrcSort := .derivation, relDstSort := .proposition } ] },
        { recordId := "rec.const.tail1"
          sourceVid := 1
          sourceSort := .proposition
          refs :=
            [ { targetVid := 3, targetSort := .dataset,
                relSrcSort := .proposition, relDstSort := .dataset } ] },
        { recordId := "rec.const.tail2"
          sourceVid := 2
          sourceSort := .proposition
          refs :=
            [ { targetVid := 3, targetSort := .dataset,
                relSrcSort := .proposition, relDstSort := .dataset } ] } ] }

def entParallel : PinnedA1Entry :=
  { snapshotId := "snap.a1.parallel.v1"
    pinnedGen := 1
    pinnedRootHex := "a1000002deadbeefcafebabe00000002"
    pinnedConstIds := ["rec.const.tail1", "rec.const.tail2"] }

def ipParallel : IssuerPartition :=
  projectIssuerPartition snapParallel entParallel.pinnedConstIds

def baseParallel : BaseData :=
  { G := projectIRGraph snapParallel
    kappa := .ePlus
    rankEntries :=
      [ (0, 1, 1), (0, 2, 1), (0, 3, 2),
        (1, 3, 1), (2, 3, 1) ]
    maxHopEntries :=
      [ (0, 1, [1]), (0, 2, [2]), (0, 3, [1, 2]),
        (1, 3, [3]), (2, 3, [3]) ] }

def certParallelGeo : ResilienceCert :=
  .geodesic
    (.finiteBounds 2 2
      [ { transitions :=
            [ { src := .start, support := [0], dst := .act 1 },
              { src := .act 1, support := [2], dst := .act 3 } ]
          stepWitnesses := [.retractableIssuer 0, .immutableStep] },
        { transitions :=
            [ { src := .start, support := [1], dst := .act 2 },
              { src := .act 2, support := [3], dst := .act 3 } ]
          stepWitnesses := [.retractableIssuer 1, .immutableStep] } ]
      [0, 1]
      [.start])

theorem r1_ex2_duplicate_ref_support_singleton :
    reconstructSupport snapParallel.irRecords 0 1 = [0] := rfl

theorem r1_ex2_anchor_ok :
    checkSourceAnchorAndSortLaw pinnedRegR1 snapParallel = true := rfl

theorem r1_ex2_lookup_ok :
    lookupPinnedA1 snapParallel.snapshotId pinnedRegR1 = some entParallel := rfl

theorem r1_ex2_verified_base_ok :
    checkVerifiedBase ipParallel baseParallel = true := rfl

theorem r1_ex2_geodesic_cert_ok :
    checkOmegaLambdaResilience ipParallel baseParallel 0 3 .geodesicBundle certParallelGeo = true := rfl

theorem r1_ex2_exact_2_string_resilience :
    (∀ D_str : List AsciiId,
      NodupList D_str →
      (∀ rid ∈ D_str, rid ∈ sourceRemRecordIds snapParallel entParallel.pinnedConstIds) →
      ¬ SourceCarrierSurvivesStr snapParallel .ePlus 0 3 .geodesicBundle D_str →
      2 ≤ D_str.length) ∧
    (∃ D_str_star : List AsciiId,
      NodupList D_str_star ∧
      (∀ rid ∈ D_str_star, rid ∈ sourceRemRecordIds snapParallel entParallel.pinnedConstIds) ∧
      D_str_star.length = 2 ∧
      ¬ SourceCarrierSurvivesStr snapParallel .ePlus 0 3 .geodesicBundle D_str_star) :=
  source_ir_to_omegaLambda_exact_resilience_sound
    pinnedRegR1 snapParallel entParallel ipParallel baseParallel 0 3 .geodesicBundle certParallelGeo 2
    r1_ex2_anchor_ok r1_ex2_lookup_ok rfl rfl
    r1_ex2_verified_base_ok r1_ex2_geodesic_cert_ok rfl

/-! ## Adversarial Source Rejection Proofs (`= false := rfl`) -/

/-- Adv-R1-A: Unlicensed `0xFF33` jump `EVENT → PROPOSITION` is rejected. -/
def snapBadSortJump : SourceSnapshot :=
  { snapHyper with
    irRecords :=
      [ { recordId := "rec.illegal.jump"
          sourceVid := 3
          sourceSort := .event
          refs :=
            [ { targetVid := 1, targetSort := .proposition,
                relSrcSort := .event, relDstSort := .proposition } ] } ] }

theorem adv_r1_rejects_forbidden_0xFF33_jump :
    checkSourceAnchorAndSortLaw pinnedRegR1 snapBadSortJump = false := rfl

/-- Adv-R1-B: Unauthorized external authority tiers `A2` (`2`) and `A3` (`3`) are rejected. -/
theorem adv_r1_rejects_a2_and_a3_authority :
    checkSourceAnchorAndSortLaw pinnedRegR1 { snapHyper with authTierTag := 2 } = false ∧
    checkSourceAnchorAndSortLaw pinnedRegR1 { snapHyper with authTierTag := 3 } = false :=
  ⟨rfl, rfl⟩

/-- Adv-R1-C: Duplicate `recordId` is rejected (prevents `|D_str| < |D|` cardinality collapse). -/
def snapDupRecordId : SourceSnapshot :=
  { snapHyper with
    irRecords :=
      [ { recordId := "rec.dup.id"
          sourceVid := 0
          sourceSort := .derivation
          refs := [] },
        { recordId := "rec.dup.id"
          sourceVid := 1
          sourceSort := .proposition
          refs := [] } ] }

theorem adv_r1_rejects_duplicate_record_id :
    checkSourceAnchorAndSortLaw pinnedRegR1 snapDupRecordId = false := rfl

/-- Adv-R1-D: Duplicate vertex `AsciiId` is rejected. -/
def snapDupVertexId : SourceSnapshot :=
  { snapHyper with
    vertexIds := ["v.same", "v.same", "v.prop.2", "v.event.3"] }

theorem adv_r1_rejects_duplicate_vertex_id :
    checkSourceAnchorAndSortLaw pinnedRegR1 snapDupVertexId = false := rfl

/-- Adv-R1-E: Unpinned / forged snapshot root is rejected. -/
theorem adv_r1_rejects_forged_snapshot_root :
    checkSourceAnchorAndSortLaw pinnedRegR1
      { snapHyper with claimedRootHex := "ffffffffffffffffffffffffffffffff" } = false := rfl

end OmegaLambda.R1Examples

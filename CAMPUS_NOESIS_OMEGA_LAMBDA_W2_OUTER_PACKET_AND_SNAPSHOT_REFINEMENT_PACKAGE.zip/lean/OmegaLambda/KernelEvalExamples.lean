/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 5: `OmegaLambda.KernelEvalExamples`

  Layer 2 (`F81-02`): Definitional Kernel Reduction (`:= rfl`) over concrete finite
  terms and adversarial attack vectors — ZERO `native_decide`, ZERO `Lean.ofReduceBool`,
  ZERO `Lean.trustCompiler`.
-/

import OmegaLambda.CheckerSoundness

namespace OmegaLambda.Examples

open OmegaLambda

/-! ## Example 1: `F82-01` Reflexive LocalPacket (`Level A` `UNBREAKABLE` + Rejections) -/

def ex1Part : IssuerPartition :=
  { constIssuers := [1], remIssuers := [10, 11] }

def ex1Base : BaseData :=
  { G := f82Graph
    kappa := .eStar
    rankEntries := [(0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0)]
    maxHopEntries := [(0, 0, []), (0, 1, [1]), (1, 0, [0]), (1, 1, [])] }

def ex1ReflCert : ResilienceCert :=
  .localReflexive (.unbreakableWalk [])

theorem ex1_base_ok : checkVerifiedBase ex1Part ex1Base = true := rfl

theorem ex1_f82_01_local_refl_accept :
    checkOmegaLambdaResilience ex1Part ex1Base 0 0
      (.localPacket f82Packet) ex1ReflCert = true := rfl

theorem ex1_f82_01_semantic_unbreakable :
    ScopedSemanticResilience ex1Part ex1Base 0 0
      (.localPacket f82Packet) .unbreakable :=
  omegaLambda_resilience_sound ex1Part ex1Base 0 0
    (.localPacket f82Packet) ex1ReflCert ex1_base_ok ex1_f82_01_local_refl_accept

/-- Rejects applying `.localPositive` when `pkt` contains a 0-step walk `[0]`. -/
theorem ex1_reject_local_positive_on_zero_step :
    checkOmegaLambdaResilience ex1Part ex1Base 0 0
      (.localPacket f82Packet) (.localPositive (.unbreakableWalk [])) = false := rfl

/-! ## Example 2: Positive LocalPacket (`EXACT = 2` + Cross-Path Splice Rejection) -/

def ex2Part : IssuerPartition :=
  { constIssuers := [], remIssuers := [10, 11, 12, 13, 14] }

def ex2Base : BaseData :=
  { G :=
      { numVertices := 4
        edges := [
          { src := 0, dst := 1, support := [10] },
          { src := 1, dst := 3, support := [11] },
          { src := 0, dst := 2, support := [12] },
          { src := 2, dst := 3, support := [13] },
          { src := 1, dst := 2, support := [14] }
        ] }
    kappa := .ePlus
    rankEntries := [
      (0, 1, 1), (0, 2, 1), (0, 3, 2),
      (1, 2, 1), (1, 3, 1),
      (2, 3, 1)
    ]
    maxHopEntries := [
      (0, 1, [1]), (0, 2, [2]), (0, 3, [1, 2]),
      (1, 2, [2]), (1, 3, [3]),
      (2, 3, [3])
    ] }

def ex2Pkt : List (List VertexId) :=
  [[0, 1, 3], [0, 2, 3]]

def ex2Chain0 : LowerWitnessWalk LocalState :=
  { transitions := [
      { src := .init, support := [10], dst := .mid 0 1 },
      { src := .mid 0 1, support := [11], dst := .final }
    ]
    stepWitnesses := [.retractableIssuer 10, .retractableIssuer 11] }

def ex2Chain1 : LowerWitnessWalk LocalState :=
  { transitions := [
      { src := .init, support := [12], dst := .mid 1 1 },
      { src := .mid 1 1, support := [13], dst := .final }
    ]
    stepWitnesses := [.retractableIssuer 12, .retractableIssuer 13] }

def ex2Cert : ResilienceCert :=
  .localPositive
    (.finiteBounds 2 2 [ex2Chain0, ex2Chain1] [10, 12] [.init])

theorem ex2_base_ok : checkVerifiedBase ex2Part ex2Base = true := rfl

theorem ex2_local_positive_accept :
    checkOmegaLambdaResilience ex2Part ex2Base 0 3
      (.localPacket ex2Pkt) ex2Cert = true := rfl

theorem ex2_local_positive_exact_2 :
    (∀ D : List IssuerId,
      NodupList D →
      (∀ d ∈ D, d ∈ ex2Part.remIssuers) →
      ¬ CarrierSurvives ex2Base 0 3 (.localPacket ex2Pkt) D →
      2 ≤ D.length) ∧
    (∃ Dstar : List IssuerId,
      NodupList Dstar ∧
      (∀ d ∈ Dstar, d ∈ ex2Part.remIssuers) ∧
      Dstar.length = 2 ∧
      ¬ CarrierSurvives ex2Base 0 3 (.localPacket ex2Pkt) Dstar) :=
  omegaLambda_exact_resilience_sound ex2Part ex2Base 0 3
    (.localPacket ex2Pkt) ex2Cert 2 ex2_base_ok ex2_local_positive_accept rfl

/-- Cross-path splicing attack: jumping from `.mid 0 1` to `.mid 1 1` / `.final` is rejected. -/
def ex2SplicedWalk : LowerWitnessWalk LocalState :=
  { transitions := [
      { src := .init, support := [10], dst := .mid 0 1 },
      { src := .mid 1 1, support := [13], dst := .final }
    ]
    stepWitnesses := [.retractableIssuer 10, .retractableIssuer 13] }

theorem ex2_reject_cross_path_splice :
    checkOmegaLambdaResilience ex2Part ex2Base 0 3 (.localPacket ex2Pkt)
      (.localPositive (.finiteBounds 1 2 [ex2SplicedWalk] [10, 12] [.init])) = false := rfl

/-- Carrier substitution attack: submitting `.globalPlus` cert against `.localPacket` carrier. -/
theorem ex2_reject_carrier_substitution :
    checkOmegaLambdaResilience ex2Part ex2Base 0 3 (.localPacket ex2Pkt)
      (.globalPlus (.unbreakableWalk [])) = false := rfl

/-! ## Example 3: `K_3` Hyperedge Polarity (Shared Single Issuer vs Co-Issued Edge) -/

def ex3Part : IssuerPartition :=
  { constIssuers := [], remIssuers := [10, 11, 12] }

/-- Polarity A: Single issuer `10` supports BOTH `0 → 1` and `0 → 2`, so `D = [10]` cuts both (`EXACT = 1`). -/
def ex3SharedBase : BaseData :=
  { G :=
      { numVertices := 4
        edges := [
          { src := 0, dst := 1, support := [10] },
          { src := 1, dst := 3, support := [11] },
          { src := 0, dst := 2, support := [10] },
          { src := 2, dst := 3, support := [12] }
        ] }
    kappa := .ePlus
    rankEntries := [(0, 1, 1), (0, 2, 1), (0, 3, 2), (1, 3, 1), (2, 3, 1)]
    maxHopEntries := [(0, 1, [1]), (0, 2, [2]), (0, 3, [1, 2]), (1, 3, [3]), (2, 3, [3])] }

def ex3SharedWalk : LowerWitnessWalk PlusState :=
  { transitions := [
      { src := .start, support := [10], dst := .act 1 },
      { src := .act 1, support := [11], dst := .act 3 }
    ]
    stepWitnesses := [.retractableIssuer 10, .retractableIssuer 11] }

def ex3SharedWalkDup : LowerWitnessWalk PlusState :=
  { transitions := [
      { src := .start, support := [10], dst := .act 2 },
      { src := .act 2, support := [12], dst := .act 3 }
    ]
    stepWitnesses := [.retractableIssuer 10, .retractableIssuer 12] }

theorem ex3_shared_base_ok : checkVerifiedBase ex3Part ex3SharedBase = true := rfl

theorem ex3_shared_exact_1_accept :
    checkOmegaLambdaResilience ex3Part ex3SharedBase 0 3 .globalGraph
      (.globalPlus (.finiteBounds 1 1 [ex3SharedWalk] [10] [.start])) = true := rfl

/-- Overclaiming `lower = 2` when both witness walks share retractable issuer `10` is rejected. -/
theorem ex3_shared_reject_non_disjoint_lower_2 :
    checkOmegaLambdaResilience ex3Part ex3SharedBase 0 3 .globalGraph
      (.globalPlus (.finiteBounds 2 2 [ex3SharedWalk, ex3SharedWalkDup] [10, 11] [.start])) =
      false := rfl

/-- Polarity B: Co-issued single edge `0 → 1` with `support = [10, 11]` requires BOTH `[10, 11]` (`EXACT = 2`). -/
def ex3CoIssuedBase : BaseData :=
  { G :=
      { numVertices := 2
        edges := [{ src := 0, dst := 1, support := [10, 11] }] }
    kappa := .ePlus
    rankEntries := [(0, 1, 1)]
    maxHopEntries := [(0, 1, [1])] }

theorem ex3_coissued_base_ok : checkVerifiedBase ex3Part ex3CoIssuedBase = true := rfl

/-- Deleting `[10]` alone fails to cut co-issued edge `support = [10, 11]`. -/
theorem ex3_coissued_reject_partial_cut :
    checkOmegaLambdaResilience ex3Part ex3CoIssuedBase 0 1 .globalGraph
      (.globalPlus (.finiteBounds 1 1
        [{ transitions := [{ src := .start, support := [10, 11], dst := .act 1 }]
           stepWitnesses := [.retractableIssuer 10] }]
        [10] [.start])) = false := rfl

theorem ex3_coissued_exact_2_accept :
    checkOmegaLambdaResilience ex3Part ex3CoIssuedBase 0 1 .globalGraph
      (.globalPlus (.finiteBounds 2 2
        [{ transitions := [{ src := .start, support := [10, 11], dst := .act 1 }]
           stepWitnesses := [.retractableIssuer 10] },
         { transitions := [{ src := .start, support := [10, 11], dst := .act 1 }]
           stepWitnesses := [.retractableIssuer 11] }]
        [10, 11] [.start])) = true := rfl

/-! ## Example 4: `E_PLUS` Self-Cycle (`s = t = 0`, Positive Length Enforced) -/

def ex4Part : IssuerPartition :=
  { constIssuers := [], remIssuers := [10, 11] }

def ex4Base : BaseData :=
  { G := f82Graph
    kappa := .ePlus
    rankEntries := [(0, 0, 2), (0, 1, 1), (1, 0, 1), (1, 1, 2)]
    maxHopEntries := [(0, 0, [1]), (0, 1, [1]), (1, 0, [0]), (1, 1, [0])] }

theorem ex4_base_ok : checkVerifiedBase ex4Part ex4Base = true := rfl

def ex4SelfCycleCert : ResilienceCert :=
  .globalPlus (.finiteBounds 1 1
    [{ transitions := [
         { src := .start, support := [10], dst := .act 1 },
         { src := .act 1, support := [11], dst := .act 0 }
       ]
       stepWitnesses := [.retractableIssuer 10, .retractableIssuer 11] }]
    [10] [.start])

theorem ex4_eplus_self_cycle_accept :
    checkOmegaLambdaResilience ex4Part ex4Base 0 0 .globalGraph ex4SelfCycleCert = true := rfl

theorem ex4_eplus_self_cycle_exact_1 :
    (∀ D : List IssuerId,
      NodupList D →
      (∀ d ∈ D, d ∈ ex4Part.remIssuers) →
      ¬ CarrierSurvives ex4Base 0 0 .globalGraph D →
      1 ≤ D.length) ∧
    (∃ Dstar : List IssuerId,
      NodupList Dstar ∧
      (∀ d ∈ Dstar, d ∈ ex4Part.remIssuers) ∧
      Dstar.length = 1 ∧
      ¬ CarrierSurvives ex4Base 0 0 .globalGraph Dstar) :=
  omegaLambda_exact_resilience_sound ex4Part ex4Base 0 0
    .globalGraph ex4SelfCycleCert 1 ex4_base_ok ex4_eplus_self_cycle_accept rfl

/-- Reflexive 0-step `[0]` is rejected under `E_PLUS` even when `s = t = 0`. -/
theorem ex4_reject_reflexive_under_eplus :
    checkOmegaLambdaResilience ex4Part ex4Base 0 0
      (.localPacket [[0]]) (.localReflexive (.unbreakableWalk [])) = false := rfl

/-! ## Example 5: `Geodesic E_PLUS` (`EXACT = 1`) vs `Global E_PLUS` (`EXACT = 2`) -/

def ex5GeoCert : ResilienceCert :=
  .geodesic (.finiteBounds 1 1
    [{ transitions := [{ src := .start, support := [10], dst := .act 2 }]
       stepWitnesses := [.retractableIssuer 10] }]
    [10] [.start])

def ex5GlobCert : ResilienceCert :=
  .globalPlus (.finiteBounds 2 2
    [{ transitions := [{ src := .start, support := [10], dst := .act 2 }]
       stepWitnesses := [.retractableIssuer 10] },
     { transitions := [
         { src := .start, support := [11], dst := .act 1 },
         { src := .act 1, support := [11], dst := .act 2 }
       ]
       stepWitnesses := [.retractableIssuer 11, .retractableIssuer 11] }]
    [10, 11] [.start])

theorem ex5_sep_base_ok : checkVerifiedBase sepPartition sepBase = true := rfl

theorem ex5_geodesic_exact_1_accept :
    checkOmegaLambdaResilience sepPartition sepBase 0 2 .geodesicBundle ex5GeoCert = true := rfl

theorem ex5_global_plus_exact_2_accept :
    checkOmegaLambdaResilience sepPartition sepBase 0 2 .globalGraph ex5GlobCert = true := rfl

/-- Claiming `D = [10]` cuts `Global E_PLUS` on `sepBase` is rejected because detour `0→1→2` survives. -/
theorem ex5_reject_detour_blind_global_cut :
    checkOmegaLambdaResilience sepPartition sepBase 0 2 .globalGraph
      (.globalPlus (.finiteBounds 1 1
        [{ transitions := [{ src := .start, support := [10], dst := .act 2 }]
           stepWitnesses := [.retractableIssuer 10] }]
        [10] [.start, .act 1])) = false := rfl

/-! ## Example 6: `F76-01` Mixed Immutable Step Witness & `B5` Spoofed Rank Rejection -/

def ex6Part : IssuerPartition :=
  { constIssuers := [1], remIssuers := [10, 11] }

def ex6Base : BaseData :=
  { G :=
      { numVertices := 3
        edges := [
          { src := 0, dst := 1, support := [1, 10] },
          { src := 1, dst := 2, support := [11] }
        ] }
    kappa := .eStar
    rankEntries := [(0, 0, 0), (0, 1, 1), (0, 2, 2), (1, 1, 0), (1, 2, 1), (2, 2, 0)]
    maxHopEntries := [(0, 1, [1]), (0, 2, [1]), (1, 2, [2])] }

theorem ex6_base_ok : checkVerifiedBase ex6Part ex6Base = true := rfl

/-- Valid `F76-01` step witness marks mixed edge `[1, 10]` as `.immutableStep`. -/
theorem ex6_mixed_immutable_step_accept :
    checkOmegaLambdaResilience ex6Part ex6Base 0 2 .globalGraph
      (.globalStar (.finiteBounds 1 1
        [{ transitions := [
             { src := 0, support := [1, 10], dst := 1 },
             { src := 1, support := [11], dst := 2 }
           ]
           stepWitnesses := [.immutableStep, .retractableIssuer 11] }]
        [11] [0, 1])) = true := rfl

/-- Forging `.retractableIssuer 10` on mixed immutable edge `[1, 10]` is rejected (`F76-01`). -/
theorem ex6_reject_forged_retractable_on_immutable_edge :
    checkOmegaLambdaResilience ex6Part ex6Base 0 2 .globalGraph
      (.globalStar (.finiteBounds 1 1
        [{ transitions := [
             { src := 0, support := [1, 10], dst := 1 },
             { src := 1, support := [11], dst := 2 }
           ]
           stepWitnesses := [.retractableIssuer 10, .retractableIssuer 11] }]
        [11] [0, 1])) = false := rfl

/-- Spoofing `rank(0, 2) = 1` without a direct edge `0 → 2` is rejected by `checkVerifiedBase` (`B5`). -/
def ex6SpoofedRankBase : BaseData :=
  { ex6Base with
    rankEntries := [(0, 0, 0), (0, 1, 1), (0, 2, 1), (1, 1, 0), (1, 2, 1), (2, 2, 0)] }

theorem ex6_reject_spoofed_b5_rank :
    checkVerifiedBase ex6Part ex6SpoofedRankBase = false := rfl

end OmegaLambda.Examples

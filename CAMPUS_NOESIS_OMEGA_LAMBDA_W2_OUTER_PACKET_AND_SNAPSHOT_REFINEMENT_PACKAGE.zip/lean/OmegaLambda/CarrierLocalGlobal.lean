/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 3A: `OmegaLambda.CarrierLocalGlobal`

  Formalizes:
    - `F82-01` Two-Level Semantic Refinement Hierarchy:
        * Level A: `ResilienceObsEquiv` (`C ≃_res M`)
        * Level B: `PathwiseBijection` (`C ≅_paths M`)
        * `levelB_implies_levelA` (`Level B ⇒ Level A`)
    - Carrier 1A (`LocalPacket` with 0-step reflexive walk):
        * `ref_loc_reflexive_levelA` (`Level A` holds)
        * `f82_01_local_reflexive_not_path_bijection` (`Level B` fails on `pkt = [[0], [0, 1, 0]]`)
    - Carrier 1B (`LocalPacket` with all positive walks):
        * `LocalState` (`init | mid j l | final`, `final` out-degree `0`)
        * `no_cross_path_splicing`, `ref_loc_positive_levelB`, `ref_loc_positive_levelA`
    - Carrier 3 (`Global E_STAR`):
        * `mkGlobalStarLTS`, `ref_glob_star_levelB`, `ref_glob_star_levelA`
    - Carrier 4 (`Global E_PLUS`):
        * `PlusState` (`start | act v`, `start ≠ act t` even if `s = t`),
          `mkGlobalPlusLTS`, `glob_plus_walk_pos_length`,
          `ref_glob_plus_levelB`, `ref_glob_plus_levelA`
-/

import OmegaLambda.GraphBase

namespace OmegaLambda

/-! ## `F82-01` Two-Level Semantic Refinement Hierarchy -/

/-- Level A (`F82-01`): Resilience-Observational Equivalence (`C ≃_res M`). -/
def ResilienceObsEquiv (survPred : List IssuerId → Prop) (M : PointedLTS Q) : Prop :=
  ∀ D : List IssuerId, survPred D ↔ LTSReachable M D M.q0 M.qf

/-- Level B (`F82-01`): Survival-preserving Pathwise Bijection (`C ≅_paths M`). -/
structure PathwiseBijection (CarrierPred : List VertexId → Prop)
    (G : LabeledGraph) (M : PointedLTS Q) where
  toLTS : (γ : List VertexId) → CarrierPred γ → List (Trans Q)
  toLTS_valid : ∀ γ (h : CarrierPred γ), LTSWalk M M.q0 M.qf (toLTS γ h)
  ofLTS : (τ : List (Trans Q)) → LTSWalk M M.q0 M.qf τ → List VertexId
  ofLTS_valid : ∀ τ (hw : LTSWalk M M.q0 M.qf τ), CarrierPred (ofLTS τ hw)
  left_inv : ∀ γ (h : CarrierPred γ), ofLTS (toLTS γ h) (toLTS_valid γ h) = γ
  right_inv : ∀ τ (hw : LTSWalk M M.q0 M.qf τ), toLTS (ofLTS τ hw) (ofLTS_valid τ hw) = τ
  survives_iff : ∀ γ (h : CarrierPred γ) (D : List IssuerId),
    WalkSurvivesGraph G D γ ↔ WalkSurvives (toLTS γ h) D

/-- Universal Bridge (`Level B ⇒ Level A`): Every Pathwise Bijection induces
    Resilience-Observational Equivalence. -/
theorem levelB_implies_levelA {CarrierPred : List VertexId → Prop}
    {G : LabeledGraph} {M : PointedLTS Q}
    (bij : PathwiseBijection CarrierPred G M) :
    ResilienceObsEquiv (fun D => ∃ γ, CarrierPred γ ∧ WalkSurvivesGraph G D γ) M := by
  intro D
  constructor
  · intro ⟨γ, hγ, hsurv⟩
    exact ⟨bij.toLTS γ hγ, bij.toLTS_valid γ hγ, (bij.survives_iff γ hγ D).mp hsurv⟩
  · intro ⟨τ, hw, hsurv⟩
    let γ := bij.ofLTS τ hw
    have hγ : CarrierPred γ := bij.ofLTS_valid τ hw
    have heq : bij.toLTS γ hγ = τ := bij.right_inv τ hw
    refine ⟨γ, hγ, ?_⟩
    apply (bij.survives_iff γ hγ D).mpr
    rw [heq]
    exact hsurv

/-! ## Carrier 1A: `LocalPacket` Reflexive Case (`Level A` Holds, `Level B` Counterexample) -/

def mkLocalReflexiveLTS : PointedLTS Unit :=
  { q0 := (), qf := (), delta := [] }

theorem localReflexive_unique_walk {τ : List (Trans Unit)}
    (hw : LTSWalk mkLocalReflexiveLTS () () τ) : τ = [] := by
  cases hw with
  | nil => rfl
  | cons _ _ hmem _ _ _ => cases hmem

/-- `Ref-Loc` Reflexive (`F82-01` Level A): When `pkt` contains a 0-step walk,
    `mkLocalReflexiveLTS` satisfies `ResilienceObsEquiv` (`Level A`). -/
theorem ref_loc_reflexive_levelA {G : LabeledGraph} {s t : VertexId}
    {pkt : List (List VertexId)}
    (hzero : ∃ γ ∈ pkt, IsValidWalk G .eStar s t γ ∧ walkSteps γ = 0) :
    ResilienceObsEquiv (fun D => ∃ γ ∈ pkt, WalkSurvivesGraph G D γ) mkLocalReflexiveLTS := by
  intro D
  rcases hzero with ⟨γ0, hmem0, hvw0, hlen0⟩
  constructor
  · intro _
    exact ⟨[], LTSWalk.nil (), fun _ h => nomatch h⟩
  · intro _
    cases γ0 with
    | nil => cases hvw0
    | cons v0 tail =>
      cases tail with
      | cons _ _ => simp [walkSteps] at hlen0
      | nil =>
        exact ⟨[v0], hmem0, trivial⟩

/-- Concrete 2-vertex directed graph from 82nd Tribunal Ruling §2 (`F82-01`). -/
def f82Graph : LabeledGraph :=
  { numVertices := 2
    edges := [
      { src := 0, dst := 1, support := [10] },
      { src := 1, dst := 0, support := [11] }
    ] }

def f82Packet : List (List VertexId) :=
  [[0], [0, 1, 0]]

/-- `F82-01` Mechanized Counterexample Theorem:
    On `f82Packet = [[0], [0, 1, 0]]` under `E_STAR`, all paths in `f82Packet` are valid
    `0 → 0` walks and `Level A` holds, yet NO `Level B` `PathwiseBijection` exists into
    `mkLocalReflexiveLTS` (`Level A ⇏ Level B`). -/
theorem f82_01_local_reflexive_not_path_bijection :
    (∀ γ ∈ f82Packet, IsValidWalk f82Graph .eStar 0 0 γ) ∧
    ResilienceObsEquiv (fun D => ∃ γ ∈ f82Packet, WalkSurvivesGraph f82Graph D γ)
      mkLocalReflexiveLTS ∧
    ¬ Nonempty (PathwiseBijection (fun γ => γ ∈ f82Packet) f82Graph mkLocalReflexiveLTS) := by
  refine ⟨?_, ?_, ?_⟩
  · intro γ hmem
    cases hmem with
    | head =>
      refine ⟨rfl, by decide, by decide, IsEdgeChain.nil 0, fun h => nomatch h⟩
    | tail _ hm2 =>
      cases hm2 with
      | head =>
        refine ⟨rfl, by decide, by decide, ?_, fun h => nomatch h⟩
        exact IsEdgeChain.cons { src := 0, dst := 1, support := [10] } [0]
          (List.Mem.head _) rfl rfl
          (IsEdgeChain.cons { src := 1, dst := 0, support := [11] } []
            (List.Mem.tail _ (List.Mem.head _)) rfl rfl (IsEdgeChain.nil 0))
      | tail _ hm3 => cases hm3
  · apply ref_loc_reflexive_levelA (s := 0) (t := 0)
    refine ⟨[0], List.Mem.head _, ?_, rfl⟩
    exact ⟨rfl, by decide, by decide, IsEdgeChain.nil 0, fun h => nomatch h⟩
  · intro ⟨bij⟩
    have h0 : ([0] : List VertexId) ∈ f82Packet := List.Mem.head _
    have h1 : ([0, 1, 0] : List VertexId) ∈ f82Packet := List.Mem.tail _ (List.Mem.head _)
    have heq0 : bij.toLTS [0] h0 = [] :=
      localReflexive_unique_walk (bij.toLTS_valid [0] h0)
    have heq1 : bij.toLTS [0, 1, 0] h1 = [] :=
      localReflexive_unique_walk (bij.toLTS_valid [0, 1, 0] h1)
    have hofEmpty : ∀ (τ : List (Trans Unit)) (hw : LTSWalk mkLocalReflexiveLTS () () τ),
        τ = [] → bij.ofLTS τ hw = bij.ofLTS [] (LTSWalk.nil ()) := by
      intro τ hw hτ
      subst hτ
      rfl
    have hc0 : [0] = bij.ofLTS [] (LTSWalk.nil ()) := by
      rw [← bij.left_inv [0] h0]
      exact hofEmpty _ _ heq0
    have hc1 : [0, 1, 0] = bij.ofLTS [] (LTSWalk.nil ()) := by
      rw [← bij.left_inv [0, 1, 0] h1]
      exact hofEmpty _ _ heq1
    have hbad : ([0] : List VertexId) = [0, 1, 0] := hc0.trans hc1.symm
    injection hbad with _ htail
    contradiction

/-! ## Carrier 1B: `LocalPacket` Positive Chains (`Level A + Level B`, Zero Splicing) -/

inductive LocalState where
  | init : LocalState
  | mid : (chainIdx : Nat) → (stepIdx : Nat) → LocalState
  | final : LocalState
  deriving DecidableEq, Repr

def locStateAt (j totalSteps ell : Nat) : LocalState :=
  if ell = 0 then .init
  else if ell = totalSteps then .final
  else .mid j ell

def buildChainTransAux (G : LabeledGraph) (j totalSteps ell : Nat) :
    VertexId → List VertexId → List (Trans LocalState)
  | _, [] => []
  | u, w :: rest =>
      { src := locStateAt j totalSteps ell
        support := (edgeSupport? G u w).getD []
        dst := locStateAt j totalSteps (ell + 1) } ::
      buildChainTransAux G j totalSteps (ell + 1) w rest

def buildChainTrans (G : LabeledGraph) (j : Nat) : List VertexId → List (Trans LocalState)
  | [] => []
  | v0 :: tail => buildChainTransAux G j tail.length 0 v0 tail

def buildAllChainsAux (G : LabeledGraph) (j : Nat) : List (List VertexId) → List (Trans LocalState)
  | [] => []
  | γ :: rest => buildChainTrans G j γ ++ buildAllChainsAux G (j + 1) rest

def mkLocalPositiveLTS (G : LabeledGraph) (pkt : List (List VertexId)) : PointedLTS LocalState :=
  { q0 := .init
    qf := .final
    delta := buildAllChainsAux G 0 pkt }

/-- Index lookup in duplicate-free packet `pkt`. -/
def indexOfWalkAux [DecidableEq α] (target : α) (idx : Nat) : List α → Nat
  | [] => idx
  | x :: rest => if x = target then idx else indexOfWalkAux target (idx + 1) rest

def indexOfWalk [DecidableEq α] (target : α) (xs : List α) : Nat :=
  indexOfWalkAux target 0 xs

def getWalkAt (pkt : List (List VertexId)) (j : Nat) (fallback : List VertexId) : List VertexId :=
  match pkt[j]? with
  | some γ => γ
  | none => fallback

theorem indexOfWalkAux_lt_and_eq [DecidableEq α] {target : α} {xs : List α}
    (hmem : target ∈ xs) (idx : Nat) :
    ∃ k < xs.length, indexOfWalkAux target idx xs = idx + k ∧ xs[k]? = some target := by
  induction xs generalizing idx with
  | nil => cases hmem
  | cons x rest ih =>
    simp only [indexOfWalkAux]
    split
    · next heq =>
      subst heq
      exact ⟨0, Nat.zero_lt_succ rest.length, by omega, rfl⟩
    · next hne =>
      cases hmem with
      | head => exact absurd rfl hne
      | tail _ hm =>
        rcases ih hm (idx + 1) with ⟨k, hklt, hkeq, hget⟩
        refine ⟨k + 1, Nat.succ_lt_succ hklt, by omega, ?_⟩
        simpa using hget

theorem indexOfWalk_spec [DecidableEq α] {target : α} {xs : List α} (hmem : target ∈ xs) :
    indexOfWalk target xs < xs.length ∧ xs[indexOfWalk target xs]? = some target := by
  rcases indexOfWalkAux_lt_and_eq hmem 0 with ⟨k, hklt, hkeq, hget⟩
  simp only [indexOfWalk, Nat.zero_add] at hkeq ⊢
  rw [hkeq]
  exact ⟨hklt, hget⟩

theorem nodup_getElem?_inj {xs : List α} (hnd : NodupList xs)
    {i j : Nat} {v : α} (hi : xs[i]? = some v) (hj : xs[j]? = some v) : i = j := by
  induction xs generalizing i j with
  | nil => simp at hi
  | cons x rest ih =>
    cases hnd with
    | cons hnotmem hndRest =>
      cases i with
      | zero =>
        simp at hi
        subst hi
        cases j with
        | zero => rfl
        | succ j' =>
          simp at hj
          exfalso
          exact hnotmem (List.mem_of_getElem? hj)
      | succ i' =>
        simp at hi
        cases j with
        | zero =>
          simp at hj
          subst hj
          exfalso
          exact hnotmem (List.mem_of_getElem? hi)
        | succ j' =>
          simp at hj
          exact congrArg Nat.succ (ih hndRest hi hj)

theorem indexOfWalk_of_getElem? [DecidableEq α] {xs : List α} (hnd : NodupList xs)
    {j : Nat} {v : α} (hj : xs[j]? = some v) : indexOfWalk v xs = j := by
  have hmem : v ∈ xs := List.mem_of_getElem? hj
  have hspec := (indexOfWalk_spec hmem).2
  exact nodup_getElem?_inj hnd hspec hj

theorem valid_len1_walk_unique {G : LabeledGraph} {κ : ClosureKind} {s t : VertexId}
    {γ : List VertexId} (hvw : IsValidWalk G κ s t γ) (hlen : walkSteps γ = 1) :
    γ = [s, t] := by
  cases γ with
  | nil => cases hvw
  | cons v0 tail =>
    cases tail with
    | nil => simp [walkSteps] at hlen
    | cons w rest =>
      cases rest with
      | cons _ _ => simp [walkSteps] at hlen
      | nil =>
        rcases hvw with ⟨rfl, _, _, hc, _⟩
        cases hc with
        | cons _ _ _ _ _ hc2 =>
          cases hc2 with
          | nil _ => rfl

/-- Membership characterization for `buildChainTransAux`. -/
theorem mem_buildChainTransAux_iff {G : LabeledGraph} {j totalSteps ell : Nat}
    {u : VertexId} {tail : List VertexId} {tr : Trans LocalState} :
    tr ∈ buildChainTransAux G j totalSteps ell u tail ↔
    ∃ k : Nat, ∃ x y : VertexId,
      k < tail.length ∧
      (u :: tail)[k]? = some x ∧
      tail[k]? = some y ∧
      tr = { src := locStateAt j totalSteps (ell + k)
             support := (edgeSupport? G x y).getD []
             dst := locStateAt j totalSteps (ell + k + 1) } := by
  induction tail generalizing ell u with
  | nil =>
    simp [buildChainTransAux]
  | cons w rest ih =>
    simp only [buildChainTransAux, List.mem_cons, ih]
    constructor
    · intro h
      cases h with
      | inl heq =>
        refine ⟨0, u, w, Nat.zero_lt_succ rest.length, rfl, rfl, ?_⟩
        simpa [Nat.add_zero] using heq
      | inr hrec =>
        rcases hrec with ⟨k, x, y, hklt, hx, hy, htr⟩
        refine ⟨k + 1, x, y, Nat.succ_lt_succ hklt, hx, hy, ?_⟩
        have hadj1 : ell + 1 + k = ell + (k + 1) := by omega
        rw [hadj1] at htr
        exact htr
    · intro ⟨k, x, y, hklt, hx, hy, htr⟩
      cases k with
      | zero =>
        simp at hx hy
        subst hx; subst hy
        left
        simpa [Nat.add_zero] using htr
      | succ k' =>
        right
        refine ⟨k', x, y, Nat.lt_of_succ_lt_succ hklt, hx, hy, ?_⟩
        have hadj1 : ell + 1 + k' = ell + (k' + 1) := by omega
        rw [hadj1]
        exact htr

theorem mem_buildAllChainsAux_iff {G : LabeledGraph} {j0 : Nat}
    {pkt : List (List VertexId)} {tr : Trans LocalState} :
    tr ∈ buildAllChainsAux G j0 pkt ↔
    ∃ idx < pkt.length, ∃ γ, pkt[idx]? = some γ ∧ tr ∈ buildChainTrans G (j0 + idx) γ := by
  induction pkt generalizing j0 with
  | nil =>
    simp [buildAllChainsAux]
  | cons γ rest ih =>
    simp only [buildAllChainsAux, List.mem_append, ih]
    constructor
    · intro h
      cases h with
      | inl hhead =>
        refine ⟨0, Nat.zero_lt_succ rest.length, γ, rfl, ?_⟩
        simpa using hhead
      | inr htail =>
        rcases htail with ⟨idx, hlt, γ', hget, hmem⟩
        refine ⟨idx + 1, Nat.succ_lt_succ hlt, γ', hget, ?_⟩
        have hadj : j0 + 1 + idx = j0 + (idx + 1) := by omega
        rw [← hadj]
        exact hmem
    · intro ⟨idx, hlt, γ', hget, hmem⟩
      cases idx with
      | zero =>
        simp at hget
        subst hget
        left
        simpa using hmem
      | succ idx' =>
        right
        refine ⟨idx', Nat.lt_of_succ_lt_succ hlt, γ', hget, ?_⟩
        have hadj : j0 + 1 + idx' = j0 + (idx' + 1) := by omega
        rw [hadj]
        exact hmem

/-- Out-degree of `.final` is strictly `0` in `mkLocalPositiveLTS`. -/
theorem localPositive_final_no_outgoing {G : LabeledGraph} {pkt : List (List VertexId)}
    (hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ)
    {tr : Trans LocalState} (hmem : tr ∈ (mkLocalPositiveLTS G pkt).delta) :
    tr.src ≠ .final := by
  rcases (mem_buildAllChainsAux_iff.mp hmem) with ⟨idx, _, γ, hget, htr⟩
  simp only [Nat.zero_add] at htr
  have hγmem : γ ∈ pkt := List.mem_of_getElem? hget
  have hlen1 : 1 ≤ walkSteps γ := hpos γ hγmem
  cases γ with
  | nil => simp [walkSteps] at hlen1
  | cons v0 tail =>
    rcases (mem_buildChainTransAux_iff.mp htr) with ⟨k, _, _, hklt, _, _, rfl⟩
    simp only [locStateAt, Nat.zero_add]
    split
    · intro h; cases h
    · split
      · next hkEq => omega
      · intro h; cases h

theorem localPositive_walk_from_final_nil {G : LabeledGraph} {pkt : List (List VertexId)}
    (hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ) {q : LocalState} {τ : List (Trans LocalState)}
    (hw : LTSWalk (mkLocalPositiveLTS G pkt) .final q τ) :
    q = .final ∧ τ = [] := by
  cases hw with
  | nil => exact ⟨rfl, rfl⟩
  | cons tr _ hmem hsrc _ _ =>
    exfalso
    exact localPositive_final_no_outgoing hpos hmem hsrc

/-- Forward walk construction for suffix starting at step `ell` of chain `j`. -/
theorem buildChainTransAux_is_walk {G : LabeledGraph} {pkt : List (List VertexId)}
    {j : Nat} {v0 : VertexId} {fullTail : List VertexId}
    (hget : pkt[j]? = some (v0 :: fullTail))
    (hlen : fullTail.length ≥ 1) :
    ∀ (ell : Nat) (u : VertexId) (remTail : List VertexId),
      ell + remTail.length = fullTail.length →
      (∀ k < remTail.length,
        (u :: remTail)[k]? = (v0 :: fullTail)[ell + k]? ∧
        remTail[k]? = fullTail[ell + k]?) →
      LTSWalk (mkLocalPositiveLTS G pkt)
        (locStateAt j fullTail.length ell)
        .final
        (buildChainTransAux G j fullTail.length ell u remTail) := by
  intro ell u remTail hsum halign
  induction remTail generalizing ell u with
  | nil =>
    simp only [List.length_nil, Nat.add_zero] at hsum
    simp only [buildChainTransAux, hsum, locStateAt]
    have hne0 : ¬ (fullTail.length = 0) := by omega
    simp [hne0]
    exact LTSWalk.nil LocalState.final
  | cons w rest ih =>
    simp only [buildChainTransAux]
    have h0 := halign 0 (Nat.zero_lt_succ rest.length)
    simp only [Nat.add_zero] at h0
    let tr0 : Trans LocalState :=
      { src := locStateAt j fullTail.length ell
        support := (edgeSupport? G u w).getD []
        dst := locStateAt j fullTail.length (ell + 1) }
    have hmem : tr0 ∈ (mkLocalPositiveLTS G pkt).delta := by
      apply mem_buildAllChainsAux_iff.mpr
      have hjlt : j < pkt.length := by
        cases Nat.lt_or_ge j pkt.length with
        | inl h => exact h
        | inr hge =>
          rw [List.getElem?_eq_none hge] at hget
          contradiction
      refine ⟨j, hjlt, v0 :: fullTail, hget, ?_⟩
      simp only [Nat.zero_add, buildChainTrans]
      apply mem_buildChainTransAux_iff.mpr
      have hellLt : ell < fullTail.length := by
        simp only [List.length_cons] at hsum
        omega
      refine ⟨ell, u, w, hellLt, h0.1.symm, h0.2.symm, ?_⟩
      simp [tr0, Nat.zero_add]
    refine LTSWalk.cons tr0 _ hmem rfl rfl ?_
    apply ih (ell + 1) w
    · simp only [List.length_cons] at hsum
      omega
    · intro k hklt
      have hk1 : k + 1 < (w :: rest).length := Nat.succ_lt_succ hklt
      have hal := halign (k + 1) hk1
      have hadj : ell + 1 + k = ell + (k + 1) := by omega
      rw [hadj]
      simpa using hal

theorem buildChainTrans_is_walk {G : LabeledGraph} {pkt : List (List VertexId)}
    {j : Nat} {γ : List VertexId}
    (hget : pkt[j]? = some γ) (hpos : 1 ≤ walkSteps γ) :
    LTSWalk (mkLocalPositiveLTS G pkt) .init .final (buildChainTrans G j γ) := by
  cases γ with
  | nil => simp [walkSteps] at hpos
  | cons v0 tail =>
    simp only [walkSteps] at hpos
    have hw := buildChainTransAux_is_walk (G := G) hget hpos 0 v0 tail (by omega)
      (fun k _ => by simp [Nat.zero_add])
    simpa [buildChainTrans, locStateAt] using hw

/-- Uniqueness of transition from `.mid j ell` (`1 ≤ ell < k_j`) in `mkLocalPositiveLTS`. -/
theorem localPositive_mid_unique_step {G : LabeledGraph} {pkt : List (List VertexId)}
    (hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ)
    {j ell : Nat} {tr : Trans LocalState}
    (hmem : tr ∈ (mkLocalPositiveLTS G pkt).delta)
    (hsrc : tr.src = .mid j ell) :
    ∃ v0 : VertexId, ∃ tail : List VertexId, ∃ x y : VertexId,
      pkt[j]? = some (v0 :: tail) ∧
      1 ≤ ell ∧
      ell < tail.length ∧
      (v0 :: tail)[ell]? = some x ∧
      tail[ell]? = some y ∧
      tr = { src := .mid j ell
             support := (edgeSupport? G x y).getD []
             dst := locStateAt j tail.length (ell + 1) } := by
  rcases (mem_buildAllChainsAux_iff.mp hmem) with ⟨idx, _, γ, hget, htr⟩
  simp only [Nat.zero_add] at htr
  have hlen1 : 1 ≤ walkSteps γ := hpos γ (List.mem_of_getElem? hget)
  cases γ with
  | nil => simp [walkSteps] at hlen1
  | cons v0 tail =>
    rcases (mem_buildChainTransAux_iff.mp htr) with ⟨k, x, y, hklt, hx, hy, htrEq⟩
    rw [htrEq] at hsrc
    simp only [Nat.zero_add, locStateAt] at hsrc htrEq
    split at hsrc
    · cases hsrc
    · next hne0 =>
      split at hsrc
      · cases hsrc
      · next hneLen =>
        injection hsrc with hj hk
        subst hj; subst hk
        refine ⟨v0, tail, x, y, hget, by omega, hklt, hx, hy, ?_⟩
        rw [htrEq]
        simp [locStateAt, hne0, hneLen]

/-- Unique suffix walk from `locStateAt j tail.length ell` (`1 ≤ ell ≤ tail.length`). -/
theorem localPositive_unique_suffix {G : LabeledGraph} {pkt : List (List VertexId)}
    (hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ)
    {j : Nat} {v0 : VertexId} {tail : List VertexId}
    (hget : pkt[j]? = some (v0 :: tail)) :
    ∀ (rem : Nat) (ell : Nat) (u : VertexId) (remTail : List VertexId) (τ : List (Trans LocalState)),
      1 ≤ ell →
      ell + rem = tail.length →
      remTail.length = rem →
      (∀ k < rem,
        (u :: remTail)[k]? = (v0 :: tail)[ell + k]? ∧
        remTail[k]? = tail[ell + k]?) →
      LTSWalk (mkLocalPositiveLTS G pkt) (locStateAt j tail.length ell) .final τ →
      τ = buildChainTransAux G j tail.length ell u remTail := by
  intro rem
  induction rem with
  | zero =>
    intro ell u remTail τ _ hsum hremLen _ hw
    cases remTail with
    | cons _ _ => simp at hremLen
    | nil =>
      have hellEq : ell = tail.length := by omega
      subst hellEq
      have hstate : locStateAt j tail.length tail.length = .final := by
        simp only [locStateAt]
        have hne0 : ¬ (tail.length = 0) := by omega
        simp [hne0]
      rw [hstate] at hw
      exact (localPositive_walk_from_final_nil hpos hw).2
  | succ rem' ih =>
    intro ell u remTail τ hell hsum hremLen halign hw
    cases remTail with
    | nil => simp at hremLen
    | cons w rest =>
      have hstate : locStateAt j tail.length ell = .mid j ell := by
        simp only [locStateAt]
        have hne0 : ¬ (ell = 0) := by omega
        have hneL : ¬ (ell = tail.length) := by omega
        simp [hne0, hneL]
      rw [hstate] at hw
      cases hw with
      | cons tr τrest hmem hsrc hdst hwRest =>
        rcases localPositive_mid_unique_step hpos hmem hsrc with
          ⟨v0', tail', x, y, hget', _, _, hx, hy, htrEq⟩
        rw [hget] at hget'
        injection hget' with hcons
        injection hcons with hv0 htail
        subst hv0; subst htail
        have h0 := halign 0 (Nat.zero_lt_succ rem')
        simp only [Nat.add_zero] at h0
        have hxEq : some u = some x := h0.1.trans hx
        have hyEq : some w = some y := h0.2.trans hy
        injection hxEq with huEq
        injection hyEq with hwEq
        subst huEq; subst hwEq
        rw [htrEq] at hdst
        subst hdst
        have hrec := ih (ell + 1) w rest τrest (by omega) (by omega)
          (by simp at hremLen; omega)
          (fun k hk => by
            have hal := halign (k + 1) (Nat.succ_lt_succ hk)
            have hadj : ell + 1 + k = ell + (k + 1) := by omega
            rw [hadj]
            simpa using hal)
          hwRest
        simp only [buildChainTransAux, hstate, htrEq, hrec]

/-- Zero Cross-Path Splicing Theorem (`no_cross_path_splicing`):
    Every `LTSWalk` from `.init` to `.final` in `mkLocalPositiveLTS G pkt` equals
    `buildChainTrans G j γ` for some single chain `(j, γ)` in `pkt`. -/
theorem no_cross_path_splicing {G : LabeledGraph} {κ : ClosureKind} {s t : VertexId}
    {pkt : List (List VertexId)}
    (hvalid : ∀ γ ∈ pkt, IsValidWalk G κ s t γ ∧ 1 ≤ walkSteps γ)
    {τ : List (Trans LocalState)}
    (hw : LTSWalk (mkLocalPositiveLTS G pkt) .init .final τ) :
    ∃ j < pkt.length, ∃ γ, pkt[j]? = some γ ∧ τ = buildChainTrans G j γ := by
  have hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ := fun γ h => (hvalid γ h).2
  cases hw with
  | cons tr τrest hmem hsrc hdst hwRest =>
    rcases (mem_buildAllChainsAux_iff.mp hmem) with ⟨j, hjlt, γ, hget, htr⟩
    simp only [Nat.zero_add] at htr
    have hγmem : γ ∈ pkt := List.mem_of_getElem? hget
    rcases hvalid γ hγmem with ⟨_, hlen1⟩
    cases γ with
    | nil => simp [walkSteps] at hlen1
    | cons v0 tail =>
      rcases (mem_buildChainTransAux_iff.mp htr) with ⟨k, x, y, hklt, hx, hy, htrEq⟩
      rw [htrEq] at hsrc
      simp only [Nat.zero_add, locStateAt] at hsrc htrEq
      have hk0 : k = 0 := by
        split at hsrc
        · next hk => exact hk
        · split at hsrc <;> cases hsrc
      subst hk0
      cases tail with
      | nil => simp at hklt
      | cons w1 tailRest =>
        simp at hx hy
        subst hx; subst hy
        cases tailRest with
        | nil =>
          simp only [List.length_cons, List.length_nil] at htrEq
          rw [htrEq] at hdst
          simp at hdst
          subst hdst
          have hnil := (localPositive_walk_from_final_nil hpos hwRest).2
          subst hnil
          refine ⟨j, hjlt, [v0, w1], hget, ?_⟩
          simp [buildChainTrans, buildChainTransAux, locStateAt, htrEq]
        | cons w2 tailRest2 =>
          rw [htrEq] at hdst
          simp only [List.length_cons] at hdst
          simp at hdst
          subst hdst
          have hsuf := localPositive_unique_suffix hpos hget
            (tailRest2.length + 1) 1 w1 (w2 :: tailRest2) τrest
            (by omega) (by simp; omega) (by simp)
            (fun k _ => by simp [Nat.add_comm 1 k])
            hwRest
          refine ⟨j, hjlt, v0 :: w1 :: w2 :: tailRest2, hget, ?_⟩
          rw [htrEq, hsuf]
          simp [buildChainTrans, buildChainTransAux, locStateAt]

/-- Survival equivalence along a single positive chain. -/
theorem chainSurvives_iff_buildChainTransAux {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (j totalSteps ell : Nat) :
    ∀ {u t : VertexId} {tail : List VertexId} (_hc : IsEdgeChain G u t tail) (D : List IssuerId),
      ChainSurvives G D u tail ↔
      WalkSurvives (buildChainTransAux G j totalSteps ell u tail) D := by
  intro u t tail hc D
  induction hc generalizing ell with
  | nil _ =>
    simp [ChainSurvives, buildChainTransAux, WalkSurvives]
  | @cons u w _ e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs : edgeSupport? G e.src e.dst = some e.support := edge_mem_gives_edgeSupport? hwf he
    simp only [ChainSurvives, buildChainTransAux, hs, Option.getD, WalkSurvives]
    constructor
    · intro ⟨⟨e', he', hu', hw', hnotall⟩, hrest⟩ tr htr
      cases htr with
      | head =>
        have heEq : e' = e := edge_unique_of_nodup_keys hwf.1 he' he hu' hw'
        subst heEq
        exact hnotall
      | tail _ hm =>
        exact (ih (ell + 1)).mp hrest tr hm
    · intro hws
      refine ⟨?_, (ih (ell + 1)).mpr (fun tr hm => hws tr (List.Mem.tail _ hm))⟩
      exact ⟨e, he, rfl, rfl, hws _ (List.Mem.head _)⟩

/-- Decode an `LTSWalk` in `mkLocalPositiveLTS` back to its unique originating walk in `pkt`. -/
def decodeLocalPositiveWalk (pkt : List (List VertexId)) (s t : VertexId) :
    List (Trans LocalState) → List VertexId
  | [] => [s, t]
  | tr0 :: _ =>
      match tr0.dst with
      | .mid j _ => getWalkAt pkt j [s, t]
      | _ => [s, t]

/-- `Ref-Loc` Positive (`F82-01` Level B): Explicit `PathwiseBijection` for positive-length
    `LocalPacket` `pkt`. -/
def ref_loc_positive_levelB {ip : IssuerPartition} {G : LabeledGraph}
    {κ : ClosureKind} {s t : VertexId} {pkt : List (List VertexId)}
    (hwf : GraphWF ip G)
    (hnd : NodupList pkt)
    (hvalid : ∀ γ ∈ pkt, IsValidWalk G κ s t γ ∧ 1 ≤ walkSteps γ) :
    PathwiseBijection (fun γ => γ ∈ pkt) G (mkLocalPositiveLTS G pkt) where
  toLTS γ _ := buildChainTrans G (indexOfWalk γ pkt) γ
  toLTS_valid γ hγ := by
    have hget := (indexOfWalk_spec hγ).2
    exact buildChainTrans_is_walk hget (hvalid γ hγ).2
  ofLTS τ _ := decodeLocalPositiveWalk pkt s t τ
  ofLTS_valid τ hw := by
    rcases no_cross_path_splicing hvalid hw with ⟨j, _, γ, hget, rfl⟩
    have hγmem : γ ∈ pkt := List.mem_of_getElem? hget
    rcases hvalid γ hγmem with ⟨hvw, hlen1⟩
    cases γ with
    | nil => simp [walkSteps] at hlen1
    | cons v0 tail =>
      cases tail with
      | nil => simp [walkSteps] at hlen1
      | cons w1 rest =>
        cases rest with
        | nil =>
          have heq : [v0, w1] = [s, t] := valid_len1_walk_unique hvw rfl
          rw [heq] at hγmem ⊢
          simp [buildChainTrans, buildChainTransAux, locStateAt, decodeLocalPositiveWalk]
          exact hγmem
        | cons w2 rest2 =>
          simp only [buildChainTrans, buildChainTransAux, locStateAt, List.length_cons]
          simp [decodeLocalPositiveWalk, getWalkAt, hget]
          exact hγmem
  left_inv γ hγ := by
    have hget := (indexOfWalk_spec hγ).2
    rcases hvalid γ hγ with ⟨hvw, hlen1⟩
    cases γ with
    | nil => simp [walkSteps] at hlen1
    | cons v0 tail =>
      cases tail with
      | nil => simp [walkSteps] at hlen1
      | cons w1 rest =>
        cases rest with
        | nil =>
          have heq : [v0, w1] = [s, t] := valid_len1_walk_unique hvw rfl
          rw [heq]
          simp [buildChainTrans, buildChainTransAux, locStateAt, decodeLocalPositiveWalk]
        | cons w2 rest2 =>
          simp only [buildChainTrans, buildChainTransAux, locStateAt, List.length_cons]
          simp [decodeLocalPositiveWalk, getWalkAt, hget]
  right_inv τ hw := by
    rcases no_cross_path_splicing hvalid hw with ⟨j, _, γ, hget, rfl⟩
    have hγmem : γ ∈ pkt := List.mem_of_getElem? hget
    have hjIdx : indexOfWalk γ pkt = j := indexOfWalk_of_getElem? hnd hget
    rcases hvalid γ hγmem with ⟨hvw, hlen1⟩
    cases γ with
    | nil => simp [walkSteps] at hlen1
    | cons v0 tail =>
      cases tail with
      | nil => simp [walkSteps] at hlen1
      | cons w1 rest =>
        cases rest with
        | nil =>
          have heq : [v0, w1] = [s, t] := valid_len1_walk_unique hvw rfl
          rw [heq]
          simp [buildChainTrans, buildChainTransAux, locStateAt, decodeLocalPositiveWalk]
        | cons w2 rest2 =>
          simp only [buildChainTrans, buildChainTransAux, locStateAt, List.length_cons]
          simp [decodeLocalPositiveWalk, getWalkAt, hget, hjIdx,
            buildChainTransAux, locStateAt]
  survives_iff γ hγ D := by
    rcases hvalid γ hγ with ⟨hvw, _⟩
    cases γ with
    | nil => cases hvw
    | cons v0 tail =>
      rcases hvw with ⟨rfl, _, _, hc, _⟩
      exact chainSurvives_iff_buildChainTransAux hwf (indexOfWalk (v0 :: tail) pkt)
        tail.length 0 hc D

/-- `Ref-Loc` Positive (`F82-01` Level A Corollary). -/
theorem ref_loc_positive_levelA {ip : IssuerPartition} {G : LabeledGraph}
    {κ : ClosureKind} {s t : VertexId} {pkt : List (List VertexId)}
    (hwf : GraphWF ip G)
    (hnd : NodupList pkt)
    (hvalid : ∀ γ ∈ pkt, IsValidWalk G κ s t γ ∧ 1 ≤ walkSteps γ) :
    ResilienceObsEquiv (fun D => ∃ γ ∈ pkt, WalkSurvivesGraph G D γ) (mkLocalPositiveLTS G pkt) :=
  levelB_implies_levelA (ref_loc_positive_levelB hwf hnd hvalid)

/-! ## Carrier 3: `Global E_STAR` (`mkGlobalStarLTS`, Level B + Level A) -/

def mkGlobalStarLTS (G : LabeledGraph) (s t : VertexId) : PointedLTS VertexId :=
  { q0 := s
    qf := t
    delta := G.edges.map (fun e => { src := e.src, support := e.support, dst := e.dst }) }

def chainToStarTrans (G : LabeledGraph) : VertexId → List VertexId → List (Trans VertexId)
  | _, [] => []
  | u, w :: rest =>
      { src := u, support := (edgeSupport? G u w).getD [], dst := w } ::
      chainToStarTrans G w rest

def starWalkToLTS (G : LabeledGraph) : List VertexId → List (Trans VertexId)
  | [] => []
  | v0 :: tail => chainToStarTrans G v0 tail

def ltsWalkToStarWalk (s : VertexId) (τ : List (Trans VertexId)) : List VertexId :=
  s :: τ.map (·.dst)

theorem chainToStarTrans_valid {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {s t0 u t : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u t tail) :
    LTSWalk (mkGlobalStarLTS G s t0) u t (chainToStarTrans G u tail) := by
  induction hc with
  | nil u0 => exact LTSWalk.nil u0
  | cons e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs := edge_mem_gives_edgeSupport? hwf he
    simp only [chainToStarTrans, hs, Option.getD]
    let tr0 : Trans VertexId := { src := e.src, support := e.support, dst := e.dst }
    have hmem : tr0 ∈ (mkGlobalStarLTS G s t0).delta :=
      List.mem_map_of_mem (f := fun x : GraphEdge =>
        ({ src := x.src, support := x.support, dst := x.dst } : Trans VertexId)) he
    exact LTSWalk.cons tr0 (chainToStarTrans G e.dst rest) hmem rfl rfl ih

theorem ltsWalk_star_chain {G : LabeledGraph} {s t0 u v : VertexId}
    {τ : List (Trans VertexId)}
    (hw : LTSWalk (mkGlobalStarLTS G s t0) u v τ) :
    IsEdgeChain G u v (τ.map (·.dst)) := by
  induction hw with
  | nil q => exact IsEdgeChain.nil q
  | cons tr rest hmem hsrc hdst _ ih =>
    subst hsrc; subst hdst
    rcases List.mem_map.mp hmem with ⟨e, he, htrEq⟩
    cases tr
    simp only [Trans.mk.injEq] at htrEq
    rcases htrEq with ⟨rfl, rfl, rfl⟩
    exact IsEdgeChain.cons e (rest.map (·.dst)) he rfl rfl ih

theorem star_left_inv_aux (G : LabeledGraph) (u : VertexId) (tail : List VertexId) :
    (chainToStarTrans G u tail).map (·.dst) = tail := by
  induction tail generalizing u with
  | nil => rfl
  | cons w rest ih =>
    simp [chainToStarTrans, ih w]

theorem star_right_inv_aux {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {s t0 u v : VertexId} {τ : List (Trans VertexId)}
    (hw : LTSWalk (mkGlobalStarLTS G s t0) u v τ) :
    chainToStarTrans G u (τ.map (·.dst)) = τ := by
  induction hw with
  | nil _ => rfl
  | cons tr rest hmem hsrc hdst _ ih =>
    subst hsrc; subst hdst
    rcases List.mem_map.mp hmem with ⟨e, he, htrEq⟩
    cases tr
    simp only [Trans.mk.injEq] at htrEq
    rcases htrEq with ⟨rfl, rfl, rfl⟩
    have hs := edge_mem_gives_edgeSupport? hwf he
    simp [chainToStarTrans, hs, ih]

theorem star_survives_aux {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {u t : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u t tail) (D : List IssuerId) :
    ChainSurvives G D u tail ↔ WalkSurvives (chainToStarTrans G u tail) D := by
  induction hc with
  | nil _ =>
    simp [ChainSurvives, chainToStarTrans, WalkSurvives]
  | cons e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs := edge_mem_gives_edgeSupport? hwf he
    simp only [ChainSurvives, chainToStarTrans, hs, Option.getD, WalkSurvives]
    constructor
    · intro ⟨⟨e', he', hu', hw', hnotall⟩, hrest⟩ tr htr
      cases htr with
      | head =>
        have heEq := edge_unique_of_nodup_keys hwf.1 he' he hu' hw'
        subst heEq
        exact hnotall
      | tail _ hm => exact ih.mp hrest tr hm
    · intro hws
      refine ⟨⟨e, he, rfl, rfl, hws _ (List.Mem.head _)⟩,
              ih.mpr (fun tr hm => hws tr (List.Mem.tail _ hm))⟩

/-- `Ref-Glob-Star` (Level B): Explicit `PathwiseBijection` for `Global E_STAR`. -/
def ref_glob_star_levelB {ip : IssuerPartition} {G : LabeledGraph}
    {s t : VertexId} (hwf : GraphWF ip G)
    (hs : s < G.numVertices) (ht : t < G.numVertices) :
    PathwiseBijection (IsValidWalk G .eStar s t) G (mkGlobalStarLTS G s t) where
  toLTS γ _ := starWalkToLTS G γ
  toLTS_valid γ hγ := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, hc, _⟩
      exact chainToStarTrans_valid hwf hc
  ofLTS τ _ := ltsWalkToStarWalk s τ
  ofLTS_valid τ hw := by
    exact ⟨rfl, hs, ht, ltsWalk_star_chain hw, fun h => nomatch h⟩
  left_inv γ hγ := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, _, _⟩
      simp [starWalkToLTS, ltsWalkToStarWalk, star_left_inv_aux]
  right_inv τ hw := by
    dsimp [ltsWalkToStarWalk, starWalkToLTS]
    exact star_right_inv_aux hwf hw
  survives_iff γ hγ D := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, hc, _⟩
      exact star_survives_aux hwf hc D

/-- `Ref-Glob-Star` (Level A Corollary). -/
theorem ref_glob_star_levelA {ip : IssuerPartition} {G : LabeledGraph}
    {s t : VertexId} (hwf : GraphWF ip G)
    (hs : s < G.numVertices) (ht : t < G.numVertices) :
    ResilienceObsEquiv
      (fun D => ∃ γ, IsValidWalk G .eStar s t γ ∧ WalkSurvivesGraph G D γ)
      (mkGlobalStarLTS G s t) :=
  levelB_implies_levelA (ref_glob_star_levelB hwf hs ht)

/-! ## Carrier 4: `Global E_PLUS` (`PlusState`, `mkGlobalPlusLTS`, Level B + Level A) -/

inductive PlusState where
  | start : PlusState
  | act : VertexId → PlusState
  deriving DecidableEq, Repr

/-- Separate transition builder for `Global E_PLUS` (allows arbitrary continuations from
    `.act u` including `u = t`, in contrast to `mkGeodesicLTS` per 82nd Ruling §3). -/
def mkGlobalPlusLTS (G : LabeledGraph) (s t : VertexId) : PointedLTS PlusState :=
  let initTrans :=
    (G.edges.filter (fun e => decide (e.src = s))).map
      (fun e => { src := .start, support := e.support, dst := .act e.dst })
  let stepTrans :=
    G.edges.map
      (fun e => { src := .act e.src, support := e.support, dst := .act e.dst })
  { q0 := .start
    qf := .act t
    delta := initTrans ++ stepTrans }

def chainToPlusActTrans (G : LabeledGraph) : VertexId → List VertexId → List (Trans PlusState)
  | _, [] => []
  | u, w :: rest =>
      { src := .act u, support := (edgeSupport? G u w).getD [], dst := .act w } ::
      chainToPlusActTrans G w rest

def plusWalkToLTS (G : LabeledGraph) : List VertexId → List (Trans PlusState)
  | v0 :: w1 :: rest =>
      { src := .start, support := (edgeSupport? G v0 w1).getD [], dst := .act w1 } ::
      chainToPlusActTrans G w1 rest
  | _ => []

def unActVertex : PlusState → VertexId
  | .start => 0
  | .act v => v

def ltsWalkToPlusWalk (s : VertexId) (τ : List (Trans PlusState)) : List VertexId :=
  s :: τ.map (fun tr => unActVertex tr.dst)

/-- Every `LTSWalk` from `.start` to `.act t` in `mkGlobalPlusLTS` has positive length `≥ 1`
    (even when `s = t`). -/
theorem glob_plus_walk_pos_length {G : LabeledGraph} {s t : VertexId}
    {τ : List (Trans PlusState)}
    (hw : LTSWalk (mkGlobalPlusLTS G s t) .start (.act t) τ) :
    1 ≤ τ.length := by
  cases hw with
  | cons _ _ _ _ _ _ => simp

theorem chainToPlusActTrans_valid {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {s t0 u t : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u t tail) :
    LTSWalk (mkGlobalPlusLTS G s t0) (PlusState.act u) (PlusState.act t)
      (chainToPlusActTrans G u tail) := by
  induction hc with
  | nil u0 => exact LTSWalk.nil (PlusState.act u0)
  | cons e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs := edge_mem_gives_edgeSupport? hwf he
    simp only [chainToPlusActTrans, hs, Option.getD]
    let tr0 : Trans PlusState :=
      { src := PlusState.act e.src, support := e.support, dst := PlusState.act e.dst }
    have hmem : tr0 ∈ (mkGlobalPlusLTS G s t0).delta := by
      apply List.mem_append.mpr
      right
      exact List.mem_map_of_mem (f := fun x : GraphEdge =>
        ({ src := PlusState.act x.src, support := x.support, dst := PlusState.act x.dst } :
          Trans PlusState)) he
    exact LTSWalk.cons tr0 (chainToPlusActTrans G e.dst rest) hmem rfl rfl ih

theorem ltsWalk_plus_act_chain_and_inv {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {s t0 : VertexId} {p q : PlusState} {τ : List (Trans PlusState)}
    (hw : LTSWalk (mkGlobalPlusLTS G s t0) p q τ) :
    ∀ u v : VertexId, p = PlusState.act u → q = PlusState.act v →
      IsEdgeChain G u v (τ.map (fun tr => unActVertex tr.dst)) ∧
      chainToPlusActTrans G u (τ.map (fun tr => unActVertex tr.dst)) = τ := by
  induction hw with
  | nil _ =>
    intro u v hp hq
    rw [hp] at hq
    injection hq with huv
    subst huv
    exact ⟨IsEdgeChain.nil u, rfl⟩
  | cons tr rest hmem hsrc hdst _ ih =>
    intro u v hp hq
    rw [hp] at hsrc
    rcases List.mem_append.mp hmem with hinit | hstep
    · rcases List.mem_map.mp hinit with ⟨e, _, htrEq⟩
      rw [← htrEq] at hsrc
      cases hsrc
    · rcases List.mem_map.mp hstep with ⟨e, he, htrEq⟩
      cases tr
      simp only [Trans.mk.injEq] at htrEq
      rcases htrEq with ⟨hsrcE, hsuppE, hdstE⟩
      rw [← hsrcE] at hsrc
      injection hsrc with huEq
      subst huEq; subst hsuppE; subst hdst
      rcases ih e.dst v hdstE.symm hq with ⟨hcRest, hinvRest⟩
      have hs := edge_mem_gives_edgeSupport? hwf he
      rw [← hdstE]
      simp only [List.map_cons]
      have hun : unActVertex (PlusState.act e.dst) = e.dst := rfl
      rw [hun]
      refine ⟨IsEdgeChain.cons e _ he rfl rfl hcRest, ?_⟩
      simp only [chainToPlusActTrans, hs, Option.getD, hsrcE, hinvRest]

theorem plus_left_inv_aux (G : LabeledGraph) (u : VertexId) (tail : List VertexId) :
    (chainToPlusActTrans G u tail).map (fun tr => unActVertex tr.dst) = tail := by
  induction tail generalizing u with
  | nil => rfl
  | cons w rest ih =>
    simp only [chainToPlusActTrans, List.map_cons]
    have hun : unActVertex (PlusState.act w) = w := rfl
    rw [hun, ih w]

theorem plus_act_survives_aux {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {u t : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain G u t tail) (D : List IssuerId) :
    ChainSurvives G D u tail ↔ WalkSurvives (chainToPlusActTrans G u tail) D := by
  induction hc with
  | nil _ =>
    simp [ChainSurvives, chainToPlusActTrans, WalkSurvives]
  | cons e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs := edge_mem_gives_edgeSupport? hwf he
    simp only [ChainSurvives, chainToPlusActTrans, hs, Option.getD, WalkSurvives]
    constructor
    · intro ⟨⟨e', he', hu', hw', hnotall⟩, hrest⟩ tr htr
      cases htr with
      | head =>
        have heEq := edge_unique_of_nodup_keys hwf.1 he' he hu' hw'
        subst heEq
        exact hnotall
      | tail _ hm => exact ih.mp hrest tr hm
    · intro hws
      refine ⟨⟨e, he, rfl, rfl, hws _ (List.Mem.head _)⟩,
              ih.mpr (fun tr hm => hws tr (List.Mem.tail _ hm))⟩

/-- `Ref-Glob-Plus` (Level B): Explicit `PathwiseBijection` for `Global E_PLUS`
    (preserving positive walk length `≥ 1` including `s = t` self-cycles). -/
def ref_glob_plus_levelB {ip : IssuerPartition} {G : LabeledGraph}
    {s t : VertexId} (hwf : GraphWF ip G)
    (hs : s < G.numVertices) (ht : t < G.numVertices) :
    PathwiseBijection (IsValidWalk G .ePlus s t) G (mkGlobalPlusLTS G s t) where
  toLTS γ _ := plusWalkToLTS G γ
  toLTS_valid γ hγ := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, hc, hplus⟩
      have hne : tail ≠ [] := hplus rfl
      cases tail with
      | nil => exact absurd rfl hne
      | cons w1 rest =>
        cases hc with
        | cons e _ he hsrc hdst hcRest =>
          subst hsrc; subst hdst
          have hsupp := edge_mem_gives_edgeSupport? hwf he
          simp only [plusWalkToLTS, hsupp, Option.getD]
          let tr0 : Trans PlusState :=
            { src := PlusState.start, support := e.support, dst := PlusState.act e.dst }
          have hmem : tr0 ∈ (mkGlobalPlusLTS G e.src t).delta := by
            apply List.mem_append.mpr
            left
            apply List.mem_map.mpr
            refine ⟨e, List.mem_filter.mpr ⟨he, decide_eq_true rfl⟩, rfl⟩
          exact LTSWalk.cons tr0 (chainToPlusActTrans G e.dst rest) hmem rfl rfl
            (chainToPlusActTrans_valid hwf hcRest)
  ofLTS τ _ := ltsWalkToPlusWalk s τ
  ofLTS_valid τ hw := by
    cases hw with
    | cons tr0 rest hmem hsrc hdst hwRest =>
      rcases List.mem_append.mp hmem with hinit | hstep
      · rcases List.mem_map.mp hinit with ⟨e0, he0f, htr0Eq⟩
        rcases List.mem_filter.mp he0f with ⟨he0, he0srcB⟩
        have he0src : e0.src = s := of_decide_eq_true he0srcB
        cases tr0
        simp only [Trans.mk.injEq] at htr0Eq
        rcases htr0Eq with ⟨_, rfl, hdst0⟩
        subst hdst
        rcases ltsWalk_plus_act_chain_and_inv hwf hwRest e0.dst t hdst0.symm rfl with
          ⟨hcRest, _⟩
        refine ⟨rfl, hs, ht, ?_, fun _ => by simp⟩
        rw [← hdst0]
        simp only [List.map_cons]
        have hun : unActVertex (PlusState.act e0.dst) = e0.dst := rfl
        rw [hun]
        exact IsEdgeChain.cons e0 _ he0 he0src rfl hcRest
      · rcases List.mem_map.mp hstep with ⟨e0, _, htr0Eq⟩
        rw [← htr0Eq] at hsrc
        cases hsrc
  left_inv γ hγ := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, _, hplus⟩
      have hne : tail ≠ [] := hplus rfl
      cases tail with
      | nil => exact absurd rfl hne
      | cons w1 rest =>
        simp only [plusWalkToLTS, ltsWalkToPlusWalk, List.map_cons]
        have hun : unActVertex (PlusState.act w1) = w1 := rfl
        rw [hun, plus_left_inv_aux]
  right_inv τ hw := by
    cases hw with
    | cons tr0 rest hmem hsrc hdst hwRest =>
      rcases List.mem_append.mp hmem with hinit | hstep
      · rcases List.mem_map.mp hinit with ⟨e0, he0f, htr0Eq⟩
        rcases List.mem_filter.mp he0f with ⟨he0, he0srcB⟩
        have he0src : e0.src = s := of_decide_eq_true he0srcB
        cases tr0
        simp only [Trans.mk.injEq] at htr0Eq
        rcases htr0Eq with ⟨hsrc0, hsupp0, hdst0⟩
        subst hsrc0; subst hsupp0; subst hdst
        rcases ltsWalk_plus_act_chain_and_inv hwf hwRest e0.dst t hdst0.symm rfl with
          ⟨_, hinvRest⟩
        have hs0 := edge_mem_gives_edgeSupport? hwf he0
        rw [he0src] at hs0
        rw [← hdst0]
        simp only [ltsWalkToPlusWalk, List.map_cons]
        have hun : unActVertex (PlusState.act e0.dst) = e0.dst := rfl
        rw [hun]
        simp only [plusWalkToLTS, hs0, Option.getD, hinvRest]
      · rcases List.mem_map.mp hstep with ⟨e0, _, htr0Eq⟩
        rw [← htr0Eq] at hsrc
        cases hsrc
  survives_iff γ hγ D := by
    cases γ with
    | nil => cases hγ
    | cons v0 tail =>
      rcases hγ with ⟨rfl, _, _, hc, hplus⟩
      have hne : tail ≠ [] := hplus rfl
      cases tail with
      | nil => exact absurd rfl hne
      | cons w1 rest =>
        cases hc with
        | cons e0 _ he0 hsrc0 hdst0 hcRest =>
          subst hsrc0; subst hdst0
          have hs0 := edge_mem_gives_edgeSupport? hwf he0
          simp only [WalkSurvivesGraph, ChainSurvives, plusWalkToLTS, hs0, Option.getD,
            WalkSurvives]
          constructor
          · intro ⟨⟨e', he', hu', hw', hnot0⟩, hrest⟩ tr htr
            cases htr with
            | head =>
              have heEq := edge_unique_of_nodup_keys hwf.1 he' he0 hu' hw'
              subst heEq
              exact hnot0
            | tail _ hm =>
              exact (plus_act_survives_aux hwf hcRest D).mp hrest tr hm
          · intro hws
            refine ⟨⟨e0, he0, rfl, rfl, hws _ (List.Mem.head _)⟩,
                    (plus_act_survives_aux hwf hcRest D).mpr
                      (fun tr hm => hws tr (List.Mem.tail _ hm))⟩

/-- `Ref-Glob-Plus` (Level A Corollary). -/
theorem ref_glob_plus_levelA {ip : IssuerPartition} {G : LabeledGraph}
    {s t : VertexId} (hwf : GraphWF ip G)
    (hs : s < G.numVertices) (ht : t < G.numVertices) :
    ResilienceObsEquiv
      (fun D => ∃ γ, IsValidWalk G .ePlus s t γ ∧ WalkSurvivesGraph G D γ)
      (mkGlobalPlusLTS G s t) :=
  levelB_implies_levelA (ref_glob_plus_levelB hwf hs ht)

end OmegaLambda

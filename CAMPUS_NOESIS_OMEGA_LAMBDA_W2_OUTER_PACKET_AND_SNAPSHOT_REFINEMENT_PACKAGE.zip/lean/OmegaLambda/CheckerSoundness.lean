/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 4: `OmegaLambda.CheckerSoundness`

  Couples executable `Bool` functions directly to semantic soundness theorems (`F81-02`):
    - Polymorphic `LTSCert Q` + `checkLTSCert` + `checkLTSCert_sound`
    - Carrier specification `CarrierSpec` and typed certificate `ResilienceCert`
      (rejecting any carrier/closure mismatch, `F75-03` / `G77-S1..S5`)
    - Original-graph semantic survival `CarrierSurvives` (defined directly on graph walks
      and `IsTrueShortestWalk`, never tautologically via LTS)
    - Master end-to-end soundness theorem `omegaLambda_resilience_sound`
    - Exact hitting-cardinality corollary `omegaLambda_exact_resilience_sound`
-/

import OmegaLambda.CarrierGeodesic

namespace OmegaLambda

/-! ## Resilience Claims & Polymorphic `LTSCert` -/

inductive ResilienceClaim where
  | unbreakable : ResilienceClaim
  | finiteBounds : (lower : Nat) → (upper : Nat) → ResilienceClaim
  deriving DecidableEq, Repr

inductive LTSCert (Q : Type) where
  | unbreakableWalk : (walk : List (Trans Q)) → LTSCert Q
  | finiteBounds :
      (lower : Nat) →
      (upper : Nat) →
      (packing : List (LowerWitnessWalk Q)) →
      (cutIssuers : List IssuerId) →
      (cutStates : List Q) →
      LTSCert Q
  deriving DecidableEq, Repr

def ltsCertClaim : LTSCert Q → ResilienceClaim
  | .unbreakableWalk _ => .unbreakable
  | .finiteBounds lower upper _ _ _ => .finiteBounds lower upper

/-- Semantic resilience contract for any survival predicate `survPred : List IssuerId → Prop`. -/
def SemanticClaimHolds (ip : IssuerPartition)
    (survPred : List IssuerId → Prop) : ResilienceClaim → Prop
  | .unbreakable =>
      ∀ D : List IssuerId, (∀ d ∈ D, d ∈ ip.remIssuers) → survPred D
  | .finiteBounds lower upper =>
      lower ≤ upper ∧
      (∀ D : List IssuerId,
        NodupList D →
        (∀ d ∈ D, d ∈ ip.remIssuers) →
        ¬ survPred D →
        lower ≤ D.length) ∧
      (∃ Dstar : List IssuerId,
        NodupList Dstar ∧
        (∀ d ∈ Dstar, d ∈ ip.remIssuers) ∧
        Dstar.length ≤ upper ∧
        ¬ survPred Dstar)

/-- Executable polymorphic `PointedLTS` certificate checker. -/
def checkLTSCert [DecidableEq Q]
    (ip : IssuerPartition) (M : PointedLTS Q) : LTSCert Q → Bool
  | .unbreakableWalk walk =>
      checkUnbreakableWalk ip M walk
  | .finiteBounds lower upper packing cutIssuers cutStates =>
      decide (lower ≤ upper) &&
      decide (packing.length = lower) &&
      checkLowerPacking ip M packing &&
      nodupBool cutIssuers &&
      listAllBool (fun d => listMemBool d ip.remIssuers) cutIssuers &&
      decide (cutIssuers.length ≤ upper) &&
      checkClosedCut M cutIssuers cutStates

/-- Universal Polymorphic `PointedLTS` Soundness Bridge:
    Any `survPred` related to `M` by `ResilienceObsEquiv` (`Level A`, `F82-01`)
    inherits full semantic soundness from `checkLTSCert ip M cert = true`. -/
theorem checkLTSCert_sound [DecidableEq Q]
    {ip : IssuerPartition} {survPred : List IssuerId → Prop} {M : PointedLTS Q}
    (hpart : WFPartition ip)
    (hequiv : ResilienceObsEquiv survPred M)
    (cert : LTSCert Q)
    (hchk : checkLTSCert ip M cert = true) :
    SemanticClaimHolds ip survPred (ltsCertClaim cert) := by
  cases cert with
  | unbreakableWalk walk =>
    simp only [checkLTSCert] at hchk
    simp only [ltsCertClaim, SemanticClaimHolds]
    intro D hD
    exact (hequiv D).mpr (checkUnbreakableWalk_sound hpart hchk D hD)
  | finiteBounds lower upper packing cutIssuers cutStates =>
    simp only [checkLTSCert, Bool.and_eq_true, decide_eq_true_eq, nodupBool_iff,
      listAllBool_iff, listMemBool_iff] at hchk
    rcases hchk with ⟨⟨⟨⟨⟨⟨hle, hpackLen⟩, hpack⟩, hndCut⟩, hremCut⟩, hcutLen⟩, hcut⟩
    simp only [ltsCertClaim, SemanticClaimHolds]
    refine ⟨hle, ?_, ?_⟩
    · intro D hndD hremD hnotSurv
      have hunreach : ¬ LTSReachable M D M.q0 M.qf := by
        intro hreach
        exact hnotSurv ((hequiv D).mpr hreach)
      rw [← hpackLen]
      exact checkLowerPacking_sound hpart hpack D hndD hremD hunreach
    · refine ⟨cutIssuers, hndCut, hremCut, hcutLen, ?_⟩
      intro hsurvCut
      exact checkClosedCut_sound hcut ((hequiv cutIssuers).mp hsurvCut)

/-! ## Carrier Specifications, Original-Graph Semantics, and Typed Certificates -/

inductive CarrierSpec where
  | localPacket : (pkt : List (List VertexId)) → CarrierSpec
  | geodesicBundle : CarrierSpec
  | globalGraph : CarrierSpec
  deriving DecidableEq, Repr

/-- Carrier-indexed typed resilience certificate (strictly tags the target carrier/closure). -/
inductive ResilienceCert where
  | localReflexive : LTSCert Unit → ResilienceCert
  | localPositive : LTSCert LocalState → ResilienceCert
  | geodesic : LTSCert GeoState → ResilienceCert
  | globalStar : LTSCert VertexId → ResilienceCert
  | globalPlus : LTSCert PlusState → ResilienceCert
  deriving DecidableEq, Repr

def certClaim : ResilienceCert → ResilienceClaim
  | .localReflexive c => ltsCertClaim c
  | .localPositive c => ltsCertClaim c
  | .geodesic c => ltsCertClaim c
  | .globalStar c => ltsCertClaim c
  | .globalPlus c => ltsCertClaim c

/-- Raw original-graph semantic survival of a carrier under deletion set `D`
    (defined directly on graph walks and `IsTrueShortestWalk` without mentioning LTS). -/
def CarrierSurvives (b : BaseData) (s t : VertexId) :
    CarrierSpec → List IssuerId → Prop
  | .localPacket pkt, D =>
      ∃ γ ∈ pkt, WalkSurvivesGraph b.G D γ
  | .geodesicBundle, D =>
      ∃ γ, IsTrueShortestWalk b.G b.kappa s t γ ∧ WalkSurvivesGraph b.G D γ
  | .globalGraph, D =>
      ∃ γ, IsValidWalk b.G b.kappa s t γ ∧ WalkSurvivesGraph b.G D γ

def ScopedSemanticResilience (ip : IssuerPartition) (b : BaseData)
    (s t : VertexId) (c : CarrierSpec) (claim : ResilienceClaim) : Prop :=
  s < b.G.numVertices ∧
  t < b.G.numVertices ∧
  (rankOf b s t).isSome = true ∧
  SemanticClaimHolds ip (CarrierSurvives b s t c) claim

/-- Executable `Bool` checker for `Ωλ-M1` resilience certificates (`F81-02`). -/
def checkOmegaLambdaResilience
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (cert : ResilienceCert) : Bool :=
  decide (s < b.G.numVertices) &&
  decide (t < b.G.numVertices) &&
  (rankOf b s t).isSome &&
  match c, cert with
  | .localPacket pkt, .localReflexive lcert =>
      decide (b.kappa = .eStar) &&
      decide (pkt ≠ []) &&
      nodupBool pkt &&
      listAllBool (fun γ => checkValidWalk b.G b.kappa s t γ) pkt &&
      listAnyBool (fun γ => decide (walkSteps γ = 0)) pkt &&
      checkLTSCert ip mkLocalReflexiveLTS lcert
  | .localPacket pkt, .localPositive lcert =>
      decide (pkt ≠ []) &&
      nodupBool pkt &&
      listAllBool (fun γ =>
        checkValidWalk b.G b.kappa s t γ && decide (1 ≤ walkSteps γ)) pkt &&
      checkLTSCert ip (mkLocalPositiveLTS b.G pkt) lcert
  | .geodesicBundle, .geodesic lcert =>
      checkLTSCert ip (mkGeodesicLTS b s t) lcert
  | .globalGraph, .globalStar lcert =>
      decide (b.kappa = .eStar) &&
      checkLTSCert ip (mkGlobalStarLTS b.G s t) lcert
  | .globalGraph, .globalPlus lcert =>
      decide (b.kappa = .ePlus) &&
      checkLTSCert ip (mkGlobalPlusLTS b.G s t) lcert
  | _, _ => false

/-! ## Master End-to-End Soundness Theorem (`omegaLambda_resilience_sound`) -/

/-- Master Soundness Theorem (`F81-02` & 82nd Ruling):
    Whenever `checkVerifiedBase ip b = true` and
    `checkOmegaLambdaResilience ip b s t c cert = true`,
    `ScopedSemanticResilience ip b s t c (certClaim cert)` holds over the original graph. -/
theorem omegaLambda_resilience_sound
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (cert : ResilienceCert)
    (hBase : checkVerifiedBase ip b = true)
    (hCert : checkOmegaLambdaResilience ip b s t c cert = true) :
    ScopedSemanticResilience ip b s t c (certClaim cert) := by
  have hb : VerifiedBase ip b := checkVerifiedBase_sound hBase
  unfold checkOmegaLambdaResilience at hCert
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hCert
  rcases hCert with ⟨⟨⟨hs, ht⟩, hsRank⟩, hbody⟩
  refine ⟨hs, ht, hsRank, ?_⟩
  cases c with
  | localPacket pkt =>
    cases cert with
    | localReflexive lcert =>
      simp only [Bool.and_eq_true, decide_eq_true_eq, nodupBool_iff,
        listAllBool_iff, listAnyBool_iff] at hbody
      rcases hbody with ⟨⟨⟨⟨⟨hκ, _⟩, _⟩, hvalidAll⟩, ⟨γ0, hγ0Mem, hγ0Zero⟩⟩, hlcert⟩
      have hvw0 : IsValidWalk b.G .eStar s t γ0 := by
        rw [← hκ]
        exact (checkValidWalk_iff hb.wfGraph b.kappa s t γ0).mp (hvalidAll γ0 hγ0Mem)
      have hequiv := ref_loc_reflexive_levelA ⟨γ0, hγ0Mem, hvw0, hγ0Zero⟩
      exact checkLTSCert_sound hb.wfPart hequiv lcert hlcert
    | localPositive lcert =>
      simp only [Bool.and_eq_true, decide_eq_true_eq, nodupBool_iff, listAllBool_iff] at hbody
      rcases hbody with ⟨⟨⟨_, hnd⟩, hvalidAll⟩, hlcert⟩
      have hvalidSem : ∀ γ ∈ pkt, IsValidWalk b.G b.kappa s t γ ∧ 1 ≤ walkSteps γ := by
        intro γ hγ
        rcases hvalidAll γ hγ with ⟨hchkW, hposW⟩
        exact ⟨(checkValidWalk_iff hb.wfGraph b.kappa s t γ).mp hchkW, hposW⟩
      have hequiv := ref_loc_positive_levelA hb.wfGraph hnd hvalidSem
      exact checkLTSCert_sound hb.wfPart hequiv lcert hlcert
    | geodesic _ => simp at hbody
    | globalStar _ => simp at hbody
    | globalPlus _ => simp at hbody
  | geodesicBundle =>
    cases cert with
    | geodesic lcert =>
      have hequiv := ref_geo_levelA hb hs ht
      exact checkLTSCert_sound hb.wfPart hequiv lcert hbody
    | localReflexive _ => simp at hbody
    | localPositive _ => simp at hbody
    | globalStar _ => simp at hbody
    | globalPlus _ => simp at hbody
  | globalGraph =>
    cases cert with
    | globalStar lcert =>
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hbody
      rcases hbody with ⟨hκ, hlcert⟩
      have hequiv : ResilienceObsEquiv (CarrierSurvives b s t .globalGraph)
          (mkGlobalStarLTS b.G s t) := by
        unfold CarrierSurvives
        rw [hκ]
        exact ref_glob_star_levelA hb.wfGraph hs ht
      exact checkLTSCert_sound hb.wfPart hequiv lcert hlcert
    | globalPlus lcert =>
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hbody
      rcases hbody with ⟨hκ, hlcert⟩
      have hequiv : ResilienceObsEquiv (CarrierSurvives b s t .globalGraph)
          (mkGlobalPlusLTS b.G s t) := by
        unfold CarrierSurvives
        rw [hκ]
        exact ref_glob_plus_levelA hb.wfGraph hs ht
      exact checkLTSCert_sound hb.wfPart hequiv lcert hlcert
    | localReflexive _ => simp at hbody
    | localPositive _ => simp at hbody
    | geodesic _ => simp at hbody

/-- Exact Resilience Corollary (`omegaLambda_exact_resilience_sound`):
    When `certClaim cert = .finiteBounds k k`, there exists an allowed duplicate-free
    retractable cut `Dstar` of EXACT cardinality `Dstar.length = k`, and every allowed
    duplicate-free retractable cut `D` satisfies `k ≤ D.length`. -/
theorem omegaLambda_exact_resilience_sound
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (cert : ResilienceCert) (k : Nat)
    (hBase : checkVerifiedBase ip b = true)
    (hCert : checkOmegaLambdaResilience ip b s t c cert = true)
    (hExact : certClaim cert = .finiteBounds k k) :
    (∀ D : List IssuerId,
      NodupList D →
      (∀ d ∈ D, d ∈ ip.remIssuers) →
      ¬ CarrierSurvives b s t c D →
      k ≤ D.length) ∧
    (∃ Dstar : List IssuerId,
      NodupList Dstar ∧
      (∀ d ∈ Dstar, d ∈ ip.remIssuers) ∧
      Dstar.length = k ∧
      ¬ CarrierSurvives b s t c Dstar) := by
  have hsound := omegaLambda_resilience_sound ip b s t c cert hBase hCert
  rcases hsound with ⟨_, _, _, hclaim⟩
  rw [hExact] at hclaim
  rcases hclaim with ⟨_, hlow, ⟨Dstar, hnd, hrem, hleU, hnotSurv⟩⟩
  have hgeL : k ≤ Dstar.length := hlow Dstar hnd hrem hnotSurv
  exact ⟨hlow, ⟨Dstar, hnd, hrem, Nat.le_antisymm hleU hgeL, hnotSurv⟩⟩

end OmegaLambda

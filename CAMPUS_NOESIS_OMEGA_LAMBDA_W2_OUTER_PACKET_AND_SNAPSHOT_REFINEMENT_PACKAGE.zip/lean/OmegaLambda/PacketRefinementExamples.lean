/-
  CAMPUS-NOESIS Omega-Lambda W2: Concrete Packet & Snapshot Refinement Examples (`#46`)
  Module: `OmegaLambda.PacketRefinementExamples`

  Concrete machine-checked examples & adversarial rejection witnesses (`0` `native_decide`):
    1. `Ex-W2-1` (`0x05` Geodesic Self-Loop + 2-Cycle Packet on `#40`'s `SNAP-PHI-EPLUS-SELFLOOP-A1`):
       - Exact 112-byte canonical `Snapshot` section roundtrip (`w2_ex1_snapshot_112bytes_roundtrip`).
       - Acceptance by Level 2 `checkCnp2ResiliencePacketPinnedA1_0x00` against `#40`'s
         15-entry `pinnedOmegaKappaA1Registry15` and `PinnedA1SourceSoundness` (`F93-01`, `F93-02`).
       - Note (`F91-02`): `mockSelfloopHash256` supplies the pinned 32-byte digest on the 149-byte
         `SNAP-PHI-EPLUS-SELFLOOP-A1` preimage inside pure Lean; real FIPS 180-4 `SHA-256` on this
         exact 112-byte slice (`0cf299cb...465f`) is verified externally in `tests/test_omega_lambda_w2.py`.
    2. `Ex-W2-2` (`0x03` `Local` + `Global` Packet Exercising All 4 `F93-03` Gates):
       - Asymmetric `0x03` wire framing (`Local` paths inline, `Global` carrier derived from
         `B_cnb1.candidateEdges` with zero duplicate `C3` wire payload) and `SourceSoundnessRelativeTo`.
    3. `Adv-W2-1`..`Adv-W2-7`:
       - `Adv-W2-1` (`F93-03` Non-Laundering): Corrupted wire `posWitnesses` rank (`99`) in `0x03`
         decodes cleanly and Gate 2's `synthesizeVerifiedBase` passes `checkVerifiedBase`, YET
         Gate 1 deterministically rejects the packet (`checkCnp2ResiliencePacket0x00 = false`).
       - `Adv-W2-2`: Non-resilience `packet_kind = 0x01` rejected (`= none`).
       - `Adv-W2-3`: Corrupted `"CNP9"` / `"CNB9"` magic rejected (`= none`).
       - `Adv-W2-4` (`93rd Ruling §2` Separation): Cross-sort duplicate vertex `"V0"` in both
         `bucket0` and `bucket1` decodes at wire layer (`some`) yet fails `checkCNB1B2Bool` (`false`).
       - `Adv-W2-5`: Unlicensed `relTag = 13` decodes at wire layer (`some`) yet fails `checkCNB1B2Bool` (`false`).
       - `Adv-W2-6`: Unsorted `bucket0 = ["L1", "L0"]` rejected by `encodeSnapshotSection` (`= none`).
       - `Adv-W2-7`: `evasion_mode = 0x01` (`HELD`) rejected (`= none`).
-/

import OmegaLambda.PacketRefinement

namespace OmegaLambda.W2Examples

open OmegaLambda

set_option maxRecDepth 16384

/-! ## `Ex-W2-1`: `#40` `SNAP-PHI-EPLUS-SELFLOOP-A1` (`112` Bytes) & Level 2 `0x05` Packet -/

def rawSnapEplusSelfloop : RawSnapshotWireTerm :=
  { snapshotId := "SNAP-PHI-EPLUS-SELFLOOP-A1"
    bucket0 := ["L0", "L1"]
    bucket1 := []
    bucket2 := []
    bucket3 := []
    irRecords :=
      [ { recTag := 2
          recordId := "IR-DET-01"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 1, targetSortCode := 0, relTag := 1 }] },
        { recTag := 2
          recordId := "IR-DET-02"
          sourceVid := 1
          sourceSortCode := 0
          refs := [{ targetVid := 0, targetSortCode := 0, relTag := 1 }] },
        { recTag := 2
          recordId := "IR-LOOP-01"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 0, targetSortCode := 0, relTag := 1 }] } ] }

def rawSnapEplusSelfloopBytes : ByteArray :=
  bytesOfList (encodeSnapshotSectionList rawSnapEplusSelfloop)

theorem w2_ex1_snapshot_112bytes_roundtrip :
    rawSnapEplusSelfloopBytes.size = 112 ∧
    encodeSnapshotSection rawSnapEplusSelfloop = some rawSnapEplusSelfloopBytes ∧
    decodeSnapshotSection rawSnapEplusSelfloopBytes = some rawSnapEplusSelfloop := by
  have hwf : WF_RawSnapshotWire rawSnapEplusSelfloop := rfl
  have henc0 : encodeSnapshotSection rawSnapEplusSelfloop = some rawSnapEplusSelfloopBytes := rfl
  rcases w2b_snapshot_forward_roundtrip hwf with ⟨B, henc, hdec⟩
  rw [henc0] at henc
  injection henc with hBeq
  subst hBeq
  exact ⟨rfl, rfl, hdec⟩

/-- Exact 32-byte digest of `0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f`. -/
def pinnedSelfloopRoot32 : ByteArray :=
  bytesOfList
    [0x0c, 0xf2, 0x99, 0xcb, 0x5b, 0xee, 0x99, 0x23,
     0xae, 0x0d, 0x54, 0x7f, 0x48, 0xec, 0x4d, 0x60,
     0xab, 0xe5, 0x82, 0xfb, 0x05, 0xdb, 0x25, 0xc4,
     0xe5, 0xa3, 0x6a, 0x32, 0x39, 0x2e, 0x46, 0x5f]

def selfloopExpectedPreimage : ByteArray :=
  mkSnapshotPreimageBytes 1 constitutionalMask0xFF33 rawSnapEplusSelfloopBytes

/-- Pure deterministic `F91-02` test hash matching `pinnedSelfloopRoot32` on the 149-byte
    `SNAP-PHI-EPLUS-SELFLOOP-A1` preimage and returning `f93ForgedZero32` on carrier preimages. -/
def mockSelfloopHash256 (bs : ByteArray) : ByteArray :=
  if decide (bs = selfloopExpectedPreimage) then pinnedSelfloopRoot32 else f93ForgedZero32

def ex1Bundle0x05 : RawCNB1Bundle :=
  { hdr :=
      { closureTag := 2
        claimShortest := 1
        authTierTag := 1
        reservedZero := 0
        generationV := 1
        policyMask := constitutionalMask0xFF33
        transitionTag := 0
        padZero := 0
        claimedRoot32 := pinnedSelfloopRoot32 }
    rawSnap := rawSnapEplusSelfloop
    candidateEdges := [(0, 0), (0, 1), (1, 0)]
    candidateRelations := [(0, 0), (0, 1), (1, 0), (1, 1)]
    posWitnesses :=
      [ { sVid := 0, tVid := 0, rank := 1, nextHop := 0 },
        { sVid := 0, tVid := 1, rank := 1, nextHop := 1 },
        { sVid := 1, tVid := 0, rank := 1, nextHop := 0 },
        { sVid := 1, tVid := 1, rank := 2, nextHop := 0 } ]
    closedCuts :=
      [ { srcVid := 0, targets := [0, 1] },
        { srcVid := 1, targets := [0, 1] } ] }

def ex1HopEntries : List RawHopWireEntry :=
  [ { sVid := 0, tVid := 0, rank := 1, hops := [0] },
    { sVid := 0, tVid := 1, rank := 1, hops := [1] },
    { sVid := 1, tVid := 0, rank := 1, hops := [0] },
    { sVid := 1, tVid := 1, rank := 2, hops := [0] } ]

def ex1GeoBindHeader : RawCarrierBindHeader :=
  { hSigma32 := pinnedSelfloopRoot32
    hCarrier32 := f93ForgedZero32
    closureTag := 2
    carrierTag := 2
    queryS := 0
    queryT := 1 }

def ex1GeoCert : SourceCertTerm :=
  { evasionModeTag := 0
    closureTag := 2
    carrierTag := 2
    modeTag := 2
    claimedL := 1
    claimedU := 1
    unbreakableRefKind := 2
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses :=
      [ { refKind := 2
          jIdx := 0
          walkVertices := [0, 1]
          stepWitnesses := [{ stepTag := 1, irIdx := 0 }] } ]
    retractionIrIndices := [0]
    dualCutVids := [0] }

def ex1PktTerm0x05 : RawCnp2ResiliencePacket0x00 :=
  .kind0x05 ex1Bundle0x05 ex1HopEntries 0 1 [] ex1GeoBindHeader ex1GeoCert

def ex1Packet0x05Bytes : ByteArray :=
  bytesOfList (encodeCnp2PacketList ex1PktTerm0x05)

theorem w2_ex1_pinned_a1_0x05_gate_ok :
    checkCnp2ResiliencePacketPinnedA1_0x00 mockSelfloopHash256 ex1Packet0x05Bytes = true := by
  have hwf : WF_Cnp2ResiliencePacket0x00 ex1PktTerm0x05 := rfl
  have hdec : decodeCnp2ResiliencePacket0x00 ex1Packet0x05Bytes = some ex1PktTerm0x05 := by
    unfold decodeCnp2ResiliencePacket0x00 ex1Packet0x05Bytes
    rw [listOfBytes_bytesOfList]
    exact parseCnp2PacketExact_encode hwf
  unfold checkCnp2ResiliencePacketPinnedA1_0x00 checkCnp2ResiliencePacket0x00
  rw [hdec]
  dsimp only [ex1PktTerm0x05]
  have hlk : lookupPinnedA1 ex1Bundle0x05.rawSnap.snapshotId pinnedOmegaKappaA1Registry15 =
      some { snapshotId := "SNAP-PHI-EPLUS-SELFLOOP-A1"
             pinnedGen := 1
             pinnedRootHex := "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f"
             pinnedConstIds := [] } := rfl
  have hmockSnap : mockSelfloopHash256 selfloopExpectedPreimage = pinnedSelfloopRoot32 := by
    unfold mockSelfloopHash256
    rw [if_pos (decide_eq_true rfl)]
  have hb1 : checkCNB1B1Bool mockSelfloopHash256 pinnedOmegaKappaA1Registry15 ex1Bundle0x05 [] = true := by
    unfold checkCNB1B1Bool
    rw [hlk]
    dsimp only
    change (decide (ex1Bundle0x05.hdr.closureTag = 1 ∨ ex1Bundle0x05.hdr.closureTag = 2) &&
            decide (ex1Bundle0x05.hdr.claimShortest = 0 ∨ ex1Bundle0x05.hdr.claimShortest = 1) &&
            decide (ex1Bundle0x05.hdr.authTierTag = 1) &&
            decide (ex1Bundle0x05.hdr.reservedZero = 0 ∧ ex1Bundle0x05.hdr.transitionTag = 0 ∧ ex1Bundle0x05.hdr.padZero = 0) &&
            decide (ex1Bundle0x05.hdr.policyMask = constitutionalMask0xFF33) &&
            decide (mockSelfloopHash256 selfloopExpectedPreimage = ex1Bundle0x05.hdr.claimedRoot32) &&
            (decide (ex1Bundle0x05.hdr.generationV = 1) &&
             decide (bytes32ToLowerHex ex1Bundle0x05.hdr.claimedRoot32 =
               "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f") &&
             strictIncNatBool [] &&
             listAllBool (fun ci => decide (ci < ex1Bundle0x05.rawSnap.irRecords.length)) [] &&
             decide (List.map (ridOfIdx (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap)) [] = []) &&
             decide ([] = (projectIssuerPartition (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap) []).constIssuers))) = true
    rw [hmockSnap]
    have hhex : decide (bytes32ToLowerHex ex1Bundle0x05.hdr.claimedRoot32 =
        "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f") = true :=
      decide_eq_true rfl
    rw [hhex]
    rfl
  rw [hb1, hlk]
  dsimp only
  unfold checkSingleDecodedClaimAgainstBase
  dsimp only
  have hrawLen : (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap).vertexIds.length = 2 := rfl
  have hencC : encodeCarrierPayload 2 (.geodesicHops ex1HopEntries) =
      some (bytesOfList (encodeCarrierPayloadList (.geodesicHops ex1HopEntries))) := rfl
  rw [hrawLen, hencC]
  dsimp only
  have hprojC : projectRawCarrierToSpec
      (projectWireBase0x05 (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap)
        ex1Bundle0x05 ex1HopEntries)
      (.geodesicHops ex1HopEntries) = some .geodesicBundle := rfl
  rw [hprojC]
  dsimp only
  unfold checkDigestVerifiedBool
  have hgenEq : (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap).generation = 1 := rfl
  rw [hgenEq]
  change (decide (ex1GeoBindHeader.queryS = 0 ∧ ex1GeoBindHeader.queryT = 1) &&
          (decide (ex1GeoBindHeader.hSigma32.size = 32) &&
           decide (ex1GeoBindHeader.hCarrier32.size = 32) &&
           decide ((mockSelfloopHash256 selfloopExpectedPreimage).size = 32) &&
           decide ((mockSelfloopHash256 (mkCarrierPreimageBytes ex1GeoBindHeader.carrierTag ex1GeoBindHeader.hSigma32
             ex1GeoBindHeader.closureTag ex1GeoBindHeader.queryS ex1GeoBindHeader.queryT
             (bytesOfList (encodeCarrierPayloadList (.geodesicHops ex1HopEntries))))).size = 32) &&
           decide (ex1GeoBindHeader.closureTag = ex1GeoCert.closureTag) &&
           decide (ex1GeoBindHeader.carrierTag = 2) &&
           decide (ex1GeoCert.carrierTag = 2) &&
           decide (ex1GeoBindHeader.queryS < 2 ∧ ex1GeoBindHeader.queryT < 2) &&
           decide (ex1GeoBindHeader.hSigma32 = mockSelfloopHash256 selfloopExpectedPreimage) &&
           decide (bytes32ToLowerHex ex1GeoBindHeader.hSigma32 =
             "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f") &&
           decide (ex1GeoBindHeader.hCarrier32 =
             mockSelfloopHash256 (mkCarrierPreimageBytes ex1GeoBindHeader.carrierTag ex1GeoBindHeader.hSigma32
               ex1GeoBindHeader.closureTag ex1GeoBindHeader.queryS ex1GeoBindHeader.queryT
               (bytesOfList (encodeCarrierPayloadList (.geodesicHops ex1HopEntries)))))) &&
          checkSourceCert0x00
            (projectIssuerPartition (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap) [])
            (projectWireBase0x05 (projectRawToSourceSnapshot mockSelfloopHash256 ex1Bundle0x05.hdr ex1Bundle0x05.rawSnap)
              ex1Bundle0x05 ex1HopEntries)
            0 1 .geodesicBundle ex1GeoCert) = true
  rw [hmockSnap]
  have hdHex : decide (bytes32ToLowerHex ex1GeoBindHeader.hSigma32 =
      "0cf299cb5bee9923ae0d547f48ec4d60abe582fb05db25c4e5a36a32392e465f") = true :=
    decide_eq_true rfl
  have hmockCar :
      mockSelfloopHash256 (mkCarrierPreimageBytes ex1GeoBindHeader.carrierTag ex1GeoBindHeader.hSigma32
        ex1GeoBindHeader.closureTag ex1GeoBindHeader.queryS ex1GeoBindHeader.queryT
        (bytesOfList (encodeCarrierPayloadList (.geodesicHops ex1HopEntries)))) = f93ForgedZero32 := by
    unfold mockSelfloopHash256
    have hne : (mkCarrierPreimageBytes ex1GeoBindHeader.carrierTag ex1GeoBindHeader.hSigma32
        ex1GeoBindHeader.closureTag ex1GeoBindHeader.queryS ex1GeoBindHeader.queryT
        (bytesOfList (encodeCarrierPayloadList (.geodesicHops ex1HopEntries)))) ≠ selfloopExpectedPreimage := by
      intro heq
      have hsz := congrArg ByteArray.size heq
      revert hsz
      decide
    rw [decide_eq_false hne]
    rfl
  rw [hdHex, hmockCar]
  rfl

theorem w2_ex1_pinned_a1_0x05_sound :
    PinnedA1SourceSoundness mockSelfloopHash256 ex1Packet0x05Bytes :=
  w2d_packet_sound_pinned_a1 mockSelfloopHash256 ex1Packet0x05Bytes w2_ex1_pinned_a1_0x05_gate_ok

/-! ## `Ex-W2-2`: `0x03` `Local` + `Global` Packet Exercising All 4 `F93-03` Gates -/

def ex2RawSnap03 : RawSnapshotWireTerm :=
  { snapshotId := "SA03"
    bucket0 := ["U0", "U1"]
    bucket1 := []
    bucket2 := []
    bucket3 := []
    irRecords :=
      [ { recTag := 1
          recordId := "C0"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 1, targetSortCode := 0, relTag := 1 }] } ] }

def ex2Reg03 : List PinnedA1Entry :=
  [ { snapshotId := "SA03"
      pinnedGen := 1
      pinnedRootHex := bytes32ToLowerHex f93ForgedZero32
      pinnedConstIds := ["C0"] } ]

def ex2Bundle0x03 : RawCNB1Bundle :=
  { hdr :=
      { closureTag := 2
        claimShortest := 0
        authTierTag := 1
        reservedZero := 0
        generationV := 1
        policyMask := constitutionalMask0xFF33
        transitionTag := 0
        padZero := 0
        claimedRoot32 := f93ForgedZero32 }
    rawSnap := ex2RawSnap03
    candidateEdges := [(0, 1)]
    candidateRelations := [(0, 1)]
    posWitnesses := [{ sVid := 0, tVid := 1, rank := 1, nextHop := 1 }]
    closedCuts := [{ srcVid := 0, targets := [1] }, { srcVid := 1, targets := [] }] }

def ex2LocBindHeader : RawCarrierBindHeader :=
  { hSigma32 := f93ForgedZero32
    hCarrier32 := f93ForgedZero32
    closureTag := 2
    carrierTag := 1
    queryS := 0
    queryT := 1 }

def ex2LocCert : SourceCertTerm :=
  { evasionModeTag := 0
    closureTag := 2
    carrierTag := 1
    modeTag := 1
    claimedL := 0
    claimedU := 0
    unbreakableRefKind := 1
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses := []
    retractionIrIndices := []
    dualCutVids := [] }

def ex2GlobBindHeader : RawCarrierBindHeader :=
  { hSigma32 := f93ForgedZero32
    hCarrier32 := f93ForgedZero32
    closureTag := 2
    carrierTag := 3
    queryS := 0
    queryT := 1 }

def ex2GlobCert : SourceCertTerm :=
  { evasionModeTag := 0
    closureTag := 2
    carrierTag := 3
    modeTag := 1
    claimedL := 0
    claimedU := 0
    unbreakableRefKind := 2
    unbreakableLocalIdx := 0
    unbreakableWalk := [0, 1]
    primalWitnesses := []
    retractionIrIndices := []
    dualCutVids := [] }

def ex2PktTerm0x03 : RawCnp2ResiliencePacket0x00 :=
  .kind0x03 ex2Bundle0x03 0 1 [0] [[0, 1]] ex2LocBindHeader ex2LocCert ex2GlobBindHeader ex2GlobCert

def ex2Packet0x03Bytes : ByteArray :=
  bytesOfList (encodeCnp2PacketList ex2PktTerm0x03)

theorem w2_ex2_0x03_packet_gate_ok :
    checkCnp2ResiliencePacket0x00 constZeroHash32 ex2Reg03 ex2Packet0x03Bytes = true := by
  have hwf : WF_Cnp2ResiliencePacket0x00 ex2PktTerm0x03 := rfl
  have hdec : decodeCnp2ResiliencePacket0x00 ex2Packet0x03Bytes = some ex2PktTerm0x03 := by
    unfold decodeCnp2ResiliencePacket0x00 ex2Packet0x03Bytes
    rw [listOfBytes_bytesOfList]
    exact parseCnp2PacketExact_encode hwf
  have hlk : lookupPinnedA1 ex2Bundle0x03.rawSnap.snapshotId ex2Reg03 =
      some { snapshotId := "SA03"
             pinnedGen := 1
             pinnedRootHex := bytes32ToLowerHex f93ForgedZero32
             pinnedConstIds := ["C0"] } := rfl
  have hb1 : checkCNB1B1Bool constZeroHash32 ex2Reg03 ex2Bundle0x03 [0] = true := by
    unfold checkCNB1B1Bool
    rw [hlk]
    dsimp only
    have hhex : decide (bytes32ToLowerHex ex2Bundle0x03.hdr.claimedRoot32 =
        bytes32ToLowerHex f93ForgedZero32) = true :=
      decide_eq_true rfl
    rw [hhex]
    rfl
  unfold checkCnp2ResiliencePacket0x00
  rw [hdec]
  dsimp only [ex2PktTerm0x03]
  have hGate1 : checkGate1Wire0x03Bool constZeroHash32 ex2Reg03 ex2Bundle0x03 0 1 [0] = true := by
    unfold checkGate1Wire0x03Bool
    rw [hb1]
    rfl
  rw [hGate1, hlk]
  dsimp only
  have hCanonOk :
      checkVerifiedBase
        (projectIssuerPartition (projectRawToSourceSnapshot constZeroHash32 ex2Bundle0x03.hdr ex2Bundle0x03.rawSnap) ["C0"])
        (synthesizeVerifiedBase
          (projectIRGraph (projectRawToSourceSnapshot constZeroHash32 ex2Bundle0x03.hdr ex2Bundle0x03.rawSnap))
          (closureOfTag ex2Bundle0x03.hdr.closureTag)) = true := rfl
  rw [hCanonOk]
  unfold checkSingleDecodedClaimAgainstBase
  dsimp only
  have hrawLen : (projectRawToSourceSnapshot constZeroHash32 ex2Bundle0x03.hdr ex2Bundle0x03.rawSnap).vertexIds.length = 2 := rfl
  have hencLoc : encodeCarrierPayload 2 (.localPaths [[0, 1]]) =
      some (bytesOfList (encodeCarrierPayloadList (.localPaths [[0, 1]]))) := rfl
  have hencGlob : encodeCarrierPayload 2 (.globalEdges ex2Bundle0x03.candidateEdges) =
      some (bytesOfList (encodeCarrierPayloadList (.globalEdges ex2Bundle0x03.candidateEdges))) := rfl
  rw [hrawLen, hencLoc, hencGlob]
  dsimp only
  have hprojGlob :
      projectRawCarrierToSpec
        (synthesizeVerifiedBase
          (projectIRGraph (projectRawToSourceSnapshot constZeroHash32 ex2Bundle0x03.hdr ex2Bundle0x03.rawSnap))
          (closureOfTag ex2Bundle0x03.hdr.closureTag))
        (.globalEdges ex2Bundle0x03.candidateEdges) = some .globalGraph := rfl
  rw [hprojGlob]
  unfold checkDigestVerifiedBool
  have hdLoc : decide (bytes32ToLowerHex ex2LocBindHeader.hSigma32 = bytes32ToLowerHex f93ForgedZero32) = true :=
    decide_eq_true rfl
  have hdGlob : decide (bytes32ToLowerHex ex2GlobBindHeader.hSigma32 = bytes32ToLowerHex f93ForgedZero32) = true :=
    decide_eq_true rfl
  rw [hdLoc, hdGlob]
  rfl

theorem w2_ex2_0x03_packet_sound :
    SourceSoundnessRelativeTo constZeroHash32 ex2Reg03 ex2Packet0x03Bytes :=
  w2d_packet_sound_relative_to_registry constZeroHash32 ex2Reg03 ex2Packet0x03Bytes w2_ex2_0x03_packet_gate_ok

/-! ## Adversarial Rejection Proofs (`Adv-W2-1`..`Adv-W2-7`) -/

def adv1BadRankBundle0x03 : RawCNB1Bundle :=
  { ex2Bundle0x03 with
    posWitnesses := [{ sVid := 0, tVid := 1, rank := 99, nextHop := 1 }] }

def adv1BadRankPktTerm0x03 : RawCnp2ResiliencePacket0x00 :=
  .kind0x03 adv1BadRankBundle0x03 0 1 [0] [[0, 1]] ex2LocBindHeader ex2LocCert ex2GlobBindHeader ex2GlobCert

def adv1BadRank0x03Bytes : ByteArray :=
  bytesOfList (encodeCnp2PacketList adv1BadRankPktTerm0x03)

/-- **`Adv-W2-1` (`F93-03` Non-Laundering Witness)**:
    Corrupting `posWitnesses[0].rank := 99` in a `0x03` packet still decodes cleanly AND
    Gate 2's `synthesizeVerifiedBase` still passes `#41`'s `checkVerifiedBase`, YET Gate 1
    causes `checkCnp2ResiliencePacket0x00` to reject (`= false`)! -/
theorem w2_adv1_f93_03_rank_laundering_rejected :
    decodeCnp2ResiliencePacket0x00 adv1BadRank0x03Bytes = some adv1BadRankPktTerm0x03 ∧
    checkVerifiedBase
      (projectIssuerPartition (projectRawToSourceSnapshot constZeroHash32 adv1BadRankBundle0x03.hdr adv1BadRankBundle0x03.rawSnap) ["C0"])
      (synthesizeVerifiedBase
        (projectIRGraph (projectRawToSourceSnapshot constZeroHash32 adv1BadRankBundle0x03.hdr adv1BadRankBundle0x03.rawSnap))
        (closureOfTag adv1BadRankBundle0x03.hdr.closureTag)) = true ∧
    checkCnp2ResiliencePacket0x00 constZeroHash32 ex2Reg03 adv1BadRank0x03Bytes = false := by
  have hwf : WF_Cnp2ResiliencePacket0x00 adv1BadRankPktTerm0x03 := rfl
  have hdec : decodeCnp2ResiliencePacket0x00 adv1BadRank0x03Bytes = some adv1BadRankPktTerm0x03 := by
    unfold decodeCnp2ResiliencePacket0x00 adv1BadRank0x03Bytes
    rw [listOfBytes_bytesOfList]
    exact parseCnp2PacketExact_encode hwf
  refine ⟨hdec, rfl, ?_⟩
  unfold checkCnp2ResiliencePacket0x00
  rw [hdec]
  dsimp only [adv1BadRankPktTerm0x03]
  have hb3Fail : checkCNB1B3Bool adv1BadRankBundle0x03 = false := rfl
  unfold checkGate1Wire0x03Bool
  rw [hb3Fail]
  simp only [Bool.and_false, Bool.false_and]

/-- **`Adv-W2-2`**: Non-resilience `packet_kind = 0x01` (`HELD`) is rejected at decode (`= none`). -/
def adv2PacketKind0x01Bytes : ByteArray :=
  bytesOfList (cnp2MagicBytes ++ (packU16BE 2 ++ (packU8 1 ++ (packU8 0 ++ encodeLenSliceList []))))

theorem w2_adv2_packet_kind_0x01_rejected :
    decodeCnp2ResiliencePacket0x00 adv2PacketKind0x01Bytes = none := by
  unfold decodeCnp2ResiliencePacket0x00 adv2PacketKind0x01Bytes
  rw [listOfBytes_bytesOfList]
  have hb : decide (cnp2EnvelopeSizeBytes ≤
      (cnp2MagicBytes ++ (packU16BE 2 ++ (packU8 1 ++ (packU8 0 ++ encodeLenSliceList [])))).length ∧
      (cnp2MagicBytes ++ (packU16BE 2 ++ (packU8 1 ++ (packU8 0 ++ encodeLenSliceList [])))).length ≤
        maxPacketBytes) = true := rfl
  unfold parseCnp2PacketExact
  rw [if_pos hb]
  unfold parseCnp2Core
  refine (optBind_eq_of_eq (parseExactMagic_append cnp2MagicBytes _)).trans ?_
  dsimp only
  have h16 : 2 < 65536 := by decide
  refine (optBind_eq_of_eq (parseU16BE_packU16BE_append h16 _)).trans ?_
  dsimp only
  have hv : decide (2 = cnp2WireVersion) = true := rfl
  rw [if_pos hv]
  have h8_1 : 1 < 256 := by decide
  have h8_0 : 0 < 256 := by decide
  refine (optBind_eq_of_eq (parseU8_packU8_append h8_1 _)).trans ?_
  dsimp only
  refine (optBind_eq_of_eq (parseU8_packU8_append h8_0 _)).trans ?_
  dsimp only
  have hev : decide ((0 : Nat) = 0) = true := rfl
  rw [if_pos hev]
  have hp0 := parseLenSlice_encode_append (sec := []) (by decide) []
  rw [List.append_nil] at hp0
  refine (optBind_eq_of_eq (expectEmptyRest_some hp0)).trans rfl

/-- **`Adv-W2-3`**: Corrupted `"CNP9"` and `"CNB9"` magic headers are rejected (`= none`). -/
def adv3BadCnpMagicBytes : ByteArray :=
  bytesOfList ([0x43, 0x4E, 0x50, 0x39] ++ packU16BE 2 ++ packU8 5 ++ packU8 0 ++ packU32BE 0)

def adv3BadCnbMagicBytes : ByteArray :=
  bytesOfList ([0x43, 0x4E, 0x42, 0x39] ++ List.replicate 58 0)

theorem w2_adv3_corrupted_magic_rejected :
    decodeCnp2ResiliencePacket0x00 adv3BadCnpMagicBytes = none ∧
    decodeCNB1Bundle adv3BadCnbMagicBytes = none := ⟨rfl, rfl⟩

/-- **`Adv-W2-4` (`93rd Ruling §2` Wire-vs-`B2` Separation)**:
    Cross-sort duplicate vertex `"V0"` in both `bucket0` and `bucket1` succeeds at per-bucket
    wire decode (`some`), yet deterministically fails `checkCNB1B2Bool` (`false`)! -/
def adv4CrossSortDupSnap : RawSnapshotWireTerm :=
  { snapshotId := "SDUP"
    bucket0 := ["V0"]
    bucket1 := ["V0"]
    bucket2 := []
    bucket3 := []
    irRecords :=
      [ { recTag := 1
          recordId := "R0"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 0, targetSortCode := 0, relTag := 1 }] } ] }

def adv4CrossSortDupBundle : RawCNB1Bundle :=
  { f93ForgedBundle with rawSnap := adv4CrossSortDupSnap }

theorem w2_adv4_cross_sort_duplicate_vertex_separated :
    decodeSnapshotSection (bytesOfList (encodeSnapshotSectionList adv4CrossSortDupSnap)) =
      some adv4CrossSortDupSnap ∧
    checkCNB1B2Bool constZeroHash32 adv4CrossSortDupBundle = false := by
  have hwf : WF_RawSnapshotWire adv4CrossSortDupSnap := rfl
  have henc0 : encodeSnapshotSection adv4CrossSortDupSnap =
      some (bytesOfList (encodeSnapshotSectionList adv4CrossSortDupSnap)) := rfl
  rcases w2b_snapshot_forward_roundtrip hwf with ⟨B, henc, hdec⟩
  rw [henc0] at henc
  injection henc with hBeq
  subst hBeq
  exact ⟨hdec, rfl⟩

/-- **`Adv-W2-5`**: Unlicensed `relTag = 13` (`expectedSortPairByRelTag 13 = none`) succeeds at
    wire decode (`1 ≤ 13 ≤ 13`), yet deterministically fails `checkCNB1B2Bool` (`false`)! -/
def adv5RelTag13Snap : RawSnapshotWireTerm :=
  { snapshotId := "SR13"
    bucket0 := ["V0", "V1"]
    bucket1 := []
    bucket2 := []
    bucket3 := []
    irRecords :=
      [ { recTag := 1
          recordId := "R0"
          sourceVid := 0
          sourceSortCode := 0
          refs := [{ targetVid := 1, targetSortCode := 0, relTag := 13 }] } ] }

def adv5RelTag13Bundle : RawCNB1Bundle :=
  { f93ForgedBundle with rawSnap := adv5RelTag13Snap }

theorem w2_adv5_unlicensed_reltag13_separated :
    decodeSnapshotSection (bytesOfList (encodeSnapshotSectionList adv5RelTag13Snap)) =
      some adv5RelTag13Snap ∧
    checkCNB1B2Bool constZeroHash32 adv5RelTag13Bundle = false := by
  have hwf : WF_RawSnapshotWire adv5RelTag13Snap := rfl
  have henc0 : encodeSnapshotSection adv5RelTag13Snap =
      some (bytesOfList (encodeSnapshotSectionList adv5RelTag13Snap)) := rfl
  rcases w2b_snapshot_forward_roundtrip hwf with ⟨B, henc, hdec⟩
  rw [henc0] at henc
  injection henc with hBeq
  subst hBeq
  exact ⟨hdec, rfl⟩

/-- **`Adv-W2-6` (`F91-03` Discipline)**: Unsorted `bucket0 = ["L1", "L0"]` is outside canonical
    wire domain (`encodeSnapshotSection = none`). -/
def adv6UnsortedSnap : RawSnapshotWireTerm :=
  { rawSnapEplusSelfloop with bucket0 := ["L1", "L0"] }

theorem w2_adv6_unsorted_bucket_encode_none :
    encodeSnapshotSection adv6UnsortedSnap = none := rfl

/-- **`Adv-W2-7`**: `evasion_mode = 0x01` (`HELD`) is rejected at outer envelope decode (`= none`). -/
def adv7Evasion0x01Bytes : ByteArray :=
  bytesOfList (cnp2MagicBytes ++ packU16BE 2 ++ packU8 5 ++ packU8 1 ++ packU32BE 0)

theorem w2_adv7_evasion_mode_0x01_rejected :
    decodeCnp2ResiliencePacket0x00 adv7Evasion0x01Bytes = none := rfl

end OmegaLambda.W2Examples

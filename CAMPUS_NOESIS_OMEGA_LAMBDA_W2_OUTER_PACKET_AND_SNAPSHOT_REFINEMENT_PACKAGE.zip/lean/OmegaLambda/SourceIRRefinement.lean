/-
  CAMPUS-NOESIS Omega-Lambda R1: Source-IR-to-Abstract Lean 4 Proof Track
  Module: `OmegaLambda.SourceIRRefinement`

  Authorized Scope (88th Independent Static Tribunal Ruling):
    1. Independent Source-Domain Syntax & Retraction Semantics (`A1` Pinned Registry,
       `0xFF33` 4-Sort Constitutional Transition Law, Multi-Ref IR Hyperedges, and
       physical record-list filtering `residualRecordsByStr` / `residualRecordsByIdx`
       defined WITHOUT mentioning `LabeledGraph` or `PointedLTS`).
    2. `Ref-IR-Commute` (`ref_ir_commute`):
         `∀ snap D u w, SourceEdgeSurvivesIdx snap D u w ↔ AbstractEdgeSurvives (projectIRGraph snap) D u w`
       including multi-ref hyperedge simultaneous retraction (`hyperedge_simultaneous_retraction`)
       and duplicate-reference idempotence (`duplicate_refs_nodup_support`).
    3. `Ref-IR-Walk-Commute` (`ref_ir_walk_commute`, `ref_ir_valid_walk_iff`,
       `ref_ir_true_shortest_walk_iff`, `ref_ir_carrier_survives_idx_iff`):
       inductive lifting from single edges to `E_STAR`/`E_PLUS` walks, true shortest
       walks, and all 3 carriers (`LocalPacket`, `GeodesicBundle`, `GlobalGraph`).
    4. `A1` String Issuer Partition Preimage, Mutual-Inverse String/Index Bijection
       (`ridsOfIdxs` / `idxsOfRids`), Exact Cardinality Preservation (`|D| = |rid(D)|`),
       and Master Bridge Theorem (`source_ir_to_omegaLambda_resilience_sound`) connecting
       `#41` `omegaLambda_resilience_sound` to pure string-keyed source resilience
       (`SourceStringSemanticResilience`).

  Discipline:
    - `sorryAx = 0`, user `axiom = 0`, `opaque = 0`
    - `Lean.ofReduceBool = 0`, `Lean.trustCompiler = 0` (`native_decide` prohibited)
-/

import OmegaLambda.CheckerSoundness

namespace OmegaLambda

abbrev AsciiId := String

/-! ## Elementary Indexed Lookup & Filter Helpers -/

def nthOpt : List α → Nat → Option α
  | [], _ => none
  | x :: _, 0 => some x
  | _ :: xs, n + 1 => nthOpt xs n

theorem nthOpt_lt_length {xs : List α} {r : Nat} {x : α}
    (h : nthOpt xs r = some x) : r < xs.length := by
  induction xs generalizing r with
  | nil => cases h
  | cons _ tl ih =>
    cases r with
    | zero =>
      simp only [List.length_cons]
      omega
    | succ k =>
      simp only [nthOpt] at h
      simp only [List.length_cons]
      exact Nat.succ_lt_succ (ih h)

theorem nthOpt_mem {xs : List α} {r : Nat} {x : α}
    (h : nthOpt xs r = some x) : x ∈ xs := by
  induction xs generalizing r with
  | nil => cases h
  | cons hd tl ih =>
    cases r with
    | zero =>
      simp only [nthOpt] at h
      injection h with heq
      subst heq
      exact List.Mem.head tl
    | succ k =>
      simp only [nthOpt] at h
      exact List.Mem.tail hd (ih h)

theorem exists_nthOpt_of_lt {xs : List α} {r : Nat} (hlt : r < xs.length) :
    ∃ x, nthOpt xs r = some x := by
  induction xs generalizing r with
  | nil =>
    simp only [List.length_nil] at hlt
    omega
  | cons hd tl ih =>
    cases r with
    | zero => exact ⟨hd, rfl⟩
    | succ k =>
      simp only [List.length_cons] at hlt
      exact ih (Nat.lt_of_succ_lt_succ hlt)

theorem mem_iff_exists_nthOpt (x : α) (xs : List α) :
    x ∈ xs ↔ ∃ r, nthOpt xs r = some x := by
  induction xs with
  | nil =>
    constructor
    · intro h; cases h
    · intro ⟨_, h⟩; cases h
  | cons hd tl ih =>
    constructor
    · intro hmem
      cases hmem with
      | head => exact ⟨0, rfl⟩
      | tail _ hm =>
        rcases ih.mp hm with ⟨k, hk⟩
        exact ⟨k + 1, hk⟩
    · intro ⟨r, hr⟩
      exact nthOpt_mem hr

theorem nodup_map_nthOpt_inj {xs : List α} {f : α → β}
    (hnd : NodupList (xs.map f))
    {r1 r2 : Nat} {x1 x2 : α}
    (h1 : nthOpt xs r1 = some x1) (h2 : nthOpt xs r2 = some x2)
    (hfeq : f x1 = f x2) : r1 = r2 := by
  induction xs generalizing r1 r2 with
  | nil => cases h1
  | cons hd tl ih =>
    simp only [List.map_cons] at hnd
    cases hnd with
    | cons hnotmem hndTl =>
      cases r1 with
      | zero =>
        simp only [nthOpt] at h1
        injection h1 with hx1
        subst hx1
        cases r2 with
        | zero => rfl
        | succ k2 =>
          simp only [nthOpt] at h2
          exfalso
          apply hnotmem
          rw [hfeq]
          exact List.mem_map_of_mem (f := f) (nthOpt_mem h2)
      | succ k1 =>
        simp only [nthOpt] at h1
        cases r2 with
        | zero =>
          simp only [nthOpt] at h2
          injection h2 with hx2
          subst hx2
          exfalso
          apply hnotmem
          rw [← hfeq]
          exact List.mem_map_of_mem (f := f) (nthOpt_mem h1)
        | succ k2 =>
          simp only [nthOpt] at h2
          exact congrArg Nat.succ (ih hndTl h1 h2)

theorem nodup_append_disjoint {xs ys : List α}
    (hndX : NodupList xs) (hndY : NodupList ys)
    (hcross : ∀ z ∈ xs, z ∉ ys) :
    NodupList (xs ++ ys) := by
  induction hndX with
  | nil => exact hndY
  | @cons z zs hz _ ih =>
    refine NodupList.cons ?_ (ih (fun w hw => hcross w (List.Mem.tail z hw)))
    intro hmemApp
    rcases List.mem_append.mp hmemApp with hmemZs | hmemYs
    · exact hz hmemZs
    · exact hcross z (List.Mem.head zs) hmemYs

theorem nodup_rangeBelow (n : Nat) : NodupList (rangeBelow n) := by
  induction n with
  | zero => exact NodupList.nil
  | succ m ih =>
    simp only [rangeBelow]
    apply nodup_append_disjoint ih (NodupList.cons (fun h => by cases h) NodupList.nil)
    intro z hz hmemSing
    have hlt := (mem_rangeBelow_iff z m).mp hz
    cases hmemSing with
    | head => omega
    | tail _ hm => cases hm

theorem nodup_filter {xs : List α} (p : α → Bool) (hnd : NodupList xs) :
    NodupList (xs.filter p) := by
  induction hnd with
  | nil => exact NodupList.nil
  | @cons x rest hx _ ih =>
    simp only [List.filter]
    split
    · refine NodupList.cons ?_ ih
      intro hmem
      exact hx (List.mem_filter.mp hmem).1
    · exact ih

theorem nodup_flatMap_pairs {xs : List α} {f : α → List β}
    (hnd : NodupList xs)
    (hinner : ∀ x ∈ xs, NodupList (f x))
    (hdisj : ∀ x1 x2 y, x1 ∈ xs → x2 ∈ xs → y ∈ f x1 → y ∈ f x2 → x1 = x2) :
    NodupList (xs.flatMap f) := by
  induction hnd with
  | nil => exact NodupList.nil
  | @cons x rest hx _ ih =>
    simp only [List.flatMap_cons]
    have hndFx : NodupList (f x) := hinner x (List.Mem.head rest)
    have hndTail : NodupList (rest.flatMap f) :=
      ih (fun a ha => hinner a (List.Mem.tail x ha))
         (fun a1 a2 y ha1 ha2 hy1 hy2 =>
           hdisj a1 a2 y (List.Mem.tail x ha1) (List.Mem.tail x ha2) hy1 hy2)
    apply nodup_append_disjoint hndFx hndTail
    intro y hyFx hyRest
    rcases List.mem_flatMap.mp hyRest with ⟨x2, hx2Rest, hyFx2⟩
    have heq : x = x2 :=
      hdisj x x2 y (List.Mem.head rest) (List.Mem.tail x hx2Rest) hyFx hyFx2
    subst heq
    exact hx hx2Rest

/-! ## `0xFF33` 4-Sort Constitutional Transition Law (`F83-01B`) -/

inductive EpistemicSort where
  | event : EpistemicSort        -- code 0
  | dataset : EpistemicSort      -- code 1
  | proposition : EpistemicSort  -- code 2
  | derivation : EpistemicSort   -- code 3
  deriving DecidableEq, Repr

def sortCode : EpistemicSort → Nat
  | .event => 0
  | .dataset => 1
  | .proposition => 2
  | .derivation => 3

def constitutionalMask0xFF33 : Nat := 0xFF33

def licensedSortBit (su sw : EpistemicSort) : Bool :=
  decide (((constitutionalMask0xFF33 / (2 ^ (4 * sortCode su + sortCode sw))) % 2) = 1)

def IsForbiddenSortJump (su sw : EpistemicSort) : Prop :=
  (su = .event ∨ su = .dataset) ∧ (sw = .proposition ∨ sw = .derivation)

/-- Exact characterization of the 16-bit mask `0xFF33`:
    A directed sort transition `(su, sw)` is licensed iff it is NOT an unlicensed
    forward jump from `{EVENT, DATASET}` into `{PROPOSITION, DERIVATION}`. -/
theorem licensedSortBit_iff_not_forbidden (su sw : EpistemicSort) :
    licensedSortBit su sw = true ↔ ¬ IsForbiddenSortJump su sw := by
  cases su <;> cases sw <;>
    simp [licensedSortBit, constitutionalMask0xFF33, sortCode, IsForbiddenSortJump]

/-! ## Source-Domain `A1` Snapshot & Multi-Ref IR Hyperedge Syntax -/

structure SourceRef where
  targetVid : VertexId
  targetSort : EpistemicSort
  relSrcSort : EpistemicSort
  relDstSort : EpistemicSort
  deriving DecidableEq, Repr

structure SourceIRRecord where
  recordId : AsciiId
  sourceVid : VertexId
  sourceSort : EpistemicSort
  refs : List SourceRef
  deriving DecidableEq, Repr

structure PinnedA1Entry where
  snapshotId : AsciiId
  pinnedGen : Nat
  pinnedRootHex : AsciiId
  pinnedConstIds : List AsciiId
  deriving DecidableEq, Repr

structure SourceSnapshot where
  snapshotId : AsciiId
  generation : Nat
  authTierTag : Nat
  policyMask : Nat
  claimedRootHex : AsciiId
  computedRootHex : AsciiId
  vertexIds : List AsciiId
  vertexSorts : List EpistemicSort
  irRecords : List SourceIRRecord
  deriving DecidableEq, Repr

/-! ## Independently Defined Pure Source Retraction & Walk Semantics (`F88-02`)
    Defined strictly over `SourceSnapshot` record lists without mentioning
    `LabeledGraph`, `GraphEdge.support`, or `PointedLTS`. -/

def filterEnumNotIn (D : List IssuerId) : Nat → List SourceIRRecord → List SourceIRRecord
  | _, [] => []
  | k, rc :: rest =>
      if listMemBool k D then filterEnumNotIn D (k + 1) rest
      else rc :: filterEnumNotIn D (k + 1) rest

/-- Residual source records after retracting positional record indices `D`. -/
def residualRecordsByIdx (snap : SourceSnapshot) (D : List IssuerId) : List SourceIRRecord :=
  filterEnumNotIn D 0 snap.irRecords

/-- Residual source records after retracting canonical string record IDs `D_str`. -/
def residualRecordsByStr (snap : SourceSnapshot) (D_str : List AsciiId) : List SourceIRRecord :=
  snap.irRecords.filter (fun rc => !(listMemBool rc.recordId D_str))

def RecordIssuesEdge (rc : SourceIRRecord) (u w : VertexId) : Prop :=
  rc.sourceVid = u ∧ ∃ ref ∈ rc.refs, ref.targetVid = w

def recordIssuesEdgeBool (rc : SourceIRRecord) (u w : VertexId) : Bool :=
  decide (rc.sourceVid = u) && listAnyBool (fun ref => decide (ref.targetVid = w)) rc.refs

theorem recordIssuesEdgeBool_iff (rc : SourceIRRecord) (u w : VertexId) :
    recordIssuesEdgeBool rc u w = true ↔ RecordIssuesEdge rc u w := by
  simp only [recordIssuesEdgeBool, RecordIssuesEdge, Bool.and_eq_true,
    decide_eq_true_eq, listAnyBool_iff]

def SourceEdgeInRecords (recs : List SourceIRRecord) (u w : VertexId) : Prop :=
  ∃ rc ∈ recs, RecordIssuesEdge rc u w

def SourceEdgeSurvivesIdx (snap : SourceSnapshot) (D : List IssuerId) (u w : VertexId) : Prop :=
  SourceEdgeInRecords (residualRecordsByIdx snap D) u w

def SourceEdgeSurvivesStr (snap : SourceSnapshot) (D_str : List AsciiId) (u w : VertexId) : Prop :=
  SourceEdgeInRecords (residualRecordsByStr snap D_str) u w

inductive SourceEdgeChain (recs : List SourceIRRecord) : VertexId → VertexId → List VertexId → Prop where
  | nil (u : VertexId) : SourceEdgeChain recs u u []
  | cons {u w t : VertexId} (rest : List VertexId) :
      SourceEdgeInRecords recs u w →
      SourceEdgeChain recs w t rest →
      SourceEdgeChain recs u t (w :: rest)

def SourceIsValidWalk (snap : SourceSnapshot) (κ : ClosureKind) (s t : VertexId) : List VertexId → Prop
  | [] => False
  | v0 :: tail =>
      v0 = s ∧
      s < snap.vertexIds.length ∧
      t < snap.vertexIds.length ∧
      SourceEdgeChain snap.irRecords s t tail ∧
      (κ = .ePlus → tail ≠ [])

def SourceIsTrueShortestWalk (snap : SourceSnapshot) (κ : ClosureKind) (s t : VertexId)
    (γ : List VertexId) : Prop :=
  SourceIsValidWalk snap κ s t γ ∧
  ∀ γ', SourceIsValidWalk snap κ s t γ' → walkSteps γ ≤ walkSteps γ'

def SourceChainSurvivesIdx (snap : SourceSnapshot) (D : List IssuerId) :
    VertexId → List VertexId → Prop
  | _, [] => True
  | u, w :: rest => SourceEdgeSurvivesIdx snap D u w ∧ SourceChainSurvivesIdx snap D w rest

def SourceWalkSurvivesIdx (snap : SourceSnapshot) (D : List IssuerId) : List VertexId → Prop
  | [] => False
  | v0 :: tail => SourceChainSurvivesIdx snap D v0 tail

def SourceChainSurvivesStr (snap : SourceSnapshot) (D_str : List AsciiId) :
    VertexId → List VertexId → Prop
  | _, [] => True
  | u, w :: rest => SourceEdgeSurvivesStr snap D_str u w ∧ SourceChainSurvivesStr snap D_str w rest

def SourceWalkSurvivesStr (snap : SourceSnapshot) (D_str : List AsciiId) : List VertexId → Prop
  | [] => False
  | v0 :: tail => SourceChainSurvivesStr snap D_str v0 tail

def SourceCarrierSurvivesIdx (snap : SourceSnapshot) (κ : ClosureKind) (s t : VertexId) :
    CarrierSpec → List IssuerId → Prop
  | .localPacket pkt, D =>
      ∃ γ ∈ pkt, SourceWalkSurvivesIdx snap D γ
  | .geodesicBundle, D =>
      ∃ γ, SourceIsTrueShortestWalk snap κ s t γ ∧ SourceWalkSurvivesIdx snap D γ
  | .globalGraph, D =>
      ∃ γ, SourceIsValidWalk snap κ s t γ ∧ SourceWalkSurvivesIdx snap D γ

def SourceCarrierSurvivesStr (snap : SourceSnapshot) (κ : ClosureKind) (s t : VertexId) :
    CarrierSpec → List AsciiId → Prop
  | .localPacket pkt, D_str =>
      ∃ γ ∈ pkt, SourceWalkSurvivesStr snap D_str γ
  | .geodesicBundle, D_str =>
      ∃ γ, SourceIsTrueShortestWalk snap κ s t γ ∧ SourceWalkSurvivesStr snap D_str γ
  | .globalGraph, D_str =>
      ∃ γ, SourceIsValidWalk snap κ s t γ ∧ SourceWalkSurvivesStr snap D_str γ

/-- Retractable source record string IDs (`I_{rem,str}(snap) = rid(I) \ C_str^*`). -/
def sourceRemRecordIds (snap : SourceSnapshot) (pinnedConstIds : List AsciiId) : List AsciiId :=
  (snap.irRecords.map SourceIRRecord.recordId).filter (fun rid => !(listMemBool rid pinnedConstIds))

/-- Pure string-domain semantic claim predicate (`ScopedSourceSoundness` core). -/
def SourceStringClaimHolds (remRids : List AsciiId) (survStrPred : List AsciiId → Prop) :
    ResilienceClaim → Prop
  | .unbreakable =>
      ∀ D_str : List AsciiId, (∀ rid ∈ D_str, rid ∈ remRids) → survStrPred D_str
  | .finiteBounds lower upper =>
      lower ≤ upper ∧
      (∀ D_str : List AsciiId,
        NodupList D_str →
        (∀ rid ∈ D_str, rid ∈ remRids) →
        ¬ survStrPred D_str →
        lower ≤ D_str.length) ∧
      (∃ D_str_star : List AsciiId,
        NodupList D_str_star ∧
        (∀ rid ∈ D_str_star, rid ∈ remRids) ∧
        D_str_star.length ≤ upper ∧
        ¬ survStrPred D_str_star)

/-! ## Projection `Π_IR` (`projectIRGraph`) & String Partition Preimage (`F83-01A`) -/

def reconstructSupport (recs : List SourceIRRecord) (u w : VertexId) : List IssuerId :=
  (rangeBelow recs.length).filter (fun r =>
    match nthOpt recs r with
    | none => false
    | some rc => recordIssuesEdgeBool rc u w)

/-- Multi-ref duplicate idempotence: `reconstructSupport` is unconditionally duplicate-free,
    even if a single `SourceIRRecord` contains duplicate references to the same target `w`. -/
theorem duplicate_refs_nodup_support (recs : List SourceIRRecord) (u w : VertexId) :
    NodupList (reconstructSupport recs u w) :=
  nodup_filter _ (nodup_rangeBelow recs.length)

theorem mem_reconstructSupport_iff (recs : List SourceIRRecord) (u w : VertexId) (r : IssuerId) :
    r ∈ reconstructSupport recs u w ↔
    ∃ rc, nthOpt recs r = some rc ∧ RecordIssuesEdge rc u w := by
  simp only [reconstructSupport, List.mem_filter, mem_rangeBelow_iff]
  constructor
  · intro ⟨_, hmatch⟩
    cases hs : nthOpt recs r with
    | none => rw [hs] at hmatch; contradiction
    | some rc =>
      rw [hs] at hmatch
      exact ⟨rc, rfl, (recordIssuesEdgeBool_iff rc u w).mp hmatch⟩
  · intro ⟨rc, hs, hiss⟩
    refine ⟨nthOpt_lt_length hs, ?_⟩
    rw [hs]
    exact (recordIssuesEdgeBool_iff rc u w).mpr hiss

def projectIRGraph (snap : SourceSnapshot) : LabeledGraph :=
  let n := snap.vertexIds.length
  let edges :=
    (rangeBelow n).flatMap (fun u =>
      (rangeBelow n).flatMap (fun w =>
        let supp := reconstructSupport snap.irRecords u w
        if supp = [] then []
        else [{ src := u, dst := w, support := supp }]))
  { numVertices := n, edges := edges }

def AbstractEdgeSurvives (G : LabeledGraph) (D : List IssuerId) (u w : VertexId) : Prop :=
  ∃ e ∈ G.edges, e.src = u ∧ e.dst = w ∧ ¬ (∀ i ∈ e.support, i ∈ D)

def projectIssuerPartition (snap : SourceSnapshot) (pinnedConstIds : List AsciiId) : IssuerPartition :=
  let m := snap.irRecords.length
  let isConstIdx (r : IssuerId) : Bool :=
    match nthOpt snap.irRecords r with
    | none => false
    | some rc => listMemBool rc.recordId pinnedConstIds
  { constIssuers := (rangeBelow m).filter isConstIdx
    remIssuers := (rangeBelow m).filter (fun r => !(isConstIdx r)) }

theorem projectIssuerPartition_wf (snap : SourceSnapshot) (pinnedConstIds : List AsciiId) :
    WFPartition (projectIssuerPartition snap pinnedConstIds) := by
  intro r hconst hrem
  simp only [projectIssuerPartition, List.mem_filter] at hconst hrem
  rw [hconst.2] at hrem
  cases hrem.2

theorem checkIssuerPartition_projectIssuerPartition (snap : SourceSnapshot)
    (pinnedConstIds : List AsciiId) :
    checkIssuerPartition (projectIssuerPartition snap pinnedConstIds) = true := by
  simp only [checkIssuerPartition, disjointListsBool_iff]
  exact projectIssuerPartition_wf snap pinnedConstIds

/-! ## Well-Boundedness & `projectIRGraph` Edge Characterization -/

def SnapshotVertexBounds (snap : SourceSnapshot) : Prop :=
  ∀ rc ∈ snap.irRecords,
    rc.sourceVid < snap.vertexIds.length ∧
    ∀ ref ∈ rc.refs, ref.targetVid < snap.vertexIds.length

theorem mem_projectIRGraph_edges_iff (snap : SourceSnapshot) (e : GraphEdge) :
    e ∈ (projectIRGraph snap).edges ↔
    e.src < snap.vertexIds.length ∧
    e.dst < snap.vertexIds.length ∧
    reconstructSupport snap.irRecords e.src e.dst ≠ [] ∧
    e.support = reconstructSupport snap.irRecords e.src e.dst := by
  simp only [projectIRGraph, List.mem_flatMap, mem_rangeBelow_iff]
  constructor
  · intro ⟨u, hu, w, hw, hmemIf⟩
    split at hmemIf
    · cases hmemIf
    · next hne =>
      cases hmemIf with
      | head => exact ⟨hu, hw, hne, rfl⟩
      | tail _ hm => cases hm
  · intro ⟨hu, hw, hne, hsupp⟩
    refine ⟨e.src, hu, e.dst, hw, ?_⟩
    split
    · next hemp => exact absurd hemp hne
    · cases e
      simp only at hsupp
      subst hsupp
      exact List.Mem.head []

theorem nodup_map_of_inj_on {xs : List α} (f : α → β)
    (hnd : NodupList xs)
    (hinj : ∀ a b, a ∈ xs → b ∈ xs → f a = f b → a = b) :
    NodupList (xs.map f) := by
  induction hnd with
  | nil => exact NodupList.nil
  | @cons e rest heNotMem _ ih =>
    simp only [List.map_cons]
    refine NodupList.cons ?_ (ih (fun a b ha hb hp =>
      hinj a b (List.Mem.tail e ha) (List.Mem.tail e hb) hp))
    intro hmemMap
    rcases List.mem_map.mp hmemMap with ⟨e2, he2Rest, hpair⟩
    have heq : e = e2 :=
      hinj e e2 (List.Mem.head rest) (List.Mem.tail e he2Rest) hpair.symm
    subst heq
    exact heNotMem he2Rest

theorem nodup_projectIRGraph_edge_keys (snap : SourceSnapshot) :
    NodupList (((projectIRGraph snap).edges).map (fun e => (e.src, e.dst))) := by
  let n := snap.vertexIds.length
  let fInner (u w : VertexId) : List GraphEdge :=
    let supp := reconstructSupport snap.irRecords u w
    if supp = [] then [] else [{ src := u, dst := w, support := supp }]
  have hOuter : NodupList ((rangeBelow n).flatMap (fun u => (rangeBelow n).flatMap (fInner u))) := by
    apply nodup_flatMap_pairs (nodup_rangeBelow n)
    · intro u _
      apply nodup_flatMap_pairs (nodup_rangeBelow n)
      · intro w _
        dsimp [fInner]
        split
        · exact NodupList.nil
        · exact NodupList.cons (fun h => by cases h) NodupList.nil
      · intro w1 w2 e _ _ he1 he2
        dsimp [fInner] at he1 he2
        split at he1
        · cases he1
        · split at he2
          · cases he2
          · cases he1 with
            | head =>
              cases he2 with
              | head => rfl
              | tail _ hm => cases hm
            | tail _ hm => cases hm
    · intro u1 u2 e _ _ he1 he2
      rcases List.mem_flatMap.mp he1 with ⟨w1, _, hw1⟩
      rcases List.mem_flatMap.mp he2 with ⟨w2, _, hw2⟩
      dsimp [fInner] at hw1 hw2
      split at hw1
      · cases hw1
      · split at hw2
        · cases hw2
        · cases hw1 with
          | head =>
            cases hw2 with
            | head => rfl
            | tail _ hm => cases hm
          | tail _ hm => cases hm
  apply nodup_map_of_inj_on (fun e => (e.src, e.dst)) hOuter
  intro e1 e2 h1 h2 hpair
  have hm1 := (mem_projectIRGraph_edges_iff snap e1).mp h1
  have hm2 := (mem_projectIRGraph_edges_iff snap e2).mp h2
  injection hpair with hsrc hdst
  cases e1; cases e2
  simp only at hsrc hdst hm1 hm2
  subst hsrc; subst hdst
  rw [hm1.2.2.2, hm2.2.2.2]

theorem projectIRGraph_wf (snap : SourceSnapshot) (pinnedConstIds : List AsciiId) :
    GraphWF (projectIssuerPartition snap pinnedConstIds) (projectIRGraph snap) := by
  refine ⟨nodup_projectIRGraph_edge_keys snap, ?_⟩
  intro e he
  rcases (mem_projectIRGraph_edges_iff snap e).mp he with ⟨hu, hw, hne, hsupp⟩
  refine ⟨hu, hw, ?_, ?_⟩
  · rw [hsupp]; exact hne
  · intro i hi
    rw [hsupp] at hi
    rcases (mem_reconstructSupport_iff snap.irRecords e.src e.dst i).mp hi with ⟨rc, hnth, _⟩
    have hlt : i < snap.irRecords.length := nthOpt_lt_length hnth
    have hmemRange : i ∈ rangeBelow snap.irRecords.length := (mem_rangeBelow_iff i _).mpr hlt
    simp only [projectIssuerPartition, List.mem_filter]
    cases hc : (match nthOpt snap.irRecords i with
                | none => false
                | some r => listMemBool r.recordId pinnedConstIds)
    · exact Or.inr ⟨hmemRange, rfl⟩
    · exact Or.inl ⟨hmemRange, rfl⟩

/-! ## Target 1: `Ref-IR-Commute` (`ref_ir_commute`) & Hyperedge Theorems -/

theorem filterEnumNotIn_exists_iff (D : List IssuerId) (P : SourceIRRecord → Prop) :
    ∀ (recs : List SourceIRRecord) (k : Nat),
      (∃ rc ∈ filterEnumNotIn D k recs, P rc) ↔
      ∃ r, (k + r) ∉ D ∧ ∃ rc, nthOpt recs r = some rc ∧ P rc := by
  intro recs
  induction recs with
  | nil =>
    intro k
    simp only [filterEnumNotIn, nthOpt]
    constructor
    · intro ⟨_, hmem, _⟩; cases hmem
    · intro ⟨_, _, _, hnth, _⟩; cases hnth
  | cons hd tl ih =>
    intro k
    simp only [filterEnumNotIn]
    split
    · next hinD =>
      have hkMem : k ∈ D := (listMemBool_iff k D).mp hinD
      rw [ih (k + 1)]
      constructor
      · intro ⟨r, hnotD, rc, hnth, hp⟩
        refine ⟨r + 1, ?_, rc, hnth, hp⟩
        have heq : k + (r + 1) = k + 1 + r := by omega
        rw [heq]
        exact hnotD
      · intro ⟨r, hnotD, rc, hnth, hp⟩
        cases r with
        | zero =>
          exfalso
          simp only [Nat.add_zero] at hnotD
          exact hnotD hkMem
        | succ r' =>
          refine ⟨r', ?_, rc, hnth, hp⟩
          have heq : k + 1 + r' = k + (r' + 1) := by omega
          rw [heq]
          exact hnotD
    · next hnotInD =>
      have hkNotMem : k ∉ D :=
        fun hm => hnotInD ((listMemBool_iff k D).mpr hm)
      constructor
      · intro ⟨rc, hmem, hp⟩
        cases hmem with
        | head =>
          refine ⟨0, ?_, hd, rfl, hp⟩
          simpa using hkNotMem
        | tail _ hm =>
          rcases (ih (k + 1)).mp ⟨rc, hm, hp⟩ with ⟨r', hnotD, rc', hnth, hp'⟩
          refine ⟨r' + 1, ?_, rc', hnth, hp'⟩
          have heq : k + (r' + 1) = k + 1 + r' := by omega
          rw [heq]
          exact hnotD
      · intro ⟨r, hnotD, rc, hnth, hp⟩
        cases r with
        | zero =>
          simp only [nthOpt] at hnth
          injection hnth with hrc
          subst hrc
          exact ⟨hd, List.Mem.head _, hp⟩
        | succ r' =>
          simp only [nthOpt] at hnth
          have hnotD' : k + 1 + r' ∉ D := by
            have heq : k + 1 + r' = k + (r' + 1) := by omega
            rw [heq]
            exact hnotD
          rcases (ih (k + 1)).mpr ⟨r', hnotD', rc, hnth, hp⟩ with ⟨rc', hm, hp'⟩
          exact ⟨rc', List.Mem.tail hd hm, hp'⟩

/-- **Core Theorem 1 (`Ref-IR-Commute`, 88th Ruling §7 Target 1)**:
    Source record retraction survival `SourceEdgeSurvivesIdx snap D u w` is strictly
    equivalent to abstract support survival `AbstractEdgeSurvives (projectIRGraph snap) D u w`
    for every deletion list `D` and every vertex pair `(u, w)`. -/
theorem ref_ir_commute {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (D : List IssuerId) (u w : VertexId) :
    SourceEdgeSurvivesIdx snap D u w ↔ AbstractEdgeSurvives (projectIRGraph snap) D u w := by
  unfold SourceEdgeSurvivesIdx SourceEdgeInRecords residualRecordsByIdx AbstractEdgeSurvives
  rw [filterEnumNotIn_exists_iff D (fun rc => RecordIssuesEdge rc u w) snap.irRecords 0]
  constructor
  · intro ⟨r, hnotD, rc, hnth, hiss⟩
    simp only [Nat.zero_add] at hnotD
    have hrSupp : r ∈ reconstructSupport snap.irRecords u w :=
      (mem_reconstructSupport_iff snap.irRecords u w r).mpr ⟨rc, hnth, hiss⟩
    have hneSupp : reconstructSupport snap.irRecords u w ≠ [] := by
      intro hemp; rw [hemp] at hrSupp; cases hrSupp
    have hrcMem : rc ∈ snap.irRecords := nthOpt_mem hnth
    rcases hbounds rc hrcMem with ⟨hsrcLt, hrefsLt⟩
    rcases hiss with ⟨hsrcEq, ref, hrefMem, hdstEq⟩
    subst hsrcEq; subst hdstEq
    have hwLt : ref.targetVid < snap.vertexIds.length := hrefsLt ref hrefMem
    let e : GraphEdge :=
      { src := rc.sourceVid, dst := ref.targetVid,
        support := reconstructSupport snap.irRecords rc.sourceVid ref.targetVid }
    have heMem : e ∈ (projectIRGraph snap).edges :=
      (mem_projectIRGraph_edges_iff snap e).mpr ⟨hsrcLt, hwLt, hneSupp, rfl⟩
    refine ⟨e, heMem, rfl, rfl, ?_⟩
    intro hall
    exact hnotD (hall r hrSupp)
  · intro ⟨e, heMem, hsrc, hdst, hnotAll⟩
    rcases (mem_projectIRGraph_edges_iff snap e).mp heMem with ⟨_, _, _, hsupp⟩
    subst hsrc; subst hdst
    rw [hsupp] at hnotAll
    rcases exists_not_mem_of_not_forall hnotAll with ⟨r, hrSupp, hrNotD⟩
    rcases (mem_reconstructSupport_iff snap.irRecords e.src e.dst r).mp hrSupp with ⟨rc, hnth, hiss⟩
    exact ⟨r, by simpa using hrNotD, rc, hnth, hiss⟩

/-- Unperturbed base-edge corollary (`D = []`) of `Ref-IR-Commute`. -/
theorem ref_ir_base_edge_iff {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (u w : VertexId) :
    SourceEdgeInRecords snap.irRecords u w ↔
    ∃ e ∈ (projectIRGraph snap).edges, e.src = u ∧ e.dst = w := by
  constructor
  · intro ⟨rc, hmem, hiss⟩
    rcases (mem_iff_exists_nthOpt rc snap.irRecords).mp hmem with ⟨r, hnth⟩
    have hsurv : SourceEdgeSurvivesIdx snap [] u w := by
      unfold SourceEdgeSurvivesIdx SourceEdgeInRecords residualRecordsByIdx
      rw [filterEnumNotIn_exists_iff [] _ snap.irRecords 0]
      refine ⟨r, ?_, rc, hnth, hiss⟩
      intro hmem
      cases hmem
    rcases (ref_ir_commute hbounds [] u w).mp hsurv with ⟨e, he, hu, hw, _⟩
    exact ⟨e, he, hu, hw⟩
  · intro ⟨e, he, hu, hw⟩
    rcases (mem_projectIRGraph_edges_iff snap e).mp he with ⟨_, _, hne, _⟩
    cases hs : reconstructSupport snap.irRecords e.src e.dst with
    | nil => exact absurd hs hne
    | cons r _ =>
      have hr : r ∈ reconstructSupport snap.irRecords e.src e.dst := by rw [hs]; exact List.Mem.head _
      rcases (mem_reconstructSupport_iff snap.irRecords e.src e.dst r).mp hr with ⟨rc, hnth, hiss⟩
      subst hu; subst hw
      exact ⟨rc, nthOpt_mem hnth, hiss⟩

/-- Multi-Ref Hyperedge Simultaneous Retraction Theorem:
    When a single record `r` is the sole issuer of two distinct edges `(u, w1)` and `(u, w2)`
    (e.g. via a multi-ref hyperedge `refs = [ref1, ref2]`), retracting `[r]` simultaneously
    destroys BOTH edges in both source and abstract semantics. -/
theorem hyperedge_simultaneous_retraction {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (r : IssuerId) (u w1 w2 : VertexId)
    (h1 : reconstructSupport snap.irRecords u w1 = [r])
    (h2 : reconstructSupport snap.irRecords u w2 = [r]) :
    ¬ SourceEdgeSurvivesIdx snap [r] u w1 ∧
    ¬ SourceEdgeSurvivesIdx snap [r] u w2 ∧
    ¬ AbstractEdgeSurvives (projectIRGraph snap) [r] u w1 ∧
    ¬ AbstractEdgeSurvives (projectIRGraph snap) [r] u w2 := by
  have hnotAbs1 : ¬ AbstractEdgeSurvives (projectIRGraph snap) [r] u w1 := by
    intro ⟨e, he, hu, hw, hnotAll⟩
    rcases (mem_projectIRGraph_edges_iff snap e).mp he with ⟨_, _, _, hsupp⟩
    subst hu; subst hw
    rw [hsupp, h1] at hnotAll
    apply hnotAll
    intro i hi
    cases hi with
    | head => exact List.Mem.head []
    | tail _ hm => cases hm
  have hnotAbs2 : ¬ AbstractEdgeSurvives (projectIRGraph snap) [r] u w2 := by
    intro ⟨e, he, hu, hw, hnotAll⟩
    rcases (mem_projectIRGraph_edges_iff snap e).mp he with ⟨_, _, _, hsupp⟩
    subst hu; subst hw
    rw [hsupp, h2] at hnotAll
    apply hnotAll
    intro i hi
    cases hi with
    | head => exact List.Mem.head []
    | tail _ hm => cases hm
  exact ⟨fun hs => hnotAbs1 ((ref_ir_commute hbounds [r] u w1).mp hs),
         fun hs => hnotAbs2 ((ref_ir_commute hbounds [r] u w2).mp hs),
         hnotAbs1, hnotAbs2⟩

/-! ## Target 2: `Ref-IR-Walk-Commute` (Inductive Lifting to Walks & Carriers) -/

theorem ref_ir_chain_commute {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (D : List IssuerId) (u : VertexId) (tail : List VertexId) :
    SourceChainSurvivesIdx snap D u tail ↔ ChainSurvives (projectIRGraph snap) D u tail := by
  induction tail generalizing u with
  | nil => simp [SourceChainSurvivesIdx, ChainSurvives]
  | cons w rest ih =>
    simp only [SourceChainSurvivesIdx, ChainSurvives]
    constructor
    · intro ⟨hedg, hrest⟩
      exact ⟨(ref_ir_commute hbounds D u w).mp hedg, (ih w).mp hrest⟩
    · intro ⟨hedg, hrest⟩
      exact ⟨(ref_ir_commute hbounds D u w).mpr hedg, (ih w).mpr hrest⟩

/-- **Core Theorem 2 (`Ref-IR-Walk-Commute`, 88th Ruling §7 Target 2)**:
    Walk survival under record retraction in `snap` commutes iff-identically with
    `WalkSurvivesGraph (projectIRGraph snap) D γ`. -/
theorem ref_ir_walk_commute {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (D : List IssuerId) (γ : List VertexId) :
    SourceWalkSurvivesIdx snap D γ ↔ WalkSurvivesGraph (projectIRGraph snap) D γ := by
  cases γ with
  | nil => simp [SourceWalkSurvivesIdx, WalkSurvivesGraph]
  | cons v0 tail => exact ref_ir_chain_commute hbounds D v0 tail

theorem ref_ir_edge_chain_iff {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (u t : VertexId) (tail : List VertexId) :
    SourceEdgeChain snap.irRecords u t tail ↔ IsEdgeChain (projectIRGraph snap) u t tail := by
  constructor
  · intro h
    induction h with
    | nil u0 => exact IsEdgeChain.nil u0
    | @cons u0 w0 _ rest0 hedg _ ih =>
      rcases (ref_ir_base_edge_iff hbounds u0 w0).mp hedg with ⟨e, he, hu, hw⟩
      exact IsEdgeChain.cons e rest0 he hu hw ih
  · intro h
    induction h with
    | nil u0 => exact SourceEdgeChain.nil u0
    | @cons u0 w0 _ e rest0 he hu hw _ ih =>
      have hedg : SourceEdgeInRecords snap.irRecords u0 w0 :=
        (ref_ir_base_edge_iff hbounds u0 w0).mpr ⟨e, he, hu, hw⟩
      exact SourceEdgeChain.cons rest0 hedg ih

theorem ref_ir_valid_walk_iff {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (κ : ClosureKind) (s t : VertexId) (γ : List VertexId) :
    SourceIsValidWalk snap κ s t γ ↔ IsValidWalk (projectIRGraph snap) κ s t γ := by
  cases γ with
  | nil => simp [SourceIsValidWalk, IsValidWalk]
  | cons v0 tail =>
    simp only [SourceIsValidWalk, IsValidWalk, projectIRGraph, ref_ir_edge_chain_iff hbounds]

theorem ref_ir_true_shortest_walk_iff {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    (κ : ClosureKind) (s t : VertexId) (γ : List VertexId) :
    SourceIsTrueShortestWalk snap κ s t γ ↔ IsTrueShortestWalk (projectIRGraph snap) κ s t γ := by
  simp only [SourceIsTrueShortestWalk, IsTrueShortestWalk, ref_ir_valid_walk_iff hbounds]

theorem ref_ir_carrier_survives_idx_iff {snap : SourceSnapshot} (hbounds : SnapshotVertexBounds snap)
    {b : BaseData} (hG : b.G = projectIRGraph snap)
    (s t : VertexId) (c : CarrierSpec) (D : List IssuerId) :
    SourceCarrierSurvivesIdx snap b.kappa s t c D ↔ CarrierSurvives b s t c D := by
  cases c with
  | localPacket pkt =>
    simp only [SourceCarrierSurvivesIdx, CarrierSurvives, hG, ref_ir_walk_commute hbounds]
  | geodesicBundle =>
    simp only [SourceCarrierSurvivesIdx, CarrierSurvives, hG,
      ref_ir_true_shortest_walk_iff hbounds, ref_ir_walk_commute hbounds]
  | globalGraph =>
    simp only [SourceCarrierSurvivesIdx, CarrierSurvives, hG,
      ref_ir_valid_walk_iff hbounds, ref_ir_walk_commute hbounds]

/-! ## Target 3: String-ID Retraction Bijection, Cardinality Preservation (`|D| = |rid(D)|`),
    Executable `A1` + `0xFF33` Gate, and Source-String Resilience Bridge -/

def ridOfIdx (snap : SourceSnapshot) (r : IssuerId) : AsciiId :=
  match nthOpt snap.irRecords r with
  | none => ""
  | some rc => rc.recordId

def findIdxByRidAux (rid : AsciiId) : Nat → List SourceIRRecord → Nat
  | _, [] => 0
  | k, rc :: rest => if rc.recordId = rid then k else findIdxByRidAux rid (k + 1) rest

def idxOfRid (snap : SourceSnapshot) (rid : AsciiId) : IssuerId :=
  findIdxByRidAux rid 0 snap.irRecords

def ridsOfIdxs (snap : SourceSnapshot) (D : List IssuerId) : List AsciiId :=
  D.map (ridOfIdx snap)

def idxsOfRids (snap : SourceSnapshot) (D_str : List AsciiId) : List IssuerId :=
  D_str.map (idxOfRid snap)

/-- Exact Cardinality Law (Index → String): `|rid(D)| = |D|`. -/
theorem length_ridsOfIdxs (snap : SourceSnapshot) (D : List IssuerId) :
    (ridsOfIdxs snap D).length = D.length :=
  List.length_map _

/-- Exact Cardinality Law (String → Index): `|idx(D_str)| = |D_str|`. -/
theorem length_idxsOfRids (snap : SourceSnapshot) (D_str : List AsciiId) :
    (idxsOfRids snap D_str).length = D_str.length :=
  List.length_map _

theorem findIdxByRidAux_of_nthOpt {recs : List SourceIRRecord}
    (hnd : NodupList (recs.map SourceIRRecord.recordId)) :
    ∀ (k r : Nat) (rc : SourceIRRecord),
      nthOpt recs r = some rc →
      findIdxByRidAux rc.recordId k recs = k + r := by
  induction recs with
  | nil =>
    intro _ _ _ hnth; cases hnth
  | cons hd tl ih =>
    simp only [List.map_cons] at hnd
    cases hnd with
    | cons hnotMem hndTl =>
      intro k r rc hnth
      cases r with
      | zero =>
        simp only [nthOpt] at hnth
        injection hnth with heq
        subst heq
        simp [findIdxByRidAux]
      | succ r' =>
        simp only [nthOpt] at hnth
        have hne : hd.recordId ≠ rc.recordId := by
          intro heq
          apply hnotMem
          rw [heq]
          exact List.mem_map_of_mem (f := SourceIRRecord.recordId) (nthOpt_mem hnth)
        simp only [findIdxByRidAux]
        split
        · next heq => exact absurd heq hne
        · rw [ih hndTl (k + 1) r' rc hnth]
          omega

theorem idxOfRid_ridOfIdx {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {r : IssuerId} (hlt : r < snap.irRecords.length) :
    idxOfRid snap (ridOfIdx snap r) = r := by
  rcases exists_nthOpt_of_lt hlt with ⟨rc, hnth⟩
  unfold ridOfIdx idxOfRid
  rw [hnth, findIdxByRidAux_of_nthOpt hnd 0 r rc hnth, Nat.zero_add]

theorem ridOfIdx_idxOfRid_and_lt {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {rid : AsciiId} (hmem : rid ∈ snap.irRecords.map SourceIRRecord.recordId) :
    ridOfIdx snap (idxOfRid snap rid) = rid ∧ idxOfRid snap rid < snap.irRecords.length := by
  rcases List.mem_map.mp hmem with ⟨rc, hrcMem, hridEq⟩
  rcases (mem_iff_exists_nthOpt rc snap.irRecords).mp hrcMem with ⟨r, hnth⟩
  subst hridEq
  have hidx : idxOfRid snap rc.recordId = r := by
    unfold idxOfRid
    rw [findIdxByRidAux_of_nthOpt hnd 0 r rc hnth, Nat.zero_add]
  rw [hidx]
  refine ⟨?_, nthOpt_lt_length hnth⟩
  unfold ridOfIdx
  rw [hnth]

theorem idxsOfRids_ridsOfIdxs {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D : List IssuerId} (hlt : ∀ r ∈ D, r < snap.irRecords.length) :
    idxsOfRids snap (ridsOfIdxs snap D) = D := by
  induction D with
  | nil => rfl
  | cons r rest ih =>
    simp only [ridsOfIdxs, idxsOfRids, List.map_cons]
    rw [idxOfRid_ridOfIdx hnd (hlt r (List.Mem.head rest))]
    exact congrArg (r :: ·) (ih (fun x hx => hlt x (List.Mem.tail r hx)))

theorem ridsOfIdxs_idxsOfRids {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D_str : List AsciiId} (hmem : ∀ s ∈ D_str, s ∈ snap.irRecords.map SourceIRRecord.recordId) :
    ridsOfIdxs snap (idxsOfRids snap D_str) = D_str := by
  induction D_str with
  | nil => rfl
  | cons s rest ih =>
    simp only [idxsOfRids, ridsOfIdxs, List.map_cons]
    rw [(ridOfIdx_idxOfRid_and_lt hnd (hmem s (List.Mem.head rest))).1]
    exact congrArg (s :: ·) (ih (fun x hx => hmem x (List.Mem.tail s hx)))

theorem nodup_of_left_inv {α β : Type} (f : α → β) (g : β → α) {xs : List α}
    (hnd : NodupList xs) (hinv : ∀ x ∈ xs, g (f x) = x) :
    NodupList (xs.map f) := by
  induction hnd with
  | nil => exact NodupList.nil
  | @cons x rest hx _ ih =>
    simp only [List.map_cons]
    refine NodupList.cons ?_ (ih (fun z hz => hinv z (List.Mem.tail x hz)))
    intro hmemMap
    rcases List.mem_map.mp hmemMap with ⟨x2, hx2Rest, hfeq⟩
    have hxEq : x = x2 := by
      have h1 := hinv x (List.Mem.head rest)
      have h2 := hinv x2 (List.Mem.tail x hx2Rest)
      rw [← h1, ← h2, hfeq]
    subst hxEq
    exact hx hx2Rest

theorem nodup_ridsOfIdxs {snap : SourceSnapshot}
    (hndRecs : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D : List IssuerId} (hndD : NodupList D)
    (hlt : ∀ r ∈ D, r < snap.irRecords.length) :
    NodupList (ridsOfIdxs snap D) :=
  nodup_of_left_inv (ridOfIdx snap) (idxOfRid snap) hndD
    (fun r hr => idxOfRid_ridOfIdx hndRecs (hlt r hr))

theorem nodup_idxsOfRids {snap : SourceSnapshot}
    (hndRecs : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D_str : List AsciiId} (hndS : NodupList D_str)
    (hmem : ∀ s ∈ D_str, s ∈ snap.irRecords.map SourceIRRecord.recordId) :
    NodupList (idxsOfRids snap D_str) :=
  nodup_of_left_inv (idxOfRid snap) (ridOfIdx snap) hndS
    (fun s hs => (ridOfIdx_idxOfRid_and_lt hndRecs (hmem s hs)).1)

/-- Partition Preimage Correspondence (`F83-01A` & 88th Ruling §5):
    `r ∈ ip.remIssuers ↔ ridOfIdx snap r ∈ sourceRemRecordIds snap C*` and conversely. -/
theorem mem_remIssuers_iff_rid_mem_sourceRem (snap : SourceSnapshot)
    (pinnedConstIds : List AsciiId) (r : IssuerId) :
    r ∈ (projectIssuerPartition snap pinnedConstIds).remIssuers ↔
    r < snap.irRecords.length ∧ ridOfIdx snap r ∈ sourceRemRecordIds snap pinnedConstIds := by
  simp only [projectIssuerPartition, sourceRemRecordIds, List.mem_filter, mem_rangeBelow_iff]
  constructor
  · intro ⟨hlt, hnotC⟩
    refine ⟨hlt, ?_⟩
    rcases exists_nthOpt_of_lt hlt with ⟨rc, hnth⟩
    rw [hnth] at hnotC
    unfold ridOfIdx
    rw [hnth]
    exact ⟨List.mem_map_of_mem (f := SourceIRRecord.recordId) (nthOpt_mem hnth), hnotC⟩
  · intro ⟨hlt, _, hnotC⟩
    refine ⟨hlt, ?_⟩
    rcases exists_nthOpt_of_lt hlt with ⟨rc, hnth⟩
    unfold ridOfIdx at hnotC
    rw [hnth] at hnotC ⊢
    exact hnotC

theorem mem_sourceRem_gives_idx_mem_remIssuers {snap : SourceSnapshot}
    (hndRecs : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    (pinnedConstIds : List AsciiId) {rid : AsciiId}
    (hrem : rid ∈ sourceRemRecordIds snap pinnedConstIds) :
    idxOfRid snap rid ∈ (projectIssuerPartition snap pinnedConstIds).remIssuers := by
  have hmemMap : rid ∈ snap.irRecords.map SourceIRRecord.recordId :=
    (List.mem_filter.mp hrem).1
  rcases ridOfIdx_idxOfRid_and_lt hndRecs hmemMap with ⟨hridEq, hlt⟩
  apply (mem_remIssuers_iff_rid_mem_sourceRem snap pinnedConstIds (idxOfRid snap rid)).mpr
  rw [hridEq]
  exact ⟨hlt, hrem⟩

/-- Literal Equality of Residual Record Lists (`residualRecordsByIdx = residualRecordsByStr`):
    Retracting positional indices `D` produces the EXACT same list of surviving
    `SourceIRRecord`s as retracting their string IDs `ridsOfIdxs snap D`! -/
theorem filterEnumNotIn_eq_filter_str {recs : List SourceIRRecord}
    (hnd : NodupList (recs.map SourceIRRecord.recordId))
    (fullRecs : List SourceIRRecord)
    (hndFull : NodupList (fullRecs.map SourceIRRecord.recordId))
    (D : List IssuerId) (hltD : ∀ r ∈ D, r < fullRecs.length) :
    ∀ (k : Nat),
      (∀ i rc, nthOpt recs i = some rc → nthOpt fullRecs (k + i) = some rc) →
      filterEnumNotIn D k recs =
      recs.filter (fun rc =>
        !(listMemBool rc.recordId (D.map (fun r =>
          match nthOpt fullRecs r with | none => "" | some x => x.recordId)))) := by
  induction recs with
  | nil =>
    intro _ _
    rfl
  | cons hd tl ih =>
    cases hnd with
    | cons _ hndTl =>
      intro k halign
      have hhdFull : nthOpt fullRecs k = some hd := by
        simpa using halign 0 hd rfl
      have hmemEquiv : listMemBool k D =
          listMemBool hd.recordId (D.map (fun r =>
            match nthOpt fullRecs r with | none => "" | some x => x.recordId)) := by
        cases hlhs : listMemBool k D
        · have hkNotD : k ∉ D := (listMemBool_false_iff k D).mp hlhs
          symm
          apply (listMemBool_false_iff _ _).mpr
          intro hmemMap
          rcases List.mem_map.mp hmemMap with ⟨r', hr'D, hstrEq⟩
          rcases exists_nthOpt_of_lt (hltD r' hr'D) with ⟨rc', hrc'⟩
          rw [hrc'] at hstrEq
          have hrk : r' = k := nodup_map_nthOpt_inj hndFull hrc' hhdFull hstrEq
          subst hrk
          exact hkNotD hr'D
        · have hkD : k ∈ D := (listMemBool_iff k D).mp hlhs
          symm
          apply (listMemBool_iff _ _).mpr
          refine List.mem_map.mpr ⟨k, hkD, ?_⟩
          rw [hhdFull]
      simp only [filterEnumNotIn, List.filter]
      rw [hmemEquiv]
      have hrec := ih hndTl (k + 1) (fun i rc hi => by
        have h1 := halign (i + 1) rc hi
        have heq : k + 1 + i = k + (i + 1) := by omega
        rw [heq]
        exact h1)
      cases listMemBool hd.recordId (D.map (fun r =>
        match nthOpt fullRecs r with | none => "" | some x => x.recordId))
      · simp only [Bool.not_false]
        exact congrArg (hd :: ·) hrec
      · simp only [Bool.not_true]
        exact hrec

theorem residualRecordsByIdx_eq_str {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D : List IssuerId} (hltD : ∀ r ∈ D, r < snap.irRecords.length) :
    residualRecordsByIdx snap D = residualRecordsByStr snap (ridsOfIdxs snap D) := by
  unfold residualRecordsByIdx residualRecordsByStr ridsOfIdxs ridOfIdx
  exact filterEnumNotIn_eq_filter_str hnd snap.irRecords hnd D hltD 0
    (fun i rc hi => by simpa using hi)

theorem residualRecordsByStr_eq_idx {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D_str : List AsciiId}
    (hmem : ∀ s ∈ D_str, s ∈ snap.irRecords.map SourceIRRecord.recordId) :
    residualRecordsByStr snap D_str = residualRecordsByIdx snap (idxsOfRids snap D_str) := by
  have hlt : ∀ r ∈ idxsOfRids snap D_str, r < snap.irRecords.length := by
    intro r hr
    rcases List.mem_map.mp hr with ⟨s, hs, rfl⟩
    exact (ridOfIdx_idxOfRid_and_lt hnd (hmem s hs)).2
  rw [residualRecordsByIdx_eq_str hnd hlt, ridsOfIdxs_idxsOfRids hnd hmem]

theorem sourceCarrierSurvivesIdx_iff_str {snap : SourceSnapshot}
    (hnd : NodupList (snap.irRecords.map SourceIRRecord.recordId))
    {D : List IssuerId} (hltD : ∀ r ∈ D, r < snap.irRecords.length)
    (κ : ClosureKind) (s t : VertexId) (c : CarrierSpec) :
    SourceCarrierSurvivesIdx snap κ s t c D ↔
    SourceCarrierSurvivesStr snap κ s t c (ridsOfIdxs snap D) := by
  have hchain : ∀ u tail,
      SourceChainSurvivesIdx snap D u tail ↔
      SourceChainSurvivesStr snap (ridsOfIdxs snap D) u tail := by
    intro u tail
    induction tail generalizing u with
    | nil => simp [SourceChainSurvivesIdx, SourceChainSurvivesStr]
    | cons w rest ih =>
      simp only [SourceChainSurvivesIdx, SourceChainSurvivesStr,
        SourceEdgeSurvivesIdx, SourceEdgeSurvivesStr,
        residualRecordsByIdx_eq_str hnd hltD, ih w]
  have hwalk : ∀ γ,
      SourceWalkSurvivesIdx snap D γ ↔
      SourceWalkSurvivesStr snap (ridsOfIdxs snap D) γ := by
    intro γ
    cases γ with
    | nil => simp [SourceWalkSurvivesIdx, SourceWalkSurvivesStr]
    | cons v0 tail => exact hchain v0 tail
  cases c with
  | localPacket pkt =>
    simp only [SourceCarrierSurvivesIdx, SourceCarrierSurvivesStr, hwalk]
  | geodesicBundle =>
    simp only [SourceCarrierSurvivesIdx, SourceCarrierSurvivesStr, hwalk]
  | globalGraph =>
    simp only [SourceCarrierSurvivesIdx, SourceCarrierSurvivesStr, hwalk]

/-! ## Executable `A1` Anchor & `0xFF33` Sort-Law Checker + Master Bridge Theorem -/

def lookupPinnedA1 (sid : AsciiId) : List PinnedA1Entry → Option PinnedA1Entry
  | [] => none
  | e :: rest => if e.snapshotId = sid then some e else lookupPinnedA1 sid rest

theorem lookupPinnedA1_mem {sid : AsciiId} {reg : List PinnedA1Entry} {ent : PinnedA1Entry}
    (h : lookupPinnedA1 sid reg = some ent) : ent ∈ reg ∧ ent.snapshotId = sid := by
  induction reg with
  | nil => cases h
  | cons hd tl ih =>
    simp only [lookupPinnedA1] at h
    split at h
    · next heq =>
      injection h with hhd
      subst hhd
      exact ⟨List.Mem.head tl, heq⟩
    · rcases ih h with ⟨hm, hs⟩
      exact ⟨List.Mem.tail hd hm, hs⟩

def checkSourceAnchorAndSortLaw (reg : List PinnedA1Entry) (snap : SourceSnapshot) : Bool :=
  decide (snap.authTierTag = 1) &&
  decide (snap.policyMask = constitutionalMask0xFF33) &&
  decide (snap.computedRootHex = snap.claimedRootHex) &&
  decide (1 ≤ snap.vertexIds.length) &&
  decide (snap.vertexIds.length = snap.vertexSorts.length) &&
  nodupBool snap.vertexIds &&
  nodupBool (snap.irRecords.map SourceIRRecord.recordId) &&
  (match lookupPinnedA1 snap.snapshotId reg with
   | none => false
   | some ent =>
       decide (snap.generation = ent.pinnedGen) &&
       decide (snap.claimedRootHex = ent.pinnedRootHex)) &&
  listAllBool (fun rc =>
    decide (rc.sourceVid < snap.vertexIds.length) &&
    decide (nthOpt snap.vertexSorts rc.sourceVid = some rc.sourceSort) &&
    listAllBool (fun ref =>
      decide (ref.targetVid < snap.vertexIds.length) &&
      decide (nthOpt snap.vertexSorts ref.targetVid = some ref.targetSort) &&
      licensedSortBit rc.sourceSort ref.targetSort &&
      decide (ref.relSrcSort = rc.sourceSort) &&
      decide (ref.relDstSort = ref.targetSort)) rc.refs) snap.irRecords

theorem anchor_gives_bounds_and_nodup {reg : List PinnedA1Entry} {snap : SourceSnapshot}
    (hchk : checkSourceAnchorAndSortLaw reg snap = true) :
    SnapshotVertexBounds snap ∧
    NodupList (snap.irRecords.map SourceIRRecord.recordId) ∧
    (∃ ent, lookupPinnedA1 snap.snapshotId reg = some ent ∧
            snap.generation = ent.pinnedGen ∧
            snap.claimedRootHex = ent.pinnedRootHex ∧
            snap.computedRootHex = ent.pinnedRootHex ∧
            snap.authTierTag = 1 ∧
            snap.policyMask = constitutionalMask0xFF33) := by
  unfold checkSourceAnchorAndSortLaw at hchk
  simp only [Bool.and_eq_true, decide_eq_true_eq, nodupBool_iff, listAllBool_iff] at hchk
  rcases hchk with ⟨⟨⟨⟨⟨⟨⟨⟨htier, hmask⟩, hrootEq⟩, _⟩, _⟩, _⟩, hndRecs⟩, hreg⟩, hrecs⟩
  refine ⟨?_, hndRecs, ?_⟩
  · intro rc hrcMem
    rcases hrecs rc hrcMem with ⟨⟨hsrcLt, _⟩, hrefs⟩
    exact ⟨hsrcLt, fun ref hrefMem => (hrefs ref hrefMem).1.1.1.1⟩
  · cases hlk : lookupPinnedA1 snap.snapshotId reg with
    | none => rw [hlk] at hreg; contradiction
    | some ent =>
      rw [hlk] at hreg
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hreg
      exact ⟨ent, rfl, hreg.1, hreg.2, hrootEq.trans hreg.2, htier, hmask⟩

/-- Constitutional `0xFF33` Preservation Under Any String Retraction:
    Every surviving edge `(u, w)` in `SourceEdgeSurvivesStr snap D_str u w` has vertex sorts
    `su, sw` obeying `¬ IsForbiddenSortJump su sw`. -/
theorem surviving_source_edge_obeys_0xFF33 {reg : List PinnedA1Entry} {snap : SourceSnapshot}
    (hchk : checkSourceAnchorAndSortLaw reg snap = true)
    (D_str : List AsciiId) (u w : VertexId)
    (hsurv : SourceEdgeSurvivesStr snap D_str u w) :
    ∃ su sw,
      nthOpt snap.vertexSorts u = some su ∧
      nthOpt snap.vertexSorts w = some sw ∧
      licensedSortBit su sw = true ∧
      ¬ IsForbiddenSortJump su sw := by
  unfold SourceEdgeSurvivesStr SourceEdgeInRecords residualRecordsByStr at hsurv
  rcases hsurv with ⟨rc, hmemFilt, hsrcEq, ref, hrefMem, hdstEq⟩
  have hrcMem : rc ∈ snap.irRecords := (List.mem_filter.mp hmemFilt).1
  unfold checkSourceAnchorAndSortLaw at hchk
  simp only [Bool.and_eq_true, listAllBool_iff, decide_eq_true_eq] at hchk
  rcases hchk.2 rc hrcMem with ⟨⟨_, hsrcSort⟩, hrefs⟩
  rcases hrefs ref hrefMem with ⟨⟨⟨⟨_, hdstSort⟩, hlic⟩, _⟩, _⟩
  subst hsrcEq; subst hdstEq
  exact ⟨rc.sourceSort, ref.targetSort, hsrcSort, hdstSort, hlic,
         (licensedSortBit_iff_not_forbidden rc.sourceSort ref.targetSort).mp hlic⟩

/-- Scoped Source-Domain Soundness (`ScopedSourceSoundness_{A1}` at the IR Snapshot Layer):
    Defined strictly in terms of pinned `A1` registry lookup, `0xFF33` policy, vertex range,
    and pure string-ID retraction sets `D_str ⊆ sourceRemRecordIds snap ent.pinnedConstIds`. -/
def SourceStringSemanticResilience (reg : List PinnedA1Entry) (snap : SourceSnapshot)
    (κ : ClosureKind) (s t : VertexId) (c : CarrierSpec) (claim : ResilienceClaim) : Prop :=
  ∃ ent : PinnedA1Entry,
    lookupPinnedA1 snap.snapshotId reg = some ent ∧
    snap.authTierTag = 1 ∧
    snap.policyMask = constitutionalMask0xFF33 ∧
    snap.computedRootHex = ent.pinnedRootHex ∧
    s < snap.vertexIds.length ∧
    t < snap.vertexIds.length ∧
    SourceStringClaimHolds
      (sourceRemRecordIds snap ent.pinnedConstIds)
      (SourceCarrierSurvivesStr snap κ s t c)
      claim

/-- **Master IR-Refinement Soundness Bridge (`source_ir_to_omegaLambda_resilience_sound`)**:
    Chains:
      1. `checkSourceAnchorAndSortLaw reg snap = true` (`A1` anchor + `0xFF33` sort law + injective IDs),
      2. `ip = projectIssuerPartition snap ent.pinnedConstIds` and `b.G = projectIRGraph snap`,
      3. `checkVerifiedBase ip b = true` and `checkOmegaLambdaResilience ip b s t c cert = true`,
    directly into **pure string-keyed source retraction resilience**
    `SourceStringSemanticResilience reg snap b.kappa s t c (certClaim cert)`! -/
theorem source_ir_to_omegaLambda_resilience_sound
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (cert : ResilienceCert)
    (hAnchor : checkSourceAnchorAndSortLaw reg snap = true)
    (hLookup : lookupPinnedA1 snap.snapshotId reg = some ent)
    (hPart : ip = projectIssuerPartition snap ent.pinnedConstIds)
    (hGraph : b.G = projectIRGraph snap)
    (hBase : checkVerifiedBase ip b = true)
    (hCert : checkOmegaLambdaResilience ip b s t c cert = true) :
    SourceStringSemanticResilience reg snap b.kappa s t c (certClaim cert) := by
  rcases anchor_gives_bounds_and_nodup hAnchor with
    ⟨hbounds, hndRecs, ent', hlk', _, _, hcompRoot, htier, hmask⟩
  rw [hLookup] at hlk'
  injection hlk' with hentEq
  subst hentEq
  have habs := omegaLambda_resilience_sound ip b s t c cert hBase hCert
  rcases habs with ⟨hsLt, htLt, _, hclaimAbs⟩
  have hsLtSrc : s < snap.vertexIds.length := by rw [hGraph, projectIRGraph] at hsLt; exact hsLt
  have htLtSrc : t < snap.vertexIds.length := by rw [hGraph, projectIRGraph] at htLt; exact htLt
  refine ⟨ent, hLookup, htier, hmask, hcompRoot, hsLtSrc, htLtSrc, ?_⟩
  cases hcl : certClaim cert with
  | unbreakable =>
    rw [hcl] at hclaimAbs
    simp only [SourceStringClaimHolds]
    intro D_str hDstrRem
    have hmemMap : ∀ rid ∈ D_str, rid ∈ snap.irRecords.map SourceIRRecord.recordId :=
      fun rid hrid => (List.mem_filter.mp (hDstrRem rid hrid)).1
    let D := idxsOfRids snap D_str
    have hDrem : ∀ d ∈ D, d ∈ ip.remIssuers := by
      intro d hd
      rcases List.mem_map.mp hd with ⟨rid, hrid, rfl⟩
      rw [hPart]
      exact mem_sourceRem_gives_idx_mem_remIssuers hndRecs ent.pinnedConstIds (hDstrRem rid hrid)
    have hltD : ∀ d ∈ D, d < snap.irRecords.length := by
      intro d hd
      have hd' := hDrem d hd
      rw [hPart] at hd'
      exact ((mem_remIssuers_iff_rid_mem_sourceRem snap ent.pinnedConstIds d).mp hd').1
    have hsurvAbs : CarrierSurvives b s t c D := hclaimAbs D hDrem
    have hsurvIdx : SourceCarrierSurvivesIdx snap b.kappa s t c D :=
      (ref_ir_carrier_survives_idx_iff hbounds hGraph s t c D).mpr hsurvAbs
    have hsurvStr := (sourceCarrierSurvivesIdx_iff_str hndRecs hltD b.kappa s t c).mp hsurvIdx
    rw [ridsOfIdxs_idxsOfRids hndRecs hmemMap] at hsurvStr
    exact hsurvStr
  | finiteBounds lower upper =>
    rw [hcl] at hclaimAbs
    rcases hclaimAbs with ⟨hle, hlowAbs, ⟨Dstar, hndDstar, hremDstar, hlenDstar, hnotSurvDstar⟩⟩
    refine ⟨hle, ?_, ?_⟩
    · intro D_str hndStr hDstrRem hnotSurvStr
      have hmemMap : ∀ rid ∈ D_str, rid ∈ snap.irRecords.map SourceIRRecord.recordId :=
        fun rid hrid => (List.mem_filter.mp (hDstrRem rid hrid)).1
      let D := idxsOfRids snap D_str
      have hndD : NodupList D := nodup_idxsOfRids hndRecs hndStr hmemMap
      have hDrem : ∀ d ∈ D, d ∈ ip.remIssuers := by
        intro d hd
        rcases List.mem_map.mp hd with ⟨rid, hrid, rfl⟩
        rw [hPart]
        exact mem_sourceRem_gives_idx_mem_remIssuers hndRecs ent.pinnedConstIds (hDstrRem rid hrid)
      have hltD : ∀ d ∈ D, d < snap.irRecords.length := by
        intro d hd
        have hd' := hDrem d hd
        rw [hPart] at hd'
        exact ((mem_remIssuers_iff_rid_mem_sourceRem snap ent.pinnedConstIds d).mp hd').1
      have hnotSurvAbs : ¬ CarrierSurvives b s t c D := by
        intro hsurvAbs
        have hsurvIdx := (ref_ir_carrier_survives_idx_iff hbounds hGraph s t c D).mpr hsurvAbs
        have hsurvStr := (sourceCarrierSurvivesIdx_iff_str hndRecs hltD b.kappa s t c).mp hsurvIdx
        rw [ridsOfIdxs_idxsOfRids hndRecs hmemMap] at hsurvStr
        exact hnotSurvStr hsurvStr
      have hlenGe : lower ≤ D.length := hlowAbs D hndD hDrem hnotSurvAbs
      rw [length_idxsOfRids] at hlenGe
      exact hlenGe
    · have hltDstar : ∀ d ∈ Dstar, d < snap.irRecords.length := by
        intro d hd
        have hd' := hremDstar d hd
        rw [hPart] at hd'
        exact ((mem_remIssuers_iff_rid_mem_sourceRem snap ent.pinnedConstIds d).mp hd').1
      let D_str_star := ridsOfIdxs snap Dstar
      have hndStrStar : NodupList D_str_star := nodup_ridsOfIdxs hndRecs hndDstar hltDstar
      have hremStrStar : ∀ rid ∈ D_str_star, rid ∈ sourceRemRecordIds snap ent.pinnedConstIds := by
        intro rid hrid
        rcases List.mem_map.mp hrid with ⟨d, hd, rfl⟩
        have hd' := hremDstar d hd
        rw [hPart] at hd'
        exact ((mem_remIssuers_iff_rid_mem_sourceRem snap ent.pinnedConstIds d).mp hd').2
      have hlenStrStar : D_str_star.length ≤ upper := by
        rw [length_ridsOfIdxs]
        exact hlenDstar
      have hnotSurvStrStar : ¬ SourceCarrierSurvivesStr snap b.kappa s t c D_str_star := by
        intro hsurvStr
        have hsurvIdx :=
          (sourceCarrierSurvivesIdx_iff_str hndRecs hltDstar b.kappa s t c).mpr hsurvStr
        have hsurvAbs :=
          (ref_ir_carrier_survives_idx_iff hbounds hGraph s t c Dstar).mp hsurvIdx
        exact hnotSurvDstar hsurvAbs
      exact ⟨D_str_star, hndStrStar, hremStrStar, hlenStrStar, hnotSurvStrStar⟩

/-- Exact String-Domain Resilience Corollary (`lower = upper = k`). -/
theorem source_ir_to_omegaLambda_exact_resilience_sound
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (cert : ResilienceCert) (k : Nat)
    (hAnchor : checkSourceAnchorAndSortLaw reg snap = true)
    (hLookup : lookupPinnedA1 snap.snapshotId reg = some ent)
    (hPart : ip = projectIssuerPartition snap ent.pinnedConstIds)
    (hGraph : b.G = projectIRGraph snap)
    (hBase : checkVerifiedBase ip b = true)
    (hCert : checkOmegaLambdaResilience ip b s t c cert = true)
    (hExact : certClaim cert = .finiteBounds k k) :
    (∀ D_str : List AsciiId,
      NodupList D_str →
      (∀ rid ∈ D_str, rid ∈ sourceRemRecordIds snap ent.pinnedConstIds) →
      ¬ SourceCarrierSurvivesStr snap b.kappa s t c D_str →
      k ≤ D_str.length) ∧
    (∃ D_str_star : List AsciiId,
      NodupList D_str_star ∧
      (∀ rid ∈ D_str_star, rid ∈ sourceRemRecordIds snap ent.pinnedConstIds) ∧
      D_str_star.length = k ∧
      ¬ SourceCarrierSurvivesStr snap b.kappa s t c D_str_star) := by
  have hres :=
    source_ir_to_omegaLambda_resilience_sound reg snap ent ip b s t c cert
      hAnchor hLookup hPart hGraph hBase hCert
  rcases hres with ⟨ent', hlk', _, _, _, _, _, hclaim⟩
  rw [hLookup] at hlk'
  injection hlk' with hentEq
  subst hentEq
  rw [hExact] at hclaim
  rcases hclaim with ⟨_, hlow, ⟨Dstar, hnd, hrem, hle, hnot⟩⟩
  have hge : k ≤ Dstar.length := hlow Dstar hnd hrem hnot
  exact ⟨hlow, ⟨Dstar, hnd, hrem, Nat.le_antisymm hle hge, hnot⟩⟩

end OmegaLambda

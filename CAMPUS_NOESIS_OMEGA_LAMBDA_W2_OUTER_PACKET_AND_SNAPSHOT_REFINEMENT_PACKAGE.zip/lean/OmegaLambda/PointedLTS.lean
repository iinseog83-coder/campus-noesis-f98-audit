/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 1: `OmegaLambda.PointedLTS`

  Universal Pointed Issuer-Labeled Transition System (`PointedLTS`) core and
  machine-checked proofs of:
    1. `lts_unb` + `checkUnbreakableWalk_sound` (Universal Unbreakability)
    2. `lts_lower` + `checkLowerPacking_sound` (Pairwise-Disjoint Step-Witness Lower Bound, F76-01)
    3. `lts_cut_iff` + `checkClosedCut_sound` (Residual Closed-Cut Soundness & Completeness)

  Discipline (`F81-02` & 82nd Ruling):
    - `sorryAx = 0`
    - user `axiom = 0`
    - `Lean.ofReduceBool = 0` and `Lean.trustCompiler = 0` (`native_decide` prohibited)
-/

namespace OmegaLambda

abbrev IssuerId := Nat

/-! ## Elementary Constructive Finite-List Helpers -/

def listMemBool [DecidableEq α] (x : α) : List α → Bool
  | [] => false
  | y :: ys => if x = y then true else listMemBool x ys

theorem listMemBool_iff [DecidableEq α] (x : α) (xs : List α) :
    listMemBool x xs = true ↔ x ∈ xs := by
  induction xs with
  | nil =>
    simp [listMemBool]
  | cons y ys ih =>
    simp only [listMemBool]
    split
    · next hxy =>
      subst hxy
      exact ⟨fun _ => List.Mem.head ys, fun _ => rfl⟩
    · next hne =>
      constructor
      · intro h
        exact List.Mem.tail y (ih.mp h)
      · intro hmem
        cases hmem with
        | head => exact absurd rfl hne
        | tail _ hm => exact ih.mpr hm

theorem listMemBool_false_iff [DecidableEq α] (x : α) (xs : List α) :
    listMemBool x xs = false ↔ x ∉ xs := by
  constructor
  · intro h hmem
    have ht := (listMemBool_iff x xs).mpr hmem
    rw [h] at ht
    contradiction
  · intro hnot
    cases h : listMemBool x xs
    · rfl
    · exfalso
      exact hnot ((listMemBool_iff x xs).mp h)

def listAllBool (p : α → Bool) : List α → Bool
  | [] => true
  | x :: xs => p x && listAllBool p xs

theorem listAllBool_iff (p : α → Bool) (xs : List α) :
    listAllBool p xs = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil =>
    simp [listAllBool]
  | cons y ys ih =>
    simp only [listAllBool, Bool.and_eq_true, ih]
    constructor
    · intro ⟨hy, hys⟩ x hx
      cases hx with
      | head => exact hy
      | tail _ hm => exact hys x hm
    · intro hall
      exact ⟨hall y (List.Mem.head ys), fun x hx => hall x (List.Mem.tail y hx)⟩

def listAnyBool (p : α → Bool) : List α → Bool
  | [] => false
  | x :: xs => p x || listAnyBool p xs

theorem listAnyBool_iff (p : α → Bool) (xs : List α) :
    listAnyBool p xs = true ↔ ∃ x ∈ xs, p x = true := by
  induction xs with
  | nil =>
    simp [listAnyBool]
  | cons y ys ih =>
    simp only [listAnyBool, Bool.or_eq_true, ih]
    constructor
    · intro h
      cases h with
      | inl hy => exact ⟨y, List.Mem.head ys, hy⟩
      | inr hys =>
        rcases hys with ⟨x, hx, hpx⟩
        exact ⟨x, List.Mem.tail y hx, hpx⟩
    · intro ⟨x, hx, hpx⟩
      cases hx with
      | head => exact Or.inl hpx
      | tail _ hm => exact Or.inr ⟨x, hm, hpx⟩

/-- Constructive duplicate-free predicate and executable checker. -/
inductive NodupList : List α → Prop where
  | nil : NodupList []
  | cons {x : α} {xs : List α} : x ∉ xs → NodupList xs → NodupList (x :: xs)

def nodupBool [DecidableEq α] : List α → Bool
  | [] => true
  | x :: xs => (!(listMemBool x xs)) && nodupBool xs

theorem nodupBool_iff [DecidableEq α] (xs : List α) :
    nodupBool xs = true ↔ NodupList xs := by
  induction xs with
  | nil =>
    simp only [nodupBool, true_iff]
    exact NodupList.nil
  | cons x rest ih =>
    simp only [nodupBool, Bool.and_eq_true, Bool.not_eq_true']
    rw [listMemBool_false_iff, ih]
    constructor
    · intro ⟨hx, hrest⟩
      exact NodupList.cons hx hrest
    · intro hnd
      cases hnd with
      | cons hx hrest => exact ⟨hx, hrest⟩

/-- Remove first occurrence of `x` from a list. -/
def removeFirst [DecidableEq α] (x : α) : List α → List α
  | [] => []
  | y :: ys => if x = y then ys else y :: removeFirst x ys

theorem length_removeFirst_of_mem [DecidableEq α] {x : α} {xs : List α} (h : x ∈ xs) :
    (removeFirst x xs).length + 1 = xs.length := by
  induction xs with
  | nil => cases h
  | cons y ys ih =>
    simp only [removeFirst]
    split
    · rfl
    · next hne =>
      cases h with
      | head => exact absurd rfl hne
      | tail _ hm =>
        simp only [List.length_cons]
        exact congrArg (· + 1) (ih hm)

theorem mem_of_mem_removeFirst [DecidableEq α] {x z : α} {xs : List α}
    (h : z ∈ removeFirst x xs) : z ∈ xs := by
  induction xs with
  | nil => cases h
  | cons y ys ih =>
    simp only [removeFirst] at h
    split at h
    · exact List.Mem.tail y h
    · cases h with
      | head => exact List.Mem.head ys
      | tail _ hm => exact List.Mem.tail y (ih hm)

theorem mem_removeFirst_of_ne [DecidableEq α] {x z : α} {xs : List α}
    (hz : z ∈ xs) (hne : z ≠ x) : z ∈ removeFirst x xs := by
  induction xs with
  | nil => cases hz
  | cons y ys ih =>
    simp only [removeFirst]
    split
    · next hxy =>
      cases hz with
      | head => exact absurd hxy.symm hne
      | tail _ hm => exact hm
    · cases hz with
      | head => exact List.Mem.head _
      | tail _ hm => exact List.Mem.tail y (ih hm)

theorem nodup_removeFirst [DecidableEq α] (x : α) {xs : List α} (hnd : NodupList xs) :
    NodupList (removeFirst x xs) := by
  induction hnd with
  | nil => exact NodupList.nil
  | @cons y ys hy hys ih =>
    simp only [removeFirst]
    split
    · exact hys
    · refine NodupList.cons ?_ ih
      intro hmem
      exact hy (mem_of_mem_removeFirst hmem)

/-- Pairwise disjointness for a list of finite sets (represented as lists). -/
inductive PairwiseDisjoint : List (List α) → Prop where
  | nil : PairwiseDisjoint []
  | cons {s : List α} {rest : List (List α)} :
      (∀ t ∈ rest, ∀ x ∈ s, x ∉ t) →
      PairwiseDisjoint rest →
      PairwiseDisjoint (s :: rest)

def disjointListsBool [DecidableEq α] (s t : List α) : Bool :=
  listAllBool (fun x => !(listMemBool x t)) s

theorem disjointListsBool_iff [DecidableEq α] (s t : List α) :
    disjointListsBool s t = true ↔ ∀ x ∈ s, x ∉ t := by
  simp only [disjointListsBool, listAllBool_iff, Bool.not_eq_true', listMemBool_false_iff]

def pairwiseDisjointBool [DecidableEq α] : List (List α) → Bool
  | [] => true
  | s :: rest =>
      listAllBool (fun t => disjointListsBool s t) rest && pairwiseDisjointBool rest

theorem pairwiseDisjointBool_iff [DecidableEq α] (sets : List (List α)) :
    pairwiseDisjointBool sets = true ↔ PairwiseDisjoint sets := by
  induction sets with
  | nil =>
    simp only [pairwiseDisjointBool, true_iff]
    exact PairwiseDisjoint.nil
  | cons s rest ih =>
    simp only [pairwiseDisjointBool, Bool.and_eq_true, listAllBool_iff, disjointListsBool_iff, ih]
    constructor
    · intro ⟨hd, hrest⟩
      exact PairwiseDisjoint.cons hd hrest
    · intro hpd
      cases hpd with
      | cons hd hrest => exact ⟨hd, hrest⟩

/-- Fundamental Counting Lemma for `LTS-Lower`:
    If `D` is duplicate-free and hits every list in a pairwise-disjoint family `sets`,
    then `sets.length ≤ D.length`. -/
theorem disjoint_hitting_length_ge [DecidableEq α]
    {sets : List (List α)} (hpd : PairwiseDisjoint sets) :
    ∀ {D : List α}, NodupList D → (∀ s ∈ sets, ∃ x ∈ s, x ∈ D) → sets.length ≤ D.length := by
  induction hpd with
  | nil =>
    intro D _ _
    exact Nat.zero_le D.length
  | @cons s rest hdisj _ ih =>
    intro D hnd hhit
    rcases hhit s (List.Mem.head rest) with ⟨x0, hx0s, hx0D⟩
    let D' := removeFirst x0 D
    have hlen : D'.length + 1 = D.length := length_removeFirst_of_mem hx0D
    have hnd' : NodupList D' := nodup_removeFirst x0 hnd
    have hhit' : ∀ t ∈ rest, ∃ y ∈ t, y ∈ D' := by
      intro t ht
      rcases hhit t (List.Mem.tail s ht) with ⟨y, hyt, hyD⟩
      have hne : y ≠ x0 := by
        intro heq
        subst heq
        exact hdisj t ht y hx0s hyt
      exact ⟨y, hyt, mem_removeFirst_of_ne hyD hne⟩
    have hrec : rest.length ≤ D'.length := ih hnd' hhit'
    simp only [List.length_cons]
    rw [← hlen]
    exact Nat.succ_le_succ hrec

/-! ## Issuer Partition & Pointed Issuer-Labeled LTS -/

structure IssuerPartition where
  constIssuers : List IssuerId
  remIssuers : List IssuerId
  deriving DecidableEq, Repr

def WFPartition (ip : IssuerPartition) : Prop :=
  ∀ i, i ∈ ip.constIssuers → i ∉ ip.remIssuers

def checkIssuerPartition (ip : IssuerPartition) : Bool :=
  disjointListsBool ip.constIssuers ip.remIssuers

theorem checkIssuerPartition_sound {ip : IssuerPartition}
    (h : checkIssuerPartition ip = true) : WFPartition ip :=
  (disjointListsBool_iff ip.constIssuers ip.remIssuers).mp h

structure Trans (Q : Type) where
  src : Q
  support : List IssuerId
  dst : Q
  deriving DecidableEq, Repr

structure PointedLTS (Q : Type) where
  q0 : Q
  qf : Q
  delta : List (Trans Q)
  deriving DecidableEq, Repr

/-- Explicit transition walk in `M` from `p` to `q`. -/
inductive LTSWalk (M : PointedLTS Q) : Q → Q → List (Trans Q) → Prop where
  | nil (q : Q) : LTSWalk M q q []
  | cons {p r s : Q} (tr : Trans Q) (rest : List (Trans Q)) :
      tr ∈ M.delta →
      tr.src = p →
      tr.dst = r →
      LTSWalk M r s rest →
      LTSWalk M p s (tr :: rest)

theorem LTSWalk.append {M : PointedLTS Q} {p q r : Q} {τ1 τ2 : List (Trans Q)}
    (hw1 : LTSWalk M p q τ1) (hw2 : LTSWalk M q r τ2) :
    LTSWalk M p r (τ1 ++ τ2) := by
  induction hw1 with
  | nil _ => exact hw2
  | cons tr rest hmem hsrc hdst _ ih =>
    exact LTSWalk.cons tr (rest ++ τ2) hmem hsrc hdst (ih hw2)

theorem LTSWalk.snoc {M : PointedLTS Q} {p q r : Q} {τ : List (Trans Q)} {tr : Trans Q}
    (hw : LTSWalk M p q τ) (hmem : tr ∈ M.delta) (hsrc : tr.src = q) (hdst : tr.dst = r) :
    LTSWalk M p r (τ ++ [tr]) :=
  hw.append (LTSWalk.cons tr [] hmem hsrc hdst (LTSWalk.nil r))

/-- Transition survival: `Λ ⊈ D` (`¬ ∀ i ∈ Λ, i ∈ D`). -/
def TransSurvives (tr : Trans Q) (D : List IssuerId) : Prop :=
  ¬ (∀ i ∈ tr.support, i ∈ D)

def transSurvivesBool (tr : Trans Q) (D : List IssuerId) : Bool :=
  listAnyBool (fun i => !(listMemBool i D)) tr.support

theorem exists_not_mem_of_not_forall [DecidableEq α] {xs D : List α}
    (hnotall : ¬ (∀ i ∈ xs, i ∈ D)) : ∃ i ∈ xs, i ∉ D := by
  induction xs with
  | nil =>
    exfalso
    apply hnotall
    intro _ hm
    cases hm
  | cons x rest ih =>
    cases hx : listMemBool x D
    · exact ⟨x, List.Mem.head rest, (listMemBool_false_iff x D).mp hx⟩
    · have hxmem : x ∈ D := (listMemBool_iff x D).mp hx
      have hrest : ¬ (∀ i ∈ rest, i ∈ D) := by
        intro hallrest
        apply hnotall
        intro i hi
        cases hi with
        | head => exact hxmem
        | tail _ hm => exact hallrest i hm
      rcases ih hrest with ⟨i, hi, hnot⟩
      exact ⟨i, List.Mem.tail x hi, hnot⟩

theorem transSurvivesBool_iff (tr : Trans Q) (D : List IssuerId) :
    transSurvivesBool tr D = true ↔ TransSurvives tr D := by
  simp only [transSurvivesBool, listAnyBool_iff, Bool.not_eq_true', listMemBool_false_iff,
    TransSurvives]
  constructor
  · intro ⟨i, hi, hnot⟩ hall
    exact hnot (hall i hi)
  · intro hnotall
    exact exists_not_mem_of_not_forall hnotall

theorem transSurvivesBool_false_iff (tr : Trans Q) (D : List IssuerId) :
    transSurvivesBool tr D = false ↔ ∀ i ∈ tr.support, i ∈ D := by
  constructor
  · intro hfalse i hi
    cases hm : listMemBool i D
    · exfalso
      have htrue : transSurvivesBool tr D = true := by
        simp only [transSurvivesBool, listAnyBool_iff, Bool.not_eq_true']
        exact ⟨i, hi, hm⟩
      rw [hfalse] at htrue
      contradiction
    · exact (listMemBool_iff i D).mp hm
  · intro hall
    cases hb : transSurvivesBool tr D
    · rfl
    · exfalso
      exact ((transSurvivesBool_iff tr D).mp hb) hall

theorem transSurvives_iff_exists (tr : Trans Q) (D : List IssuerId) :
    TransSurvives tr D ↔ ∃ i ∈ tr.support, i ∉ D := by
  rw [← transSurvivesBool_iff, transSurvivesBool, listAnyBool_iff]
  simp only [Bool.not_eq_true', listMemBool_false_iff]

def WalkSurvives (τ : List (Trans Q)) (D : List IssuerId) : Prop :=
  ∀ tr ∈ τ, TransSurvives tr D

theorem WalkSurvives.append {τ1 τ2 : List (Trans Q)} {D : List IssuerId}
    (h1 : WalkSurvives τ1 D) (h2 : WalkSurvives τ2 D) :
    WalkSurvives (τ1 ++ τ2) D := by
  intro tr hmem
  rcases List.mem_append.mp hmem with h | h
  · exact h1 tr h
  · exact h2 tr h

def LTSReachable (M : PointedLTS Q) (D : List IssuerId) (p q : Q) : Prop :=
  ∃ τ : List (Trans Q), LTSWalk M p q τ ∧ WalkSurvives τ D

/-! ##Executable Walk Checker on `PointedLTS` -/

def checkLTSWalkFrom [DecidableEq Q] (M : PointedLTS Q) : Q → Q → List (Trans Q) → Bool
  | p, q, [] => decide (p = q)
  | p, q, tr :: rest =>
      listMemBool tr M.delta && decide (tr.src = p) && checkLTSWalkFrom M tr.dst q rest

theorem checkLTSWalkFrom_iff [DecidableEq Q] (M : PointedLTS Q) (p q : Q) (τ : List (Trans Q)) :
    checkLTSWalkFrom M p q τ = true ↔ LTSWalk M p q τ := by
  induction τ generalizing p with
  | nil =>
    simp only [checkLTSWalkFrom, decide_eq_true_eq]
    constructor
    · intro h; subst h; exact LTSWalk.nil p
    · intro hw; cases hw; rfl
  | cons tr rest ih =>
    simp only [checkLTSWalkFrom, Bool.and_eq_true, listMemBool_iff, decide_eq_true_eq, ih]
    constructor
    · intro ⟨⟨hmem, hsrc⟩, hrest⟩
      exact LTSWalk.cons tr rest hmem hsrc rfl hrest
    · intro hw
      cases hw with
      | cons _ _ hmem hsrc hdst hrest =>
        subst hdst
        exact ⟨⟨hmem, hsrc⟩, hrest⟩

/-! ## Theorem 1: `LTS-Unb` (Universal Unbreakability) -/

theorem lts_unb {ip : IssuerPartition} (hpart : WFPartition ip)
    {M : PointedLTS Q} {τ : List (Trans Q)}
    (hwalk : LTSWalk M M.q0 M.qf τ)
    (himm : ∀ tr ∈ τ, ∃ c ∈ tr.support, c ∈ ip.constIssuers) :
    ∀ D : List IssuerId, (∀ d ∈ D, d ∈ ip.remIssuers) → LTSReachable M D M.q0 M.qf := by
  intro D hD
  refine ⟨τ, hwalk, ?_⟩
  intro tr htr hall
  rcases himm tr htr with ⟨c, hcsupp, hcconst⟩
  have hcD : c ∈ D := hall c hcsupp
  have hcrem : c ∈ ip.remIssuers := hD c hcD
  exact hpart c hcconst hcrem

def checkUnbreakableWalk [DecidableEq Q]
    (ip : IssuerPartition) (M : PointedLTS Q) (τ : List (Trans Q)) : Bool :=
  checkLTSWalkFrom M M.q0 M.qf τ &&
  listAllBool (fun tr => listAnyBool (fun c => listMemBool c ip.constIssuers) tr.support) τ

theorem checkUnbreakableWalk_sound [DecidableEq Q]
    {ip : IssuerPartition} {M : PointedLTS Q} {τ : List (Trans Q)}
    (hpart : WFPartition ip)
    (hchk : checkUnbreakableWalk ip M τ = true) :
    ∀ D : List IssuerId, (∀ d ∈ D, d ∈ ip.remIssuers) → LTSReachable M D M.q0 M.qf := by
  simp only [checkUnbreakableWalk, Bool.and_eq_true, checkLTSWalkFrom_iff,
    listAllBool_iff, listAnyBool_iff, listMemBool_iff] at hchk
  exact lts_unb hpart hchk.1 hchk.2

/-! ## Theorem 2: `LTS-Lower` (Pairwise-Disjoint Step-Witness Packing Lower Bound, `F76-01`) -/

inductive StepWitness where
  | immutableStep : StepWitness
  | retractableIssuer : IssuerId → StepWitness
  deriving DecidableEq, Repr

def ValidStepWitness (ip : IssuerPartition) (tr : Trans Q) : StepWitness → Prop
  | .immutableStep => ∃ c ∈ tr.support, c ∈ ip.constIssuers
  | .retractableIssuer i =>
      (∀ c ∈ tr.support, c ∉ ip.constIssuers) ∧ i ∈ tr.support ∧ i ∈ ip.remIssuers

def checkStepWitness (ip : IssuerPartition) (tr : Trans Q) : StepWitness → Bool
  | .immutableStep =>
      listAnyBool (fun c => listMemBool c ip.constIssuers) tr.support
  | .retractableIssuer i =>
      disjointListsBool tr.support ip.constIssuers &&
      listMemBool i tr.support &&
      listMemBool i ip.remIssuers

theorem checkStepWitness_sound {ip : IssuerPartition} {tr : Trans Q} {sw : StepWitness}
    (h : checkStepWitness ip tr sw = true) : ValidStepWitness ip tr sw := by
  cases sw with
  | immutableStep =>
    simp only [checkStepWitness, listAnyBool_iff, listMemBool_iff] at h
    exact h
  | retractableIssuer i =>
    simp only [checkStepWitness, Bool.and_eq_true, disjointListsBool_iff, listMemBool_iff] at h
    exact ⟨h.1.1, h.1.2, h.2⟩

def extractRetractableIssuers : List StepWitness → List IssuerId
  | [] => []
  | .immutableStep :: rest => extractRetractableIssuers rest
  | .retractableIssuer i :: rest => i :: extractRetractableIssuers rest

inductive ValidWitnessedSteps (ip : IssuerPartition) :
    List (Trans Q) → List StepWitness → Prop where
  | nil : ValidWitnessedSteps ip [] []
  | cons {tr : Trans Q} {trs : List (Trans Q)} {sw : StepWitness} {sws : List StepWitness} :
      ValidStepWitness ip tr sw →
      ValidWitnessedSteps ip trs sws →
      ValidWitnessedSteps ip (tr :: trs) (sw :: sws)

def checkWitnessedSteps (ip : IssuerPartition) : List (Trans Q) → List StepWitness → Bool
  | [], [] => true
  | tr :: trs, sw :: sws => checkStepWitness ip tr sw && checkWitnessedSteps ip trs sws
  | _, _ => false

theorem checkWitnessedSteps_sound {ip : IssuerPartition}
    {trs : List (Trans Q)} {sws : List StepWitness}
    (h : checkWitnessedSteps ip trs sws = true) : ValidWitnessedSteps ip trs sws := by
  induction trs generalizing sws with
  | nil =>
    cases sws with
    | nil => exact ValidWitnessedSteps.nil
    | cons _ _ => simp [checkWitnessedSteps] at h
  | cons tr rest ih =>
    cases sws with
    | nil => simp [checkWitnessedSteps] at h
    | cons sw swrest =>
      simp only [checkWitnessedSteps, Bool.and_eq_true] at h
      exact ValidWitnessedSteps.cons (checkStepWitness_sound h.1) (ih h.2)

/-- Key Lemma for `LTS-Lower`: If an allowed deletion set `D ⊆ remIssuers` breaks a
    step-witnessed walk `(τ, sws)`, `D` must intersect `extractRetractableIssuers sws`. -/
theorem broken_walk_hits_extracted {ip : IssuerPartition} (hpart : WFPartition ip)
    {τ : List (Trans Q)} {sws : List StepWitness}
    (hvalid : ValidWitnessedSteps ip τ sws)
    {D : List IssuerId} (hD : ∀ d ∈ D, d ∈ ip.remIssuers)
    (hbroken : ¬ WalkSurvives τ D) :
    ∃ i ∈ extractRetractableIssuers sws, i ∈ D := by
  induction hvalid with
  | nil =>
    exfalso
    apply hbroken
    intro _ hmem
    cases hmem
  | @cons tr trs sw swrest hsw hrest ih =>
    cases htrb : transSurvivesBool tr D
    · have hallD : ∀ x ∈ tr.support, x ∈ D :=
        (transSurvivesBool_false_iff tr D).mp htrb
      cases sw with
      | immutableStep =>
        rcases hsw with ⟨c, hcsupp, hcconst⟩
        exfalso
        exact hpart c hcconst (hD c (hallD c hcsupp))
      | retractableIssuer i =>
        rcases hsw with ⟨_, hisupp, _⟩
        exact ⟨i, List.Mem.head _, hallD i hisupp⟩
    · have htr : TransSurvives tr D := (transSurvivesBool_iff tr D).mp htrb
      have hrestBroken : ¬ WalkSurvives trs D := by
        intro hsurvRest
        apply hbroken
        intro t ht
        cases ht with
        | head => exact htr
        | tail _ hm => exact hsurvRest t hm
      rcases ih hrestBroken with ⟨i, hi, hiD⟩
      cases sw with
      | immutableStep =>
        simpa [extractRetractableIssuers] using ⟨i, hi, hiD⟩
      | retractableIssuer j =>
        exact ⟨i, List.Mem.tail j hi, hiD⟩

structure LowerWitnessWalk (Q : Type) where
  transitions : List (Trans Q)
  stepWitnesses : List StepWitness
  deriving DecidableEq, Repr

/-- Universal Lower-Bound Packing Theorem (`LTS-Lower`). -/
theorem lts_lower {ip : IssuerPartition} (hpart : WFPartition ip)
    {M : PointedLTS Q} {packing : List (LowerWitnessWalk Q)}
    (hwalks : ∀ w ∈ packing, LTSWalk M M.q0 M.qf w.transitions ∧
                             ValidWitnessedSteps ip w.transitions w.stepWitnesses)
    (hdisj : PairwiseDisjoint (packing.map (fun w => extractRetractableIssuers w.stepWitnesses))) :
    ∀ D : List IssuerId,
      NodupList D →
      (∀ d ∈ D, d ∈ ip.remIssuers) →
      ¬ LTSReachable M D M.q0 M.qf →
      packing.length ≤ D.length := by
  intro D hnd hD hunreach
  have hlen : (packing.map (fun w => extractRetractableIssuers w.stepWitnesses)).length =
      packing.length := List.length_map _
  rw [← hlen]
  apply disjoint_hitting_length_ge hdisj hnd
  intro s hs
  rcases List.mem_map.mp hs with ⟨w, hwmem, rfl⟩
  rcases hwalks w hwmem with ⟨hlts, hvsteps⟩
  have hbroken : ¬ WalkSurvives w.transitions D := by
    intro hsurv
    exact hunreach ⟨w.transitions, hlts, hsurv⟩
  exact broken_walk_hits_extracted hpart hvsteps hD hbroken

def checkLowerPacking [DecidableEq Q]
    (ip : IssuerPartition) (M : PointedLTS Q) (packing : List (LowerWitnessWalk Q)) : Bool :=
  listAllBool (fun w =>
    checkLTSWalkFrom M M.q0 M.qf w.transitions &&
    checkWitnessedSteps ip w.transitions w.stepWitnesses &&
    decide (extractRetractableIssuers w.stepWitnesses ≠ [])) packing &&
  pairwiseDisjointBool (packing.map (fun w => extractRetractableIssuers w.stepWitnesses))

theorem checkLowerPacking_sound [DecidableEq Q]
    {ip : IssuerPartition} {M : PointedLTS Q} {packing : List (LowerWitnessWalk Q)}
    (hpart : WFPartition ip)
    (hchk : checkLowerPacking ip M packing = true) :
    ∀ D : List IssuerId,
      NodupList D →
      (∀ d ∈ D, d ∈ ip.remIssuers) →
      ¬ LTSReachable M D M.q0 M.qf →
      packing.length ≤ D.length := by
  simp only [checkLowerPacking, Bool.and_eq_true, listAllBool_iff, checkLTSWalkFrom_iff,
    pairwiseDisjointBool_iff] at hchk
  apply lts_lower hpart _ hchk.2
  intro w hw
  have hwchk := hchk.1 w hw
  exact ⟨hwchk.1.1, checkWitnessedSteps_sound hwchk.1.2⟩

/-! ## Theorem 3: `LTS-Cut` (Universal Residual Closed-Cut Soundness & Completeness) -/

def PostClosedPred (M : PointedLTS Q) (D : List IssuerId) (C : Q → Prop) : Prop :=
  ∀ tr ∈ M.delta, TransSurvives tr D → C tr.src → C tr.dst

theorem closed_cut_walk_invariant {M : PointedLTS Q} {D : List IssuerId} {C : Q → Prop}
    (hclosed : PostClosedPred M D C)
    {p q : Q} {τ : List (Trans Q)}
    (hw : LTSWalk M p q τ) (hsurv : WalkSurvives τ D) (hp : C p) : C q := by
  induction hw with
  | nil _ => exact hp
  | cons tr rest hmem hsrc hdst _ ih =>
    have htrSurv : TransSurvives tr D := hsurv tr (List.Mem.head rest)
    have hrestSurv : WalkSurvives rest D := fun t ht => hsurv t (List.Mem.tail tr ht)
    subst hsrc
    subst hdst
    exact ih hrestSurv (hclosed tr hmem htrSurv hp)

/-- Universal Residual Closed-Cut Equivalence (`LTS-Cut`, Soundness & Completeness). -/
theorem lts_cut_iff (M : PointedLTS Q) (D : List IssuerId) :
    ¬ LTSReachable M D M.q0 M.qf ↔
    ∃ C : Q → Prop, C M.q0 ∧ ¬ C M.qf ∧ PostClosedPred M D C := by
  constructor
  · intro hunreach
    refine ⟨fun q => LTSReachable M D M.q0 q, ?_, hunreach, ?_⟩
    · exact ⟨[], LTSWalk.nil M.q0, fun _ h => nomatch h⟩
    · intro tr hmem hsurv ⟨τ, hw, hτsurv⟩
      refine ⟨τ ++ [tr], hw.snoc hmem rfl rfl, ?_⟩
      apply hτsurv.append
      intro t ht
      cases ht with
      | head => exact hsurv
      | tail _ hm => cases hm
  · intro ⟨C, hq0, hnotqf, hclosed⟩ ⟨τ, hw, hsurv⟩
    exact hnotqf (closed_cut_walk_invariant hclosed hw hsurv hq0)

/-- Executable finite closed-cut checker for finite state cut `cutStates : List Q`. -/
def checkClosedCut [DecidableEq Q]
    (M : PointedLTS Q) (D : List IssuerId) (cutStates : List Q) : Bool :=
  nodupBool cutStates &&
  listMemBool M.q0 cutStates &&
  !(listMemBool M.qf cutStates) &&
  listAllBool (fun tr =>
    (!(transSurvivesBool tr D && listMemBool tr.src cutStates)) ||
    listMemBool tr.dst cutStates) M.delta

theorem checkClosedCut_sound [DecidableEq Q]
    {M : PointedLTS Q} {D : List IssuerId} {cutStates : List Q}
    (hchk : checkClosedCut M D cutStates = true) :
    ¬ LTSReachable M D M.q0 M.qf := by
  simp only [checkClosedCut, Bool.and_eq_true, Bool.not_eq_true',
    listMemBool_iff, listMemBool_false_iff, listAllBool_iff] at hchk
  rcases hchk with ⟨⟨⟨_, hq0⟩, hnotqf⟩, hpost⟩
  apply (lts_cut_iff M D).mpr
  refine ⟨fun q => q ∈ cutStates, hq0, hnotqf, ?_⟩
  intro tr hmem hsurv hsrc
  have htr := hpost tr hmem
  have hcond1 : transSurvivesBool tr D = true := (transSurvivesBool_iff tr D).mpr hsurv
  have hcond2 : listMemBool tr.src cutStates = true := (listMemBool_iff tr.src cutStates).mpr hsrc
  rw [hcond1, hcond2] at htr
  simp only [Bool.and_self, Bool.not_true, Bool.false_or] at htr
  exact (listMemBool_iff tr.dst cutStates).mp htr

end OmegaLambda

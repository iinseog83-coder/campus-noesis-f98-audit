/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 3B: `OmegaLambda.CarrierGeodesic`

  Carrier 2 (`GeodesicBundle` `H_max`):
    - Separate state type `GeoState` (`reflDone | start | act v`) and separate
      transition builder `mkGeodesicLTS` (`Act t` out-degree `0`, distinct from
      `mkGlobalPlusLTS` per 82nd Ruling §3).
    - Strict unit rank potential `geoPhi` and machine-checked proofs of:
        * `geo_grading`: `geoPhi tr.src = geoPhi tr.dst + 1` on every transition
        * `geo_walk_exact_length`: every geodesic LTS walk `start →* act t` has
          exact length `r0 = d^κ(s, t)`
        * `ref_geo_levelB`: `PathwiseBijection` onto `IsTrueShortestWalk`
        * `ref_geo_levelA`: `ResilienceObsEquiv` (`Level A`) for all `s, t < n`
        * `geo_excludes_longer_detour`: surviving longer walks (`> r0`) cannot
          make `mkGeodesicLTS` reachable when all shortest walks (`= r0`) break
        * `geodesic_vs_global_plus_distinction`: concrete `E_PLUS` separation
          between `mkGeodesicLTS` and `mkGlobalPlusLTS`
-/

import OmegaLambda.CarrierLocalGlobal

namespace OmegaLambda

inductive GeoState where
  | reflDone : GeoState
  | start : GeoState
  | act : VertexId → GeoState
  deriving DecidableEq, Repr

def buildGeoActTrans (b : BaseData) (t : VertexId) : List VertexId → List (Trans GeoState)
  | [] => []
  | u :: rest =>
      (if u = t then []
       else
         (maxHopsOf b u t).map (fun w =>
           { src := .act u
             support := (edgeSupport? b.G u w).getD []
             dst := .act w })) ++
      buildGeoActTrans b t rest

def geoPosDelta (b : BaseData) (s t : VertexId) : List (Trans GeoState) :=
  let initTrans :=
    (maxHopsOf b s t).map (fun w =>
      { src := .start
        support := (edgeSupport? b.G s w).getD []
        dst := .act w })
  let actTrans := buildGeoActTrans b t (rangeBelow b.G.numVertices)
  initTrans ++ actTrans

/-- Separate transition builder for `GeodesicBundle` (`Act t` has out-degree `0`). -/
def mkGeodesicLTS (b : BaseData) (s t : VertexId) : PointedLTS GeoState :=
  if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then
    { q0 := .reflDone, qf := .reflDone, delta := [] }
  else if s < b.G.numVertices ∧ t < b.G.numVertices ∧ (rankOf b s t).isSome = true then
    { q0 := .start, qf := .act t, delta := geoPosDelta b s t }
  else
    { q0 := .start, qf := .act t, delta := [] }

theorem mkGeodesicLTS_eq_refl {b : BaseData} {s t : VertexId}
    (hrefl : b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices) :
    mkGeodesicLTS b s t = { q0 := .reflDone, qf := .reflDone, delta := [] } := by
  unfold mkGeodesicLTS
  split
  · rfl
  · next hnot => exact absurd hrefl hnot

theorem mkGeodesicLTS_eq_pos {b : BaseData} {s t : VertexId}
    (hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices))
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hsRank : (rankOf b s t).isSome = true) :
    mkGeodesicLTS b s t = { q0 := .start, qf := .act t, delta := geoPosDelta b s t } := by
  unfold mkGeodesicLTS
  split
  · next hrefl => exact absurd hrefl hnotRefl
  · split
    · rfl
    · next hnotPos => exact absurd ⟨hs, ht, hsRank⟩ hnotPos

theorem mkGeodesicLTS_eq_unreach {b : BaseData} {s t : VertexId}
    (hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices))
    (hunreach : rankOf b s t = none) :
    mkGeodesicLTS b s t = { q0 := .start, qf := .act t, delta := [] } := by
  unfold mkGeodesicLTS
  split
  · next hrefl => exact absurd hrefl hnotRefl
  · split
    · next hpos =>
      rcases hpos with ⟨_, _, hsome⟩
      rw [hunreach] at hsome
      contradiction
    · rfl

/-- Strict geodesic rank potential `Φ`. -/
def geoPhi (b : BaseData) (s t : VertexId) : GeoState → Nat
  | .reflDone => 0
  | .start => (rankOf b s t).getD 0
  | .act v => if v = t then 0 else (rankOf b v t).getD 0

theorem mem_buildGeoActTrans_iff {b : BaseData} {t : VertexId}
    {us : List VertexId} {tr : Trans GeoState} :
    tr ∈ buildGeoActTrans b t us ↔
    ∃ u ∈ us, u ≠ t ∧ ∃ w ∈ maxHopsOf b u t,
      tr = { src := .act u
             support := (edgeSupport? b.G u w).getD []
             dst := .act w } := by
  induction us with
  | nil =>
    simp [buildGeoActTrans]
  | cons u rest ih =>
    simp only [buildGeoActTrans, List.mem_append, ih]
    constructor
    · intro h
      cases h with
      | inl hhead =>
        split at hhead
        · cases hhead
        · next hne =>
          rcases List.mem_map.mp hhead with ⟨w, hw, htrEq⟩
          exact ⟨u, List.Mem.head rest, hne, w, hw, htrEq.symm⟩
      | inr htail =>
        rcases htail with ⟨u', hu', hne, w, hw, htrEq⟩
        exact ⟨u', List.Mem.tail u hu', hne, w, hw, htrEq⟩
    · intro ⟨u', hu', hne, w, hw, htrEq⟩
      cases hu' with
      | head =>
        left
        simp only [hne, ↓reduceIte]
        apply List.mem_map.mpr
        exact ⟨w, hw, htrEq.symm⟩
      | tail _ hm =>
        right
        exact ⟨u', hm, hne, w, hw, htrEq⟩

/-- If `rankOf b u t = some (r' + 2)`, no direct edge `(u, t)` exists in `b.G`. -/
theorem no_direct_edge_of_rank_ge_two {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {u t : VertexId} {r' : Nat}
    (hu : u < b.G.numVertices) (ht : t < b.G.numVertices)
    (hr : rankOf b u t = some (r' + 2)) :
    ∀ e ∈ b.G.edges, ¬ (e.src = u ∧ e.dst = t) := by
  intro e he ⟨hsrc, hdst⟩
  have hrp := hb.rankPairs u t hu ht
  unfold checkRankPair at hrp
  have hs := edge_mem_gives_edgeSupport? hb.wfGraph he
  rw [hsrc, hdst] at hs
  rw [hr, hs] at hrp
  simp at hrp

/-- Fundamental step lemma for `maxHopsOf`: every `w ∈ maxHopsOf b u t` corresponds to a
    valid edge `(u, w)` and drops distance-to-`t` by strictly `1`. -/
theorem first_hop_edge_and_drop {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {u t w : VertexId}
    (hu : u < b.G.numVertices) (ht : t < b.G.numVertices)
    (hwmem : w ∈ maxHopsOf b u t) :
    (∃ e ∈ b.G.edges, e.src = u ∧ e.dst = w) ∧
    (rankOf b u t).getD 0 = geoPhi b s0 t (.act w) + 1 := by
  have hhop := (b6_maxHops_iff hb hu ht w).mp hwmem
  unfold IsShortestFirstHop at hhop
  cases hr : rankOf b u t with
  | none => rw [hr] at hhop; cases hhop
  | some r =>
    cases r with
    | zero => rw [hr] at hhop; cases hhop
    | succ r1 =>
      cases r1 with
      | zero =>
        rw [hr] at hhop
        rcases hhop with ⟨hedge, rfl⟩
        refine ⟨hedge, ?_⟩
        simp [geoPhi]
      | succ r' =>
        rw [hr] at hhop
        rcases hhop with ⟨hedge, hrw⟩
        have hwNe : w ≠ t := by
          intro hwt
          subst hwt
          rcases hedge with ⟨e, he, hsrc, hdst⟩
          exact no_direct_edge_of_rank_ge_two hb hu ht hr e he ⟨hsrc, hdst⟩
        refine ⟨hedge, ?_⟩
        simp [geoPhi, hwNe, hrw]

/-! ## `Geo-Grading` Lemma & Exact Geodesic Walk Length -/

/-- `Geo-Grading` (`Strict Grading Lemma`, 81st/82nd Rulings):
    Every transition in `mkGeodesicLTS b s t` decreases `geoPhi` by strictly `1`. -/
theorem geo_grading {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    {tr : Trans GeoState} (hmem : tr ∈ (mkGeodesicLTS b s t).delta) :
    geoPhi b s t tr.src = geoPhi b s t tr.dst + 1 := by
  unfold mkGeodesicLTS at hmem
  split at hmem
  · cases hmem
  · split at hmem
    · next hcond =>
      rcases hcond with ⟨hs, ht, _⟩
      simp only [geoPosDelta, List.mem_append] at hmem
      cases hmem with
      | inl hinit =>
        rcases List.mem_map.mp hinit with ⟨w, hwmem, htrEq⟩
        rw [← htrEq]
        simpa [geoPhi] using (first_hop_edge_and_drop (s0 := s) hb hs ht hwmem).2
      | inr hact =>
        rcases mem_buildGeoActTrans_iff.mp hact with ⟨u, huRange, huNe, w, hwmem, htrEq⟩
        have hu : u < b.G.numVertices := (mem_rangeBelow_iff u _).mp huRange
        rw [htrEq]
        have hdrop := (first_hop_edge_and_drop (s0 := s) hb hu ht hwmem).2
        simp [geoPhi, huNe, hdrop]
    · cases hmem

/-- Out-degree of `.act t` in `mkGeodesicLTS b s t` is strictly `0`. -/
theorem geo_target_no_outgoing (b : BaseData) (s t : VertexId)
    {tr : Trans GeoState} (hmem : tr ∈ (mkGeodesicLTS b s t).delta) :
    tr.src ≠ .act t := by
  unfold mkGeodesicLTS at hmem
  split at hmem
  · cases hmem
  · split at hmem
    · simp only [geoPosDelta, List.mem_append] at hmem
      cases hmem with
      | inl hinit =>
        rcases List.mem_map.mp hinit with ⟨_, _, htrEq⟩
        rw [← htrEq]
        intro h; cases h
      | inr hact =>
        rcases mem_buildGeoActTrans_iff.mp hact with ⟨u, _, huNe, _, _, htrEq⟩
        rw [htrEq]
        intro h
        injection h with huEq
        exact huNe huEq
    · cases hmem

theorem geo_walk_potential_diff {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId} {p q : GeoState}
    {τ : List (Trans GeoState)}
    (hw : LTSWalk (mkGeodesicLTS b s t) p q τ) :
    geoPhi b s t p = geoPhi b s t q + τ.length := by
  induction hw with
  | nil _ => simp
  | cons tr rest hmem hsrc hdst _ ih =>
    have hgrad := geo_grading hb hmem
    rw [hsrc, hdst] at hgrad
    simp only [List.length_cons]
    omega

/-- Every geodesic LTS walk from `q0` to `qf` has exact step length `r0 = rankOf b s t`. -/
theorem geo_walk_exact_length {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId} {r0 : Nat}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hr0 : rankOf b s t = some r0)
    {τ : List (Trans GeoState)}
    (hw : LTSWalk (mkGeodesicLTS b s t) (mkGeodesicLTS b s t).q0 (mkGeodesicLTS b s t).qf τ) :
    τ.length = r0 := by
  have hdiff := geo_walk_potential_diff hb hw
  by_cases hrefl : b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices
  · rw [mkGeodesicLTS_eq_refl hrefl] at hdiff
    rcases hrefl with ⟨hκ, hst, _⟩
    subst hst
    have hrp := hb.rankPairs s s hs hs
    unfold checkRankPair at hrp
    rw [hr0] at hrp
    cases r0 with
    | zero =>
      simp only [geoPhi] at hdiff
      omega
    | succ r1 =>
      cases r1 <;> simp [hκ] at hrp
  · have hsRank : (rankOf b s t).isSome = true := by rw [hr0]; rfl
    rw [mkGeodesicLTS_eq_pos hrefl hs ht hsRank] at hdiff
    simp only [geoPhi, hr0, Option.getD, ↓reduceIte] at hdiff
    omega

/-! ## Geodesic Walk Conversions & `Ref-Geo` (Level B + Level A) -/

def geoChainToActTrans (b : BaseData) : VertexId → List VertexId → List (Trans GeoState)
  | _, [] => []
  | u, w :: rest =>
      { src := .act u, support := (edgeSupport? b.G u w).getD [], dst := .act w } ::
      geoChainToActTrans b w rest

def geoWalkToLTS (b : BaseData) : List VertexId → List (Trans GeoState)
  | v0 :: w1 :: rest =>
      { src := .start, support := (edgeSupport? b.G v0 w1).getD [], dst := .act w1 } ::
      geoChainToActTrans b w1 rest
  | _ => []

def geoStateVertex (s : VertexId) : GeoState → VertexId
  | .reflDone => s
  | .start => s
  | .act v => v

def ltsWalkToGeoWalk (s : VertexId) (τ : List (Trans GeoState)) : List VertexId :=
  s :: τ.map (fun tr => geoStateVertex s tr.dst)

/-- Key optimality step along a shortest chain: if `u :: w :: rest` is a chain to `t`
    of length `k ≥ 1` matching `rankOf b u t = some k`, then `w ∈ maxHopsOf b u t` and
    (when `rest ≠ []`) `w ≠ t` with `rankOf b w t = some rest.length`. -/
theorem shortest_chain_step_props {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {u w t : VertexId} {rest : List VertexId}
    (hu : u < b.G.numVertices) (ht : t < b.G.numVertices)
    (he : ∃ e ∈ b.G.edges, e.src = u ∧ e.dst = w)
    (hcRest : IsEdgeChain b.G w t rest)
    (hr : rankOf b u t = some (rest.length + 1)) :
    w < b.G.numVertices ∧
    w ∈ maxHopsOf b u t ∧
    (rest ≠ [] → w ≠ t ∧ rankOf b w t = some rest.length) := by
  rcases he with ⟨e, heMem, hsrc, hdst⟩
  have hw : w < b.G.numVertices := by
    rw [← hdst]
    exact (hb.wfGraph.2 e heMem).2.1
  cases rest with
  | nil =>
    cases hcRest with
    | nil _ =>
      simp only [List.length_nil, Nat.zero_add] at hr
      have hhop : IsShortestFirstHop b u w w := by
        unfold IsShortestFirstHop
        rw [hr]
        exact ⟨⟨e, heMem, hsrc, hdst⟩, rfl⟩
      refine ⟨hw, (b6_maxHops_iff hb hu ht w).mpr hhop, ?_⟩
      intro hne; exact absurd rfl hne
  | cons w2 rest2 =>
    simp only [List.length_cons] at hr
    have hwNe : w ≠ t := by
      intro hwt
      subst hwt
      exact no_direct_edge_of_rank_ge_two hb hu ht hr e heMem ⟨hsrc, hdst⟩
    have hvwSub : IsValidWalk b.G b.kappa w t (w :: w2 :: rest2) :=
      ⟨rfl, hw, ht, hcRest, fun _ => by simp⟩
    rcases b5_rank_lower_bound hb (rest2.length + 1) hvwSub rfl with ⟨rw, hrw, hrwLe⟩
    have hrp := hb.rankPairs u t hu ht
    unfold checkRankPair at hrp
    rw [hr] at hrp
    simp only [Bool.and_eq_true, listAllBool_iff] at hrp
    have hechk := hrp.2 e heMem
    rw [hsrc, hdst, hrw] at hechk
    simp at hechk
    have hrwEq : rw = rest2.length + 1 := by omega
    subst hrwEq
    have hhop : IsShortestFirstHop b u t w := by
      unfold IsShortestFirstHop
      rw [hr]
      exact ⟨⟨e, heMem, hsrc, hdst⟩, hrw⟩
    refine ⟨hw, (b6_maxHops_iff hb hu ht w).mpr hhop, ?_⟩
    intro _
    exact ⟨hwNe, hrw⟩

theorem geoChainToActTrans_valid {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    (hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices))
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hsRank : (rankOf b s t).isSome = true) :
    ∀ {u t' : VertexId} {tail : List VertexId},
      IsEdgeChain b.G u t' tail →
      t' = t →
      u < b.G.numVertices →
      (tail ≠ [] → u ≠ t ∧ rankOf b u t = some tail.length) →
      LTSWalk (mkGeodesicLTS b s t) (GeoState.act u) (GeoState.act t)
        (geoChainToActTrans b u tail) := by
  intro u t' tail hc htEq hu hneProps
  induction hc with
  | nil u0 =>
    subst htEq
    exact LTSWalk.nil (GeoState.act u0)
  | @cons u0 w tEnd e rest he hsrc hdst hcRest ih =>
    subst htEq
    have hprops := hneProps (by simp)
    rcases hprops with ⟨huNe, hru⟩
    rcases shortest_chain_step_props hb hu ht ⟨e, he, hsrc, hdst⟩ hcRest hru with
      ⟨hw, hwMax, hrestProps⟩
    subst hsrc; subst hdst
    have hsupp := edge_mem_gives_edgeSupport? hb.wfGraph he
    simp only [geoChainToActTrans, hsupp, Option.getD]
    let tr0 : Trans GeoState :=
      { src := GeoState.act e.src, support := e.support, dst := GeoState.act e.dst }
    have hmem : tr0 ∈ (mkGeodesicLTS b s tEnd).delta := by
      rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
      simp only [geoPosDelta, List.mem_append]
      right
      apply mem_buildGeoActTrans_iff.mpr
      refine ⟨e.src, (mem_rangeBelow_iff e.src _).mpr hu, huNe, e.dst, hwMax, ?_⟩
      simp [tr0, hsupp]
    exact LTSWalk.cons tr0 (geoChainToActTrans b e.dst rest) hmem rfl rfl
      (ih rfl hw hrestProps)

theorem geo_ltsWalk_act_chain_and_inv {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    (hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices))
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hsRank : (rankOf b s t).isSome = true)
    {p q : GeoState} {τ : List (Trans GeoState)}
    (hw : LTSWalk (mkGeodesicLTS b s t) p q τ) :
    ∀ u v : VertexId, p = GeoState.act u → q = GeoState.act v →
      IsEdgeChain b.G u v (τ.map (fun tr => geoStateVertex s tr.dst)) ∧
      geoChainToActTrans b u (τ.map (fun tr => geoStateVertex s tr.dst)) = τ := by
  induction hw with
  | nil _ =>
    intro u v hp hq
    rw [hp] at hq
    injection hq with huv
    subst huv
    exact ⟨IsEdgeChain.nil u, rfl⟩
  | cons tr rest hmem hsrc hdst _ ih =>
    intro u v hp hq
    rw [hp] at hsrc
    have hmem' := hmem
    rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank] at hmem'
    simp only [geoPosDelta, List.mem_append] at hmem'
    cases hmem' with
    | inl hinit =>
      rcases List.mem_map.mp hinit with ⟨w, _, htrEq⟩
      rw [← htrEq] at hsrc
      cases hsrc
    | inr hact =>
      rcases mem_buildGeoActTrans_iff.mp hact with ⟨u', huRange, _, w, hwMax, htrEq⟩
      have hu' : u' < b.G.numVertices := (mem_rangeBelow_iff u' _).mp huRange
      rcases (first_hop_edge_and_drop (s0 := s) hb hu' ht hwMax).1 with ⟨e, he, heSrc, heDst⟩
      have hsupp := edge_mem_gives_edgeSupport? hb.wfGraph he
      rw [heSrc, heDst] at hsupp
      rw [htrEq] at hsrc hdst
      injection hsrc with huEq
      subst huEq; subst hdst
      rcases ih w v rfl hq with ⟨hcRest, hinvRest⟩
      rw [htrEq]
      simp only [List.map_cons]
      have hgv : geoStateVertex s (GeoState.act w) = w := rfl
      rw [hgv]
      refine ⟨IsEdgeChain.cons e _ he heSrc heDst hcRest, ?_⟩
      simp only [geoChainToActTrans, hsupp, Option.getD, hinvRest]

theorem geo_left_inv_aux (b : BaseData) (s u : VertexId) (tail : List VertexId) :
    (geoChainToActTrans b u tail).map (fun tr => geoStateVertex s tr.dst) = tail := by
  induction tail generalizing u with
  | nil => rfl
  | cons w rest ih =>
    simp only [geoChainToActTrans, List.map_cons]
    have hgv : geoStateVertex s (GeoState.act w) = w := rfl
    rw [hgv, ih w]

theorem geo_survives_aux {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {u t : VertexId} {tail : List VertexId}
    (hc : IsEdgeChain b.G u t tail) (D : List IssuerId) :
    ChainSurvives b.G D u tail ↔ WalkSurvives (geoChainToActTrans b u tail) D := by
  induction hc with
  | nil _ =>
    simp [ChainSurvives, geoChainToActTrans, WalkSurvives]
  | cons e rest he hsrc hdst _ ih =>
    subst hsrc; subst hdst
    have hs := edge_mem_gives_edgeSupport? hb.wfGraph he
    simp only [ChainSurvives, geoChainToActTrans, hs, Option.getD, WalkSurvives]
    constructor
    · intro ⟨⟨e', he', hu', hw', hnotall⟩, hrest⟩ tr htr
      cases htr with
      | head =>
        have heEq := edge_unique_of_nodup_keys hb.wfGraph.1 he' he hu' hw'
        subst heEq
        exact hnotall
      | tail _ hm => exact ih.mp hrest tr hm
    · intro hws
      refine ⟨⟨e, he, rfl, rfl, hws _ (List.Mem.head _)⟩,
              ih.mpr (fun tr hm => hws tr (List.Mem.tail _ hm))⟩

/-- `Ref-Geo` (Level B): Explicit `PathwiseBijection` between `IsTrueShortestWalk` and
    `mkGeodesicLTS` whenever `(s, t)` is reachable (`rankOf b s t = some r0`). -/
def ref_geo_levelB {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId} {r0 : Nat}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hr0 : rankOf b s t = some r0) :
    PathwiseBijection (IsTrueShortestWalk b.G b.kappa s t) b.G (mkGeodesicLTS b s t) where
  toLTS γ _ :=
    if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
    else geoWalkToLTS b γ
  toLTS_valid γ hγ := by
    rcases (b5_rank_iff_true_shortest hb hs ht hr0 γ).mp hγ with ⟨hvw, hlen⟩
    split
    · next hrefl =>
      rw [mkGeodesicLTS_eq_refl hrefl]
      exact LTSWalk.nil GeoState.reflDone
    · next hnotRefl =>
      have hrPos : 1 ≤ r0 := by
        cases r0 with
        | zero =>
          have hrp := hb.rankPairs s t hs ht
          unfold checkRankPair at hrp
          rw [hr0] at hrp
          simp only [decide_eq_true_eq] at hrp
          exfalso
          exact hnotRefl ⟨hrp.1, hrp.2, hs⟩
        | succ _ => omega
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        rcases hvw with ⟨rfl, _, _, hc, _⟩
        cases tail with
        | nil =>
          simp [walkSteps] at hlen
          omega
        | cons w1 rest =>
          cases hc with
          | cons e0 _ he0 hsrc0 hdst0 hcRest =>
            simp only [walkSteps, List.length_cons] at hlen
            subst hlen
            rcases shortest_chain_step_props hb hs ht ⟨e0, he0, hsrc0, hdst0⟩ hcRest hr0 with
              ⟨hw1, hw1Max, hrestProps⟩
            subst hsrc0; subst hdst0
            have hsupp0 := edge_mem_gives_edgeSupport? hb.wfGraph he0
            have hsRank : (rankOf b e0.src t).isSome = true := by rw [hr0]; rfl
            simp only [geoWalkToLTS, hsupp0, Option.getD]
            let tr0 : Trans GeoState :=
              { src := GeoState.start, support := e0.support, dst := GeoState.act e0.dst }
            have hmem0 : tr0 ∈ (mkGeodesicLTS b e0.src t).delta := by
              rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
              simp only [geoPosDelta, List.mem_append]
              left
              apply List.mem_map.mpr
              refine ⟨e0.dst, hw1Max, ?_⟩
              simp [tr0, hsupp0]
            have hq0 : (mkGeodesicLTS b e0.src t).q0 = GeoState.start := by
              rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
            have hqf : (mkGeodesicLTS b e0.src t).qf = GeoState.act t := by
              rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
            rw [hq0, hqf]
            exact LTSWalk.cons tr0 (geoChainToActTrans b e0.dst rest) hmem0 rfl rfl
              (geoChainToActTrans_valid hb hnotRefl hs ht hsRank hcRest rfl hw1 hrestProps)
  ofLTS τ _ :=
    if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then [s]
    else ltsWalkToGeoWalk s τ
  ofLTS_valid τ hw := by
    have hτLen : τ.length = r0 := geo_walk_exact_length hb hs ht hr0 hw
    apply (b5_rank_iff_true_shortest hb hs ht hr0 _).mpr
    split
    · next hrefl =>
      rcases hrefl with ⟨hκ, hst, _⟩
      subst hst
      have hr0Zero : r0 = 0 := by
        have hrp := hb.rankPairs s s hs hs
        unfold checkRankPair at hrp
        rw [hr0] at hrp
        cases r0 with
        | zero => rfl
        | succ r1 => cases r1 <;> simp [hκ] at hrp
      subst hr0Zero
      refine ⟨⟨rfl, hs, hs, IsEdgeChain.nil s, ?_⟩, rfl⟩
      intro hp; rw [hκ] at hp; contradiction
    · next hnotRefl =>
      have hsRank : (rankOf b s t).isSome = true := by rw [hr0]; rfl
      have hq0 : (mkGeodesicLTS b s t).q0 = GeoState.start := by
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
      have hqf : (mkGeodesicLTS b s t).qf = GeoState.act t := by
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
      have hw' : LTSWalk (mkGeodesicLTS b s t) GeoState.start (GeoState.act t) τ := by
        rw [← hq0, ← hqf]
        exact hw
      cases hw' with
      | cons tr0 rest hmem0 hsrc0 hdst0 hwRest =>
        have hmem0' := hmem0
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank] at hmem0'
        simp only [geoPosDelta, List.mem_append] at hmem0'
        cases hmem0' with
        | inl hinit =>
          rcases List.mem_map.mp hinit with ⟨w1, hw1Max, htr0Eq⟩
          rcases (first_hop_edge_and_drop (s0 := s) hb hs ht hw1Max).1 with
            ⟨e0, he0, he0Src, he0Dst⟩
          rw [← htr0Eq] at hdst0
          subst hdst0
          rcases geo_ltsWalk_act_chain_and_inv hb hnotRefl hs ht hsRank hwRest w1 t rfl rfl with
            ⟨hcRest, _⟩
          rw [← htr0Eq] at hτLen ⊢
          refine ⟨⟨rfl, hs, ht, ?_, fun _ => by simp⟩, ?_⟩
          · simp only [List.map_cons]
            have hgv : geoStateVertex s (GeoState.act w1) = w1 := rfl
            rw [hgv]
            exact IsEdgeChain.cons e0 _ he0 he0Src he0Dst hcRest
          · simp only [ltsWalkToGeoWalk, walkSteps, List.map_cons, List.length_cons,
              List.length_map] at hτLen ⊢
            exact hτLen
        | inr hact =>
          rcases mem_buildGeoActTrans_iff.mp hact with ⟨_, _, _, _, _, htr0Eq⟩
          rw [htr0Eq] at hsrc0
          cases hsrc0
  left_inv γ hγ := by
    rcases (b5_rank_iff_true_shortest hb hs ht hr0 γ).mp hγ with ⟨hvw, hlen⟩
    split
    · next hrefl =>
      rcases hrefl with ⟨hκ, hst, _⟩
      subst hst
      have hr0Zero : r0 = 0 := by
        have hrp := hb.rankPairs s s hs hs
        unfold checkRankPair at hrp
        rw [hr0] at hrp
        cases r0 with
        | zero => rfl
        | succ r1 => cases r1 <;> simp [hκ] at hrp
      rw [hr0Zero] at hlen
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        cases tail with
        | cons _ _ => simp [walkSteps] at hlen
        | nil =>
          rcases hvw with ⟨rfl, _, _, _, _⟩
          rfl
    · next hnotRefl =>
      have hrPos : 1 ≤ r0 := by
        cases r0 with
        | zero =>
          have hrp := hb.rankPairs s t hs ht
          unfold checkRankPair at hrp
          rw [hr0] at hrp
          simp only [decide_eq_true_eq] at hrp
          exfalso
          exact hnotRefl ⟨hrp.1, hrp.2, hs⟩
        | succ _ => omega
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        rcases hvw with ⟨rfl, _, _, _, _⟩
        cases tail with
        | nil => simp [walkSteps] at hlen; omega
        | cons w1 rest =>
          simp only [geoWalkToLTS, ltsWalkToGeoWalk, List.map_cons]
          have hgv : geoStateVertex v0 (GeoState.act w1) = w1 := rfl
          rw [hgv, geo_left_inv_aux]
  right_inv τ hw := by
    split
    · next hrefl =>
      rw [mkGeodesicLTS_eq_refl hrefl] at hw
      cases hw with
      | nil => rfl
      | cons _ _ hmem _ _ _ => cases hmem
    · next hnotRefl =>
      have hsRank : (rankOf b s t).isSome = true := by rw [hr0]; rfl
      have hq0 : (mkGeodesicLTS b s t).q0 = GeoState.start := by
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
      have hqf : (mkGeodesicLTS b s t).qf = GeoState.act t := by
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
      have hw' : LTSWalk (mkGeodesicLTS b s t) GeoState.start (GeoState.act t) τ := by
        rw [← hq0, ← hqf]
        exact hw
      cases hw' with
      | cons tr0 rest hmem0 hsrc0 hdst0 hwRest =>
        have hmem0' := hmem0
        rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank] at hmem0'
        simp only [geoPosDelta, List.mem_append] at hmem0'
        cases hmem0' with
        | inl hinit =>
          rcases List.mem_map.mp hinit with ⟨w1, hw1Max, htr0Eq⟩
          rcases (first_hop_edge_and_drop (s0 := s) hb hs ht hw1Max).1 with
            ⟨e0, he0, he0Src, he0Dst⟩
          have hsupp0 := edge_mem_gives_edgeSupport? hb.wfGraph he0
          rw [he0Src, he0Dst] at hsupp0
          rw [← htr0Eq] at hdst0
          subst hdst0
          rcases geo_ltsWalk_act_chain_and_inv hb hnotRefl hs ht hsRank hwRest w1 t rfl rfl with
            ⟨_, hinvRest⟩
          rw [← htr0Eq]
          simp only [ltsWalkToGeoWalk, List.map_cons]
          have hgv : geoStateVertex s (GeoState.act w1) = w1 := rfl
          rw [hgv]
          simp only [geoWalkToLTS, hinvRest]
        | inr hact =>
          rcases mem_buildGeoActTrans_iff.mp hact with ⟨_, _, _, _, _, htr0Eq⟩
          rw [htr0Eq] at hsrc0
          cases hsrc0
  survives_iff γ hγ D := by
    rcases (b5_rank_iff_true_shortest hb hs ht hr0 γ).mp hγ with ⟨hvw, hlen⟩
    split
    · next hrefl =>
      rcases hrefl with ⟨hκ, hst, _⟩
      subst hst
      have hr0Zero : r0 = 0 := by
        have hrp := hb.rankPairs s s hs hs
        unfold checkRankPair at hrp
        rw [hr0] at hrp
        cases r0 with
        | zero => rfl
        | succ r1 => cases r1 <;> simp [hκ] at hrp
      rw [hr0Zero] at hlen
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        cases tail with
        | cons _ _ => simp [walkSteps] at hlen
        | nil => simp [WalkSurvivesGraph, ChainSurvives, WalkSurvives]
    · next hnotRefl =>
      have hrPos : 1 ≤ r0 := by
        cases r0 with
        | zero =>
          have hrp := hb.rankPairs s t hs ht
          unfold checkRankPair at hrp
          rw [hr0] at hrp
          simp only [decide_eq_true_eq] at hrp
          exfalso
          exact hnotRefl ⟨hrp.1, hrp.2, hs⟩
        | succ _ => omega
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        rcases hvw with ⟨rfl, _, _, hc, _⟩
        cases tail with
        | nil => simp [walkSteps] at hlen; omega
        | cons w1 rest =>
          cases hc with
          | cons e0 _ he0 hsrc0 hdst0 hcRest =>
            subst hsrc0; subst hdst0
            have hs0 := edge_mem_gives_edgeSupport? hb.wfGraph he0
            simp only [WalkSurvivesGraph, ChainSurvives, geoWalkToLTS, hs0, Option.getD,
              WalkSurvives]
            constructor
            · intro ⟨⟨e', he', hu', hw', hnot0⟩, hrest⟩ tr htr
              cases htr with
              | head =>
                have heEq := edge_unique_of_nodup_keys hb.wfGraph.1 he' he0 hu' hw'
                subst heEq
                exact hnot0
              | tail _ hm =>
                exact (geo_survives_aux hb hcRest D).mp hrest tr hm
            · intro hws
              refine ⟨⟨e0, he0, rfl, rfl, hws _ (List.Mem.head _)⟩,
                      (geo_survives_aux hb hcRest D).mpr
                        (fun tr hm => hws tr (List.Mem.tail _ hm))⟩

/-- `Ref-Geo` (Level A): `ResilienceObsEquiv` holds for ALL `s, t < n` (both reachable
    and unreachable pairs). -/
theorem ref_geo_levelA {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices) :
    ResilienceObsEquiv
      (fun D => ∃ γ, IsTrueShortestWalk b.G b.kappa s t γ ∧ WalkSurvivesGraph b.G D γ)
      (mkGeodesicLTS b s t) := by
  cases hr0 : rankOf b s t with
  | some r0 =>
    exact levelB_implies_levelA (ref_geo_levelB hb hs ht hr0)
  | none =>
    intro D
    constructor
    · intro ⟨γ, ⟨hvw, _⟩, _⟩
      rcases b5_rank_lower_bound hb (walkSteps γ) hvw rfl with ⟨r, hr, _⟩
      rw [hr0] at hr
      contradiction
    · intro ⟨τ, hw, _⟩
      have hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices) := by
        intro ⟨hκ, hst, _⟩
        subst hst
        have hrp := hb.rankPairs s s hs hs
        unfold checkRankPair at hrp
        rw [hr0] at hrp
        simp [hκ] at hrp
      rw [mkGeodesicLTS_eq_unreach hnotRefl hr0] at hw
      cases hw with
      | cons _ _ hmem _ _ _ => cases hmem

/-- Detour Exclusion Theorem (`geo_excludes_longer_detour`):
    If `rankOf b s t = some r0` and every walk of length `r0` breaks under `D`, then
    even if a longer walk `γ_long` (`r0 < walkSteps γ_long`) survives in `b.G`,
    `mkGeodesicLTS b s t` is unreachable under `D`. -/
theorem geo_excludes_longer_detour {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId} {r0 : Nat}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hr0 : rankOf b s t = some r0) {D : List IssuerId}
    (hnoShortest : ∀ γ, IsValidWalk b.G b.kappa s t γ → walkSteps γ = r0 →
      ¬ WalkSurvivesGraph b.G D γ)
    {γ_long : List VertexId}
    (_hlongValid : IsValidWalk b.G b.kappa s t γ_long)
    (_hlongGt : r0 < walkSteps γ_long)
    (_hlongSurv : WalkSurvivesGraph b.G D γ_long) :
    ¬ LTSReachable (mkGeodesicLTS b s t) D (mkGeodesicLTS b s t).q0 (mkGeodesicLTS b s t).qf := by
  intro hreach
  have hequiv := (levelB_implies_levelA (ref_geo_levelB hb hs ht hr0) D).mpr hreach
  rcases hequiv with ⟨γ, hshort, hsurv⟩
  rcases (b5_rank_iff_true_shortest hb hs ht hr0 γ).mp hshort with ⟨hvw, hlen⟩
  exact hnoShortest γ hvw hlen hsurv

/-! ## Explicit `Geodesic E_PLUS` vs `Global E_PLUS` Separation (82nd Ruling §3) -/

def sepPartition : IssuerPartition :=
  { constIssuers := [], remIssuers := [10, 11] }

def sepBase : BaseData :=
  { G :=
      { numVertices := 3
        edges := [
          { src := 0, dst := 2, support := [10] },
          { src := 0, dst := 1, support := [11] },
          { src := 1, dst := 2, support := [11] }
        ] }
    kappa := .ePlus
    rankEntries := [(0, 1, 1), (0, 2, 1), (1, 2, 1)]
    maxHopEntries := [(0, 1, [1]), (0, 2, [2]), (1, 2, [2])] }

/-- Concrete `E_PLUS` separation theorem (82nd Ruling §3):
    Under deletion `D = [10]`, `mkGlobalPlusLTS` remains reachable via the 2-step detour
    `0 → 1 → 2`, whereas `mkGeodesicLTS` is unreachable because the unique shortest walk
    `0 → 2` (`rank = 1`) is retracted. -/
theorem geodesic_vs_global_plus_distinction :
    VerifiedBase sepPartition sepBase ∧
    LTSReachable (mkGlobalPlusLTS sepBase.G 0 2) [10] .start (.act 2) ∧
    ¬ LTSReachable (mkGeodesicLTS sepBase 0 2) [10]
        (mkGeodesicLTS sepBase 0 2).q0 (mkGeodesicLTS sepBase 0 2).qf := by
  have hbBool : checkVerifiedBase sepPartition sepBase = true := rfl
  have hb : VerifiedBase sepPartition sepBase := checkVerifiedBase_sound hbBool
  refine ⟨hb, ?_, ?_⟩
  · apply (ref_glob_plus_levelA hb.wfGraph (by decide) (by decide) [10]).mp
    refine ⟨[0, 1, 2], ?_, ?_⟩
    · refine ⟨rfl, by decide, by decide, ?_, fun _ => by simp⟩
      exact IsEdgeChain.cons { src := 0, dst := 1, support := [11] } [2]
        (List.Mem.tail _ (List.Mem.head _)) rfl rfl
        (IsEdgeChain.cons { src := 1, dst := 2, support := [11] } []
          (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))) rfl rfl (IsEdgeChain.nil 2))
    · have h11not : ¬ (∀ i ∈ ([11] : List IssuerId), i ∈ ([10] : List IssuerId)) := by
        intro hall
        have h11 := hall 11 (List.Mem.head _)
        cases h11 with
        | tail _ hm => cases hm
      exact ⟨⟨{ src := 0, dst := 1, support := [11] },
               List.Mem.tail _ (List.Mem.head _), rfl, rfl, h11not⟩,
             ⟨{ src := 1, dst := 2, support := [11] },
               List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)), rfl, rfl, h11not⟩,
             trivial⟩
  · have hcut : checkClosedCut (mkGeodesicLTS sepBase 0 2) [10] [GeoState.start] = true := rfl
    exact checkClosedCut_sound hcut

end OmegaLambda

/-
  CAMPUS-NOESIS Omega-Lambda R2: Kernel Evaluation & Adversarial Guard Proofs
  Module: `OmegaLambda.CertRefinementExamples`

  Exercises `Cert-0`..`Cert-4` and mandatory guards `F89-01`..`F89-03` via kernel
  definitional reduction (`rfl`, zero `native_decide`):
    1. `Ex-R2-1`: `LocalPositive` multi-step chain `[0, 1, 2, 3]` + `[0, 3]` showing
       exact internal `.mid 0 1` prefix cut synthesis (`liftLocalPositiveCut = [.init, .mid 0 1]`)
       and canonical `F89-02` `minConst` (`constIssuers = [0, 1]`, `irIdx = 0`).
    2. `Ex-R2-2`: `LocalReflexive` on `#41`'s `f82Packet = [[0], [0, 1, 0]]` (`F82-01`
       Level-A-only unbreakability accepted; finite-cut mode rejected).
    3. `Ex-R2-3`: `GlobalPlus` self-cycle `s = t = 0` (`0 → 1 → 0`) with `C_V = [1]`
       lifting to `[.start, .act 1]` (`qf = .act 0` excluded despite `s = t`).
    4. `Ex-R2-4`: `Geodesic` `E_PLUS` rank-1 direct edge (`0 → 1`) cut & packing.
    5. `Adv-R2-*`: Kernel-reduced (`= false := rfl`) rejection proofs for `F89-01`
       unregistered tags & `evasionModeTag = 1` (`HELD`), `F89-02` non-minimal
       `const` issuer (`irIdx = 1 ≠ min [0, 1]`), and `F89-03` unclosed dual cuts.
-/

import OmegaLambda.CertRefinement
import OmegaLambda.SourceIRRefinementExamples

namespace OmegaLambda.R2Examples

open OmegaLambda

/-! ## Ex-R2-1: `LocalPositive` Prefix `.mid 0 1` Cut Lifting & `F89-02` `minConst` -/

def ipEx1 : IssuerPartition :=
  { constIssuers := [0, 1]
    remIssuers := [2, 3] }

def graphEx1 : LabeledGraph :=
  { numVertices := 4
    edges :=
      [ { src := 0, dst := 1, support := [1, 0] },  -- const on edge = [1, 0], min = 0!
        { src := 1, dst := 2, support := [2] },     -- rem issuer 2
        { src := 2, dst := 3, support := [0] },     -- const issuer 0
        { src := 0, dst := 3, support := [3] } ] }  -- rem issuer 3

def baseEx1 : BaseData :=
  { G := graphEx1
    kappa := .ePlus
    rankEntries :=
      [ (0, 1, 1), (0, 2, 2), (0, 3, 1),
        (1, 2, 1), (1, 3, 2), (2, 3, 1) ]
    maxHopEntries :=
      [ (0, 1, [1]), (0, 2, [1]), (0, 3, [3]),
        (1, 2, [2]), (1, 3, [2]), (2, 3, [3]) ] }

def pktEx1 : List (List VertexId) :=
  [[0, 1, 2, 3], [0, 3]]

def srcCertEx1 : SourceCertTerm :=
  { closureTag := 2
    carrierTag := 1
    modeTag := 2
    evasionModeTag := 0
    claimedL := 2
    claimedU := 2
    unbreakableRefKind := 0
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses :=
      [ { refKind := 1
          jIdx := 0
          walkVertices := []
          stepWitnesses :=
            [ { stepTag := 2, irIdx := 0 },  -- canonical min([1, 0]) = 0 (`F89-02`)
              { stepTag := 1, irIdx := 2 },
              { stepTag := 2, irIdx := 0 } ] },
        { refKind := 1
          jIdx := 1
          walkVertices := []
          stepWitnesses :=
            [ { stepTag := 1, irIdx := 3 } ] } ]
    retractionIrIndices := [2, 3]
    dualCutVids := [] }

theorem r2_ex1_base_ok : checkVerifiedBase ipEx1 baseEx1 = true := rfl

theorem r2_ex1_lifted_mid_cut_exact :
    liftLocalPositiveCut graphEx1 pktEx1 [2, 3] = [.init, .mid 0 1] := rfl

theorem r2_ex1_source_cert_ok :
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1) srcCertEx1 = true := rfl

theorem r2_ex1_sound :
    SourceCertificateSoundness ipEx1 baseEx1 0 3 (.localPacket pktEx1) srcCertEx1 :=
  source_cert_0x00_checker_sound r2_ex1_base_ok r2_ex1_source_cert_ok

/-! ## Ex-R2-5: Combined `Ωλ-R1 + Ωλ-R2 + Ωλ-M1` Bridge on `snapHyper` (`"rec.hyper.shared"`) -/

def srcCertHyperR2 : SourceCertTerm :=
  { closureTag := 2
    carrierTag := 3
    modeTag := 2
    evasionModeTag := 0
    claimedL := 1
    claimedU := 1
    unbreakableRefKind := 0
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses :=
      [ { refKind := 2
          jIdx := 0
          walkVertices := [0, 1, 3]
          stepWitnesses :=
            [ { stepTag := 1, irIdx := 0 },
              { stepTag := 2, irIdx := 1 } ] } ]
    retractionIrIndices := [0]
    dualCutVids := [] }

theorem r2_ex5_hyper_src_cert_ok :
    checkSourceCert0x00 R1Examples.ipHyper R1Examples.baseHyper 0 3 .globalGraph srcCertHyperR2 = true := rfl

theorem r2_ex5_full_r1_r2_string_resilience_sound :
    srcCertHyperR2.evasionModeTag = 0 ∧
    TagContextMatch srcCertHyperR2 .ePlus .globalGraph ∧
    ((srcCertHyperR2.modeTag = 1 ∧ srcCertHyperR2.claimedL = 0 ∧ srcCertHyperR2.claimedU = 0 ∧
      SourceStringSemanticResilience R1Examples.pinnedRegR1 R1Examples.snapHyper .ePlus 0 3
        .globalGraph .unbreakable) ∨
     (srcCertHyperR2.modeTag = 2 ∧ 1 ≤ srcCertHyperR2.claimedL ∧
      srcCertHyperR2.claimedL ≤ srcCertHyperR2.claimedU ∧
      SourceStringSemanticResilience R1Examples.pinnedRegR1 R1Examples.snapHyper .ePlus 0 3
        .globalGraph (.finiteBounds 1 1))) :=
  cert4_with_r1_source_string_sound
    R1Examples.pinnedRegR1 R1Examples.snapHyper R1Examples.entHyper
    R1Examples.ipHyper R1Examples.baseHyper 0 3 .globalGraph srcCertHyperR2
    R1Examples.r1_ex1_anchor_ok R1Examples.r1_ex1_lookup_ok rfl rfl
    R1Examples.r1_ex1_verified_base_ok r2_ex5_hyper_src_cert_ok

/-! ## Ex-R2-2: `LocalReflexive` on `#41` `f82Packet = [[0], [0, 1, 0]]` (`F82-01` Guard) -/

def ipF82 : IssuerPartition :=
  { constIssuers := []
    remIssuers := [10, 11] }

def baseF82 : BaseData :=
  { G := f82Graph
    kappa := .eStar
    rankEntries := [(0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0)]
    maxHopEntries := [(0, 0, []), (0, 1, [1]), (1, 0, [0]), (1, 1, [])] }

def srcCertF82Unb : SourceCertTerm :=
  { closureTag := 1
    carrierTag := 1
    modeTag := 1
    evasionModeTag := 0
    claimedL := 0
    claimedU := 0
    unbreakableRefKind := 1
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses := []
    retractionIrIndices := []
    dualCutVids := [] }

theorem r2_ex2_f82_base_ok : checkVerifiedBase ipF82 baseF82 = true := rfl

theorem r2_ex2_f82_reflexive_unbreakable_ok :
    checkSourceCert0x00 ipF82 baseF82 0 0 (.localPacket f82Packet) srcCertF82Unb = true ∧
    liftSourceCert0x00 baseF82 0 0 (.localPacket f82Packet) srcCertF82Unb =
      some (.localReflexive (.unbreakableWalk [])) :=
  ⟨rfl, rfl⟩

theorem r2_ex2_f82_finite_cut_impossible :
    checkSourceCert0x00 ipF82 baseF82 0 0 (.localPacket f82Packet)
      { srcCertF82Unb with modeTag := 2, claimedL := 1, claimedU := 1 } = false := rfl

/-! ## Ex-R2-3: `GlobalPlus` Self-Cycle `s = t = 0` (`0 → 1 → 0`, `C_V = [1]`) -/

def baseF82Plus : BaseData :=
  { G := f82Graph
    kappa := .ePlus
    rankEntries := [(0, 0, 2), (0, 1, 1), (1, 0, 1), (1, 1, 2)]
    maxHopEntries := [(0, 0, [1]), (0, 1, [1]), (1, 0, [0]), (1, 1, [0])] }

def srcCertSelfCyclePlus : SourceCertTerm :=
  { closureTag := 2
    carrierTag := 3
    modeTag := 2
    evasionModeTag := 0
    claimedL := 1
    claimedU := 1
    unbreakableRefKind := 0
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses :=
      [ { refKind := 2
          jIdx := 0
          walkVertices := [0, 1, 0]
          stepWitnesses :=
            [ { stepTag := 1, irIdx := 10 },
              { stepTag := 1, irIdx := 11 } ] } ]
    retractionIrIndices := [11]
    dualCutVids := [1] }

theorem r2_ex3_self_cycle_base_ok : checkVerifiedBase ipF82 baseF82Plus = true := rfl

theorem r2_ex3_self_cycle_plus_cert_ok :
    checkSourceCert0x00 ipF82 baseF82Plus 0 0 .globalGraph srcCertSelfCyclePlus = true ∧
    liftGlobalPlusCut [1] = [.start, .act 1] :=
  ⟨rfl, rfl⟩

/-! ## Ex-R2-4: `Geodesic` `E_PLUS` Rank-1 Direct Edge `(0, 1)` Cut (`F89-03` Row 4) -/

def srcCertGeoRank1 : SourceCertTerm :=
  { closureTag := 2
    carrierTag := 2
    modeTag := 2
    evasionModeTag := 0
    claimedL := 1
    claimedU := 1
    unbreakableRefKind := 0
    unbreakableLocalIdx := 0
    unbreakableWalk := []
    primalWitnesses :=
      [ { refKind := 2
          jIdx := 0
          walkVertices := [0, 1]
          stepWitnesses := [ { stepTag := 1, irIdx := 10 } ] } ]
    retractionIrIndices := [10]
    dualCutVids := [] }

theorem r2_ex4_geodesic_eplus_rank1_cert_ok :
    checkSourceCert0x00 ipF82 baseF82Plus 0 1 .geodesicBundle srcCertGeoRank1 = true := rfl

/-! ## Adversarial Rejection Proofs (`F89-01`, `F89-02`, `F89-03` — `= false := rfl`) -/

/-- `F89-01`: Unregistered `modeTag = 0` and `modeTag = 3` are rejected. -/
theorem adv_r2_f89_01_unregistered_modes_rejected :
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1)
      { srcCertEx1 with modeTag := 0 } = false ∧
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1)
      { srcCertEx1 with modeTag := 3 } = false :=
  ⟨rfl, rfl⟩

/-- `F89-01`: `evasionModeTag = 1` (`0x01`, `HELD` Evasion Table) is rejected in `0x00` track. -/
theorem adv_r2_f89_01_evasion_0x01_held_rejected :
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1)
      { srcCertEx1 with evasionModeTag := 1 } = false := rfl

/-- `F89-01`: Unregistered `closureTag = 9` and `carrierTag = 0` are rejected. -/
theorem adv_r2_f89_01_bad_closure_and_carrier_tags_rejected :
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1)
      { srcCertEx1 with closureTag := 9 } = false ∧
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1)
      { srcCertEx1 with carrierTag := 0 } = false :=
  ⟨rfl, rfl⟩

/-- `F89-02`: Non-minimal immutable issuer (`irIdx = 1` instead of `min [1, 0] = 0`) is rejected! -/
def srcCertBadMinConst : SourceCertTerm :=
  { srcCertEx1 with
    primalWitnesses :=
      [ { refKind := 1
          jIdx := 0
          walkVertices := []
          stepWitnesses :=
            [ { stepTag := 2, irIdx := 1 },  -- FORGED non-minimal const index!
              { stepTag := 1, irIdx := 2 },
              { stepTag := 2, irIdx := 0 } ] },
        { refKind := 1
          jIdx := 1
          walkVertices := []
          stepWitnesses :=
            [ { stepTag := 1, irIdx := 3 } ] } ] }

theorem adv_r2_f89_02_non_minimal_const_rejected :
    checkSourceCert0x00 ipEx1 baseEx1 0 3 (.localPacket pktEx1) srcCertBadMinConst = false := rfl

/-- `F89-03`: Unclosed `GlobalPlus` dual cut (`dualCutVids = []` when `0 → 1` survives `[11]`)
    is rejected! -/
theorem adv_r2_f89_03_unclosed_dual_cut_rejected :
    checkSourceCert0x00 ipF82 baseF82Plus 0 0 .globalGraph
      { srcCertSelfCyclePlus with dualCutVids := [] } = false := rfl

end OmegaLambda.R2Examples

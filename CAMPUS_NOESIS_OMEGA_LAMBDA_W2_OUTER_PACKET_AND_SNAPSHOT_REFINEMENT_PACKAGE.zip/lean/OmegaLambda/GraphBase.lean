/-
  CAMPUS-NOESIS Omega-Lambda M1: Minimal Lean 4 Mathematical Proof Kernel
  Module 2: `OmegaLambda.GraphBase`

  Directed issuer-labeled graphs, `E_STAR` / `E_PLUS` walk closures, walk survival,
  and executable Verified Base (`B1`..`B6`) shortest-walk rank (`B5`) and maximal
  geodesic first-hop bundle (`B6`) equations with machine-checked soundness and
  completeness theorems.
-/

import OmegaLambda.PointedLTS

namespace OmegaLambda

abbrev VertexId := Nat

inductive ClosureKind where
  | eStar : ClosureKind
  | ePlus : ClosureKind
  deriving DecidableEq, Repr

structure GraphEdge where
  src : VertexId
  dst : VertexId
  support : List IssuerId
  deriving DecidableEq, Repr

structure LabeledGraph where
  numVertices : Nat
  edges : List GraphEdge
  deriving DecidableEq, Repr

/-! ## Range Helper (`0 .. n-1`) -/

def rangeBelow : Nat → List Nat
  | 0 => []
  | n + 1 => rangeBelow n ++ [n]

theorem mem_rangeBelow_iff (x n : Nat) : x ∈ rangeBelow n ↔ x < n := by
  induction n with
  | zero =>
    simp [rangeBelow]
  | succ m ih =>
    simp only [rangeBelow, List.mem_append, ih]
    constructor
    · intro h
      cases h with
      | inl hlt => exact Nat.lt_succ_of_lt hlt
      | inr hmem =>
        cases hmem with
        | head => omega
        | tail _ hm => cases hm
    · intro hlt
      by_cases heq : x = m
      · subst heq
        exact Or.inr (List.Mem.head [])
      · exact Or.inl (by omega)

/-! ## Graph Well-Formedness & Canonical Edge Support Lookup -/

def GraphWF (ip : IssuerPartition) (G : LabeledGraph) : Prop :=
  NodupList (G.edges.map (fun e => (e.src, e.dst))) ∧
  ∀ e ∈ G.edges,
    e.src < G.numVertices ∧
    e.dst < G.numVertices ∧
    e.support ≠ [] ∧
    ∀ i ∈ e.support, i ∈ ip.constIssuers ∨ i ∈ ip.remIssuers

def checkGraphWF (ip : IssuerPartition) (G : LabeledGraph) : Bool :=
  nodupBool (G.edges.map (fun e => (e.src, e.dst))) &&
  listAllBool (fun e =>
    decide (e.src < G.numVertices) &&
    decide (e.dst < G.numVertices) &&
    decide (e.support ≠ []) &&
    listAllBool (fun i =>
      listMemBool i ip.constIssuers || listMemBool i ip.remIssuers) e.support) G.edges

theorem checkGraphWF_sound {ip : IssuerPartition} {G : LabeledGraph}
    (h : checkGraphWF ip G = true) : GraphWF ip G := by
  simp only [checkGraphWF, Bool.and_eq_true, nodupBool_iff, listAllBool_iff,
    decide_eq_true_eq, Bool.or_eq_true, listMemBool_iff] at h
  refine ⟨h.1, ?_⟩
  intro e he
  rcases h.2 e he with ⟨⟨⟨hsrc, hdst⟩, hne⟩, hsupp⟩
  exact ⟨hsrc, hdst, hne, hsupp⟩

def findEdgeSupportAux (u v : VertexId) : List GraphEdge → Option (List IssuerId)
  | [] => none
  | e :: rest =>
      if e.src = u ∧ e.dst = v then some e.support else findEdgeSupportAux u v rest

def edgeSupport? (G : LabeledGraph) (u v : VertexId) : Option (List IssuerId) :=
  findEdgeSupportAux u v G.edges

theorem edge_unique_of_nodup_keys {edges : List GraphEdge}
    (hnd : NodupList (edges.map (fun e => (e.src, e.dst))))
    {e1 e2 : GraphEdge} (h1 : e1 ∈ edges) (h2 : e2 ∈ edges)
    (hsrc : e1.src = e2.src) (hdst : e1.dst = e2.dst) : e1 = e2 := by
  induction edges with
  | nil => cases h1
  | cons hd tl ih =>
    cases hnd with
    | cons hnotmem hndTl =>
      cases h1 with
      | head =>
        cases h2 with
        | head => rfl
        | tail _ hm2 =>
          exfalso
          apply hnotmem
          dsimp
          rw [hsrc, hdst]
          exact List.mem_map_of_mem (f := fun e => (e.src, e.dst)) hm2
      | tail _ hm1 =>
        cases h2 with
        | head =>
          exfalso
          apply hnotmem
          dsimp
          rw [← hsrc, ← hdst]
          exact List.mem_map_of_mem (f := fun e => (e.src, e.dst)) hm1
        | tail _ hm2 =>
          exact ih hndTl hm1 hm2

theorem findEdgeSupportAux_eq_some_iff {edges : List GraphEdge}
    (hnd : NodupList (edges.map (fun e => (e.src, e.dst))))
    (u v : VertexId) (supp : List IssuerId) :
    findEdgeSupportAux u v edges = some supp ↔
    ({ src := u, dst := v, support := supp } : GraphEdge) ∈ edges := by
  induction edges with
  | nil =>
    simp [findEdgeSupportAux]
  | cons e rest ih =>
    cases hnd with
    | cons hnotmem hndRest =>
      simp only [findEdgeSupportAux]
      split
      · next heq =>
        rcases heq with ⟨hu, hv⟩
        constructor
        · intro hsome
          injection hsome with hsupp
          cases e
          simp only at hu hv hsupp
          subst hu; subst hv; subst hsupp
          exact List.Mem.head rest
        · intro hmem
          cases hmem with
          | head => rfl
          | tail _ hm =>
            exfalso
            apply hnotmem
            dsimp
            have hmap := List.mem_map_of_mem (f := fun x => (x.src, x.dst)) hm
            dsimp at hmap
            rw [hu, hv]
            exact hmap
      · next hne =>
        rw [ih hndRest]
        constructor
        · intro hm
          exact List.Mem.tail e hm
        · intro hm
          cases hm with
          | head =>
            exfalso
            exact hne ⟨rfl, rfl⟩
          | tail _ hmr => exact hmr

theorem edgeSupport?_eq_some_iff {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (u v : VertexId) (supp : List IssuerId) :
    edgeSupport? G u v = some supp ↔
    ({ src := u, dst := v, support := supp } : GraphEdge) ∈ G.edges :=
  findEdgeSupportAux_eq_some_iff hwf.1 u v supp

theorem edge_mem_gives_edgeSupport? {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) {e : GraphEdge} (he : e ∈ G.edges) :
    edgeSupport? G e.src e.dst = some e.support := by
  cases e with
  | mk u v supp =>
    exact (edgeSupport?_eq_some_iff hwf u v supp).mpr he

theorem edgeSupport?_none_iff_no_edge {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (u v : VertexId) :
    edgeSupport? G u v = none ↔ ∀ e ∈ G.edges, ¬ (e.src = u ∧ e.dst = v) := by
  constructor
  · intro hnone e he ⟨hu, hv⟩
    have hsome := edge_mem_gives_edgeSupport? hwf he
    rw [hu, hv, hnone] at hsome
    contradiction
  · intro hno
    cases hs : edgeSupport? G u v with
    | none => rfl
    | some supp =>
      exfalso
      have he := (edgeSupport?_eq_some_iff hwf u v supp).mp hs
      exact hno { src := u, dst := v, support := supp } he ⟨rfl, rfl⟩

/-! ## Graph Walks (`E_STAR` & `E_PLUS`) and Survival -/

inductive IsEdgeChain (G : LabeledGraph) : VertexId → VertexId → List VertexId → Prop where
  | nil (u : VertexId) : IsEdgeChain G u u []
  | cons {u w t : VertexId} (e : GraphEdge) (rest : List VertexId) :
      e ∈ G.edges →
      e.src = u →
      e.dst = w →
      IsEdgeChain G w t rest →
      IsEdgeChain G u t (w :: rest)

def walkSteps : List VertexId → Nat
  | [] => 0
  | _ :: tail => tail.length

def IsValidWalk (G : LabeledGraph) (κ : ClosureKind) (s t : VertexId) : List VertexId → Prop
  | [] => False
  | v0 :: tail =>
      v0 = s ∧
      s < G.numVertices ∧
      t < G.numVertices ∧
      IsEdgeChain G s t tail ∧
      (κ = .ePlus → tail ≠ [])

def checkEdgeChain (G : LabeledGraph) : VertexId → VertexId → List VertexId → Bool
  | u, t, [] => decide (u = t)
  | u, t, w :: rest =>
      (edgeSupport? G u w).isSome && checkEdgeChain G w t rest

theorem checkEdgeChain_iff {ip : IssuerPartition} {G : LabeledGraph} (hwf : GraphWF ip G)
    (u t : VertexId) (tail : List VertexId) :
    checkEdgeChain G u t tail = true ↔ IsEdgeChain G u t tail := by
  induction tail generalizing u with
  | nil =>
    simp only [checkEdgeChain, decide_eq_true_eq]
    constructor
    · intro h; subst h; exact IsEdgeChain.nil u
    · intro hc; cases hc; rfl
  | cons w rest ih =>
    simp only [checkEdgeChain, Bool.and_eq_true, ih]
    constructor
    · intro ⟨hsome, hrest⟩
      cases hs : edgeSupport? G u w with
      | none => rw [hs] at hsome; contradiction
      | some supp =>
        have he := (edgeSupport?_eq_some_iff hwf u w supp).mp hs
        exact IsEdgeChain.cons { src := u, dst := w, support := supp } rest he rfl rfl hrest
    · intro hc
      cases hc with
      | cons e _ he hsrc hdst hrest =>
        subst hsrc; subst hdst
        have hs := edge_mem_gives_edgeSupport? hwf he
        rw [hs]
        exact ⟨rfl, hrest⟩

def checkValidWalk (G : LabeledGraph) (κ : ClosureKind) (s t : VertexId) : List VertexId → Bool
  | [] => false
  | v0 :: tail =>
      decide (v0 = s) &&
      decide (s < G.numVertices) &&
      decide (t < G.numVertices) &&
      checkEdgeChain G s t tail &&
      (match κ with
       | .eStar => true
       | .ePlus => decide (tail ≠ []))

theorem checkValidWalk_iff {ip : IssuerPartition} {G : LabeledGraph} (hwf : GraphWF ip G)
    (κ : ClosureKind) (s t : VertexId) (γ : List VertexId) :
    checkValidWalk G κ s t γ = true ↔ IsValidWalk G κ s t γ := by
  cases γ with
  | nil =>
    simp [checkValidWalk, IsValidWalk]
  | cons v0 tail =>
    cases κ <;>
    simp [checkValidWalk, IsValidWalk, Bool.and_eq_true, decide_eq_true_eq,
      checkEdgeChain_iff hwf, and_assoc]

def ChainSurvives (G : LabeledGraph) (D : List IssuerId) : VertexId → List VertexId → Prop
  | _, [] => True
  | u, w :: rest =>
      (∃ e ∈ G.edges, e.src = u ∧ e.dst = w ∧ ¬ (∀ i ∈ e.support, i ∈ D)) ∧
      ChainSurvives G D w rest

def WalkSurvivesGraph (G : LabeledGraph) (D : List IssuerId) : List VertexId → Prop
  | [] => False
  | v0 :: tail => ChainSurvives G D v0 tail

def IsTrueShortestWalk (G : LabeledGraph) (κ : ClosureKind) (s t : VertexId) (γ : List VertexId) : Prop :=
  IsValidWalk G κ s t γ ∧ ∀ γ', IsValidWalk G κ s t γ' → walkSteps γ ≤ walkSteps γ'

/-! ## Verified Base (`B5` Shortest Rank + `B6` Maximal Geodesic First-Hop Bundle) -/

structure BaseData where
  G : LabeledGraph
  kappa : ClosureKind
  rankEntries : List (VertexId × VertexId × Nat)
  maxHopEntries : List (VertexId × VertexId × List VertexId)
  deriving DecidableEq, Repr

def lookupPairNat (u v : VertexId) : List (VertexId × VertexId × Nat) → Option Nat
  | [] => none
  | (x, y, r) :: rest => if x = u ∧ y = v then some r else lookupPairNat u v rest

def rankOf (b : BaseData) (u v : VertexId) : Option Nat :=
  lookupPairNat u v b.rankEntries

def lookupPairList (u v : VertexId) : List (VertexId × VertexId × List VertexId) → List VertexId
  | [] => []
  | (x, y, ws) :: rest => if x = u ∧ y = v then ws else lookupPairList u v rest

def maxHopsOf (b : BaseData) (u v : VertexId) : List VertexId :=
  lookupPairList u v b.maxHopEntries

/-- Executable Bellman-Ford / shortest-walk optimality check (`B5`) at pair `(u, v)`. -/
def checkRankPair (b : BaseData) (u v : VertexId) : Bool :=
  let isReflStar := decide (b.kappa = .eStar ∧ u = v)
  let hasDirect := (edgeSupport? b.G u v).isSome
  match rankOf b u v with
  | some 0 => isReflStar
  | some 1 => (!isReflStar) && hasDirect
  | some (r' + 2) =>
      (!isReflStar) &&
      (!hasDirect) &&
      listAnyBool (fun e =>
        decide (e.src = u) && decide (rankOf b e.dst v = some (r' + 1))) b.G.edges &&
      listAllBool (fun e =>
        if e.src = u then
          match rankOf b e.dst v with
          | some rw => decide (r' + 2 ≤ rw + 1)
          | none => true
        else
          true) b.G.edges
  | none =>
      (!isReflStar) &&
      (!hasDirect) &&
      listAllBool (fun e =>
        if e.src = u then decide (rankOf b e.dst v = none) else true) b.G.edges

/-- Mathematical predicate for shortest geodesic first hop (`B6`). -/
def IsShortestFirstHop (b : BaseData) (u t w : VertexId) : Prop :=
  match rankOf b u t with
  | none => False
  | some 0 => False
  | some 1 => (∃ e ∈ b.G.edges, e.src = u ∧ e.dst = w) ∧ w = t
  | some (r' + 2) => (∃ e ∈ b.G.edges, e.src = u ∧ e.dst = w) ∧ rankOf b w t = some (r' + 1)

def checkShortestFirstHopBool (b : BaseData) (u t w : VertexId) : Bool :=
  match rankOf b u t with
  | none => false
  | some 0 => false
  | some 1 => (edgeSupport? b.G u w).isSome && decide (w = t)
  | some (r' + 2) => (edgeSupport? b.G u w).isSome && decide (rankOf b w t = some (r' + 1))

theorem checkShortestFirstHopBool_iff {ip : IssuerPartition} {b : BaseData}
    (hwf : GraphWF ip b.G) (u t w : VertexId) :
    checkShortestFirstHopBool b u t w = true ↔ IsShortestFirstHop b u t w := by
  have hedge : (edgeSupport? b.G u w).isSome = true ↔ ∃ e ∈ b.G.edges, e.src = u ∧ e.dst = w := by
    cases hs : edgeSupport? b.G u w with
    | none =>
      simp only [Option.isSome, Bool.false_eq_true, false_iff]
      intro ⟨e, he, hu, hw⟩
      exact (edgeSupport?_none_iff_no_edge hwf u w).mp hs e he ⟨hu, hw⟩
    | some supp =>
      simp only [Option.isSome, true_iff]
      exact ⟨{ src := u, dst := w, support := supp },
        (edgeSupport?_eq_some_iff hwf u w supp).mp hs, rfl, rfl⟩
  unfold checkShortestFirstHopBool IsShortestFirstHop
  cases rankOf b u t with
  | none => simp
  | some r =>
    cases r with
    | zero => simp
    | succ r1 =>
      cases r1 with
      | zero =>
        simp only [Bool.and_eq_true, decide_eq_true_eq, hedge]
      | succ r' =>
        simp only [Bool.and_eq_true, decide_eq_true_eq, hedge]

def checkMaxHopsPair (b : BaseData) (u t : VertexId) : Bool :=
  let hs := maxHopsOf b u t
  nodupBool hs &&
  listAllBool (fun w => decide (w < b.G.numVertices)) hs &&
  listAllBool (fun w =>
    decide (listMemBool w hs = checkShortestFirstHopBool b u t w))
    (rangeBelow b.G.numVertices)

def checkVerifiedBase (ip : IssuerPartition) (b : BaseData) : Bool :=
  let vs := rangeBelow b.G.numVertices
  checkIssuerPartition ip &&
  checkGraphWF ip b.G &&
  listAllBool (fun u =>
    listAllBool (fun v =>
      checkRankPair b u v && checkMaxHopsPair b u v) vs) vs

structure VerifiedBase (ip : IssuerPartition) (b : BaseData) : Prop where
  wfPart : WFPartition ip
  wfGraph : GraphWF ip b.G
  rankPairs : ∀ u v, u < b.G.numVertices → v < b.G.numVertices → checkRankPair b u v = true
  maxHopPairs : ∀ u v, u < b.G.numVertices → v < b.G.numVertices → checkMaxHopsPair b u v = true

theorem checkVerifiedBase_sound {ip : IssuerPartition} {b : BaseData}
    (h : checkVerifiedBase ip b = true) : VerifiedBase ip b := by
  simp only [checkVerifiedBase, Bool.and_eq_true, listAllBool_iff, mem_rangeBelow_iff] at h
  rcases h with ⟨⟨hpart, hgraph⟩, hpairs⟩
  refine ⟨checkIssuerPartition_sound hpart, checkGraphWF_sound hgraph, ?_, ?_⟩
  · intro u v hu hv
    exact (hpairs u hu v hv).1
  · intro u v hu hv
    exact (hpairs u hu v hv).2

/-! ## `B5` Soundness & Completeness Theorems -/

theorem edgeChain_last_lt {ip : IssuerPartition} {G : LabeledGraph} (hwf : GraphWF ip G)
    {u t : VertexId} {tail : List VertexId}
    (hu : u < G.numVertices) (hc : IsEdgeChain G u t tail) : t < G.numVertices := by
  induction hc with
  | nil _ => exact hu
  | cons e _ he _ hdst _ ih =>
    subst hdst
    exact ih (hwf.2 e he).2.1

/-- `B5` Lower Bound (Optimality): Any valid `κ`-walk from `u` to `v` of step length `k`
    implies `rankOf b u v = some r` with `r ≤ k`. -/
theorem b5_rank_lower_bound {ip : IssuerPartition} {b : BaseData} (hb : VerifiedBase ip b) :
    ∀ (k : Nat) {u v : VertexId} {γ : List VertexId},
      IsValidWalk b.G b.kappa u v γ →
      walkSteps γ = k →
      ∃ r, rankOf b u v = some r ∧ r ≤ k := by
  intro k
  induction k with
  | zero =>
    intro u v γ hvw hlen
    cases γ with
    | nil => cases hvw
    | cons v0 tail =>
      cases tail with
      | cons _ _ => simp [walkSteps] at hlen
      | nil =>
        rcases hvw with ⟨hv0, hu, hv, hchain, hplus⟩
        subst hv0
        cases hchain with
        | nil _ =>
          have hκ : b.kappa = .eStar := by
            cases hk : b.kappa with
            | eStar => rfl
            | ePlus => exfalso; exact hplus hk rfl
          have hrp := hb.rankPairs v v hu hu
          unfold checkRankPair at hrp
          cases hr : rankOf b v v with
          | none =>
            rw [hr] at hrp
            simp [hκ] at hrp
          | some r =>
            cases r with
            | zero => exact ⟨0, rfl, Nat.le_refl 0⟩
            | succ r1 =>
              cases r1 <;> (rw [hr] at hrp; simp [hκ] at hrp)
  | succ k1 ih =>
    cases k1 with
    | zero =>
      intro u v γ hvw hlen
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        cases tail with
        | nil => simp [walkSteps] at hlen
        | cons w rest =>
          cases rest with
          | cons _ _ => simp [walkSteps] at hlen
          | nil =>
            rcases hvw with ⟨hv0, hu, hv, hchain, _⟩
            subst hv0
            cases hchain with
            | cons e _ he hsrc hdst hc2 =>
              cases hc2 with
              | nil _ =>
                have hhas : (edgeSupport? b.G v0 v).isSome = true := by
                  have hs := edge_mem_gives_edgeSupport? hb.wfGraph he
                  rw [hsrc, hdst] at hs
                  rw [hs]; rfl
                have hrp := hb.rankPairs v0 v hu hv
                unfold checkRankPair at hrp
                cases hr : rankOf b v0 v with
                | none =>
                  rw [hr, hhas] at hrp
                  simp at hrp
                | some r =>
                  cases r with
                  | zero => exact ⟨0, rfl, Nat.zero_le 1⟩
                  | succ r1 =>
                    cases r1 with
                    | zero => exact ⟨1, rfl, Nat.le_refl 1⟩
                    | succ r' =>
                      rw [hr, hhas] at hrp
                      simp at hrp
    | succ k' =>
      intro u v γ hvw hlen
      cases γ with
      | nil => cases hvw
      | cons v0 tail =>
        cases tail with
        | nil => simp [walkSteps] at hlen
        | cons w rest =>
          cases rest with
          | nil => simp [walkSteps] at hlen
          | cons w2 rest2 =>
            rcases hvw with ⟨hv0, hu, hv, hchain, _⟩
            subst hv0
            cases hchain with
            | cons e _ he hsrc hdst hcrest =>
              have hw : w < b.G.numVertices := by
                rw [← hdst]
                exact (hb.wfGraph.2 e he).2.1
              have hvwSub : IsValidWalk b.G b.kappa w v (w :: w2 :: rest2) := by
                refine ⟨rfl, hw, hv, hcrest, ?_⟩
                intro _; simp
              have hlenSub : walkSteps (w :: w2 :: rest2) = k' + 1 := by
                simp only [walkSteps, List.length_cons] at hlen ⊢
                omega
              rcases ih hvwSub hlenSub with ⟨rw, hrw, hrwLe⟩
              have hrp := hb.rankPairs v0 v hu hv
              unfold checkRankPair at hrp
              cases hr : rankOf b v0 v with
              | none =>
                rw [hr] at hrp
                simp only [Bool.and_eq_true, listAllBool_iff] at hrp
                have hechk := hrp.2 e he
                rw [hsrc, hdst, hrw] at hechk
                simp at hechk
              | some r =>
                cases r with
                | zero => exact ⟨0, rfl, Nat.zero_le _⟩
                | succ r1 =>
                  cases r1 with
                  | zero => exact ⟨1, rfl, by omega⟩
                  | succ r' =>
                    rw [hr] at hrp
                    simp only [Bool.and_eq_true, listAllBool_iff] at hrp
                    have hechk := hrp.2 e he
                    rw [hsrc, hdst, hrw] at hechk
                    simp at hechk
                    exact ⟨r' + 2, rfl, by omega⟩

/-- `B5` Achievability (Upper Bound): If `rankOf b u v = some r` (`u, v < n`),
    there exists a valid `κ`-walk from `u` to `v` of exact step length `r`. -/
theorem b5_rank_achievable {ip : IssuerPartition} {b : BaseData} (hb : VerifiedBase ip b) :
    ∀ (r : Nat) {u v : VertexId},
      u < b.G.numVertices →
      v < b.G.numVertices →
      rankOf b u v = some r →
      ∃ γ, IsValidWalk b.G b.kappa u v γ ∧ walkSteps γ = r := by
  intro r
  induction r with
  | zero =>
    intro u v hu hv hr
    have hrp := hb.rankPairs u v hu hv
    unfold checkRankPair at hrp
    rw [hr] at hrp
    simp only [decide_eq_true_eq] at hrp
    rcases hrp with ⟨hκ, rfl⟩
    refine ⟨[u], ?_, rfl⟩
    refine ⟨rfl, hu, hu, IsEdgeChain.nil u, ?_⟩
    intro hp; rw [hκ] at hp; contradiction
  | succ r1 ih =>
    cases r1 with
    | zero =>
      intro u v hu hv hr
      have hrp := hb.rankPairs u v hu hv
      unfold checkRankPair at hrp
      rw [hr] at hrp
      simp only [Bool.and_eq_true] at hrp
      have hhas := hrp.2
      cases hs : edgeSupport? b.G u v with
      | none => rw [hs] at hhas; contradiction
      | some supp =>
        have he := (edgeSupport?_eq_some_iff hb.wfGraph u v supp).mp hs
        refine ⟨[u, v], ?_, rfl⟩
        exact ⟨rfl, hu, hv,
          IsEdgeChain.cons { src := u, dst := v, support := supp } [] he rfl rfl (IsEdgeChain.nil v),
          fun _ => by simp⟩
    | succ r' =>
      intro u v hu hv hr
      have hrp := hb.rankPairs u v hu hv
      unfold checkRankPair at hrp
      rw [hr] at hrp
      simp only [Bool.and_eq_true, listAnyBool_iff, decide_eq_true_eq] at hrp
      rcases hrp.1.2 with ⟨e, he, hsrc, hrw⟩
      have hw : e.dst < b.G.numVertices := (hb.wfGraph.2 e he).2.1
      rcases ih hw hv hrw with ⟨γw, hvw, hlenw⟩
      cases γw with
      | nil => cases hvw
      | cons w0 tailw =>
        rcases hvw with ⟨rfl, _, _, hchainw, _⟩
        refine ⟨u :: e.dst :: tailw, ?_, ?_⟩
        · refine ⟨rfl, hu, hv, IsEdgeChain.cons e tailw he hsrc rfl hchainw, ?_⟩
          intro _; simp
        · simp only [walkSteps, List.length_cons] at hlenw ⊢
          omega

/-- `B5` Exact Characterization of True Shortest Walks. -/
theorem b5_rank_iff_true_shortest {ip : IssuerPartition} {b : BaseData} (hb : VerifiedBase ip b)
    {u v : VertexId} {r : Nat} (hu : u < b.G.numVertices) (hv : v < b.G.numVertices)
    (hr : rankOf b u v = some r) (γ : List VertexId) :
    IsTrueShortestWalk b.G b.kappa u v γ ↔ (IsValidWalk b.G b.kappa u v γ ∧ walkSteps γ = r) := by
  constructor
  · intro ⟨hvw, hmin⟩
    rcases b5_rank_lower_bound hb (walkSteps γ) hvw rfl with ⟨r1, hr1, hr1Le⟩
    rw [hr] at hr1
    injection hr1 with heqr
    subst heqr
    rcases b5_rank_achievable hb r hu hv hr with ⟨γ0, hvw0, hlen0⟩
    have hle2 : walkSteps γ ≤ r := by
      rw [← hlen0]
      exact hmin γ0 hvw0
    exact ⟨hvw, Nat.le_antisymm hle2 hr1Le⟩
  · intro ⟨hvw, hlen⟩
    refine ⟨hvw, ?_⟩
    intro γ' hvw'
    rcases b5_rank_lower_bound hb (walkSteps γ') hvw' rfl with ⟨r1, hr1, hr1Le⟩
    rw [hr] at hr1
    injection hr1 with heqr
    subst heqr
    rw [hlen]
    exact hr1Le

/-- `B6` Soundness & Completeness of Maximal Geodesic First-Hop Bundle. -/
theorem b6_maxHops_iff {ip : IssuerPartition} {b : BaseData} (hb : VerifiedBase ip b)
    {u t : VertexId} (hu : u < b.G.numVertices) (ht : t < b.G.numVertices) (w : VertexId) :
    w ∈ maxHopsOf b u t ↔ IsShortestFirstHop b u t w := by
  have hmp := hb.maxHopPairs u t hu ht
  simp only [checkMaxHopsPair, Bool.and_eq_true, nodupBool_iff, listAllBool_iff,
    decide_eq_true_eq, mem_rangeBelow_iff] at hmp
  rcases hmp with ⟨⟨_, hwlt⟩, heq⟩
  constructor
  · intro hmem
    have hw : w < b.G.numVertices := hwlt w hmem
    have hbool : listMemBool w (maxHopsOf b u t) = true := (listMemBool_iff w _).mpr hmem
    have hchk := heq w hw
    rw [hbool] at hchk
    exact (checkShortestFirstHopBool_iff hb.wfGraph u t w).mp hchk.symm
  · intro hhop
    have hw : w < b.G.numVertices := by
      unfold IsShortestFirstHop at hhop
      cases hr : rankOf b u t with
      | none => rw [hr] at hhop; cases hhop
      | some r =>
        cases r with
        | zero => rw [hr] at hhop; cases hhop
        | succ r1 =>
          cases r1 with
          | zero =>
            rw [hr] at hhop
            rcases hhop with ⟨_, rfl⟩
            exact ht
          | succ r' =>
            rw [hr] at hhop
            rcases hhop with ⟨⟨e, he, _, rfl⟩, _⟩
            exact (hb.wfGraph.2 e he).2.1
    have hchk := heq w hw
    have hbool : checkShortestFirstHopBool b u t w = true :=
      (checkShortestFirstHopBool_iff hb.wfGraph u t w).mpr hhop
    rw [hbool] at hchk
    exact (listMemBool_iff w _).mp hchk

end OmegaLambda

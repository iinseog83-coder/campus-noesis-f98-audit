/-
  CAMPUS-NOESIS Omega-Lambda R2: Source-to-Abstract Certificate Refinement (`0x00` Packing Track)
  Module: `OmegaLambda.CertRefinement`

  Authorized Scope (89th Independent Tribunal Ruling):
    - Mandatory Guards (`F89-01` .. `F89-03`):
        * `F89-01`: Total raw integer tag gating (`modeTag`, `closureTag`, `carrierTag`,
          `evasionModeTag`, `stepTag`, `refKind`) and exact 3-way `ClaimMatch` equivalence
          (unregistered tags evaluate to `False`, never vacuously `True`).
        * `F89-02`: Explicit honesty proof that raw immutable-step projection loses the
          issuer index (`f89_02_raw_projection_not_injective`), paired with canonical
          minimum-const uniqueness (`i = min(Supp(e) ∩ I_const)`,
          `f89_02_canonical_immutable_step_spec`).
        * `F89-03`: Carrier-indexed dual-cut lifting (`LiftCut`) and machine-checked proofs
          across all 5 carriers (`LocalPositive` prefix `.mid(j, m)` states, `GlobalStar`,
          `GlobalPlus` including `s = t` self-cycles, `Geodesic` including `E_PLUS` rank-1
          direct-edge branch, and `LocalReflexive` finite-cut impossibility preserving
          `F82-01` Level-A-only discipline).
    - Proof Track `Cert-0` .. `Cert-4`:
        * `Cert-0`: Tag & claim correspondence (`cert0_claimMatch_iff`, `f89_01_*`).
        * `Cert-1`: Unbreakable witness refinement (`liftSourceCert0x00_complete_sound`).
        * `Cert-2`: Pairwise-disjoint 3-byte step-witness packing refinement
          (`cert2_liftPackingList_sound`).
        * `Cert-3`: Upper-bound cut lifting & residual closed-cut soundness
          (`cert3_local_positive_cut_sound`, `cert3_global_star_cut_sound`,
           `cert3_global_plus_cut_sound`, `cert3_geodesic_cut_sound`,
           `cert3_local_reflexive_no_finite_cut`).
        * `Cert-4`: Constructive lifting completeness (`liftSourceCert0x00_complete_sound`),
          abstract composition (`cert4_refinement_0x00_composition_sound`), and combined
          `Ωλ-R1 + Ωλ-R2 + Ωλ-M1` string-keyed source snapshot soundness
          (`cert4_with_r1_source_string_sound`).

  Discipline:
    - `sorryAx = 0`, user `axiom = 0`, `opaque = 0`
    - `Lean.ofReduceBool = 0`, `Lean.trustCompiler = 0` (`native_decide` prohibited)
-/

import OmegaLambda.SourceIRRefinement

namespace OmegaLambda

/-! ## Raw `CNP-v2` Source Certificate Witness Syntax (`evasionModeTag = 0x00` Track) -/

/-- Raw 3-byte `CNP-v2` step witness (`>BH`):
    `stepTag = 1` (`0x01` retractable issuer `irIdx`),
    `stepTag = 2` (`0x02` immutable step with canonical `irIdx = min(Supp(e) ∩ I_const)`),
    any other `stepTag` is unregistered and rejected (`F89-01`). -/
structure SourceStepWitness where
  stepTag : Nat
  irIdx : IssuerId
  deriving DecidableEq, Repr

/-- Raw lower-bound primal witness entry in `CNP-v2`:
    `refKind = 1` references `pkt[jIdx]` on `LocalPacket`;
    `refKind = 2` carries explicit `walkVertices` on `Geodesic` / `Global`. -/
structure SourcePrimalWitness where
  refKind : Nat
  jIdx : Nat
  walkVertices : List VertexId
  stepWitnesses : List SourceStepWitness
  deriving DecidableEq, Repr

/-- Expanded raw source resilience certificate term `T` (`88th Ruling §4` & `89th Ruling §3`). -/
structure SourceCertTerm where
  closureTag : Nat          -- 1 (`0x01` E_STAR), 2 (`0x02` E_PLUS)
  carrierTag : Nat          -- 1 (`0x01` Local), 2 (`0x02` Geodesic), 3 (`0x03` Global)
  modeTag : Nat             -- 1 (`0x01` UNBREAKABLE), 2 (`0x02` FINITE_BOUNDS)
  evasionModeTag : Nat      -- 0 (`0x00` Packing Regime); 1 (`0x01` HELD) & >=2 rejected
  claimedL : Nat
  claimedU : Nat
  unbreakableRefKind : Nat  -- 1 (local index), 2 (explicit walk)
  unbreakableLocalIdx : Nat
  unbreakableWalk : List VertexId
  primalWitnesses : List SourcePrimalWitness
  retractionIrIndices : List IssuerId
  dualCutVids : List VertexId
  deriving DecidableEq, Repr

/-! ## `Cert-0` & Guard `F89-01`: Total Tag Gating & Exact `ClaimMatch` -/

/-- Exact 3-branch `ClaimMatch` (`F89-01`):
    Unregistered `modeTag ∉ {1, 2}` evaluates strictly to `False`. -/
def ClaimMatch (T : SourceCertTerm) (claim : ResilienceClaim) : Prop :=
  if T.modeTag = 1 then
    claim = .unbreakable ∧ T.claimedL = 0 ∧ T.claimedU = 0
  else if T.modeTag = 2 then
    claim = .finiteBounds T.claimedL T.claimedU ∧ 1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU
  else
    False

def checkClaimMatchBool (T : SourceCertTerm) (claim : ResilienceClaim) : Bool :=
  if T.modeTag = 1 then
    decide (claim = .unbreakable) && decide (T.claimedL = 0) && decide (T.claimedU = 0)
  else if T.modeTag = 2 then
    decide (claim = .finiteBounds T.claimedL T.claimedU) &&
    decide (1 ≤ T.claimedL) && decide (T.claimedL ≤ T.claimedU)
  else
    false

theorem cert0_claimMatch_iff (T : SourceCertTerm) (claim : ResilienceClaim) :
    checkClaimMatchBool T claim = true ↔ ClaimMatch T claim := by
  unfold checkClaimMatchBool ClaimMatch
  split
  · simp [Bool.and_eq_true, decide_eq_true_eq, and_assoc]
  · split
    · simp [Bool.and_eq_true, decide_eq_true_eq, and_assoc]
    · simp

/-- `F89-01` Guard Theorem 1: Any unregistered `modeTag ∉ {1, 2}` is unconditionally rejected. -/
theorem f89_01_unregistered_mode_rejected (T : SourceCertTerm) (claim : ResilienceClaim)
    (hne1 : T.modeTag ≠ 1) (hne2 : T.modeTag ≠ 2) :
    ¬ ClaimMatch T claim ∧ checkClaimMatchBool T claim = false := by
  unfold ClaimMatch checkClaimMatchBool
  simp [hne1, hne2]

/-- Total wire-tag context correspondence (`closureTag`, `carrierTag`, `evasionModeTag = 0x00`). -/
def TagContextMatch (T : SourceCertTerm) (κ : ClosureKind) (c : CarrierSpec) : Prop :=
  T.evasionModeTag = 0 ∧
  ((T.closureTag = 1 ∧ κ = .eStar) ∨ (T.closureTag = 2 ∧ κ = .ePlus)) ∧
  ((T.carrierTag = 1 ∧ ∃ pkt, c = .localPacket pkt) ∨
   (T.carrierTag = 2 ∧ c = .geodesicBundle) ∨
   (T.carrierTag = 3 ∧ c = .globalGraph))

def checkClosureTagMatchBool (closureTag : Nat) (κ : ClosureKind) : Bool :=
  match closureTag, κ with
  | 1, .eStar => true
  | 2, .ePlus => true
  | _, _ => false

def checkCarrierTagMatchBool (carrierTag : Nat) (c : CarrierSpec) : Bool :=
  match carrierTag, c with
  | 1, .localPacket _ => true
  | 2, .geodesicBundle => true
  | 3, .globalGraph => true
  | _, _ => false

def checkTagContextMatchBool (T : SourceCertTerm) (κ : ClosureKind) (c : CarrierSpec) : Bool :=
  decide (T.evasionModeTag = 0) &&
  checkClosureTagMatchBool T.closureTag κ &&
  checkCarrierTagMatchBool T.carrierTag c

theorem cert0_tagContextMatch_iff (T : SourceCertTerm) (κ : ClosureKind) (c : CarrierSpec) :
    checkTagContextMatchBool T κ c = true ↔ TagContextMatch T κ c := by
  unfold checkTagContextMatchBool TagContextMatch
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  refine ⟨?_, ?_⟩
  · intro ⟨⟨hev, hclo⟩, hcar⟩
    refine ⟨hev, ?_, ?_⟩
    · cases hcTag : T.closureTag with
      | zero => rw [hcTag] at hclo; cases κ <;> cases hclo
      | succ n =>
        cases n with
        | zero => rw [hcTag] at hclo; cases κ <;> simp [checkClosureTagMatchBool] at hclo ⊢
        | succ m =>
          cases m with
          | zero => rw [hcTag] at hclo; cases κ <;> simp [checkClosureTagMatchBool] at hclo ⊢
          | succ _ => rw [hcTag] at hclo; cases κ <;> cases hclo
    · cases hcarTag : T.carrierTag with
      | zero => rw [hcarTag] at hcar; cases c <;> cases hcar
      | succ n =>
        cases n with
        | zero =>
          rw [hcarTag] at hcar
          cases c with
          | localPacket pkt => exact Or.inl ⟨rfl, pkt, rfl⟩
          | geodesicBundle => cases hcar
          | globalGraph => cases hcar
        | succ m =>
          cases m with
          | zero =>
            rw [hcarTag] at hcar
            cases c <;> simp [checkCarrierTagMatchBool] at hcar ⊢
          | succ p =>
            cases p with
            | zero =>
              rw [hcarTag] at hcar
              cases c <;> simp [checkCarrierTagMatchBool] at hcar ⊢
            | succ _ => rw [hcarTag] at hcar; cases c <;> cases hcar
  · intro ⟨hev, hclo, hcar⟩
    refine ⟨⟨hev, ?_⟩, ?_⟩
    · rcases hclo with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> rw [h1, h2] <;> rfl
    · rcases hcar with ⟨h1, _, h2⟩ | ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> rw [h1, h2] <;> rfl

/-- `F89-01` Guard Theorem 2: Non-zero `evasionModeTag` (including `0x01` Held Evasion) or
    unregistered `closureTag` / `carrierTag` is rejected by `checkTagContextMatchBool`. -/
theorem f89_01_invalid_context_tags_rejected (T : SourceCertTerm) (κ : ClosureKind) (c : CarrierSpec)
    (hbad : T.evasionModeTag ≠ 0 ∨ (T.closureTag ≠ 1 ∧ T.closureTag ≠ 2) ∨
            (T.carrierTag ≠ 1 ∧ T.carrierTag ≠ 2 ∧ T.carrierTag ≠ 3)) :
    checkTagContextMatchBool T κ c = false := by
  cases hchk : checkTagContextMatchBool T κ c
  · rfl
  · exfalso
    rcases (cert0_tagContextMatch_iff T κ c).mp hchk with ⟨hev, hclo, hcar⟩
    rcases hbad with hbadEv | hbadClo | hbadCar
    · exact hbadEv hev
    · rcases hclo with ⟨h1, _⟩ | ⟨h2, _⟩
      · exact hbadClo.1 h1
      · exact hbadClo.2 h2
    · rcases hcar with ⟨h1, _⟩ | ⟨h2, _⟩ | ⟨h3, _⟩
      · exact hbadCar.1 h1
      · exact hbadCar.2.1 h2
      · exact hbadCar.2.2 h3

/-! ## Guard `F89-02`: 3-Byte StepWitness Projection Non-Injectivity & Canonical `minConst` -/

def minNatAux (acc : Nat) : List Nat → Nat
  | [] => acc
  | x :: xs => minNatAux (if x < acc then x else acc) xs

def minNatList : List Nat → Option Nat
  | [] => none
  | x :: xs => some (minNatAux x xs)

theorem minNatAux_mem_or_eq (acc : Nat) (xs : List Nat) :
    minNatAux acc xs = acc ∨ minNatAux acc xs ∈ xs := by
  induction xs generalizing acc with
  | nil => exact Or.inl rfl
  | cons x rest ih =>
    simp only [minNatAux]
    split
    · rcases ih x with heq | hmem
      · exact Or.inr (by rw [heq]; exact List.Mem.head rest)
      · exact Or.inr (List.Mem.tail x hmem)
    · rcases ih acc with heq | hmem
      · exact Or.inl heq
      · exact Or.inr (List.Mem.tail x hmem)

theorem minNatAux_le_all (acc : Nat) (xs : List Nat) :
    minNatAux acc xs ≤ acc ∧ ∀ y ∈ xs, minNatAux acc xs ≤ y := by
  induction xs generalizing acc with
  | nil =>
    refine ⟨Nat.le_refl acc, ?_⟩
    intro _ h; cases h
  | cons x rest ih =>
    simp only [minNatAux]
    split
    · next hlt =>
      rcases ih x with ⟨hleX, hleRest⟩
      refine ⟨by omega, ?_⟩
      intro y hy
      cases hy with
      | head => exact hleX
      | tail _ hm => exact hleRest y hm
    · next hge =>
      rcases ih acc with ⟨hleAcc, hleRest⟩
      refine ⟨hleAcc, ?_⟩
      intro y hy
      cases hy with
      | head => omega
      | tail _ hm => exact hleRest y hm

theorem minNatList_eq_some_iff (xs : List Nat) (m : Nat) :
    minNatList xs = some m ↔ m ∈ xs ∧ ∀ y ∈ xs, m ≤ y := by
  cases xs with
  | nil =>
    simp only [minNatList]
    constructor
    · intro h; cases h
    · intro ⟨hm, _⟩; cases hm
  | cons x rest =>
    simp only [minNatList, Option.some.injEq]
    constructor
    · intro heq
      subst heq
      have hmem : minNatAux x rest ∈ x :: rest := by
        rcases minNatAux_mem_or_eq x rest with h0 | h1
        · rw [h0]; exact List.Mem.head rest
        · exact List.Mem.tail x h1
      have hbounds := minNatAux_le_all x rest
      refine ⟨hmem, ?_⟩
      intro y hy
      cases hy with
      | head => exact hbounds.1
      | tail _ hm => exact hbounds.2 y hm
    · intro ⟨hmMem, hmLe⟩
      have hauxMem : minNatAux x rest ∈ x :: rest := by
        rcases minNatAux_mem_or_eq x rest with h0 | h1
        · rw [h0]; exact List.Mem.head rest
        · exact List.Mem.tail x h1
      have hbounds := minNatAux_le_all x rest
      have hle1 : minNatAux x rest ≤ m := by
        cases hmMem with
        | head => exact hbounds.1
        | tail _ hm => exact hbounds.2 m hm
      have hle2 : m ≤ minNatAux x rest := hmLe _ hauxMem
      exact Nat.le_antisymm hle1 hle2

def projectSourceStepWitness (sw : SourceStepWitness) : Option StepWitness :=
  if sw.stepTag = 1 then some (.retractableIssuer sw.irIdx)
  else if sw.stepTag = 2 then some .immutableStep
  else none

/-- **`F89-02` Honesty Theorem (Raw Non-Injectivity)**:
    Distinct raw immutable source step witnesses `{stepTag := 2, irIdx := 0}` and
    `{stepTag := 2, irIdx := 1}` map to the SAME abstract `.immutableStep`, proving
    that raw source-to-abstract step projection is NOT byte-injective. -/
theorem f89_02_raw_projection_not_injective :
    ∃ sw1 sw2 : SourceStepWitness,
      sw1 ≠ sw2 ∧
      projectSourceStepWitness sw1 = some .immutableStep ∧
      projectSourceStepWitness sw2 = some .immutableStep := by
  refine ⟨{ stepTag := 2, irIdx := 0 }, { stepTag := 2, irIdx := 1 }, ?_, rfl, rfl⟩
  intro heq
  injection heq with _ hidx
  cases hidx

def checkSourceStepWitness (ip : IssuerPartition) (supp : List IssuerId)
    (sw : SourceStepWitness) : Bool :=
  if sw.stepTag = 1 then
    disjointListsBool supp ip.constIssuers &&
    listMemBool sw.irIdx supp &&
    listMemBool sw.irIdx ip.remIssuers
  else if sw.stepTag = 2 then
    let constOnEdge := supp.filter (fun i => listMemBool i ip.constIssuers)
    listMemBool sw.irIdx supp &&
    listMemBool sw.irIdx ip.constIssuers &&
    decide (minNatList constOnEdge = some sw.irIdx)
  else
    false

/-- **`F89-02` Canonical Immutable Step Theorem**:
    Validating `{stepTag := 2, irIdx := i}` enforces:
      1. `i ∈ supp ∧ i ∈ ip.constIssuers`,
      2. `i` is the unique minimum of `supp ∩ ip.constIssuers`,
      3. `projectSourceStepWitness` yields `some .immutableStep`. -/
theorem f89_02_canonical_immutable_step_spec {ip : IssuerPartition} {supp : List IssuerId}
    {i : IssuerId}
    (hchk : checkSourceStepWitness ip supp { stepTag := 2, irIdx := i } = true) :
    i ∈ supp ∧
    i ∈ ip.constIssuers ∧
    (∀ c ∈ supp, c ∈ ip.constIssuers → i ≤ c) ∧
    projectSourceStepWitness { stepTag := 2, irIdx := i } = some .immutableStep ∧
    (∀ j : IssuerId,
      checkSourceStepWitness ip supp { stepTag := 2, irIdx := j } = true → i = j) := by
  change (listMemBool i supp && listMemBool i ip.constIssuers &&
    decide (minNatList (supp.filter (fun c => listMemBool c ip.constIssuers)) = some i)) = true at hchk
  simp only [Bool.and_eq_true, listMemBool_iff, decide_eq_true_eq] at hchk
  rcases hchk with ⟨⟨hiSupp, hiConst⟩, hminI⟩
  have hminSpec := (minNatList_eq_some_iff _ i).mp hminI
  refine ⟨hiSupp, hiConst, ?_, rfl, ?_⟩
  · intro c hcSupp hcConst
    apply hminSpec.2 c
    exact List.mem_filter.mpr ⟨hcSupp, (listMemBool_iff c ip.constIssuers).mpr hcConst⟩
  · intro j hj
    change (listMemBool j supp && listMemBool j ip.constIssuers &&
      decide (minNatList (supp.filter (fun c => listMemBool c ip.constIssuers)) = some j)) = true at hj
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hj
    rw [hminI] at hj
    injection hj.2

theorem checkSourceStepWitness_projects_sound {Q : Type} {ip : IssuerPartition}
    {tr : Trans Q} {sw : SourceStepWitness}
    (hchk : checkSourceStepWitness ip tr.support sw = true) :
    ∃ asw : StepWitness,
      projectSourceStepWitness sw = some asw ∧
      checkStepWitness ip tr asw = true ∧
      (extractRetractableIssuers [asw] =
        if sw.stepTag = 1 then [sw.irIdx] else []) := by
  unfold checkSourceStepWitness at hchk
  split at hchk
  · next h1 =>
    refine ⟨.retractableIssuer sw.irIdx, ?_, ?_, ?_⟩
    · simp [projectSourceStepWitness, h1]
    · simpa [checkStepWitness] using hchk
    · simp [extractRetractableIssuers, h1]
  · next hne1 =>
    split at hchk
    · next h2 =>
      simp only [Bool.and_eq_true, listMemBool_iff] at hchk
      rcases hchk with ⟨⟨hiSupp, hiConst⟩, _⟩
      refine ⟨.immutableStep, ?_, ?_, ?_⟩
      · simp [projectSourceStepWitness, h2]
      · simp only [checkStepWitness, listAnyBool_iff, listMemBool_iff]
        exact ⟨sw.irIdx, hiSupp, hiConst⟩
      · simp [extractRetractableIssuers, hne1]
    · cases hchk

/-! ## Universal Support-List Transfer Helpers for `Cert-1` & `Cert-2` -/

def chainEdgeSupports (G : LabeledGraph) : VertexId → List VertexId → List (List IssuerId)
  | _, [] => []
  | u, w :: rest => (edgeSupport? G u w).getD [] :: chainEdgeSupports G w rest

def walkEdgeSupports (G : LabeledGraph) : List VertexId → List (List IssuerId)
  | [] => []
  | v0 :: tail => chainEdgeSupports G v0 tail

theorem buildChainTrans_supports (G : LabeledGraph) (j : Nat) (γ : List VertexId) :
    (buildChainTrans G j γ).map Trans.support = walkEdgeSupports G γ := by
  cases γ with
  | nil => rfl
  | cons v0 tail =>
    simp only [buildChainTrans, walkEdgeSupports]
    suffices ∀ ell u (tl : List VertexId),
        (buildChainTransAux G j tail.length ell u tl).map Trans.support =
        chainEdgeSupports G u tl from this 0 v0 tail
    intro ell u tl
    induction tl generalizing ell u with
    | nil => rfl
    | cons w rest ih =>
      simp [buildChainTransAux, chainEdgeSupports, ih (ell + 1) w]

theorem starWalkToLTS_supports (G : LabeledGraph) (γ : List VertexId) :
    (starWalkToLTS G γ).map Trans.support = walkEdgeSupports G γ := by
  cases γ with
  | nil => rfl
  | cons v0 tail =>
    simp only [starWalkToLTS, walkEdgeSupports]
    induction tail generalizing v0 with
    | nil => rfl
    | cons w rest ih =>
      simp [chainToStarTrans, chainEdgeSupports, ih w]

theorem plusWalkToLTS_supports (G : LabeledGraph) {γ : List VertexId}
    (hpos : 1 ≤ walkSteps γ) :
    (plusWalkToLTS G γ).map Trans.support = walkEdgeSupports G γ := by
  cases γ with
  | nil => simp [walkSteps] at hpos
  | cons v0 tail =>
    cases tail with
    | nil => simp [walkSteps] at hpos
    | cons w1 rest =>
      simp only [plusWalkToLTS, walkEdgeSupports, chainEdgeSupports, List.map_cons]
      congr 1
      suffices ∀ u (tl : List VertexId),
          (chainToPlusActTrans G u tl).map Trans.support = chainEdgeSupports G u tl from
        this w1 rest
      intro u tl
      induction tl generalizing u with
      | nil => rfl
      | cons w2 rest2 ih =>
        simp [chainToPlusActTrans, chainEdgeSupports, ih w2]

theorem geoWalkToLTS_supports (b : BaseData) {γ : List VertexId}
    (hpos : 1 ≤ walkSteps γ) :
    (geoWalkToLTS b γ).map Trans.support = walkEdgeSupports b.G γ := by
  cases γ with
  | nil => simp [walkSteps] at hpos
  | cons v0 tail =>
    cases tail with
    | nil => simp [walkSteps] at hpos
    | cons w1 rest =>
      simp only [geoWalkToLTS, walkEdgeSupports, chainEdgeSupports, List.map_cons]
      congr 1
      suffices ∀ u (tl : List VertexId),
          (geoChainToActTrans b u tl).map Trans.support = chainEdgeSupports b.G u tl from
        this w1 rest
      intro u tl
      induction tl generalizing u with
      | nil => rfl
      | cons w2 rest2 ih =>
        simp [geoChainToActTrans, chainEdgeSupports, ih w2]

def checkWalkEdgesConstBool (ip : IssuerPartition) (G : LabeledGraph) (γ : List VertexId) : Bool :=
  listAllBool (fun supp => listAnyBool (fun c => listMemBool c ip.constIssuers) supp)
    (walkEdgeSupports G γ)

theorem supports_unbreakable_transfer {Q : Type} (ip : IssuerPartition)
    {τ : List (Trans Q)} {supps : List (List IssuerId)}
    (hmap : τ.map Trans.support = supps)
    (hconst : listAllBool (fun supp => listAnyBool (fun c => listMemBool c ip.constIssuers) supp) supps = true) :
    listAllBool (fun tr => listAnyBool (fun c => listMemBool c ip.constIssuers) tr.support) τ = true := by
  induction τ generalizing supps with
  | nil => rfl
  | cons tr rest ih =>
    cases supps with
    | nil => cases hmap
    | cons s0 srest =>
      simp only [List.map_cons, List.cons.injEq] at hmap
      simp only [listAllBool, Bool.and_eq_true] at hconst ⊢
      rw [hmap.1]
      exact ⟨hconst.1, ih hmap.2 hconst.2⟩

def extractSourceRetractable : List SourceStepWitness → List IssuerId
  | [] => []
  | sw :: rest =>
      if sw.stepTag = 1 then sw.irIdx :: extractSourceRetractable rest
      else extractSourceRetractable rest

def projectSourceStepList : List SourceStepWitness → Option (List StepWitness)
  | [] => some []
  | sw :: rest =>
      match projectSourceStepWitness sw, projectSourceStepList rest with
      | some asw, some arest => some (asw :: arest)
      | _, _ => none

def checkSourceStepList (ip : IssuerPartition) :
    List (List IssuerId) → List SourceStepWitness → Bool
  | [], [] => true
  | supp :: srest, sw :: wrest =>
      checkSourceStepWitness ip supp sw && checkSourceStepList ip srest wrest
  | _, _ => false

theorem supports_witnessed_steps_transfer {Q : Type} (ip : IssuerPartition)
    {τ : List (Trans Q)} {supps : List (List IssuerId)} {srcSteps : List SourceStepWitness}
    (hmap : τ.map Trans.support = supps)
    (hchk : checkSourceStepList ip supps srcSteps = true) :
    ∃ sws : List StepWitness,
      projectSourceStepList srcSteps = some sws ∧
      checkWitnessedSteps ip τ sws = true ∧
      extractRetractableIssuers sws = extractSourceRetractable srcSteps := by
  induction τ generalizing supps srcSteps with
  | nil =>
    cases supps with
    | nil =>
      cases srcSteps with
      | nil => exact ⟨[], rfl, rfl, rfl⟩
      | cons _ _ => simp [checkSourceStepList] at hchk
    | cons _ _ => cases hmap
  | cons tr rest ih =>
    cases supps with
    | nil => cases hmap
    | cons s0 srest =>
      cases srcSteps with
      | nil => simp [checkSourceStepList] at hchk
      | cons sw0 wrest =>
        simp only [List.map_cons, List.cons.injEq] at hmap
        simp only [checkSourceStepList, Bool.and_eq_true] at hchk
        rw [← hmap.1] at hchk
        rcases checkSourceStepWitness_projects_sound hchk.1 with ⟨asw0, hproj0, hstep0, hextr0⟩
        rcases ih hmap.2 hchk.2 with ⟨arest, hprojRest, hstepsRest, hextrRest⟩
        refine ⟨asw0 :: arest, ?_, ?_, ?_⟩
        · simp [projectSourceStepList, hproj0, hprojRest]
        · simp [checkWitnessedSteps, hstep0, hstepsRest]
        · cases asw0 with
          | immutableStep =>
            simp only [extractRetractableIssuers] at hextr0 ⊢
            simp only [extractSourceRetractable]
            split
            · next h1 => rw [if_pos h1] at hextr0; cases hextr0
            · exact hextrRest
          | retractableIssuer idx =>
            simp only [extractRetractableIssuers] at hextr0 ⊢
            simp only [extractSourceRetractable]
            split
            · next h1 =>
              rw [if_pos h1] at hextr0
              injection hextr0 with hidxEq
              rw [hidxEq, hextrRest]
            · next hne1 =>
              rw [if_neg hne1] at hextr0
              cases hextr0

/-! ## Executable Residual Edge & Walk Survival Helpers (`Cert-3` / `F89-03`) -/

def edgeSurvivesBool (G : LabeledGraph) (D : List IssuerId) (u w : VertexId) : Bool :=
  match edgeSupport? G u w with
  | none => false
  | some supp => listAnyBool (fun i => !(listMemBool i D)) supp

theorem transSurvivesBool_getD_eq_edgeSurvivesBool {Q : Type} (G : LabeledGraph)
    (D : List IssuerId) (u w : VertexId) (p q : Q) :
    transSurvivesBool ({ src := p, support := (edgeSupport? G u w).getD [], dst := q } : Trans Q) D =
    edgeSurvivesBool G D u w := by
  unfold edgeSurvivesBool transSurvivesBool
  cases edgeSupport? G u w <;> rfl

theorem transSurvivesBool_edge_eq_edgeSurvivesBool {Q : Type} {ip : IssuerPartition}
    {G : LabeledGraph} (hwf : GraphWF ip G) {e : GraphEdge} (he : e ∈ G.edges)
    (D : List IssuerId) (p q : Q) :
    transSurvivesBool ({ src := p, support := e.support, dst := q } : Trans Q) D =
    edgeSurvivesBool G D e.src e.dst := by
  have hs := edge_mem_gives_edgeSupport? hwf he
  unfold edgeSurvivesBool transSurvivesBool
  rw [hs]

def checkChainSurvivesBool (G : LabeledGraph) (D : List IssuerId) :
    VertexId → List VertexId → Bool
  | _, [] => true
  | u, w :: rest => edgeSurvivesBool G D u w && checkChainSurvivesBool G D w rest

def checkWalkSurvivesBool (G : LabeledGraph) (D : List IssuerId) : List VertexId → Bool
  | [] => false
  | v0 :: tail => checkChainSurvivesBool G D v0 tail

theorem edgeSurvivesBool_iff {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (D : List IssuerId) (u w : VertexId) :
    edgeSurvivesBool G D u w = true ↔
    ∃ e ∈ G.edges, e.src = u ∧ e.dst = w ∧ ¬ (∀ i ∈ e.support, i ∈ D) := by
  unfold edgeSurvivesBool
  cases hs : edgeSupport? G u w with
  | none =>
    simp only [Bool.false_eq_true, false_iff]
    intro ⟨e, he, hu, hw, _⟩
    exact (edgeSupport?_none_iff_no_edge hwf u w).mp hs e he ⟨hu, hw⟩
  | some supp =>
    dsimp only
    have heIn : ({ src := u, dst := w, support := supp } : GraphEdge) ∈ G.edges :=
      (edgeSupport?_eq_some_iff hwf u w supp).mp hs
    have htr : listAnyBool (fun i => !(listMemBool i D)) supp =
        transSurvivesBool ({ src := u, support := supp, dst := w } : Trans VertexId) D := rfl
    rw [htr, transSurvivesBool_iff]
    unfold TransSurvives
    dsimp
    constructor
    · intro hnotAll
      exact ⟨{ src := u, dst := w, support := supp }, heIn, rfl, rfl, hnotAll⟩
    · intro ⟨e', he', hu, hw, hnotAll⟩
      have heq := edge_unique_of_nodup_keys hwf.1 he' heIn hu hw
      subst heq
      exact hnotAll

theorem checkWalkSurvivesBool_iff {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (D : List IssuerId) (γ : List VertexId) :
    checkWalkSurvivesBool G D γ = true ↔ WalkSurvivesGraph G D γ := by
  cases γ with
  | nil => simp [checkWalkSurvivesBool, WalkSurvivesGraph]
  | cons v0 tail =>
    simp only [checkWalkSurvivesBool, WalkSurvivesGraph]
    induction tail generalizing v0 with
    | nil => simp [checkChainSurvivesBool, ChainSurvives]
    | cons w rest ih =>
      simp only [checkChainSurvivesBool, ChainSurvives, Bool.and_eq_true,
        edgeSurvivesBool_iff hwf, ih w]

/-! ## `Cert-3` & Guard `F89-03`: Carrier-Indexed Cut Lifting (`LiftCut`) Across All 5 Carriers -/

/-- **Carrier 1A (`LocalReflexive`, `F89-03` Row 5 & `F82-01` Guard)**:
    When `pkt` contains a 0-step walk `[s]`, NO deletion list `D` breaks all local paths
    and NO finite `cutStates : List Unit` satisfies `checkClosedCut mkLocalReflexiveLTS`. -/
theorem cert3_local_reflexive_no_finite_cut (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId) (s : VertexId) (hmem0 : [s] ∈ pkt) :
    listAllBool (fun γ => !(checkWalkSurvivesBool G D γ)) pkt = false ∧
    ∀ cutStates : List Unit, checkClosedCut mkLocalReflexiveLTS D cutStates = false := by
  refine ⟨?_, ?_⟩
  · cases hall : listAllBool (fun γ => !(checkWalkSurvivesBool G D γ)) pkt
    · rfl
    · exfalso
      have hs := (listAllBool_iff _ pkt).mp hall [s] hmem0
      simp [checkWalkSurvivesBool, checkChainSurvivesBool] at hs
  · intro cutStates
    cases hc : checkClosedCut mkLocalReflexiveLTS D cutStates
    · rfl
    · exfalso
      unfold checkClosedCut mkLocalReflexiveLTS at hc
      simp only [Bool.and_eq_true, Bool.not_eq_true'] at hc
      rw [hc.1.1.2] at hc
      cases hc.1.2

/-- Prefix survival up to step `m` along walk `γ` (`F89-03` Row 1: `LocalPositive`). -/
def edgeAtSurvivesBool (G : LabeledGraph) (D : List IssuerId) (γ : List VertexId) (k : Nat) : Bool :=
  match γ[k]?, γ[k + 1]? with
  | some x, some y => edgeSurvivesBool G D x y
  | _, _ => false

def allEdgesBeforeSurviveBool (G : LabeledGraph) (D : List IssuerId) (γ : List VertexId) :
    Nat → Bool
  | 0 => true
  | m + 1 => allEdgesBeforeSurviveBool G D γ m && edgeAtSurvivesBool G D γ m

theorem allEdgesBefore_iff_forall (G : LabeledGraph) (D : List IssuerId) (γ : List VertexId) (m : Nat) :
    allEdgesBeforeSurviveBool G D γ m = true ↔
    ∀ k < m, edgeAtSurvivesBool G D γ k = true := by
  induction m with
  | zero =>
    simp only [allEdgesBeforeSurviveBool, true_iff]
    intro k hk; omega
  | succ m' ih =>
    simp only [allEdgesBeforeSurviveBool, Bool.and_eq_true, ih]
    constructor
    · intro ⟨hprev, hm'⟩ k hk
      by_cases heq : k = m'
      · subst heq; exact hm'
      · exact hprev k (by omega)
    · intro hall
      exact ⟨fun k hk => hall k (by omega), hall m' (by omega)⟩

theorem checkChainSurvives_iff_forall_idx (G : LabeledGraph) (D : List IssuerId) :
    ∀ (u : VertexId) (tail : List VertexId),
      checkChainSurvivesBool G D u tail = true ↔
      ∀ k < tail.length, edgeAtSurvivesBool G D (u :: tail) k = true := by
  intro u tail
  induction tail generalizing u with
  | nil =>
    simp only [checkChainSurvivesBool, List.length_nil, true_iff]
    intro k hk; omega
  | cons w rest ih =>
    simp only [checkChainSurvivesBool, Bool.and_eq_true, ih w, List.length_cons]
    constructor
    · intro ⟨h0, hrest⟩ k hk
      cases k with
      | zero => simpa [edgeAtSurvivesBool] using h0
      | succ k' =>
        have hr := hrest k' (Nat.lt_of_succ_lt_succ hk)
        simpa [edgeAtSurvivesBool] using hr
    · intro hall
      refine ⟨?_, ?_⟩
      · have h0 := hall 0 (Nat.zero_lt_succ rest.length)
        simpa [edgeAtSurvivesBool] using h0
      · intro k' hk'
        have hs := hall (k' + 1) (Nat.succ_lt_succ hk')
        simpa [edgeAtSurvivesBool] using hs

theorem allEdgesBefore_full_eq_walkSurvives (G : LabeledGraph) (D : List IssuerId)
    (v0 : VertexId) (tail : List VertexId) :
    allEdgesBeforeSurviveBool G D (v0 :: tail) tail.length =
    checkChainSurvivesBool G D v0 tail := by
  cases hl : allEdgesBeforeSurviveBool G D (v0 :: tail) tail.length
  · cases hr : checkChainSurvivesBool G D v0 tail
    · rfl
    · exfalso
      have hall := (checkChainSurvives_iff_forall_idx G D v0 tail).mp hr
      have hlTrue := (allEdgesBefore_iff_forall G D (v0 :: tail) tail.length).mpr hall
      rw [hl] at hlTrue
      cases hlTrue
  · symm
    apply (checkChainSurvives_iff_forall_idx G D v0 tail).mpr
    exact (allEdgesBefore_iff_forall G D (v0 :: tail) tail.length).mp hl

def chainMidCutStates (G : LabeledGraph) (D : List IssuerId) (j : Nat)
    (γ : List VertexId) : List LocalState :=
  let totalSteps := walkSteps γ
  ((rangeBelow totalSteps).filter (fun m =>
    decide (1 ≤ m) && allEdgesBeforeSurviveBool G D γ m)).map (fun m => LocalState.mid j m)

/-- Constructive `LiftCut` for `LocalPositive` (`F89-03` Row 1):
    `.init` plus all internal `.mid j m` states (`1 ≤ m < walkSteps γ_j`) whose
    `m`-edge prefix along `γ_j` survives `D`. -/
def liftLocalPositiveCut (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId) : List LocalState :=
  LocalState.init ::
  (rangeBelow pkt.length).flatMap (fun j =>
    match pkt[j]? with
    | none => []
    | some γ => chainMidCutStates G D j γ)

def checkSourceLocalCut (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId) : Bool :=
  listAllBool (fun γ => !(checkWalkSurvivesBool G D γ)) pkt

theorem mem_chainMidCutStates_iff (G : LabeledGraph) (D : List IssuerId)
    (j : Nat) (γ : List VertexId) (q : LocalState) :
    q ∈ chainMidCutStates G D j γ ↔
    ∃ m, q = LocalState.mid j m ∧ 1 ≤ m ∧ m < walkSteps γ ∧
         allEdgesBeforeSurviveBool G D γ m = true := by
  simp only [chainMidCutStates, List.mem_map, List.mem_filter, mem_rangeBelow_iff,
    Bool.and_eq_true, decide_eq_true_eq]
  constructor
  · intro ⟨m, ⟨hmLt, hmGe1, hsurv⟩, hq⟩
    exact ⟨m, hq.symm, hmGe1, hmLt, hsurv⟩
  · intro ⟨m, hq, hmGe1, hmLt, hsurv⟩
    exact ⟨m, ⟨hmLt, hmGe1, hsurv⟩, hq.symm⟩

/-- Exact Prefix Correspondence for `liftLocalPositiveCut` (`F89-03` Row 1a). -/
theorem mem_liftLocalPositiveCut_mid_iff (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId) (j m : Nat) :
    LocalState.mid j m ∈ liftLocalPositiveCut G pkt D ↔
    ∃ γ, pkt[j]? = some γ ∧ 1 ≤ m ∧ m < walkSteps γ ∧
         allEdgesBeforeSurviveBool G D γ m = true := by
  simp only [liftLocalPositiveCut, List.mem_cons, reduceCtorEq, false_or,
    List.mem_flatMap, mem_rangeBelow_iff]
  constructor
  · intro ⟨j', _, hmemInner⟩
    cases hget : pkt[j']? with
    | none => rw [hget] at hmemInner; cases hmemInner
    | some γ =>
      rw [hget] at hmemInner
      rcases (mem_chainMidCutStates_iff G D j' γ (LocalState.mid j m)).mp hmemInner with
        ⟨m', heqMid, hmGe1, hmLt, hsurv⟩
      injection heqMid with hjEq hmEq
      subst hjEq; subst hmEq
      exact ⟨γ, hget, hmGe1, hmLt, hsurv⟩
  · intro ⟨γ, hget, hmGe1, hmLt, hsurv⟩
    have hjLt : j < pkt.length := by
      by_cases hlt : j < pkt.length
      · exact hlt
      · exfalso
        have hnone : pkt[j]? = none := List.getElem?_eq_none (by omega)
        rw [hnone] at hget
        cases hget
    refine ⟨j, hjLt, ?_⟩
    rw [hget]
    exact (mem_chainMidCutStates_iff G D j γ (LocalState.mid j m)).mpr
      ⟨m, rfl, hmGe1, hmLt, hsurv⟩

theorem nodup_liftLocalPositiveCut (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId) :
    NodupList (liftLocalPositiveCut G pkt D) := by
  unfold liftLocalPositiveCut
  refine NodupList.cons ?_ ?_
  · intro hinitMem
    rcases List.mem_flatMap.mp hinitMem with ⟨j, _, hm⟩
    cases hget : pkt[j]? with
    | none => rw [hget] at hm; cases hm
    | some γ =>
      rw [hget] at hm
      rcases (mem_chainMidCutStates_iff G D j γ LocalState.init).mp hm with ⟨_, hq, _⟩
      cases hq
  · apply nodup_flatMap_pairs (nodup_rangeBelow pkt.length)
    · intro j _
      cases pkt[j]? with
      | none => exact NodupList.nil
      | some γ =>
        apply nodup_map_of_inj_on (fun m => LocalState.mid j m)
          (nodup_filter _ (nodup_rangeBelow (walkSteps γ)))
        intro a b _ _ heq
        injection heq
    · intro j1 j2 q _ _ h1 h2
      cases hg1 : pkt[j1]? with
      | none => rw [hg1] at h1; cases h1
      | some γ1 =>
        rw [hg1] at h1
        cases hg2 : pkt[j2]? with
        | none => rw [hg2] at h2; cases h2
        | some γ2 =>
          rw [hg2] at h2
          rcases (mem_chainMidCutStates_iff G D j1 γ1 q).mp h1 with ⟨_, hq1, _⟩
          rcases (mem_chainMidCutStates_iff G D j2 γ2 q).mp h2 with ⟨_, hq2, _⟩
          rw [hq1] at hq2
          injection hq2

/-- **`Cert-3` Row 1 (`LocalPositive` Closed-Cut Theorem, `F89-03`)**:
    Whenever `D` breaks every walk in a positive packet `pkt` (`checkSourceLocalCut G pkt D = true`),
    `liftLocalPositiveCut G pkt D` is a valid residual closed cut in `mkLocalPositiveLTS G pkt`. -/
theorem cert3_local_positive_cut_sound (G : LabeledGraph) (pkt : List (List VertexId))
    (D : List IssuerId)
    (hpos : ∀ γ ∈ pkt, 1 ≤ walkSteps γ)
    (hcut : checkSourceLocalCut G pkt D = true) :
    checkClosedCut (mkLocalPositiveLTS G pkt) D (liftLocalPositiveCut G pkt D) = true := by
  unfold checkClosedCut
  simp only [Bool.and_eq_true, nodupBool_iff, listMemBool_iff, Bool.not_eq_true',
    listMemBool_false_iff, listAllBool_iff]
  refine ⟨⟨⟨nodup_liftLocalPositiveCut G pkt D, List.Mem.head _⟩, ?_⟩, ?_⟩
  · intro hfin
    cases hfin with
    | tail _ hm =>
      rcases List.mem_flatMap.mp hm with ⟨j, _, hjMem⟩
      cases hg : pkt[j]? with
      | none => rw [hg] at hjMem; cases hjMem
      | some γ =>
        rw [hg] at hjMem
        rcases (mem_chainMidCutStates_iff G D j γ LocalState.final).mp hjMem with ⟨_, hq, _⟩
        cases hq
  · intro tr htrMem
    cases hcond : (transSurvivesBool tr D && listMemBool tr.src (liftLocalPositiveCut G pkt D))
    · simp
    · simp only [Bool.not_true, Bool.false_or, listMemBool_iff]
      simp only [Bool.and_eq_true, listMemBool_iff] at hcond
      rcases hcond with ⟨htrSurv, hsrcCut⟩
      rcases mem_buildAllChainsAux_iff.mp htrMem with ⟨j, _, γ, hget, htrChain⟩
      simp only [Nat.zero_add] at htrChain
      have hγMem : γ ∈ pkt := List.mem_of_getElem? hget
      have hγPos : 1 ≤ walkSteps γ := hpos γ hγMem
      have hγBroken : checkWalkSurvivesBool G D γ = false := by
        have hall := (listAllBool_iff _ pkt).mp hcut γ hγMem
        simpa using hall
      cases γ with
      | nil => simp [walkSteps] at hγPos
      | cons v0 tail =>
        rcases mem_buildChainTransAux_iff.mp htrChain with ⟨k, x, y, hkLt, hx, hy, rfl⟩
        simp only [Nat.zero_add] at hsrcCut ⊢
        have hedgSurv : edgeAtSurvivesBool G D (v0 :: tail) k = true := by
          unfold edgeAtSurvivesBool
          have hy' : (v0 :: tail)[k + 1]? = some y := hy
          rw [hx, hy']
          dsimp only
          rw [← transSurvivesBool_getD_eq_edgeSurvivesBool G D x y
            (locStateAt j tail.length k) (locStateAt j tail.length (k + 1))]
          exact htrSurv
        have hprevSurv : allEdgesBeforeSurviveBool G D (v0 :: tail) k = true := by
          cases k with
          | zero => rfl
          | succ k' =>
            have hneTot : k' + 1 ≠ tail.length := by omega
            have hloc : locStateAt j tail.length (k' + 1) = LocalState.mid j (k' + 1) := by
              simp [locStateAt, hneTot]
            rw [hloc] at hsrcCut
            rcases (mem_liftLocalPositiveCut_mid_iff G pkt D j (k' + 1)).mp hsrcCut with
              ⟨γ', hget', _, _, hsurv'⟩
            rw [hget] at hget'
            injection hget' with hγEq
            subst hγEq
            exact hsurv'
        have hnextSurv : allEdgesBeforeSurviveBool G D (v0 :: tail) (k + 1) = true := by
          simp [allEdgesBeforeSurviveBool, hprevSurv, hedgSurv]
        have hk1NeTot : k + 1 ≠ tail.length := by
          intro heqTot
          rw [heqTot, allEdgesBefore_full_eq_walkSurvives] at hnextSurv
          simp only [checkWalkSurvivesBool] at hγBroken
          rw [hnextSurv] at hγBroken
          cases hγBroken
        have hdstMid : locStateAt j tail.length (k + 1) = LocalState.mid j (k + 1) := by
          simp [locStateAt, hk1NeTot]
        rw [hdstMid]
        exact (mem_liftLocalPositiveCut_mid_iff G pkt D j (k + 1)).mpr
          ⟨v0 :: tail, hget, by omega, by simp [walkSteps]; omega, hnextSurv⟩

/-- **Carrier 3 (`GlobalStar`, `F89-03` Row 2)**: `LiftCut` is the identity on `C_V`. -/
def checkSourceGlobalStarCut (G : LabeledGraph) (s t : VertexId)
    (D : List IssuerId) (C_V : List VertexId) : Bool :=
  nodupBool C_V &&
  listMemBool s C_V &&
  !(listMemBool t C_V) &&
  listAllBool (fun e =>
    (!(edgeSurvivesBool G D e.src e.dst && listMemBool e.src C_V)) ||
    listMemBool e.dst C_V) G.edges

theorem cert3_global_star_cut_sound {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (s t : VertexId) (D : List IssuerId) (C_V : List VertexId)
    (hcut : checkSourceGlobalStarCut G s t D C_V = true) :
    checkClosedCut (mkGlobalStarLTS G s t) D C_V = true := by
  unfold checkSourceGlobalStarCut at hcut
  unfold checkClosedCut mkGlobalStarLTS
  simp only [Bool.and_eq_true, listAllBool_iff] at hcut ⊢
  refine ⟨hcut.1, ?_⟩
  intro tr htr
  rcases List.mem_map.mp htr with ⟨e, he, rfl⟩
  rw [transSurvivesBool_edge_eq_edgeSurvivesBool hwf he D e.src e.dst]
  exact hcut.2 e he

/-- **Carrier 4 (`GlobalPlus`, `F89-03` Row 3)**:
    `liftGlobalPlusCut C_V = .start :: C_V.map PlusState.act` (works even when `s = t`!). -/
def liftGlobalPlusCut (C_V : List VertexId) : List PlusState :=
  PlusState.start :: C_V.map PlusState.act

def checkSourceGlobalPlusCut (G : LabeledGraph) (s t : VertexId)
    (D : List IssuerId) (C_V : List VertexId) : Bool :=
  nodupBool C_V &&
  !(listMemBool t C_V) &&
  listAllBool (fun e =>
    if e.src = s then
      (!(edgeSurvivesBool G D e.src e.dst)) || listMemBool e.dst C_V
    else
      true) G.edges &&
  listAllBool (fun e =>
    (!(edgeSurvivesBool G D e.src e.dst && listMemBool e.src C_V)) ||
    listMemBool e.dst C_V) G.edges

theorem mem_liftGlobalPlusCut_act_iff (C_V : List VertexId) (v : VertexId) :
    listMemBool (PlusState.act v) (liftGlobalPlusCut C_V) = listMemBool v C_V := by
  cases hv : listMemBool v C_V
  · apply (listMemBool_false_iff _ _).mpr
    intro hmem
    cases hmem with
    | tail _ hm =>
      rcases List.mem_map.mp hm with ⟨v', hv', heq⟩
      injection heq with hvEq
      rw [hvEq] at hv'
      exact ((listMemBool_false_iff v C_V).mp hv) hv'
  · apply (listMemBool_iff _ _).mpr
    exact List.Mem.tail _ (List.mem_map.mpr ⟨v, (listMemBool_iff v C_V).mp hv, rfl⟩)

theorem nodup_liftGlobalPlusCut {C_V : List VertexId} (hnd : NodupList C_V) :
    NodupList (liftGlobalPlusCut C_V) := by
  refine NodupList.cons ?_ ?_
  · intro hmem
    rcases List.mem_map.mp hmem with ⟨_, _, h⟩
    cases h
  · apply nodup_map_of_inj_on PlusState.act hnd
    intro a b _ _ heq
    injection heq

theorem cert3_global_plus_cut_sound {ip : IssuerPartition} {G : LabeledGraph}
    (hwf : GraphWF ip G) (s t : VertexId) (D : List IssuerId) (C_V : List VertexId)
    (hcut : checkSourceGlobalPlusCut G s t D C_V = true) :
    checkClosedCut (mkGlobalPlusLTS G s t) D (liftGlobalPlusCut C_V) = true := by
  unfold checkSourceGlobalPlusCut at hcut
  simp only [Bool.and_eq_true, nodupBool_iff, listAllBool_iff] at hcut
  rcases hcut with ⟨⟨⟨hnd, htNot⟩, hbase⟩, hstep⟩
  unfold checkClosedCut
  simp only [Bool.and_eq_true, nodupBool_iff, listMemBool_iff, listAllBool_iff]
  refine ⟨⟨⟨nodup_liftGlobalPlusCut hnd, List.Mem.head _⟩, ?_⟩, ?_⟩
  · change (!(listMemBool (PlusState.act t) (liftGlobalPlusCut C_V))) = true
    rw [mem_liftGlobalPlusCut_act_iff]
    exact htNot
  · intro tr htr
    simp only [mkGlobalPlusLTS, List.mem_append] at htr
    cases htr with
    | inl hinit =>
      rcases List.mem_map.mp hinit with ⟨e, hef, rfl⟩
      rcases List.mem_filter.mp hef with ⟨he, heSrcB⟩
      have heSrc : e.src = s := of_decide_eq_true heSrcB
      have hb := hbase e he
      rw [if_pos heSrc] at hb
      have hstartMem : listMemBool PlusState.start (liftGlobalPlusCut C_V) = true :=
        (listMemBool_iff _ _).mpr (List.Mem.head _)
      dsimp
      rw [hstartMem, Bool.and_true,
        transSurvivesBool_edge_eq_edgeSurvivesBool hwf he D PlusState.start (PlusState.act e.dst),
        mem_liftGlobalPlusCut_act_iff]
      exact hb
    | inr hact =>
      rcases List.mem_map.mp hact with ⟨e, he, rfl⟩
      dsimp
      rw [transSurvivesBool_edge_eq_edgeSurvivesBool hwf he D
            (PlusState.act e.src) (PlusState.act e.dst),
          mem_liftGlobalPlusCut_act_iff C_V e.src,
          mem_liftGlobalPlusCut_act_iff C_V e.dst]
      exact hstep e he

/-- **Carrier 2 (`GeodesicBundle`, `F89-03` Row 4)**:
    Matches `#40` `omega_kappa_pure_checker.py` lines 1051–1083 verbatim, including the
    `b.kappa = .ePlus ∧ rk = 1` direct-edge `(u, t)` check! -/
def liftGeodesicCut (C_V : List VertexId) : List GeoState :=
  GeoState.start :: C_V.map GeoState.act

def checkGeoVertexClosedBool (b : BaseData) (t : VertexId) (D : List IssuerId)
    (C_V : List VertexId) (u : VertexId) : Bool :=
  match rankOf b u t with
  | none => true
  | some rk =>
      if b.kappa = .ePlus ∧ rk = 1 then
        !(edgeSurvivesBool b.G D u t)
      else
        listAllBool (fun w =>
          (!(edgeSurvivesBool b.G D u w)) || listMemBool w C_V) (maxHopsOf b u t)

def checkSourceGeodesicCut (b : BaseData) (s t : VertexId)
    (D : List IssuerId) (C_V : List VertexId) : Bool :=
  (!(decide (b.kappa = .eStar ∧ s = t))) &&
  nodupBool C_V &&
  listAllBool (fun u => decide (u < b.G.numVertices)) C_V &&
  !(listMemBool t C_V) &&
  (rankOf b s t).isSome &&
  checkGeoVertexClosedBool b t D C_V s &&
  listAllBool (fun u => checkGeoVertexClosedBool b t D C_V u) C_V

theorem mem_liftGeodesicCut_act_iff (C_V : List VertexId) (v : VertexId) :
    listMemBool (GeoState.act v) (liftGeodesicCut C_V) = listMemBool v C_V := by
  cases hv : listMemBool v C_V
  · apply (listMemBool_false_iff _ _).mpr
    intro hmem
    cases hmem with
    | tail _ hm =>
      rcases List.mem_map.mp hm with ⟨v', hv', heq⟩
      injection heq with hvEq
      rw [hvEq] at hv'
      exact ((listMemBool_false_iff v C_V).mp hv) hv'
  · apply (listMemBool_iff _ _).mpr
    exact List.Mem.tail _ (List.mem_map.mpr ⟨v, (listMemBool_iff v C_V).mp hv, rfl⟩)

theorem nodup_liftGeodesicCut {C_V : List VertexId} (hnd : NodupList C_V) :
    NodupList (liftGeodesicCut C_V) := by
  refine NodupList.cons ?_ ?_
  · intro hmem
    rcases List.mem_map.mp hmem with ⟨_, _, h⟩
    cases h
  · apply nodup_map_of_inj_on GeoState.act hnd
    intro a b _ _ heq
    injection heq

theorem geo_vertex_closed_step {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {u t w : VertexId} {D : List IssuerId} {C_V : List VertexId}
    (hu : u < b.G.numVertices) (ht : t < b.G.numVertices)
    (hwMax : w ∈ maxHopsOf b u t)
    (hclosedU : checkGeoVertexClosedBool b t D C_V u = true) :
    ((!(edgeSurvivesBool b.G D u w)) || listMemBool w C_V) = true := by
  have hhop : IsShortestFirstHop b u t w := (b6_maxHops_iff hb hu ht w).mp hwMax
  unfold checkGeoVertexClosedBool at hclosedU
  unfold IsShortestFirstHop at hhop
  cases hrk : rankOf b u t with
  | none => rw [hrk] at hhop; cases hhop
  | some rk =>
    rw [hrk] at hhop hclosedU
    dsimp only at hclosedU
    split at hclosedU
    · next hplus1 =>
      rcases hplus1 with ⟨_, hrk1⟩
      subst hrk1
      rcases hhop with ⟨_, hwt⟩
      subst hwt
      rw [hclosedU]
      rfl
    · exact (listAllBool_iff _ (maxHopsOf b u t)).mp hclosedU w hwMax

theorem cert3_geodesic_cut_sound {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (D : List IssuerId) (C_V : List VertexId)
    (hcut : checkSourceGeodesicCut b s t D C_V = true) :
    checkClosedCut (mkGeodesicLTS b s t) D (liftGeodesicCut C_V) = true := by
  unfold checkSourceGeodesicCut at hcut
  simp only [Bool.and_eq_true, nodupBool_iff, listAllBool_iff, decide_eq_true_eq,
    Bool.not_eq_true', decide_eq_false_iff_not] at hcut
  rcases hcut with ⟨⟨⟨⟨⟨⟨hnotRefl0, hnd⟩, _⟩, htNot⟩, hsRank⟩, hsClosed⟩, hcvClosed⟩
  have hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices) :=
    fun ⟨hk, hst, _⟩ => hnotRefl0 ⟨hk, hst⟩
  rw [mkGeodesicLTS_eq_pos hnotRefl hs ht hsRank]
  unfold checkClosedCut
  simp only [Bool.and_eq_true, nodupBool_iff, listMemBool_iff, listAllBool_iff]
  refine ⟨⟨⟨nodup_liftGeodesicCut hnd, List.Mem.head _⟩, ?_⟩, ?_⟩
  · change (!(listMemBool (GeoState.act t) (liftGeodesicCut C_V))) = true
    rw [mem_liftGeodesicCut_act_iff, htNot]
    rfl
  · intro tr htr
    simp only [geoPosDelta, List.mem_append] at htr
    cases htr with
    | inl hinit =>
      rcases List.mem_map.mp hinit with ⟨w, hwMax, rfl⟩
      have hstartMem : listMemBool GeoState.start (liftGeodesicCut C_V) = true :=
        (listMemBool_iff _ _).mpr (List.Mem.head _)
      dsimp
      rw [hstartMem, Bool.and_true,
        transSurvivesBool_getD_eq_edgeSurvivesBool b.G D s w GeoState.start (GeoState.act w),
        mem_liftGeodesicCut_act_iff]
      exact geo_vertex_closed_step hb hs ht hwMax hsClosed
    | inr hact =>
      rcases mem_buildGeoActTrans_iff.mp hact with ⟨u, huRange, _, w, hwMax, rfl⟩
      have hu : u < b.G.numVertices := (mem_rangeBelow_iff u _).mp huRange
      dsimp
      rw [transSurvivesBool_getD_eq_edgeSurvivesBool b.G D u w (GeoState.act u) (GeoState.act w),
        mem_liftGeodesicCut_act_iff C_V u,
        mem_liftGeodesicCut_act_iff C_V w]
      cases huIn : listMemBool u C_V
      · simp
      · simp only [Bool.and_true]
        have huMem : u ∈ C_V := (listMemBool_iff u C_V).mp huIn
        exact geo_vertex_closed_step hb hu ht hwMax (hcvClosed u huMem)

/-! ## `Cert-1`, `Cert-2`, & `Cert-4`: Full `0x00` Source Certificate Checker, Constructive
    Lifter `liftSourceCert0x00`, `CertRefinement0x00`, and Composition Soundness -/

def checkValidGeodesicWalkBool (b : BaseData) (s t : VertexId) (γ : List VertexId) : Bool :=
  checkValidWalk b.G b.kappa s t γ &&
  decide (rankOf b s t = some (walkSteps γ))

theorem checkValidGeodesicWalkBool_iff {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    {r0 : Nat} (hr0 : rankOf b s t = some r0) (γ : List VertexId) :
    checkValidGeodesicWalkBool b s t γ = true ↔ IsTrueShortestWalk b.G b.kappa s t γ := by
  unfold checkValidGeodesicWalkBool
  rw [Bool.and_eq_true, checkValidWalk_iff hb.wfGraph, decide_eq_true_eq, hr0, Option.some.injEq]
  rw [b5_rank_iff_true_shortest hb hs ht hr0 γ]
  exact ⟨fun ⟨hvw, heq⟩ => ⟨hvw, heq.symm⟩, fun ⟨hvw, heq⟩ => ⟨hvw, heq.symm⟩⟩

def checkSourcePackingCommon (ip : IssuerPartition) (G : LabeledGraph)
    (claimedL claimedU : Nat) (pws : List SourcePrimalWitness)
    (resolveWalk : SourcePrimalWitness → Option (List VertexId)) : Bool :=
  decide (1 ≤ claimedL) &&
  decide (claimedL ≤ claimedU) &&
  decide (pws.length = claimedL) &&
  listAllBool (fun pw =>
    match resolveWalk pw with
    | none => false
    | some γ =>
        checkSourceStepList ip (walkEdgeSupports G γ) pw.stepWitnesses &&
        decide (extractSourceRetractable pw.stepWitnesses ≠ [])) pws &&
  pairwiseDisjointBool (pws.map (fun pw => extractSourceRetractable pw.stepWitnesses))

def checkSourceUpperCommon (ip : IssuerPartition) (claimedU : Nat)
    (retractionIrIndices : List IssuerId) : Bool :=
  nodupBool retractionIrIndices &&
  listAllBool (fun d => listMemBool d ip.remIssuers) retractionIrIndices &&
  decide (retractionIrIndices.length = claimedU)

/-- Executable source-domain `0x00` certificate checker (`Cert-0` + `Cert-1` + `Cert-2` + `Cert-3`). -/
def checkSourceCert0x00 (ip : IssuerPartition) (b : BaseData)
    (s t : VertexId) (c : CarrierSpec) (T : SourceCertTerm) : Bool :=
  decide (s < b.G.numVertices) &&
  decide (t < b.G.numVertices) &&
  (rankOf b s t).isSome &&
  checkTagContextMatchBool T b.kappa c &&
  match c with
  | .localPacket pkt =>
      decide (pkt ≠ []) &&
      nodupBool pkt &&
      if listAnyBool (fun γ => decide (walkSteps γ = 0)) pkt then
        decide (b.kappa = .eStar) &&
        listAllBool (fun γ => checkValidWalk b.G b.kappa s t γ) pkt &&
        decide (T.modeTag = 1) &&
        decide (T.claimedL = 0) &&
        decide (T.claimedU = 0) &&
        decide (T.unbreakableRefKind = 1) &&
        match pkt[T.unbreakableLocalIdx]? with
        | none => false
        | some γ0 => decide (walkSteps γ0 = 0)
      else
        listAllBool (fun γ =>
          checkValidWalk b.G b.kappa s t γ && decide (1 ≤ walkSteps γ)) pkt &&
        if T.modeTag = 1 then
          decide (T.claimedL = 0) &&
          decide (T.claimedU = 0) &&
          decide (T.unbreakableRefKind = 1) &&
          match pkt[T.unbreakableLocalIdx]? with
          | none => false
          | some γ => checkWalkEdgesConstBool ip b.G γ
        else if T.modeTag = 2 then
          checkSourcePackingCommon ip b.G T.claimedL T.claimedU T.primalWitnesses
            (fun pw => if pw.refKind = 1 then pkt[pw.jIdx]? else none) &&
          checkSourceUpperCommon ip T.claimedU T.retractionIrIndices &&
          checkSourceLocalCut b.G pkt T.retractionIrIndices
        else false
  | .geodesicBundle =>
      if T.modeTag = 1 then
        decide (T.claimedL = 0) &&
        decide (T.claimedU = 0) &&
        decide (T.unbreakableRefKind = 2) &&
        checkValidGeodesicWalkBool b s t T.unbreakableWalk &&
        checkWalkEdgesConstBool ip b.G T.unbreakableWalk
      else if T.modeTag = 2 then
        checkSourcePackingCommon ip b.G T.claimedL T.claimedU T.primalWitnesses
          (fun pw =>
            if pw.refKind = 2 && checkValidGeodesicWalkBool b s t pw.walkVertices then
              some pw.walkVertices
            else none) &&
        checkSourceUpperCommon ip T.claimedU T.retractionIrIndices &&
        checkSourceGeodesicCut b s t T.retractionIrIndices T.dualCutVids
      else false
  | .globalGraph =>
      match b.kappa with
      | .eStar =>
          if T.modeTag = 1 then
            decide (T.claimedL = 0) &&
            decide (T.claimedU = 0) &&
            decide (T.unbreakableRefKind = 2) &&
            checkValidWalk b.G .eStar s t T.unbreakableWalk &&
            checkWalkEdgesConstBool ip b.G T.unbreakableWalk
          else if T.modeTag = 2 then
            checkSourcePackingCommon ip b.G T.claimedL T.claimedU T.primalWitnesses
              (fun pw =>
                if pw.refKind = 2 && checkValidWalk b.G .eStar s t pw.walkVertices then
                  some pw.walkVertices
                else none) &&
            checkSourceUpperCommon ip T.claimedU T.retractionIrIndices &&
            checkSourceGlobalStarCut b.G s t T.retractionIrIndices T.dualCutVids
          else false
      | .ePlus =>
          if T.modeTag = 1 then
            decide (T.claimedL = 0) &&
            decide (T.claimedU = 0) &&
            decide (T.unbreakableRefKind = 2) &&
            checkValidWalk b.G .ePlus s t T.unbreakableWalk &&
            checkWalkEdgesConstBool ip b.G T.unbreakableWalk
          else if T.modeTag = 2 then
            checkSourcePackingCommon ip b.G T.claimedL T.claimedU T.primalWitnesses
              (fun pw =>
                if pw.refKind = 2 && checkValidWalk b.G .ePlus s t pw.walkVertices then
                  some pw.walkVertices
                else none) &&
            checkSourceUpperCommon ip T.claimedU T.retractionIrIndices &&
            checkSourceGlobalPlusCut b.G s t T.retractionIrIndices T.dualCutVids
          else false

def liftPackingList {Q : Type}
    (mkTrans : SourcePrimalWitness → Option (List (Trans Q))) :
    List SourcePrimalWitness → Option (List (LowerWitnessWalk Q))
  | [] => some []
  | pw :: rest =>
      match mkTrans pw, projectSourceStepList pw.stepWitnesses, liftPackingList mkTrans rest with
      | some τ, some sws, some tail =>
          some ({ transitions := τ, stepWitnesses := sws } :: tail)
      | _, _, _ => none

/-- Constructive source-to-abstract certificate compiler (`LiftCert` for `evasionModeTag = 0x00`). -/
def liftSourceCert0x00 (b : BaseData) (s t : VertexId) (c : CarrierSpec)
    (T : SourceCertTerm) : Option ResilienceCert :=
  match c with
  | .localPacket pkt =>
      if listAnyBool (fun γ => decide (walkSteps γ = 0)) pkt then
        if T.modeTag = 1 then some (.localReflexive (.unbreakableWalk []))
        else none
      else
        if T.modeTag = 1 then
          match pkt[T.unbreakableLocalIdx]? with
          | none => none
          | some γ => some (.localPositive (.unbreakableWalk (buildChainTrans b.G T.unbreakableLocalIdx γ)))
        else if T.modeTag = 2 then
          match liftPackingList
            (fun pw =>
              if pw.refKind = 1 then
                match pkt[pw.jIdx]? with
                | none => none
                | some γ => some (buildChainTrans b.G pw.jIdx γ)
              else none) T.primalWitnesses with
          | none => none
          | some packing =>
              some (.localPositive (.finiteBounds T.claimedL T.claimedU packing
                T.retractionIrIndices (liftLocalPositiveCut b.G pkt T.retractionIrIndices)))
        else none
  | .geodesicBundle =>
      if T.modeTag = 1 then
        let τ := if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
                 else geoWalkToLTS b T.unbreakableWalk
        some (.geodesic (.unbreakableWalk τ))
      else if T.modeTag = 2 then
        match liftPackingList
          (fun pw =>
            if pw.refKind = 2 then
              some (if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
                    else geoWalkToLTS b pw.walkVertices)
            else none) T.primalWitnesses with
        | none => none
        | some packing =>
            some (.geodesic (.finiteBounds T.claimedL T.claimedU packing
              T.retractionIrIndices (liftGeodesicCut T.dualCutVids)))
      else none
  | .globalGraph =>
      match b.kappa with
      | .eStar =>
          if T.modeTag = 1 then
            some (.globalStar (.unbreakableWalk (starWalkToLTS b.G T.unbreakableWalk)))
          else if T.modeTag = 2 then
            match liftPackingList
              (fun pw => if pw.refKind = 2 then some (starWalkToLTS b.G pw.walkVertices) else none)
              T.primalWitnesses with
            | none => none
            | some packing =>
                some (.globalStar (.finiteBounds T.claimedL T.claimedU packing
                  T.retractionIrIndices T.dualCutVids))
          else none
      | .ePlus =>
          if T.modeTag = 1 then
            some (.globalPlus (.unbreakableWalk (plusWalkToLTS b.G T.unbreakableWalk)))
          else if T.modeTag = 2 then
            match liftPackingList
              (fun pw => if pw.refKind = 2 then some (plusWalkToLTS b.G pw.walkVertices) else none)
              T.primalWitnesses with
            | none => none
            | some packing =>
                some (.globalPlus (.finiteBounds T.claimedL T.claimedU packing
                  T.retractionIrIndices (liftGlobalPlusCut T.dualCutVids)))
          else none

def CertRefinement0x00 (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (T : SourceCertTerm) (cert : ResilienceCert) : Prop :=
  T.evasionModeTag = 0 ∧
  TagContextMatch T b.kappa c ∧
  ClaimMatch T (certClaim cert) ∧
  liftSourceCert0x00 b s t c T = some cert ∧
  checkSourceCert0x00 ip b s t c T = true

def SourceCertificateSoundness (ip : IssuerPartition) (b : BaseData)
    (s t : VertexId) (c : CarrierSpec) (T : SourceCertTerm) : Prop :=
  T.evasionModeTag = 0 ∧
  TagContextMatch T b.kappa c ∧
  s < b.G.numVertices ∧
  t < b.G.numVertices ∧
  (rankOf b s t).isSome = true ∧
  if T.modeTag = 1 then
    T.claimedL = 0 ∧ T.claimedU = 0 ∧
    SemanticClaimHolds ip (CarrierSurvives b s t c) .unbreakable
  else if T.modeTag = 2 then
    1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU ∧
    SemanticClaimHolds ip (CarrierSurvives b s t c) (.finiteBounds T.claimedL T.claimedU)
  else
    False

/-- Universal `Cert-2` Packing Lifting Lemma across any `PointedLTS Q`. -/
theorem cert2_liftPackingList_sound {Q : Type} [DecidableEq Q]
    (ip : IssuerPartition) (G : LabeledGraph) (M : PointedLTS Q)
    (claimedL claimedU : Nat) (pws : List SourcePrimalWitness)
    (resolveWalk : SourcePrimalWitness → Option (List VertexId))
    (mkTrans : SourcePrimalWitness → Option (List (Trans Q)))
    (hpackChk : checkSourcePackingCommon ip G claimedL claimedU pws resolveWalk = true)
    (hbridge : ∀ pw ∈ pws, ∀ γ, resolveWalk pw = some γ →
      ∃ τ, mkTrans pw = some τ ∧
           LTSWalk M M.q0 M.qf τ ∧
           τ.map Trans.support = walkEdgeSupports G γ) :
    ∃ packing : List (LowerWitnessWalk Q),
      liftPackingList mkTrans pws = some packing ∧
      1 ≤ claimedL ∧
      claimedL ≤ claimedU ∧
      packing.length = claimedL ∧
      checkLowerPacking ip M packing = true := by
  unfold checkSourcePackingCommon at hpackChk
  simp only [Bool.and_eq_true, decide_eq_true_eq, listAllBool_iff] at hpackChk
  rcases hpackChk with ⟨⟨⟨⟨h1L, hLU⟩, hlenPws⟩, hpwsOk⟩, hdisjSrc⟩
  suffices ∀ (xs : List SourcePrimalWitness),
      (∀ pw ∈ xs,
        (match resolveWalk pw with
         | none => false
         | some γ =>
             checkSourceStepList ip (walkEdgeSupports G γ) pw.stepWitnesses &&
             decide (extractSourceRetractable pw.stepWitnesses ≠ [])) = true) →
      (∀ pw ∈ xs, ∀ γ, resolveWalk pw = some γ →
        ∃ τ, mkTrans pw = some τ ∧
             LTSWalk M M.q0 M.qf τ ∧
             τ.map Trans.support = walkEdgeSupports G γ) →
      ∃ packing : List (LowerWitnessWalk Q),
        liftPackingList mkTrans xs = some packing ∧
        packing.length = xs.length ∧
        (∀ w ∈ packing, checkLTSWalkFrom M M.q0 M.qf w.transitions = true ∧
                        checkWitnessedSteps ip w.transitions w.stepWitnesses = true ∧
                        decide (extractRetractableIssuers w.stepWitnesses ≠ []) = true) ∧
        packing.map (fun w => extractRetractableIssuers w.stepWitnesses) =
          xs.map (fun pw => extractSourceRetractable pw.stepWitnesses) by
    rcases this pws hpwsOk hbridge with ⟨packing, hlift, hlenEq, hallW, hmapExtr⟩
    refine ⟨packing, hlift, h1L, hLU, hlenEq.trans hlenPws, ?_⟩
    unfold checkLowerPacking
    rw [Bool.and_eq_true, listAllBool_iff, hmapExtr]
    refine ⟨?_, hdisjSrc⟩
    intro w hw
    rcases hallW w hw with ⟨h1, h2, h3⟩
    simp [h1, h2, h3]
  intro xs hxsOk hxsBridge
  induction xs with
  | nil =>
    refine ⟨[], rfl, rfl, ?_, rfl⟩
    intro _ h; cases h
  | cons pw rest ih =>
    have hpwOk := hxsOk pw (List.Mem.head rest)
    cases hres : resolveWalk pw with
    | none => rw [hres] at hpwOk; cases hpwOk
    | some γ =>
      rw [hres] at hpwOk
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hpwOk
      rcases hxsBridge pw (List.Mem.head rest) γ hres with ⟨τ, hmk, hltsW, hmapSupp⟩
      rcases supports_witnessed_steps_transfer ip hmapSupp hpwOk.1 with
        ⟨sws, hprojSws, hchkSws, hextrEq⟩
      rcases ih (fun x hx => hxsOk x (List.Mem.tail pw hx))
                (fun x hx g hg => hxsBridge x (List.Mem.tail pw hx) g hg) with
        ⟨packRest, hliftRest, hlenRest, hallRest, hmapRest⟩
      refine ⟨{ transitions := τ, stepWitnesses := sws } :: packRest, ?_, ?_, ?_, ?_⟩
      · simp [liftPackingList, hmk, hprojSws, hliftRest]
      · simp [hlenRest]
      · intro w hw
        cases hw with
        | head =>
          refine ⟨(checkLTSWalkFrom_iff M M.q0 M.qf τ).mpr hltsW, hchkSws, ?_⟩
          rw [hextrEq]
          exact decide_eq_true hpwOk.2
        | tail _ hm => exact hallRest w hm
      · simp [hextrEq, hmapRest]

theorem checkLTSCert_finiteBounds_of_parts {Q : Type} [DecidableEq Q]
    (ip : IssuerPartition) (M : PointedLTS Q)
    (L U : Nat) (packing : List (LowerWitnessWalk Q))
    (D : List IssuerId) (cutStates : List Q)
    (hLU : L ≤ U) (hlenP : packing.length = L)
    (hlow : checkLowerPacking ip M packing = true)
    (hupperCommon : checkSourceUpperCommon ip U D = true)
    (hclosed : checkClosedCut M D cutStates = true) :
    checkLTSCert ip M (.finiteBounds L U packing D cutStates) = true := by
  unfold checkSourceUpperCommon at hupperCommon
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hupperCommon
  rcases hupperCommon with ⟨⟨hndD, hremD⟩, hlenD⟩
  unfold checkLTSCert
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  exact ⟨⟨⟨⟨⟨⟨hLU, hlenP⟩, hlow⟩, hndD⟩, hremD⟩, by omega⟩, hclosed⟩

theorem valid_eplus_walk_pos_steps {G : LabeledGraph} {s t : VertexId} {γ : List VertexId}
    (hvw : IsValidWalk G .ePlus s t γ) : 1 ≤ walkSteps γ := by
  cases γ with
  | nil => cases hvw
  | cons v0 tail =>
    rcases hvw with ⟨_, _, _, _, hplus⟩
    have hne : tail ≠ [] := hplus rfl
    cases tail with
    | nil => exact absurd rfl hne
    | cons _ _ => simp [walkSteps]

theorem nonrefl_shortest_pos_steps {ip : IssuerPartition} {b : BaseData}
    (hb : VerifiedBase ip b) {s t : VertexId} {r0 : Nat} {γ : List VertexId}
    (hs : s < b.G.numVertices) (ht : t < b.G.numVertices)
    (hr0 : rankOf b s t = some r0)
    (hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices))
    (hshort : IsTrueShortestWalk b.G b.kappa s t γ) :
    1 ≤ walkSteps γ := by
  rcases (b5_rank_iff_true_shortest hb hs ht hr0 γ).mp hshort with ⟨_, hlen⟩
  rw [hlen]
  cases r0 with
  | zero =>
    have hrp := hb.rankPairs s t hs ht
    unfold checkRankPair at hrp
    rw [hr0] at hrp
    simp only [decide_eq_true_eq] at hrp
    exfalso
    exact hnotRefl ⟨hrp.1, hrp.2, hs⟩
  | succ _ => omega

/-- **Constructive Lifting Completeness & Soundness (`Cert-0` + `Cert-1` + `Cert-2` + `Cert-3`)**:
    Every source certificate `T` accepted by `checkSourceCert0x00` compiles via
    `liftSourceCert0x00` to a typed Lean `ResilienceCert` satisfying both
    `CertRefinement0x00` AND `checkOmegaLambdaResilience ip b s t c cert = true`. -/
theorem liftSourceCert0x00_complete_sound
    {ip : IssuerPartition} {b : BaseData} {s t : VertexId}
    {c : CarrierSpec} {T : SourceCertTerm}
    (hBase : checkVerifiedBase ip b = true)
    (hSrc : checkSourceCert0x00 ip b s t c T = true) :
    ∃ cert : ResilienceCert,
      CertRefinement0x00 ip b s t c T cert ∧
      checkOmegaLambdaResilience ip b s t c cert = true := by
  have hb : VerifiedBase ip b := checkVerifiedBase_sound hBase
  have hSrcCopy := hSrc
  unfold checkSourceCert0x00 at hSrc
  rcases (Bool.and_eq_true _ _).mp hSrc with ⟨hHdr4, hbody⟩
  rcases (Bool.and_eq_true _ _).mp hHdr4 with ⟨hHdr3, htagB⟩
  rcases (Bool.and_eq_true _ _).mp hHdr3 with ⟨hHdr2, hsRank⟩
  rcases (Bool.and_eq_true _ _).mp hHdr2 with ⟨hsB, htB⟩
  have hs : s < b.G.numVertices := of_decide_eq_true hsB
  have ht : t < b.G.numVertices := of_decide_eq_true htB
  have htag : TagContextMatch T b.kappa c := (cert0_tagContextMatch_iff T b.kappa c).mp htagB
  cases hrankOpt : rankOf b s t with
  | none => rw [hrankOpt] at hsRank; cases hsRank
  | some r0 =>
    cases c with
    | localPacket pkt =>
      dsimp only at hbody
      rcases (Bool.and_eq_true _ _).mp hbody with ⟨hpktHdr, hlocIf⟩
      rcases (Bool.and_eq_true _ _).mp hpktHdr with ⟨hpktNeB, hndPktB⟩
      cases hzero : listAnyBool (fun γ => decide (walkSteps γ = 0)) pkt with
      | true =>
        rw [hzero] at hlocIf
        simp only [ite_true, Bool.and_eq_true] at hlocIf
        rcases hlocIf with ⟨⟨⟨⟨⟨⟨hκB, hallValid⟩, hmode1B⟩, hL0B⟩, hU0B⟩, _⟩, _⟩
        have hmode1 : T.modeTag = 1 := of_decide_eq_true hmode1B
        have hL0 : T.claimedL = 0 := of_decide_eq_true hL0B
        have hU0 : T.claimedU = 0 := of_decide_eq_true hU0B
        refine ⟨.localReflexive (.unbreakableWalk []), ?_, ?_⟩
        · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
          · unfold ClaimMatch; simp [hmode1, hL0, hU0, certClaim, ltsCertClaim]
          · simp [liftSourceCert0x00, hzero, hmode1]
        · unfold checkOmegaLambdaResilience
          simp only [Bool.and_eq_true]
          exact ⟨⟨⟨hsB, htB⟩, hsRank⟩, ⟨⟨⟨⟨⟨hκB, hpktNeB⟩, hndPktB⟩, hallValid⟩, hzero⟩, rfl⟩⟩
      | false =>
        rw [hzero] at hlocIf
        simp only [Bool.false_eq_true, ite_false] at hlocIf
        rcases (Bool.and_eq_true _ _).mp hlocIf with ⟨hallPosValid, hmodeIf⟩
        have hposAll : ∀ γ ∈ pkt, 1 ≤ walkSteps γ := by
          intro γ hγ
          have hp := (listAllBool_iff _ pkt).mp hallPosValid γ hγ
          simp only [Bool.and_eq_true, decide_eq_true_eq] at hp
          exact hp.2
        split at hmodeIf
        · next hmode1 =>
          simp only [Bool.and_eq_true] at hmodeIf
          rcases hmodeIf with ⟨⟨⟨hL0B, hU0B⟩, _⟩, hgetChk⟩
          cases hget : pkt[T.unbreakableLocalIdx]? with
          | none => rw [hget] at hgetChk; cases hgetChk
          | some γ =>
            rw [hget] at hgetChk
            have hL0 : T.claimedL = 0 := of_decide_eq_true hL0B
            have hU0 : T.claimedU = 0 := of_decide_eq_true hU0B
            let τ := buildChainTrans b.G T.unbreakableLocalIdx γ
            have hγMem : γ ∈ pkt := List.mem_of_getElem? hget
            have hltsW : LTSWalk (mkLocalPositiveLTS b.G pkt) .init .final τ :=
              buildChainTrans_is_walk hget (hposAll γ hγMem)
            have hunbChk : checkUnbreakableWalk ip (mkLocalPositiveLTS b.G pkt) τ = true := by
              unfold checkUnbreakableWalk
              rw [Bool.and_eq_true]
              exact ⟨(checkLTSWalkFrom_iff _ _ _ τ).mpr hltsW,
                     supports_unbreakable_transfer ip
                       (buildChainTrans_supports b.G T.unbreakableLocalIdx γ) hgetChk⟩
            refine ⟨.localPositive (.unbreakableWalk τ), ?_, ?_⟩
            · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
              · unfold ClaimMatch; simp [hmode1, hL0, hU0, certClaim, ltsCertClaim]
              · simp [liftSourceCert0x00, hzero, hmode1, hget, τ]
            · unfold checkOmegaLambdaResilience
              simp only [Bool.and_eq_true]
              exact ⟨⟨⟨hsB, htB⟩, hsRank⟩, ⟨⟨hpktNeB, hndPktB⟩, hallPosValid⟩, hunbChk⟩
        · next hne1 =>
          split at hmodeIf
          · next hmode2 =>
            rcases (Bool.and_eq_true _ _).mp hmodeIf with ⟨hpackAndUp, hcutSrc⟩
            rcases (Bool.and_eq_true _ _).mp hpackAndUp with ⟨hpackSrc, hupperSrc⟩
            rcases cert2_liftPackingList_sound ip b.G (mkLocalPositiveLTS b.G pkt)
                T.claimedL T.claimedU T.primalWitnesses
                (fun pw => if pw.refKind = 1 then pkt[pw.jIdx]? else none)
                (fun pw =>
                  if pw.refKind = 1 then
                    match pkt[pw.jIdx]? with
                    | none => none
                    | some γ => some (buildChainTrans b.G pw.jIdx γ)
                  else none)
                hpackSrc
                (fun pw _ γ hres => by
                  split at hres
                  · next href1 =>
                    rw [hres]
                    have hγMem : γ ∈ pkt := List.mem_of_getElem? hres
                    exact ⟨buildChainTrans b.G pw.jIdx γ,
                           by simp [href1],
                           buildChainTrans_is_walk hres (hposAll γ hγMem),
                           buildChainTrans_supports b.G pw.jIdx γ⟩
                  · cases hres) with
              ⟨packing, hliftPack, h1L, hLU, hlenP, hlowOk⟩
            have hclosedOk := cert3_local_positive_cut_sound b.G pkt T.retractionIrIndices hposAll hcutSrc
            have hltsCertOk := checkLTSCert_finiteBounds_of_parts ip (mkLocalPositiveLTS b.G pkt)
              T.claimedL T.claimedU packing T.retractionIrIndices
              (liftLocalPositiveCut b.G pkt T.retractionIrIndices)
              hLU hlenP hlowOk hupperSrc hclosedOk
            let cert := ResilienceCert.localPositive
              (.finiteBounds T.claimedL T.claimedU packing T.retractionIrIndices
                (liftLocalPositiveCut b.G pkt T.retractionIrIndices))
            refine ⟨cert, ?_, ?_⟩
            · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
              · unfold ClaimMatch; simp [hmode2, cert, certClaim, ltsCertClaim, h1L, hLU]
              · simp [liftSourceCert0x00, hzero, hmode2, hliftPack, cert]
            · dsimp only [cert]
              unfold checkOmegaLambdaResilience
              simp only [Bool.and_eq_true]
              exact ⟨⟨⟨hsB, htB⟩, hsRank⟩, ⟨⟨hpktNeB, hndPktB⟩, hallPosValid⟩, hltsCertOk⟩
          · cases hmodeIf
    | geodesicBundle =>
      dsimp only at hbody
      split at hbody
      · next hmode1 =>
        simp only [Bool.and_eq_true] at hbody
        rcases hbody with ⟨⟨⟨⟨hL0B, hU0B⟩, _⟩, hgeoW⟩, hconstW⟩
        have hL0 : T.claimedL = 0 := of_decide_eq_true hL0B
        have hU0 : T.claimedU = 0 := of_decide_eq_true hU0B
        have hshort : IsTrueShortestWalk b.G b.kappa s t T.unbreakableWalk :=
          (checkValidGeodesicWalkBool_iff hb hs ht hrankOpt T.unbreakableWalk).mp hgeoW
        let τ := if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
                 else geoWalkToLTS b T.unbreakableWalk
        have hltsW : LTSWalk (mkGeodesicLTS b s t) (mkGeodesicLTS b s t).q0 (mkGeodesicLTS b s t).qf τ :=
          (ref_geo_levelB hb hs ht hrankOpt).toLTS_valid T.unbreakableWalk hshort
        have hunbChk : checkUnbreakableWalk ip (mkGeodesicLTS b s t) τ = true := by
          unfold checkUnbreakableWalk
          rw [Bool.and_eq_true]
          refine ⟨(checkLTSWalkFrom_iff _ _ _ τ).mpr hltsW, ?_⟩
          dsimp only [τ]
          split
          · rfl
          · next hnotRefl =>
            have hpos := nonrefl_shortest_pos_steps hb hs ht hrankOpt hnotRefl hshort
            exact supports_unbreakable_transfer ip (geoWalkToLTS_supports b hpos) hconstW
        refine ⟨.geodesic (.unbreakableWalk τ), ?_, ?_⟩
        · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
          · unfold ClaimMatch; simp [hmode1, hL0, hU0, certClaim, ltsCertClaim]
          · simp [liftSourceCert0x00, hmode1, τ]
        · unfold checkOmegaLambdaResilience
          simp only [Bool.and_eq_true]
          exact ⟨⟨⟨hsB, htB⟩, hsRank⟩, hunbChk⟩
      · next hne1 =>
        split at hbody
        · next hmode2 =>
          rcases (Bool.and_eq_true _ _).mp hbody with ⟨hpackAndUp, hcutSrc⟩
          rcases (Bool.and_eq_true _ _).mp hpackAndUp with ⟨hpackSrc, hupperSrc⟩
          have hnotRefl : ¬ (b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices) := by
            unfold checkSourceGeodesicCut at hcutSrc
            simp only [Bool.and_eq_true, Bool.not_eq_true', decide_eq_false_iff_not] at hcutSrc
            exact fun ⟨hk, hst, _⟩ => hcutSrc.1.1.1.1.1.1 ⟨hk, hst⟩
          rcases cert2_liftPackingList_sound ip b.G (mkGeodesicLTS b s t)
              T.claimedL T.claimedU T.primalWitnesses
              (fun pw =>
                if pw.refKind = 2 && checkValidGeodesicWalkBool b s t pw.walkVertices then
                  some pw.walkVertices
                else none)
              (fun pw =>
                if pw.refKind = 2 then
                  some (if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
                        else geoWalkToLTS b pw.walkVertices)
                else none)
              hpackSrc
              (fun pw _ γ hres => by
                split at hres
                · next hcond =>
                  injection hres with hγEq
                  subst hγEq
                  simp only [Bool.and_eq_true, decide_eq_true_eq] at hcond
                  have hshort :=
                    (checkValidGeodesicWalkBool_iff hb hs ht hrankOpt pw.walkVertices).mp hcond.2
                  have hltsW :=
                    (ref_geo_levelB hb hs ht hrankOpt).toLTS_valid pw.walkVertices hshort
                  have hpos := nonrefl_shortest_pos_steps hb hs ht hrankOpt hnotRefl hshort
                  refine ⟨if b.kappa = .eStar ∧ s = t ∧ s < b.G.numVertices then []
                          else geoWalkToLTS b pw.walkVertices, ?_, hltsW, ?_⟩
                  · simp [hcond.1]
                  · rw [if_neg hnotRefl]
                    exact geoWalkToLTS_supports b hpos
                · cases hres) with
            ⟨packing, hliftPack, h1L, hLU, hlenP, hlowOk⟩
          have hclosedOk := cert3_geodesic_cut_sound hb hs ht T.retractionIrIndices T.dualCutVids hcutSrc
          have hltsCertOk := checkLTSCert_finiteBounds_of_parts ip (mkGeodesicLTS b s t)
            T.claimedL T.claimedU packing T.retractionIrIndices (liftGeodesicCut T.dualCutVids)
            hLU hlenP hlowOk hupperSrc hclosedOk
          let cert := ResilienceCert.geodesic
            (.finiteBounds T.claimedL T.claimedU packing T.retractionIrIndices
              (liftGeodesicCut T.dualCutVids))
          refine ⟨cert, ?_, ?_⟩
          · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
            · unfold ClaimMatch; simp [hmode2, cert, certClaim, ltsCertClaim, h1L, hLU]
            · simp [liftSourceCert0x00, hmode2, hliftPack, cert]
          · unfold checkOmegaLambdaResilience
            simp only [Bool.and_eq_true]
            exact ⟨⟨⟨hsB, htB⟩, hsRank⟩, hltsCertOk⟩
        · cases hbody
    | globalGraph =>
      dsimp only at hbody
      cases hκ : b.kappa with
      | eStar =>
        rw [hκ] at hbody
        dsimp only at hbody
        split at hbody
        · next hmode1 =>
          simp only [Bool.and_eq_true] at hbody
          rcases hbody with ⟨⟨⟨⟨hL0B, hU0B⟩, _⟩, hvwB⟩, hconstW⟩
          have hL0 : T.claimedL = 0 := of_decide_eq_true hL0B
          have hU0 : T.claimedU = 0 := of_decide_eq_true hU0B
          have hvw : IsValidWalk b.G .eStar s t T.unbreakableWalk :=
            (checkValidWalk_iff hb.wfGraph .eStar s t T.unbreakableWalk).mp hvwB
          let τ := starWalkToLTS b.G T.unbreakableWalk
          have hltsW := (ref_glob_star_levelB hb.wfGraph hs ht).toLTS_valid T.unbreakableWalk hvw
          have hunbChk : checkUnbreakableWalk ip (mkGlobalStarLTS b.G s t) τ = true := by
            unfold checkUnbreakableWalk
            rw [Bool.and_eq_true]
            exact ⟨(checkLTSWalkFrom_iff _ _ _ τ).mpr hltsW,
                   supports_unbreakable_transfer ip (starWalkToLTS_supports b.G T.unbreakableWalk) hconstW⟩
          refine ⟨.globalStar (.unbreakableWalk τ), ?_, ?_⟩
          · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
            · unfold ClaimMatch; simp [hmode1, hL0, hU0, certClaim, ltsCertClaim]
            · simp [liftSourceCert0x00, hκ, hmode1, τ]
          · unfold checkOmegaLambdaResilience
            simp only [Bool.and_eq_true]
            refine ⟨⟨⟨hsB, htB⟩, hsRank⟩, ?_⟩
            rw [hκ]
            exact ⟨decide_eq_true rfl, hunbChk⟩
        · next hne1 =>
          split at hbody
          · next hmode2 =>
            rcases (Bool.and_eq_true _ _).mp hbody with ⟨hpackAndUp, hcutSrc⟩
            rcases (Bool.and_eq_true _ _).mp hpackAndUp with ⟨hpackSrc, hupperSrc⟩
            rcases cert2_liftPackingList_sound ip b.G (mkGlobalStarLTS b.G s t)
                T.claimedL T.claimedU T.primalWitnesses
                (fun pw =>
                  if pw.refKind = 2 && checkValidWalk b.G .eStar s t pw.walkVertices then
                    some pw.walkVertices
                  else none)
                (fun pw => if pw.refKind = 2 then some (starWalkToLTS b.G pw.walkVertices) else none)
                hpackSrc
                (fun pw _ γ hres => by
                  split at hres
                  · next hcond =>
                    injection hres with hγEq
                    subst hγEq
                    simp only [Bool.and_eq_true, decide_eq_true_eq] at hcond
                    have hvw :=
                      (checkValidWalk_iff hb.wfGraph .eStar s t pw.walkVertices).mp hcond.2
                    exact ⟨starWalkToLTS b.G pw.walkVertices,
                           by simp [hcond.1],
                           (ref_glob_star_levelB hb.wfGraph hs ht).toLTS_valid pw.walkVertices hvw,
                           starWalkToLTS_supports b.G pw.walkVertices⟩
                  · cases hres) with
              ⟨packing, hliftPack, h1L, hLU, hlenP, hlowOk⟩
            have hclosedOk := cert3_global_star_cut_sound hb.wfGraph s t T.retractionIrIndices T.dualCutVids hcutSrc
            have hltsCertOk := checkLTSCert_finiteBounds_of_parts ip (mkGlobalStarLTS b.G s t)
              T.claimedL T.claimedU packing T.retractionIrIndices T.dualCutVids
              hLU hlenP hlowOk hupperSrc hclosedOk
            let cert := ResilienceCert.globalStar
              (.finiteBounds T.claimedL T.claimedU packing T.retractionIrIndices T.dualCutVids)
            refine ⟨cert, ?_, ?_⟩
            · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
              · unfold ClaimMatch; simp [hmode2, cert, certClaim, ltsCertClaim, h1L, hLU]
              · simp [liftSourceCert0x00, hκ, hmode2, hliftPack, cert]
            · dsimp only [cert]
              unfold checkOmegaLambdaResilience
              simp only [Bool.and_eq_true]
              refine ⟨⟨⟨hsB, htB⟩, hsRank⟩, ?_⟩
              rw [hκ]
              exact ⟨decide_eq_true rfl, hltsCertOk⟩
          · cases hbody
      | ePlus =>
        rw [hκ] at hbody
        dsimp only at hbody
        split at hbody
        · next hmode1 =>
          simp only [Bool.and_eq_true] at hbody
          rcases hbody with ⟨⟨⟨⟨hL0B, hU0B⟩, _⟩, hvwB⟩, hconstW⟩
          have hL0 : T.claimedL = 0 := of_decide_eq_true hL0B
          have hU0 : T.claimedU = 0 := of_decide_eq_true hU0B
          have hvw : IsValidWalk b.G .ePlus s t T.unbreakableWalk :=
            (checkValidWalk_iff hb.wfGraph .ePlus s t T.unbreakableWalk).mp hvwB
          let τ := plusWalkToLTS b.G T.unbreakableWalk
          have hltsW := (ref_glob_plus_levelB hb.wfGraph hs ht).toLTS_valid T.unbreakableWalk hvw
          have hpos := valid_eplus_walk_pos_steps hvw
          have hunbChk : checkUnbreakableWalk ip (mkGlobalPlusLTS b.G s t) τ = true := by
            unfold checkUnbreakableWalk
            rw [Bool.and_eq_true]
            exact ⟨(checkLTSWalkFrom_iff _ _ _ τ).mpr hltsW,
                   supports_unbreakable_transfer ip (plusWalkToLTS_supports b.G hpos) hconstW⟩
          refine ⟨.globalPlus (.unbreakableWalk τ), ?_, ?_⟩
          · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
            · unfold ClaimMatch; simp [hmode1, hL0, hU0, certClaim, ltsCertClaim]
            · simp [liftSourceCert0x00, hκ, hmode1, τ]
          · unfold checkOmegaLambdaResilience
            simp only [Bool.and_eq_true]
            refine ⟨⟨⟨hsB, htB⟩, hsRank⟩, ?_⟩
            rw [hκ]
            exact ⟨decide_eq_true rfl, hunbChk⟩
        · next hne1 =>
          split at hbody
          · next hmode2 =>
            rcases (Bool.and_eq_true _ _).mp hbody with ⟨hpackAndUp, hcutSrc⟩
            rcases (Bool.and_eq_true _ _).mp hpackAndUp with ⟨hpackSrc, hupperSrc⟩
            rcases cert2_liftPackingList_sound ip b.G (mkGlobalPlusLTS b.G s t)
                T.claimedL T.claimedU T.primalWitnesses
                (fun pw =>
                  if pw.refKind = 2 && checkValidWalk b.G .ePlus s t pw.walkVertices then
                    some pw.walkVertices
                  else none)
                (fun pw => if pw.refKind = 2 then some (plusWalkToLTS b.G pw.walkVertices) else none)
                hpackSrc
                (fun pw _ γ hres => by
                  split at hres
                  · next hcond =>
                    injection hres with hγEq
                    subst hγEq
                    simp only [Bool.and_eq_true, decide_eq_true_eq] at hcond
                    have hvw :=
                      (checkValidWalk_iff hb.wfGraph .ePlus s t pw.walkVertices).mp hcond.2
                    have hpos := valid_eplus_walk_pos_steps hvw
                    exact ⟨plusWalkToLTS b.G pw.walkVertices,
                           by simp [hcond.1],
                           (ref_glob_plus_levelB hb.wfGraph hs ht).toLTS_valid pw.walkVertices hvw,
                           plusWalkToLTS_supports b.G hpos⟩
                  · cases hres) with
              ⟨packing, hliftPack, h1L, hLU, hlenP, hlowOk⟩
            have hclosedOk := cert3_global_plus_cut_sound hb.wfGraph s t T.retractionIrIndices T.dualCutVids hcutSrc
            have hltsCertOk := checkLTSCert_finiteBounds_of_parts ip (mkGlobalPlusLTS b.G s t)
              T.claimedL T.claimedU packing T.retractionIrIndices (liftGlobalPlusCut T.dualCutVids)
              hLU hlenP hlowOk hupperSrc hclosedOk
            let cert := ResilienceCert.globalPlus
              (.finiteBounds T.claimedL T.claimedU packing T.retractionIrIndices
                (liftGlobalPlusCut T.dualCutVids))
            refine ⟨cert, ?_, ?_⟩
            · refine ⟨htag.1, htag, ?_, ?_, hSrcCopy⟩
              · unfold ClaimMatch; simp [hmode2, cert, certClaim, ltsCertClaim, h1L, hLU]
              · simp [liftSourceCert0x00, hκ, hmode2, hliftPack, cert]
            · dsimp only [cert]
              unfold checkOmegaLambdaResilience
              simp only [Bool.and_eq_true]
              refine ⟨⟨⟨hsB, htB⟩, hsRank⟩, ?_⟩
              rw [hκ]
              exact ⟨decide_eq_true rfl, hltsCertOk⟩
          · cases hbody

/-- **`Cert-4` Master Composition Theorem (`89th Ruling §5`)**:
    `CertRefinement_{0x00}(T, A) ∧ LeanCheck(A) = true ⇒ SourceCertificateSoundness(T)`. -/
theorem cert4_refinement_0x00_composition_sound
    {ip : IssuerPartition} {b : BaseData} {s t : VertexId}
    {c : CarrierSpec} {T : SourceCertTerm} {cert : ResilienceCert}
    (hRef : CertRefinement0x00 ip b s t c T cert)
    (hBase : checkVerifiedBase ip b = true)
    (hCert : checkOmegaLambdaResilience ip b s t c cert = true) :
    SourceCertificateSoundness ip b s t c T := by
  rcases hRef with ⟨hev0, htag, hclaimMatch, _, _⟩
  rcases omegaLambda_resilience_sound ip b s t c cert hBase hCert with
    ⟨hsLt, htLt, hsRank, hsem⟩
  refine ⟨hev0, htag, hsLt, htLt, hsRank, ?_⟩
  unfold ClaimMatch at hclaimMatch
  by_cases hm1 : T.modeTag = 1
  · rw [if_pos hm1] at hclaimMatch ⊢
    rcases hclaimMatch with ⟨hclEq, hL0, hU0⟩
    rw [hclEq] at hsem
    exact ⟨hL0, hU0, hsem⟩
  · rw [if_neg hm1] at hclaimMatch ⊢
    by_cases hm2 : T.modeTag = 2
    · rw [if_pos hm2] at hclaimMatch ⊢
      rcases hclaimMatch with ⟨hclEq, h1L, hLU⟩
      rw [hclEq] at hsem
      exact ⟨h1L, hLU, hsem⟩
    · rw [if_neg hm2] at hclaimMatch ⊢
      exact hclaimMatch

/-- Direct Source-Checker Corollary (`Cert-0..4` end-to-end):
    `checkVerifiedBase = true ∧ checkSourceCert0x00 = true ⇒ SourceCertificateSoundness`. -/
theorem source_cert_0x00_checker_sound
    {ip : IssuerPartition} {b : BaseData} {s t : VertexId}
    {c : CarrierSpec} {T : SourceCertTerm}
    (hBase : checkVerifiedBase ip b = true)
    (hSrc : checkSourceCert0x00 ip b s t c T = true) :
    SourceCertificateSoundness ip b s t c T := by
  rcases liftSourceCert0x00_complete_sound hBase hSrc with ⟨cert, hRef, hCert⟩
  exact cert4_refinement_0x00_composition_sound hRef hBase hCert

/-- **Combined `Ωλ-R1 + Ωλ-R2 + Ωλ-M1` Bridge (`cert4_with_r1_source_string_sound`)**:
    Chains `A1` Anchor & `0xFF33` Sort Law (`#43` `Ωλ-R1`) + `checkSourceCert0x00` (`#44` `Ωλ-R2`)
    directly into pure string-keyed source snapshot resilience (`SourceStringSemanticResilience`). -/
theorem cert4_with_r1_source_string_sound
    (reg : List PinnedA1Entry) (snap : SourceSnapshot) (ent : PinnedA1Entry)
    (ip : IssuerPartition) (b : BaseData) (s t : VertexId)
    (c : CarrierSpec) (T : SourceCertTerm)
    (hAnchor : checkSourceAnchorAndSortLaw reg snap = true)
    (hLookup : lookupPinnedA1 snap.snapshotId reg = some ent)
    (hPart : ip = projectIssuerPartition snap ent.pinnedConstIds)
    (hGraph : b.G = projectIRGraph snap)
    (hBase : checkVerifiedBase ip b = true)
    (hSrc : checkSourceCert0x00 ip b s t c T = true) :
    T.evasionModeTag = 0 ∧
    TagContextMatch T b.kappa c ∧
    ((T.modeTag = 1 ∧ T.claimedL = 0 ∧ T.claimedU = 0 ∧
      SourceStringSemanticResilience reg snap b.kappa s t c .unbreakable) ∨
     (T.modeTag = 2 ∧ 1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU ∧
      SourceStringSemanticResilience reg snap b.kappa s t c
        (.finiteBounds T.claimedL T.claimedU))) := by
  rcases liftSourceCert0x00_complete_sound hBase hSrc with ⟨cert, hRef, hCert⟩
  have hstr :=
    source_ir_to_omegaLambda_resilience_sound reg snap ent ip b s t c cert
      hAnchor hLookup hPart hGraph hBase hCert
  rcases hRef with ⟨hev0, htag, hclaimMatch, _, _⟩
  refine ⟨hev0, htag, ?_⟩
  unfold ClaimMatch at hclaimMatch
  split at hclaimMatch
  · next hm1 =>
    rcases hclaimMatch with ⟨hclEq, hL0, hU0⟩
    rw [hclEq] at hstr
    exact Or.inl ⟨hm1, hL0, hU0, hstr⟩
  · split at hclaimMatch
    · next hm2 =>
      rcases hclaimMatch with ⟨hclEq, h1L, hLU⟩
      rw [hclEq] at hstr
      exact Or.inr ⟨hm2, h1L, hLU, hstr⟩
    · cases hclaimMatch

end OmegaLambda

/-
  CAMPUS-NOESIS Omega-Lambda W2: Kernel Axiom Audit (`#46`)
  Module: `OmegaLambda.W2AxiomAudit`

  Prints kernel axiom dependencies for all 23 required `W2-A..D` & `F93-01..03` theorems
  plus concrete `Ex-W2-1..2` / `Adv-W2-1..7` theorems.
-/

import OmegaLambda.PacketRefinement
import OmegaLambda.PacketRefinementExamples

-- W2-B: Restricted 66-Char ASCII Codec & Raw Snapshot Wire Bijection
#print axioms OmegaLambda.w2b_ascii_id_forward_roundtrip
#print axioms OmegaLambda.w2b_ascii_id_backward_roundtrip
#print axioms OmegaLambda.w2b_ascii_id_byte_lex_iff_string_lex
#print axioms OmegaLambda.w2b_encodeSnapshotSection_domain_iff
#print axioms OmegaLambda.w2b_noncanonical_snapshot_encode_none
#print axioms OmegaLambda.w2b_snapshot_forward_roundtrip
#print axioms OmegaLambda.w2b_snapshot_backward_roundtrip
#print axioms OmegaLambda.w2b_snapshot_ir_ids_nodup

-- W2-A: CNB-v1 Contiguous Partition & CNP-v2 (0x03 / 0x05) Outer Packet Bijection
#print axioms OmegaLambda.w2a_cnb1_contiguous_partition_exact
#print axioms OmegaLambda.w2a_cnb1_encode_domain_iff
#print axioms OmegaLambda.w2a_cnb1_forward_roundtrip
#print axioms OmegaLambda.w2a_cnb1_backward_roundtrip
#print axioms OmegaLambda.w2a_cnp2_packet_encode_domain_iff
#print axioms OmegaLambda.w2a_cnp2_packet_forward_roundtrip
#print axioms OmegaLambda.w2a_cnp2_packet_backward_roundtrip

-- W2-C: F92-01 Snapshot Projection, F93-02 (0x05 B1..B6), and F93-03 (0x03 4-Gate Non-Laundering)
#print axioms OmegaLambda.w2c_b1_b2_implies_r1_anchor_and_graph
#print axioms OmegaLambda.f93_02_b1_to_b6_implies_checkVerifiedBase
#print axioms OmegaLambda.f93_03_synthesizeVerifiedBase_sound
#print axioms OmegaLambda.f93_03_packet0x03_requires_original_wire_b1_b5

-- W2-D & F93-01: Two-Level A1 Registry Authority Separation & End-to-End Packet Soundness
#print axioms OmegaLambda.f93_01_arbitrary_reg_does_not_imply_trusted_a1
#print axioms OmegaLambda.w2d_packet_sound_relative_to_registry
#print axioms OmegaLambda.w2d_packet_sound_pinned_a1
#print axioms OmegaLambda.w2d_pinned_a1_snapshot_unique

-- Concrete Examples & Adversarial Rejections
#print axioms OmegaLambda.W2Examples.w2_ex1_snapshot_112bytes_roundtrip
#print axioms OmegaLambda.W2Examples.w2_ex1_pinned_a1_0x05_gate_ok
#print axioms OmegaLambda.W2Examples.w2_ex1_pinned_a1_0x05_sound
#print axioms OmegaLambda.W2Examples.w2_ex2_0x03_packet_gate_ok
#print axioms OmegaLambda.W2Examples.w2_ex2_0x03_packet_sound
#print axioms OmegaLambda.W2Examples.w2_adv1_f93_03_rank_laundering_rejected
#print axioms OmegaLambda.W2Examples.w2_adv4_cross_sort_duplicate_vertex_separated
#print axioms OmegaLambda.W2Examples.w2_adv5_unlicensed_reltag13_separated

/-
  CAMPUS-NOESIS Omega-Lambda W1: Kernel Evaluation & Adversarial Wire Slice Proofs (`#45`)
  Module: `OmegaLambda.WireRefinementExamples`

  Exercises `W-1A`..`W-1E` and mandatory guards `F91-02`..`F91-03` via pure kernel
  definitional reduction (`rfl`, zero `native_decide`):
    1. `Ex-W1-1`: End-to-end `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT` on
       `#43` `R1Examples.snapHyper` (`GlobalPlus` `carrierTag = 3`, asymmetric wire claim
       with `dualCutVids = []`, 68B+payload Carrier preimage, 37B+payload Snapshot preimage).
    2. `Ex-W1-2`: `LocalReflexive` 4-byte `[0]` wire encoding (`[0, 0, 0, 0]`) & `#41`
       `f82Packet = [[0], [0, 1, 0]]` 14-byte carrier slice roundtrip (`F82-01` preserved).
    3. `Ex-W1-3`: Asymmetric `Local` (`carrierTag = 1`, explicit trailing `0x00` `evasion_mode`
       byte) vs `Geodesic` (`carrierTag = 2`, `RawHopWireEntry` table + `dualCutVids`, zero
       trailing `evasion_mode` byte) bidirectional roundtrips.
    4. `Adv-W1-*`: Kernel-reduced (`= none := rfl` / `= false := rfl`) adversarial rejections:
       - `F91-03`: Unsorted `retractionIrIndices` rejected by `encodeClaimSlice0x00` (`= none`),
       - Trailing slack bytes on 70B `CarrierBindHeader` (`71` B) & `Global` claim rejected,
       - `0xFFFF` (`NONE_VID_SENTINEL`) vertex slot rejected (`= none`),
       - `evasion_mode = 0x01` (`HELD`) wire byte rejected (`= none`),
       - Unsorted local packet `[[0, 3], [0, 1, 2, 3]]` rejected by `decodeCarrierPayload` (`= none`).
-/

import OmegaLambda.WireRefinement
import OmegaLambda.CertRefinementExamples

namespace OmegaLambda.W1Examples

open OmegaLambda

/-! ## Synthetic Deterministic 32-Byte Test Digest Oracle for Kernel `rfl` Evaluation
    (`F91-02`: Real FIPS `SHA-256` execution binding is tested separately against `#40`!) -/

def toyHash256 (b : ByteArray) : ByteArray :=
  let bs := listOfBytes b
  let checksum : UInt8 := bs.foldl (fun (a : UInt8) x => a + x) (UInt8.ofNat bs.length)
  bytesOfList ((rangeBelow 32).map (fun k => checksum ^^^ UInt8.ofNat (k + 91)))

theorem toyHash256_size32 (b : ByteArray) : (toyHash256 b).size = 32 := by
  rw [byteArray_size_eq_length]
  unfold toyHash256
  dsimp only
  rw [listOfBytes_bytesOfList, List.length_map]
  decide

/-! ## Ex-W1-1: End-to-End `W-1E` Scoped Slice Refinement on `R1Examples.snapHyper` -/

def snapSliceHyperW1 : ByteArray :=
  bytesOfList [0x48, 0x59, 0x50, 0x45, 0x52, 0x01]

def hSigmaHyperW1 : ByteArray :=
  toyHash256 (mkSnapshotPreimageBytes 1 constitutionalMask0xFF33 snapSliceHyperW1)

def rootHexHyperW1 : String :=
  bytes32ToLowerHex hSigmaHyperW1

def snapHyperW1 : SourceSnapshot :=
  { R1Examples.snapHyper with
    claimedRootHex := rootHexHyperW1
    computedRootHex := rootHexHyperW1 }

def entHyperW1 : PinnedA1Entry :=
  { R1Examples.entHyper with
    pinnedRootHex := rootHexHyperW1 }

def regHyperW1 : List PinnedA1Entry := [entHyperW1]

def rawGlobalCarrierHyperW1 : RawCarrierPayload :=
  .globalEdges [(0, 1), (0, 2), (1, 3), (2, 3)]

def bCarHyperW1 : ByteArray :=
  bytesOfList (encodeCarrierPayloadList rawGlobalCarrierHyperW1)

def hCarHyperW1 : ByteArray :=
  toyHash256 (mkCarrierPreimageBytes 3 hSigmaHyperW1 2 0 3 bCarHyperW1)

def bhHyperW1 : RawCarrierBindHeader :=
  { hSigma32 := hSigmaHyperW1
    hCarrier32 := hCarHyperW1
    closureTag := 2
    carrierTag := 3
    queryS := 0
    queryT := 3 }

/-- Canonical wire normal form (`unbreakableRefKind = 2` per `#40` `omega_kappa_decoder.py` L868). -/
def srcCertHyperW1 : SourceCertTerm :=
  { R2Examples.srcCertHyperR2 with unbreakableRefKind := 2 }

def bClaimHyperW1 : ByteArray :=
  bytesOfList (encodeClaimPair0x00List (bhHyperW1, srcCertHyperW1))

theorem w1_ex1_carrier_roundtrip_exact :
    encodeCarrierPayload 4 rawGlobalCarrierHyperW1 = some bCarHyperW1 ∧
    decodeCarrierPayload 3 4 bCarHyperW1 = some rawGlobalCarrierHyperW1 :=
  ⟨rfl, rfl⟩

theorem w1_ex1_claim_roundtrip_exact :
    encodeClaimSlice0x00 4 3 bhHyperW1 srcCertHyperW1 = some bClaimHyperW1 ∧
    decodeClaimSlice0x00 4 3 bClaimHyperW1 = some (bhHyperW1, srcCertHyperW1) :=
  ⟨rfl, rfl⟩

theorem w1_ex1_scoped_slices_gate_ok :
    checkScopedCanonicalSlices0x00 toyHash256 regHyperW1 snapHyperW1 entHyperW1
      R1Examples.ipHyper R1Examples.baseHyper
      snapSliceHyperW1 bCarHyperW1 bClaimHyperW1 = true := by
  have hAnch : checkSourceAnchorAndSortLaw regHyperW1 snapHyperW1 = true := by
    unfold checkSourceAnchorAndSortLaw lookupPinnedA1
    have hEq1 : decide (snapHyperW1.computedRootHex = snapHyperW1.claimedRootHex) =
        decide (rootHexHyperW1 = rootHexHyperW1) := rfl
    rw [hEq1, decide_eq_true rfl]
    dsimp [regHyperW1]
    have hId : entHyperW1.snapshotId = snapHyperW1.snapshotId := rfl
    rw [if_pos hId]
    dsimp only
    have hEq2 : decide (snapHyperW1.claimedRootHex = entHyperW1.pinnedRootHex) =
        decide (rootHexHyperW1 = rootHexHyperW1) := rfl
    rw [hEq2, decide_eq_true rfl]
    rfl
  have hLk : decide (lookupPinnedA1 snapHyperW1.snapshotId regHyperW1 = some entHyperW1) = true := by
    apply decide_eq_true
    unfold lookupPinnedA1 regHyperW1
    dsimp only
    exact if_pos rfl
  have hPart : decide (R1Examples.ipHyper = projectIssuerPartition snapHyperW1 entHyperW1.pinnedConstIds) = true := rfl
  have hGr : decide (R1Examples.baseHyper.G = projectIRGraph snapHyperW1) = true := rfl
  have hBase : checkVerifiedBase R1Examples.ipHyper R1Examples.baseHyper = true := rfl
  have hDecClm : decodeClaimSlice0x00 snapHyperW1.vertexIds.length snapHyperW1.irRecords.length bClaimHyperW1 =
      some (bhHyperW1, srcCertHyperW1) := rfl
  have hDecCar : decodeCarrierPayload bhHyperW1.carrierTag snapHyperW1.vertexIds.length bCarHyperW1 =
      some rawGlobalCarrierHyperW1 := rfl
  have hProj : projectRawCarrierToSpec R1Examples.baseHyper rawGlobalCarrierHyperW1 = some .globalGraph := rfl
  have hDig : checkDigestVerifiedBool toyHash256 entHyperW1 snapHyperW1.generation snapSliceHyperW1 bCarHyperW1
      bhHyperW1 rawGlobalCarrierHyperW1 srcCertHyperW1 snapHyperW1.vertexIds.length = true := by
    unfold checkDigestVerifiedBool
    have hd1 : wfRawBindHeaderBool bhHyperW1 = true := rfl
    have hd2 : decide (bhHyperW1.hSigma32 = toyHash256 (mkSnapshotPreimageBytes snapHyperW1.generation constitutionalMask0xFF33 snapSliceHyperW1)) = true :=
      decide_eq_true rfl
    have hd3 : decide (bytes32ToLowerHex bhHyperW1.hSigma32 = entHyperW1.pinnedRootHex) =
        decide (rootHexHyperW1 = rootHexHyperW1) := rfl
    have hd4 : decide (encodeCarrierPayload snapHyperW1.vertexIds.length rawGlobalCarrierHyperW1 = some bCarHyperW1) = true := rfl
    have hd5 : decide (bhHyperW1.hCarrier32 = toyHash256
      (mkCarrierPreimageBytes bhHyperW1.carrierTag bhHyperW1.hSigma32 bhHyperW1.closureTag bhHyperW1.queryS bhHyperW1.queryT bCarHyperW1)) = true :=
      decide_eq_true rfl
    rw [hd1, hd2, hd3, decide_eq_true rfl, hd4, hd5]
    rfl
  have hSrc : checkSourceCert0x00 R1Examples.ipHyper R1Examples.baseHyper bhHyperW1.queryS bhHyperW1.queryT
      .globalGraph srcCertHyperW1 = true := rfl
  unfold checkScopedCanonicalSlices0x00
  dsimp only
  rw [hAnch, hLk, hPart, hGr, hBase, hDecClm]
  dsimp only
  rw [hDecCar]
  dsimp only
  rw [hProj]
  dsimp only
  rw [hDig, hSrc]
  rfl

theorem w1_ex1_end_to_end_scoped_resilience_sound :
    ∃ (bh : RawCarrierBindHeader) (cRaw : RawCarrierPayload) (c : CarrierSpec) (T : SourceCertTerm),
      ScopedCanonicalSlicesRefinement toyHash256 entHyperW1 snapHyperW1
        snapSliceHyperW1 bCarHyperW1 bClaimHyperW1 bh cRaw T ∧
      projectRawCarrierToSpec R1Examples.baseHyper cRaw = some c ∧
      TagContextMatch T .ePlus c ∧
      ((T.modeTag = 1 ∧ T.claimedL = 0 ∧ T.claimedU = 0 ∧
        SourceStringSemanticResilience regHyperW1 snapHyperW1 .ePlus bh.queryS bh.queryT c .unbreakable) ∨
       (T.modeTag = 2 ∧ 1 ≤ T.claimedL ∧ T.claimedL ≤ T.claimedU ∧
        SourceStringSemanticResilience regHyperW1 snapHyperW1 .ePlus bh.queryS bh.queryT c
          (.finiteBounds T.claimedL T.claimedU))) :=
  w1e_scoped_canonical_slices_with_trusted_snapshot_sound
    toyHash256 regHyperW1 snapHyperW1 entHyperW1 R1Examples.ipHyper R1Examples.baseHyper
    snapSliceHyperW1 bCarHyperW1 bClaimHyperW1 w1_ex1_scoped_slices_gate_ok

/-! ## Ex-W1-2: `LocalReflexive` 4-Byte `[0]` & 14-Byte `f82Packet` Roundtrip (`F82-01`) -/

def rawF82CarrierW1 : RawCarrierPayload :=
  .localPaths f82Packet

def bCarF82W1 : ByteArray :=
  bytesOfList (encodeCarrierPayloadList rawF82CarrierW1)

theorem w1_ex2_reflexive_walk_4bytes_and_f82_14bytes :
    encodeWalkSlice 2 [0] = some (bytesOfList [0, 0, 0, 0]) ∧
    decodeWalkSlice 2 (bytesOfList [0, 0, 0, 0]) = some [0] ∧
    bCarF82W1.size = 14 ∧
    encodeCarrierPayload 2 rawF82CarrierW1 = some bCarF82W1 ∧
    decodeCarrierPayload 1 2 bCarF82W1 = some rawF82CarrierW1 :=
  ⟨rfl, rfl, rfl, rfl, rfl⟩

/-! ## Ex-W1-3: Asymmetric `Local` (`evasion_mode` Byte) vs `Geodesic` (`RawHopWireEntry`) -/

def pktSortedEx1 : List (List VertexId) :=
  [[0, 1, 2, 3], [0, 3]]

def z32W1 : ByteArray :=
  bytesOfList (List.replicate 32 0xAA)

def bhLocalEx1 : RawCarrierBindHeader :=
  { hSigma32 := z32W1
    hCarrier32 := z32W1
    closureTag := 2
    carrierTag := 1
    queryS := 0
    queryT := 3 }

def srcCertEx1W1 : SourceCertTerm :=
  { R2Examples.srcCertEx1 with unbreakableRefKind := 1 }

def bClaimLocalEx1 : ByteArray :=
  bytesOfList (encodeClaimPair0x00List (bhLocalEx1, srcCertEx1W1))

theorem w1_ex3_local_claim_roundtrip_with_trailing_zero_evasion_byte :
    encodeClaimSlice0x00 4 4 bhLocalEx1 srcCertEx1W1 = some bClaimLocalEx1 ∧
    decodeClaimSlice0x00 4 4 bClaimLocalEx1 = some (bhLocalEx1, srcCertEx1W1) :=
  ⟨rfl, rfl⟩

def rawGeoHopCarrierW1 : RawCarrierPayload :=
  .geodesicHops
    [ { sVid := 0, tVid := 0, rank := 2, hops := [1] },
      { sVid := 0, tVid := 1, rank := 1, hops := [1] },
      { sVid := 1, tVid := 0, rank := 1, hops := [0] },
      { sVid := 1, tVid := 1, rank := 2, hops := [0] } ]

def bCarGeoW1 : ByteArray :=
  bytesOfList (encodeCarrierPayloadList rawGeoHopCarrierW1)

def bhGeoRank1W1 : RawCarrierBindHeader :=
  { hSigma32 := z32W1
    hCarrier32 := z32W1
    closureTag := 2
    carrierTag := 2
    queryS := 0
    queryT := 1 }

def srcCertGeoRank1W1 : SourceCertTerm :=
  { R2Examples.srcCertGeoRank1 with unbreakableRefKind := 2 }

def bClaimGeoRank1W1 : ByteArray :=
  bytesOfList (encodeClaimPair0x00List (bhGeoRank1W1, srcCertGeoRank1W1))

theorem w1_ex3_geodesic_carrier_and_claim_roundtrip :
    encodeCarrierPayload 2 rawGeoHopCarrierW1 = some bCarGeoW1 ∧
    decodeCarrierPayload 2 2 bCarGeoW1 = some rawGeoHopCarrierW1 ∧
    projectRawCarrierToSpec R2Examples.baseF82Plus rawGeoHopCarrierW1 = some .geodesicBundle ∧
    encodeClaimSlice0x00 2 2 bhGeoRank1W1 srcCertGeoRank1W1 = some bClaimGeoRank1W1 ∧
    decodeClaimSlice0x00 2 2 bClaimGeoRank1W1 = some (bhGeoRank1W1, srcCertGeoRank1W1) :=
  ⟨rfl, rfl, rfl, rfl, rfl⟩

/-! ## Adversarial Wire Rejection Proofs (`F91-01..03`, `= none := rfl`) -/

/-- `F91-03`: Non-canonical `unbreakableRefKind = 0` (`R2Examples.srcCertEx1`) is rejected by
    `encodeClaimSlice0x00` (`= none`), preventing encoder/decoder domain mismatch! -/
theorem adv_w1_f91_03_unsorted_retraction_encode_none :
    encodeClaimSlice0x00 4 4 bhLocalEx1 R2Examples.srcCertEx1 = none ∧
    encodeClaimSlice0x00 4 4 bhLocalEx1
      { srcCertEx1W1 with retractionIrIndices := [3, 2] } = none :=
  ⟨rfl, rfl⟩

/-- `F91-03`: Non-canonical `Local` claim carrying non-empty `dualCutVids = [1]` is rejected (`= none`). -/
theorem adv_w1_f91_03_local_nonempty_dualcut_encode_none :
    encodeClaimSlice0x00 4 4 bhLocalEx1
      { srcCertEx1W1 with dualCutVids := [1] } = none := rfl

/-- Trailing slack byte on 70B `CarrierBindHeader` (`71` B) or `Global` claim is rejected (`= none`). -/
theorem adv_w1_trailing_slack_bytes_rejected :
    decodeBindHeader (byteConcat (bytesOfList (encodeBindHeaderList bhHyperW1)) (bytesOfList [0])) = none ∧
    decodeClaimSlice0x00 4 3 (byteConcat bClaimHyperW1 (bytesOfList [0])) = none :=
  ⟨rfl, rfl⟩

/-- `0xFFFF` (`NONE_VID_SENTINEL`) in a walk vertex slot is rejected (`= none`). -/
theorem adv_w1_sentinel_0xffff_vertex_rejected :
    decodeWalkSlice 70000 (bytesOfList [0, 0, 0xFF, 0xFF]) = none := rfl

/-- `evasion_mode = 0x01` (`HELD`) wire byte on `Local` claim is rejected (`= none`). -/
def bClaimLocalForgedEvasion0x01 : ByteArray :=
  bytesOfList (
    encodeBindHeaderList bhLocalEx1 ++
    packU8 2 ++
    packU16BE R2Examples.srcCertEx1.claimedL ++
    packU16BE R2Examples.srcCertEx1.claimedU ++
    encodeRepeat encodeLocalPrimalList R2Examples.srcCertEx1.primalWitnesses ++
    encodeRepeat packU16BE R2Examples.srcCertEx1.retractionIrIndices ++
    packU8 1)

theorem adv_w1_local_evasion_0x01_wire_rejected :
    decodeClaimSlice0x00 4 4 bClaimLocalForgedEvasion0x01 = none := rfl

/-- Non-sorted local packet `[[0, 3], [0, 1, 2, 3]]` wire bytes are rejected (`= none`,
    preventing silent normalization). -/
def bCarUnsortedLocal : ByteArray :=
  bytesOfList (packU16BE 2 ++ encodeWalkList [0, 3] ++ encodeWalkList [0, 1, 2, 3])

theorem adv_w1_unsorted_local_packet_bytes_rejected :
    decodeCarrierPayload 1 4 bCarUnsortedLocal = none := rfl

end OmegaLambda.W1Examples

/-
  CAMPUS-NOESIS Omega-Lambda R2: Compile-Time Kernel Axiom Audit
  Module: `OmegaLambda.R2AxiomAudit`

  Emits `#print axioms` at compile time for every flagship `Ωλ-R2` theorem in
  `CertRefinement` and `CertRefinementExamples` (`Cert-0`..`Cert-4` and mandatory
  guards `F89-01`..`F89-03`), verifying strict adherence to standard Lean 4
  foundation axioms (`propext`, `Quot.sound`, `Classical.choice`; `sorryAx = 0`,
  `ofReduceBool = 0`, `._native. = 0`, user `axiom = 0`).
-/

import OmegaLambda.CertRefinement
import OmegaLambda.CertRefinementExamples

#print axioms OmegaLambda.cert0_claimMatch_iff
#print axioms OmegaLambda.f89_01_unregistered_mode_rejected
#print axioms OmegaLambda.cert0_tagContextMatch_iff
#print axioms OmegaLambda.f89_01_invalid_context_tags_rejected
#print axioms OmegaLambda.f89_02_raw_projection_not_injective
#print axioms OmegaLambda.f89_02_canonical_immutable_step_spec
#print axioms OmegaLambda.checkSourceStepWitness_projects_sound
#print axioms OmegaLambda.cert3_local_reflexive_no_finite_cut
#print axioms OmegaLambda.mem_liftLocalPositiveCut_mid_iff
#print axioms OmegaLambda.cert3_local_positive_cut_sound
#print axioms OmegaLambda.cert3_global_star_cut_sound
#print axioms OmegaLambda.cert3_global_plus_cut_sound
#print axioms OmegaLambda.cert3_geodesic_cut_sound
#print axioms OmegaLambda.cert2_liftPackingList_sound
#print axioms OmegaLambda.liftSourceCert0x00_complete_sound
#print axioms OmegaLambda.cert4_refinement_0x00_composition_sound
#print axioms OmegaLambda.source_cert_0x00_checker_sound
#print axioms OmegaLambda.cert4_with_r1_source_string_sound
#print axioms OmegaLambda.R2Examples.r2_ex1_lifted_mid_cut_exact
#print axioms OmegaLambda.R2Examples.r2_ex1_source_cert_ok
#print axioms OmegaLambda.R2Examples.r2_ex1_sound
#print axioms OmegaLambda.R2Examples.r2_ex2_f82_reflexive_unbreakable_ok
#print axioms OmegaLambda.R2Examples.r2_ex2_f82_finite_cut_impossible
#print axioms OmegaLambda.R2Examples.r2_ex3_self_cycle_plus_cert_ok
#print axioms OmegaLambda.R2Examples.r2_ex4_geodesic_eplus_rank1_cert_ok
#print axioms OmegaLambda.R2Examples.r2_ex5_full_r1_r2_string_resilience_sound
#print axioms OmegaLambda.R2Examples.adv_r2_f89_01_unregistered_modes_rejected
#print axioms OmegaLambda.R2Examples.adv_r2_f89_01_evasion_0x01_held_rejected
#print axioms OmegaLambda.R2Examples.adv_r2_f89_01_bad_closure_and_carrier_tags_rejected
#print axioms OmegaLambda.R2Examples.adv_r2_f89_02_non_minimal_const_rejected
#print axioms OmegaLambda.R2Examples.adv_r2_f89_03_unclosed_dual_cut_rejected

/-
  CAMPUS-NOESIS Omega-Lambda W1: Root Aggregator Module (`#45`)
  Scope: `SCOPED_CANONICAL_SLICES_WITH_TRUSTED_SNAPSHOT_INPUT`
  Imports untouched `#41` `OmegaLambda`, untouched `#43` `OmegaLambdaR1`,
  untouched `#44` `OmegaLambdaR2`, and the `Ωλ-W1` Scoped Canonical Slice
  Refinement Track (`W-1A`..`W-1E` + `F91-01`..`F91-03`).
-/

import OmegaLambdaR2
import OmegaLambda.WireRefinement
import OmegaLambda.WireRefinementExamples
import OmegaLambda.W1AxiomAudit

/-
  CAMPUS-NOESIS Omega-Lambda R1: Root Aggregator Module
  Imports untouched `#41` `OmegaLambda` plus the `Ωλ-R1` Source-IR-to-Abstract
  Refinement Proof Track (`SourceIRRefinement`, `SourceIRRefinementExamples`, `R1AxiomAudit`).
-/

import OmegaLambda
import OmegaLambda.SourceIRRefinement
import OmegaLambda.SourceIRRefinementExamples
import OmegaLambda.R1AxiomAudit

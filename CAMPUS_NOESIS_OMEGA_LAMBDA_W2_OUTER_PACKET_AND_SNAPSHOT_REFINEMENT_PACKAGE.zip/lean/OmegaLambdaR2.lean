/-
  CAMPUS-NOESIS Omega-Lambda R2: Root Aggregator Module
  Imports untouched `#41` `OmegaLambda`, untouched `#43` `OmegaLambdaR1`, and the
  `Ωλ-R2` `CertRefinement` (`0x00` Packing Track, `Cert-0`..`Cert-4` + `F89-01`..`F89-03`).
-/

import OmegaLambdaR1
import OmegaLambda.CertRefinement
import OmegaLambda.CertRefinementExamples
import OmegaLambda.R2AxiomAudit
